# GL Match Calc v24 — All-Encompassing Hybrid Fast Move & Play Protect Hardened Edition

## What's Fixed in v24 (Verified Against `16337.jpg` Beedrill vs Thievul & `16335.jpg` Samsung Play Protect)

1. **Fixed Overlay Self-Occlusion Over the Top-Right HUD Pill (`16337.jpg` Root Cause #1)**:
   - In `16337.jpg`, the floating overlay sits at `y = 7.9%..24.5%` on the right side, directly covering the Opponent's 3 Red Pokéball icons (`y = 7.5%..10.5%`).
   - `v23` required `redPokeballDots >= 3` on **both** the left and right HUD pills (`checkBattlePillSide(left) && checkBattlePillSide(right)`), which caused `isBattleHudVisible` to drop to `false` (`⏸ Paused (Cutscene)`) during active combat whenever the overlay covered the right Pokéballs or when 1–2 Pokémon fainted.
   - `v24` masks out the overlay's own screen rectangle, checks `leftPillVisible || rightPillVisible` with single-Pokéball tolerance, and treats **Dual Floating HP Bar presence (`playerHpFillPx > 0 && opponentHpFillPx > 0`)** as direct proof of active combat even before the top HUD pills finish sliding in during `"3, 2, 1, GO!"`.

2. **All-Encompassing Position-Independent Floating HP Bar Scanner (Works Anywhere on Screen)**:
   - Removed `if (abs(hpBarY - refPlayerHpBarY) > 8) return false` and `if (zoomedWithoutHpDurationMs >= 1500L) refPlayerHpFillPx = null`, which previously wiped out fast move HP drops whenever a Pokémon lunged, flinched, hovered, or had its HP bar briefly obscured.
   - Added **Top/Bottom Horizontal Box-Border Luminance Verification** (`hasHorizontalBoxBorder`), **Vertical Strip Thickness Guards**, **2-row/3-row half-res consistency**, and **Pokémon GO HP Stage Fill Bounds** (`Green >= 44%`, `Yellow 15..58%`, `Red <= 26%`), preventing false matches on red-orange Pokémon fur (Thievul) or autumn trees.

3. **Full 450ms Drain-Settling Window + Opening 100% Lead Anchor + Cumulative Segment Reconciliation**:
   - Anchors the lead Pokémon at battle start to `100%` full bar width (`barLen`) so fast moves thrown during the `"3, 2, 1, GO!"` zoom-out before the first frame locks in are immediately credited.
   - Follows the full `380–450ms` Pokémon GO orange damage-drain animation (`settleWindowMs`) so the tail end of Hit #1's drain never false-triggers Hit #2 early or swallows the next real hit.
   - Continuously reconciles the fast move count against **Cumulative Segment HP Loss (`(defenderSegmentStartHpPx - hpPx) / calibratedPxPerFastHit`)** bounded by the **Active Combat Turn Clock (`segmentActiveCombatMs / moveMs`)**, including during the `"Attack incoming! Use a Protect Shield?"` prompt (`16337.jpg`), guaranteeing `6/6` Poison Jabs (`42E`) on Beedrill.

4. **Samsung / Google Play Protect Red Warning Fix (`16335.jpg`)**:
   - Replaced `assembleDebug` (which injected `android:debuggable="true"` and signed with the flagged default `CN=Android Debug` certificate) with a custom 2048-bit RSA release-signed `assembleRelease` build (`isDebuggable = false`).
   - Removed `moveTaskToBack(true)` after `startForegroundService` and unchained `ACTION_MANAGE_OVERLAY_PERMISSION` from `createScreenCaptureIntent()` in `MainActivity.kt` (eliminating Play Protect's stalkerware heuristic triggers), and rotated `applicationId` to `com.gltrainer.matchcalc.v24`.
