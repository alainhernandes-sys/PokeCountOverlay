# PokéCount PvPoke Great League Overlay v4 (Native Android APK Project)

## What's New in v4
1. **Every Single Great League Pokémon on PvPoke Included**:
   - **265+ Built-in Great League Species & Regional Forms** compiled directly into `PvPokeRepository.kt` for instant offline detection.
   - **Live PvPoke `gamemaster.json` + `rankings-1500.json` Sync (`syncFullPvPokeGreatLeagueData`)**: On launch, the app also fetches and caches PvPoke's complete `gamemaster.json` and Great League rankings (`rankings-1500.json`), indexing **all 1,000+ Great League Pokémon on PvPoke** with their exact recommended Fast Move and Charged Moves!
2. **Exact PvPoke `Fast Move Count: X - Y - Z - W` Focus (Matches Your PvPoke Screenshot)**:
   - Under every Charged Move on the overlay, it displays the exact PvPoke **`Fast Move Count: 4 - 4 - 4 - 4`** (or `5 - 4 - 5 - 4`, `5 - 5 - 5 - 5`) sequence!
   - Shows a prominent **Fast Attack Counter** (`FAST: 0`, `1`, `2`, `3`, `4`, `5...`) that moves **UP** on every opponent fast attack and moves **DOWN** by the exact Charged Move's Fast Move Count (`-4`, `-5`, etc.) when the opponent uses a Charged Move!
