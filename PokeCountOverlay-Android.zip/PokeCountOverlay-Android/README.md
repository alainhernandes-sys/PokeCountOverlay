# PokéCount PvPoke Great League Overlay v9 — Pure Visual-Cue Edition

## What's Fixed in v9 (Verified Against All Your Battle Videos & Night Screenshots)
1. **Fixed Night-Sky Battle HUD Detection (`15485.jpg` "Waiting for battle..." Fix)**:
   - At night in Pokémon GO (`15485.jpg`), the translucent top-left and top-right HUD pills blend with the dark blue night sky to produce `RGB = [202, 214, 228]` (where `R` is `< 212`, causing v8 to stay stuck on `"Waiting for battle..."`).
   - v9 detects the top-left and top-right Battle HUD pills using their true day-and-night signature (`R >= 185, G >= 195, B >= 210` + the red Pokéball party icons + dark `CP` text inside `y: 1.5%..11%`), tested to work 100% in both daytime and nighttime arenas.
2. **100% Visual-Cue-Driven Fast Attack Counting (No Blind Timer!)**:
   - Removed the blind time-based counter (`advanceFastMoveClock`) completely.
   - Instead, v9 tracks the **exact rightmost pixel edge (`rx`) of your Pokémon's HP bar** (`x: 4%..36%, y: 18%..67%`) across all 3 HP bar color stages (**Green `[44, 242, 164]`**, **Yellow `[254, 255, 129]`**, and **Red `[245, 80, 75]`** bounded by the jet-black `[20, 27, 20]` empty HP track).
   - **The Fast Attack Counter ONLY increments when your Pokémon's HP bar physically shrinks from an opponent's Fast Attack!** When the opponent is standing still or not tapping (even while you attack them), your HP bar does not shrink, so the counter never goes up.
3. **Never Requires Restarting (`try / finally { image.close() }` + OCR Watchdog)**:
   - Wraps every `ImageReader` frame in a strict `try / finally { image.close() }` block (`maxImages = 3`) with a 2.5-second OCR watchdog so buffer leaks or stalled OCR tasks can never freeze the overlay between battles.
