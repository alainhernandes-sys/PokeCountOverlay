# GL Match Calc v25 — Resolution-Scaled HP Bar, Post-Charged-Move & Battle-Start Lock Edition

## What's Fixed in v25 (Verified Against `1793153922113.jpeg` Mimikyu vs Klefki & `16337.jpg` Thievul vs Beedrill)

1. **Fixed 1080p/1440p HP Bar Thickness Self-Rejection (`1793153922113.jpeg` Mimikyu vs Klefki Root Cause)**:
   - On 1080p (`540x1113` half-res) and 1440p (`720x1544` half-res) Samsung screens, the player's green HP bar interior is **9 to 12 pixels tall** (`py = 701..709` at `540x1113`).
   - `v24`'s hardcoded `py - 5` / `py + 5` vertical thickness check landed *inside* the 9-pixel-tall HP bar on 8 of the 9 rows, leaving only 1 row (`py = 705`) and causing the 2-row consistency check (`prev1RowY == py - 1`) to fail on stationary frames (leaving `▼ Subtracted Foul Play` stuck at `2 FAST [20E]` while Mimikyu took 4 Astonishes from `147px` down to `116px`).
   - `v25` removes the self-rejecting `py ± 5` check, scales `hasHorizontalBoxBorder`'s vertical search distance `maxBorderDy = max(5, (height * 0.013f).toInt())` proportionally to capture height (passing all 9 rows at `540x1113` and all 12 rows at `720x1544`), and widens orange drain notch detection (`r >= 138`) to catch Mimikyu's `6px` mid-fade orange drain notch (`R = 143..167, G = 121..136, B = 37..57`).

2. **Fixed Missing Fast Moves After Opponent Uses a Charged Move**:
   - **Kept `chargedAttackDetectedDuringPause` Active Until Cutscene Ends**: Previously, reading `"Klefki used Foul Play!"` mid-cutscene cleared `chargedAttackDetectedDuringPause = false` 3 seconds *before* the cutscene ended, skipping the post-cutscene HP re-anchor when the Battle HUD returned.
   - **Pre-Cutscene Energy Snapshot (`energyAtCutsceneStart` + `postCutsceneFastEnergyEarned`)**: Snapshots opponent energy when the cutscene starts so that even if a Charged Move subtraction or banner reconciliation fires after combat resumes, it subtracts strictly from `energyAtCutsceneStart` and never wipes out new fast attacks thrown after the Charged Move.
   - **Post-Cutscene Turn-Clock Lead-In (`550ms`) & `preMovesCreditedAtAnchor`**: Credits fast attacks executed during the post-cutscene camera zoom-out and `"SUPER EFFECTIVE!"` banner even if the HP bar locks in after the first post-cutscene hit has already landed.

3. **Fixed Missing Fast Moves at the Beginning of a Battle**:
   - **Preserved Opening Segment on Lead OCR Lock-In (`!wasFirstOpponentLock`)**: Previously, when ML Kit OCR locked onto the lead opponent's name (`Klefki` or `Beedrill`) 1.0–2.0s into the match, `matchedPoke.id != currentPokemon.id` called `resetSegmentForNewOpponentOrSwitch()`, wiping out the opening `segmentActiveCombatMs` and `defenderSegmentStartHpPx` accumulated during `"3, 2, 1, GO!"`.
   - `v25` preserves the opening `100%` `barLen` anchor and active combat timer when locking onto the lead opponent and immediately runs `reconcileCumulativeSegmentFastMoves(forceAudit = true)`.
