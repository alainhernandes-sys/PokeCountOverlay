# PokéCount PvPoke Great League Overlay v6 — Visual Fast-Attack Detector

## What's New in v6
1. **Visual Fast-Attack Classifier (`FastMoveVisualClassifier.kt`)**:
   - Automatically identifies **which Fast Attack** the opponent's Pokémon is using by combining 3 visual signals from the live battle screen:
     1. **Elemental Particle Color Signature (`RGB / HSV` Delta Burst)** in the arena between the opponent and player (distinguishing e.g. `Shadow Claw`'s purple-violet slash vs `Water Gun`'s cyan stream vs `Powder Snow`'s icy white puff vs `Poison Sting`'s magenta needles vs `Mud Shot`'s brown mud blobs vs `Ember`'s orange flames vs `Peck`'s white-pink strike).
     2. **Observed Attack Lunge & HP-Bar Impact Cadence (`Δt`)**: Measures the exact millisecond interval between attack impacts (`0.5s` = 1-Turn, `1.0s` = 2-Turn, `1.5s` = 3-Turn, `2.0s` = 4-Turn, `2.5s` = 5-Turn) to distinguish moves of different speeds (e.g. `Fairy Wind` [2T] vs `Bullet Seed` [3T], `Dragon Breath` [1T] vs `Dragon Tail` [3T]).
     3. **Effectiveness Callout Cross-Check (`"SUPER EFFECTIVE!"` / `"NOT VERY EFFECTIVE..."`)**: Reads your Pokémon's name in the top-left corner (e.g., `Altaria`) and checks whether the opponent's fast attack triggers an effectiveness callout above your HP bar (e.g., `Combusken`'s Fire-type `Ember` triggers `"NOT VERY EFFECTIVE..."` against `Altaria`, whereas Flying-type `Peck` is neutral).
   - The moment the opponent's Fast Attack is visually identified, the overlay switches to that Fast Move and **immediately recalculates the Fast Move Counter timing and every Charged Move's `Fast Move Count: X - Y - Z - W` sequence**!
   - You can also tap the Fast Move name (`[Swap Fast]`) on the overlay header at any time to cycle candidate Fast Moves manually.
