package com.pokecount.overlay

import android.os.SystemClock
import kotlin.math.ceil
import kotlin.math.max

enum class BattleState {
    ACTIVE,
    PAUSED_CHARGED_MOVE,
    PAUSED_SWITCH_WINDOW
}

data class FastMoveProfile(
    val name: String = "Unknown",
    val energyGain: Int = 9,      // e.g., Thunder Shock = 9
    val durationTurns: Int = 2    // e.g., Thunder Shock = 2 turns (1000ms)
)

/**
 * Per-Pokémon persistent energy and move configuration stored across switches.
 */
data class SlotEngineState(
    val pokemonId: String,
    val energy: Int,
    val fastMoveCount: Int,
    val cycleIndex: Int,
    val fastMoveDurationTurns: Int,
    val fastMoveEnergyGain: Int,
    val fastMoveName: String
)

data class BattleSnapshot(
    val state: BattleState = BattleState.ACTIVE,
    val energy: Int = 0,
    val displayedFastMoveCount: Int = 0, // Derived strictly from current energy, NEVER cumulative!
    val totalLifetimeFastMoves: Int = 0,
    val activeFastMove: FastMoveProfile = FastMoveProfile(),
    val isLockedOut: Boolean = false,
    val pokemonId: String = "default",
    val fastMoveCount: Int = displayedFastMoveCount,
    val totalFastMovesInMatch: Int = totalLifetimeFastMoves,
    val cooldownTurnsRemaining: Int = 0,
    val fastMoveDurationTurns: Int = activeFastMove.durationTurns,
    val fastMoveEnergyGain: Int = activeFastMove.energyGain,
    val fastMoveName: String = activeFastMove.name,
    val cycleIndex: Int = 0,
    val elapsedActiveTurns: Long = 0L,
    val lastChargedMoveName: String? = null,
    val benchedSlots: Map<String, SlotEngineState> = emptyMap()
)

class PokemonBattleEngine(
    private val clockMs: () -> Long = { SystemClock.elapsedRealtime() }
) {
    companion object {
        const val TURN_MS = 500L
        const val TURN_DURATION_MS = 500L
        const val MIN_ENERGY = 0
        const val MAX_ENERGY = 100
        const val MIN_TURNS = 1
        const val MAX_TURNS = 5
        // 220ms frame-capture & 2-tick confirmation tolerance so back-to-back 2-turn moves
        // (e.g., Clodsire's Poison Sting / Mud Shot) are NEVER dropped when hit #1 took 2 ticks to confirm!
        const val JITTER_TOLERANCE_MS = 220L
        const val ONE_TURN_JITTER_TOLERANCE_MS = 180L
        // 1250ms post-Charged-Move settle lockout so ongoing Charged Move HP drain / ATTACK ROSE animations aren't counted as fast moves
        const val POST_MINIGAME_GRACE_MS = 80L
    }

    var currentPokemonId: String = "default"
        private set

    var state: BattleState = BattleState.ACTIVE
        private set

    var energy: Int = 0
        private set

    var totalLifetimeFastMoves: Int = 0
        private set

    var activeFastMove: FastMoveProfile = FastMoveProfile()
        private set

    var cycleIndex: Int = 0
        private set

    var elapsedActiveTurns: Long = 0L
        private set

    var lastChargedMoveName: String? = null
        private set

    var nextAllowedFastMoveTimeMs: Long = 0L
        private set

    var chargedMoveDeductedInCurrentMinigame: Boolean = false
        private set

    private var energyBeforeCutsceneDeduction: Int? = null
    private var cycleIndexBeforeCutsceneDeduction: Int? = null
    private var pokemonIdOfCutsceneDeduction: String? = null

    private val slotMemory = linkedMapOf<String, SlotEngineState>()

    val fastMoveDurationTurns: Int
        get() = activeFastMove.durationTurns

    val fastMoveEnergyGain: Int
        get() = activeFastMove.energyGain

    val fastMoveName: String
        get() = activeFastMove.name

    fun configureFastMove(profile: FastMoveProfile): BattleSnapshot {
        val safeTurns = profile.durationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        val safeEnergy = max(1, profile.energyGain)
        activeFastMove = profile.copy(durationTurns = safeTurns, energyGain = safeEnergy)
        saveCurrentSlot()
        return snapshot()
    }

    fun configureFastMove(
        durationTurns: Int,
        energyGain: Int,
        moveName: String = activeFastMove.name,
        preserveMoveCount: Boolean = true,
        nowMs: Long = clockMs()
    ): BattleSnapshot {
        val oldEquivalentMoves = if (activeFastMove.energyGain > 0) energy / activeFastMove.energyGain else 0
        val safeTurns = durationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        val safeEnergy = max(1, energyGain)
        activeFastMove = FastMoveProfile(
            name = moveName,
            energyGain = safeEnergy,
            durationTurns = safeTurns
        )
        if (preserveMoveCount && oldEquivalentMoves > 0) {
            energy = (oldEquivalentMoves * safeEnergy).coerceIn(MIN_ENERGY, MAX_ENERGY)
        }
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    /**
     * Advances the battle clock by one discrete 500 ms turn if and only if [state] is [BattleState.ACTIVE].
     */
    fun onTurnTick(nowMs: Long = clockMs()): BattleSnapshot {
        if (state == BattleState.ACTIVE) {
            elapsedActiveTurns++
        }
        return snapshot(nowMs)
    }

    /**
     * Called when FastMoveVisualClassifier / ScreenCaptureAnalyzer detects a fast attack.
     */
    fun onFastMoveSignal(nowMs: Long = clockMs()): BattleSnapshot {
        tryFastMoveSignal(allowDuringCutsceneIntro = false, count = 1, nowMs = nowMs)
        return snapshot(nowMs)
    }

    /**
     * Turn-Cadence Auto-Ticker safety net: if [state] is [BattleState.ACTIVE] and [nowMs] has reached
     * [nextAllowedFastMoveTimeMs], automatically executes [tryFastMoveSignal] and returns true.
     */
    fun checkTurnCadenceAutoTick(nowMs: Long = clockMs(), lastAcceptedFastMoveMs: Long = 0L): Boolean {
        val minRequiredElapsedMs = activeFastMove.durationTurns * TURN_MS + 60L
        val elapsedOk = lastAcceptedFastMoveMs == 0L || (nowMs - lastAcceptedFastMoveMs) >= minRequiredElapsedMs
        if (state == BattleState.ACTIVE && nowMs >= nextAllowedFastMoveTimeMs && elapsedOk) {
            val (accepted, _) = tryFastMoveSignal(
                allowDuringCutsceneIntro = false,
                count = 1,
                nowMs = nowMs,
                effectiveHitTimeMs = nowMs
            )
            return accepted
        }
        return false
    }

    /**
     * Attempts to register [count] fast move(s) and returns `(accepted, snapshot)`.
     */
    fun tryFastMoveSignal(
        allowDuringCutsceneIntro: Boolean = false,
        count: Int = 1,
        nowMs: Long = clockMs(),
        effectiveHitTimeMs: Long = nowMs
    ): Pair<Boolean, BattleSnapshot> {
        val canExecuteInCurrentState =
            state == BattleState.ACTIVE || (allowDuringCutsceneIntro && state == BattleState.PAUSED_CHARGED_MOVE)
        if (!canExecuteInCurrentState) return false to snapshot(nowMs)
        if (!allowDuringCutsceneIntro && nowMs < nextAllowedFastMoveTimeMs && effectiveHitTimeMs < nextAllowedFastMoveTimeMs) {
            return false to snapshot(nowMs)
        }

        val safeCount = count.coerceIn(1, 8)
        energy = (energy + safeCount * activeFastMove.energyGain).coerceIn(MIN_ENERGY, MAX_ENERGY)
        totalLifetimeFastMoves += safeCount

        val moveDurationMs = activeFastMove.durationTurns * TURN_MS
        val jitterMs = when (activeFastMove.durationTurns) {
            1 -> 150L
            2 -> 170L
            else -> 130L
        }
        val minLockMs = if (activeFastMove.durationTurns == 1) 320L else 380L
        val anchorMs = effectiveHitTimeMs.coerceAtMost(nowMs)
        nextAllowedFastMoveTimeMs = anchorMs + max(minLockMs, moveDurationMs - jitterMs)

        saveCurrentSlot()
        return true to snapshot(nowMs)
    }

    /**
     * Called when "Attack incoming! Use a Protect Shield?" or charged move text is detected.
     */
    fun onChargedMoveSignal(energyCost: Int, nowMs: Long = clockMs()): BattleSnapshot {
        return onChargedMoveSignal(
            cost = energyCost,
            moveName = null,
            pauseClock = true,
            forceManualTap = false,
            nowMs = nowMs
        )
    }

    fun onChargedMoveSignal(
        cost: Int,
        moveName: String? = null,
        pauseClock: Boolean = true,
        forceManualTap: Boolean = false,
        nowMs: Long = clockMs()
    ): BattleSnapshot {
        val safeCost = cost.coerceAtLeast(0)
        if ((forceManualTap || !chargedMoveDeductedInCurrentMinigame) && safeCost > 0) {
            if (!forceManualTap) {
                energyBeforeCutsceneDeduction = energy
                cycleIndexBeforeCutsceneDeduction = cycleIndex
                pokemonIdOfCutsceneDeduction = currentPokemonId
            }
            energy = (energy - safeCost).coerceIn(MIN_ENERGY, MAX_ENERGY)
            chargedMoveDeductedInCurrentMinigame = !forceManualTap
            cycleIndex = (cycleIndex + 1) % 4
            lastChargedMoveName = moveName
        }
        if (pauseClock) {
            state = BattleState.PAUSED_CHARGED_MOVE
        } else if (!forceManualTap) {
            nextAllowedFastMoveTimeMs = max(nextAllowedFastMoveTimeMs, nowMs + POST_MINIGAME_GRACE_MS)
        }
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    /**
     * Reconciles energy when post-cutscene banner OCR identifies a specific Charged Move whose cost
     * differs from the initial cutscene estimate.
     */
    fun reconcileChargedMoveCost(
        previousCost: Int,
        actualCost: Int,
        actualMoveName: String,
        nowMs: Long = clockMs()
    ): BattleSnapshot {
        val baseEnergy = if (
            energyBeforeCutsceneDeduction != null &&
            pokemonIdOfCutsceneDeduction == currentPokemonId
        ) {
            energyBeforeCutsceneDeduction!!
        } else {
            energy + previousCost.coerceAtLeast(0)
        }
        energy = (baseEnergy - actualCost.coerceAtLeast(0)).coerceIn(MIN_ENERGY, MAX_ENERGY)
        lastChargedMoveName = actualMoveName
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    /**
     * Restores deducted energy ONLY if a Charged Move was actually deducted during the current cutscene
     * on the current Pokémon and the cutscene was determined to be the player's own Charged Move.
     */
    fun undoChargedMove(cost: Int, nowMs: Long = clockMs()): BattleSnapshot {
        if (
            chargedMoveDeductedInCurrentMinigame &&
            energyBeforeCutsceneDeduction != null &&
            pokemonIdOfCutsceneDeduction == currentPokemonId
        ) {
            energy = energyBeforeCutsceneDeduction!!.coerceIn(MIN_ENERGY, MAX_ENERGY)
            cycleIndex = cycleIndexBeforeCutsceneDeduction ?: cycleIndex
            lastChargedMoveName = null
        }
        chargedMoveDeductedInCurrentMinigame = false
        energyBeforeCutsceneDeduction = null
        cycleIndexBeforeCutsceneDeduction = null
        pokemonIdOfCutsceneDeduction = null
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    fun onMinigameStart(nowMs: Long = clockMs()): BattleSnapshot {
        if (state != BattleState.PAUSED_CHARGED_MOVE) {
            chargedMoveDeductedInCurrentMinigame = false
            energyBeforeCutsceneDeduction = null
            cycleIndexBeforeCutsceneDeduction = null
            pokemonIdOfCutsceneDeduction = null
        }
        state = BattleState.PAUSED_CHARGED_MOVE
        return snapshot(nowMs)
    }

    fun onMinigameEnd(nowMs: Long = clockMs()): BattleSnapshot {
        if (state != BattleState.ACTIVE) {
            state = BattleState.ACTIVE
            chargedMoveDeductedInCurrentMinigame = false
            nextAllowedFastMoveTimeMs = nowMs + POST_MINIGAME_GRACE_MS
        }
        return snapshot(nowMs)
    }

    fun onMinigameEnd(clearCutsceneSnapshot: Boolean = false, nowMs: Long = clockMs()): BattleSnapshot {
        if (clearCutsceneSnapshot) {
            energyBeforeCutsceneDeduction = null
            cycleIndexBeforeCutsceneDeduction = null
            pokemonIdOfCutsceneDeduction = null
        }
        if (state != BattleState.ACTIVE) {
            state = BattleState.ACTIVE
            chargedMoveDeductedInCurrentMinigame = false
            nextAllowedFastMoveTimeMs = nowMs + POST_MINIGAME_GRACE_MS
        }
        return snapshot(nowMs)
    }

    fun clearCutsceneEnergySnapshot(nowMs: Long = clockMs()): BattleSnapshot {
        chargedMoveDeductedInCurrentMinigame = false
        energyBeforeCutsceneDeduction = null
        cycleIndexBeforeCutsceneDeduction = null
        pokemonIdOfCutsceneDeduction = null
        return snapshot(nowMs)
    }

    fun onSwitch(newProfile: FastMoveProfile? = null, nowMs: Long = clockMs()): BattleSnapshot {
        if (newProfile != null) {
            configureFastMove(newProfile)
        }
        energy = 0
        totalLifetimeFastMoves = 0
        chargedMoveDeductedInCurrentMinigame = false
        energyBeforeCutsceneDeduction = null
        cycleIndexBeforeCutsceneDeduction = null
        pokemonIdOfCutsceneDeduction = null
        state = BattleState.ACTIVE
        nextAllowedFastMoveTimeMs = nowMs
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    fun onSwitch(
        newPokemonId: String,
        durationTurns: Int,
        energyGain: Int,
        moveName: String,
        transferOpeningEnergy: Boolean = false,
        pauseForSwitchWindow: Boolean = false,
        nowMs: Long = clockMs()
    ): BattleSnapshot {
        val oldPokemonId = currentPokemonId
        val oldCount = if (activeFastMove.energyGain > 0) energy / activeFastMove.energyGain else 0
        val oldCycle = cycleIndex
        saveCurrentSlot()

        val safeTurns = durationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        val safeEnergy = max(1, energyGain)

        currentPokemonId = newPokemonId
        activeFastMove = FastMoveProfile(
            name = moveName,
            energyGain = safeEnergy,
            durationTurns = safeTurns
        )
        chargedMoveDeductedInCurrentMinigame = false
        energyBeforeCutsceneDeduction = null
        cycleIndexBeforeCutsceneDeduction = null
        pokemonIdOfCutsceneDeduction = null

        val existingSlot = slotMemory[newPokemonId]
        if (transferOpeningEnergy && oldCount > 0 && (existingSlot == null || existingSlot.energy == 0)) {
            slotMemory.remove(oldPokemonId)
            energy = (oldCount * safeEnergy).coerceIn(MIN_ENERGY, MAX_ENERGY)
            cycleIndex = oldCycle
        } else if (existingSlot != null) {
            energy = existingSlot.energy.coerceIn(MIN_ENERGY, MAX_ENERGY)
            cycleIndex = existingSlot.cycleIndex
        } else {
            energy = 0
            cycleIndex = 0
        }

        state = if (pauseForSwitchWindow) {
            BattleState.PAUSED_SWITCH_WINDOW
        } else {
            BattleState.ACTIVE
        }
        nextAllowedFastMoveTimeMs = nowMs
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    fun resumeFromSwitchWindow(nowMs: Long = clockMs()): BattleSnapshot {
        state = BattleState.ACTIVE
        nextAllowedFastMoveTimeMs = nowMs
        return snapshot(nowMs)
    }

    fun adjustFastMovesManually(deltaMoves: Int, nowMs: Long = clockMs()): BattleSnapshot {
        val safeGain = max(1, activeFastMove.energyGain)
        energy = (energy + deltaMoves * safeGain).coerceIn(MIN_ENERGY, MAX_ENERGY)
        totalLifetimeFastMoves = (totalLifetimeFastMoves + deltaMoves).coerceAtLeast(0)
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    fun resetMatch(
        initialPokemonId: String = currentPokemonId,
        durationTurns: Int = activeFastMove.durationTurns,
        energyGain: Int = activeFastMove.energyGain,
        moveName: String = activeFastMove.name,
        nowMs: Long = clockMs()
    ): BattleSnapshot {
        slotMemory.clear()
        currentPokemonId = initialPokemonId
        activeFastMove = FastMoveProfile(
            name = moveName,
            energyGain = max(1, energyGain),
            durationTurns = durationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        )
        state = BattleState.ACTIVE
        energy = 0
        totalLifetimeFastMoves = 0
        cycleIndex = 0
        elapsedActiveTurns = 0L
        lastChargedMoveName = null
        nextAllowedFastMoveTimeMs = 0L
        chargedMoveDeductedInCurrentMinigame = false
        energyBeforeCutsceneDeduction = null
        cycleIndexBeforeCutsceneDeduction = null
        pokemonIdOfCutsceneDeduction = null
        saveCurrentSlot()
        return snapshot(nowMs)
    }

    private fun saveCurrentSlot() {
        val equivalentMoves = if (activeFastMove.energyGain > 0) energy / activeFastMove.energyGain else 0
        slotMemory[currentPokemonId] = SlotEngineState(
            pokemonId = currentPokemonId,
            energy = energy,
            fastMoveCount = equivalentMoves,
            cycleIndex = cycleIndex,
            fastMoveDurationTurns = activeFastMove.durationTurns,
            fastMoveEnergyGain = activeFastMove.energyGain,
            fastMoveName = activeFastMove.name
        )
    }

    fun snapshot(nowMs: Long = clockMs()): BattleSnapshot {
        val equivalentMoves = if (activeFastMove.energyGain > 0) {
            energy / activeFastMove.energyGain
        } else {
            0
        }

        val remainingLockMs = (nextAllowedFastMoveTimeMs - nowMs).coerceAtLeast(0L)
        val remainingTurns = if (remainingLockMs > 0L) {
            ceil(remainingLockMs.toDouble() / TURN_MS.toDouble()).toInt().coerceAtLeast(1)
        } else {
            0
        }
        val lockedOut = (state != BattleState.ACTIVE) || (nowMs < nextAllowedFastMoveTimeMs)

        return BattleSnapshot(
            state = state,
            energy = energy,
            displayedFastMoveCount = equivalentMoves,
            totalLifetimeFastMoves = totalLifetimeFastMoves,
            activeFastMove = activeFastMove,
            isLockedOut = lockedOut,
            pokemonId = currentPokemonId,
            fastMoveCount = equivalentMoves,
            totalFastMovesInMatch = totalLifetimeFastMoves,
            cooldownTurnsRemaining = remainingTurns,
            fastMoveDurationTurns = activeFastMove.durationTurns,
            fastMoveEnergyGain = activeFastMove.energyGain,
            fastMoveName = activeFastMove.name,
            cycleIndex = cycleIndex,
            elapsedActiveTurns = elapsedActiveTurns,
            lastChargedMoveName = lastChargedMoveName,
            benchedSlots = slotMemory.toMap()
        )
    }
}
