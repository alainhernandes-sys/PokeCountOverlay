package com.pokecount.overlay

import kotlin.math.max

/**
 * Explicit battle states for the deterministic 500 ms turn engine.
 */
enum class BattleState {
    ACTIVE,
    PAUSED_CHARGED_MOVE,
    PAUSED_SWITCH_WINDOW
}

/**
 * Per-Pokémon persistent energy and move configuration stored across switches.
 */
data class SlotEngineState(
    val pokemonId: String,
    val energy: Int,
    val fastMoveCount: Int,
    val cycleIndex: Int,
    val fastMoveDurationTurns: Int,
    val fastMoveEnergyGain: Int,
    val fastMoveName: String
)

/**
 * Immutable snapshot emitted by [PokemonBattleEngine] and [BattleSessionManager].
 */
data class BattleSnapshot(
    val pokemonId: String = "default",
    val state: BattleState = BattleState.ACTIVE,
    val energy: Int = 0,
    val fastMoveCount: Int = 0,
    val totalFastMovesInMatch: Int = 0,
    val cooldownTurnsRemaining: Int = 0,
    val fastMoveDurationTurns: Int = 2,
    val fastMoveEnergyGain: Int = 7,
    val fastMoveName: String = "Fast Move",
    val cycleIndex: Int = 0,
    val elapsedActiveTurns: Long = 0L,
    val lastChargedMoveName: String? = null,
    val benchedSlots: Map<String, SlotEngineState> = emptyMap()
)

/**
 * Headless, deterministic Pokémon GO PvP turn engine (pure Kotlin; zero Android UI or OCR imports).
 *
 * - Turns are strictly modeled as discrete 500 ms units ([TURN_DURATION_MS]).
 * - Fast moves enforce a cooldown lockout equal to their turn duration (clamped 1..5 turns).
 *   When [onFastMoveSignal] is called while `cooldownTurnsRemaining == 0` and `state == ACTIVE`,
 *   the move executes immediately and sets `cooldownTurnsRemaining = fastMoveDurationTurns`.
 *   Any duplicate fast-move signals arriving while `cooldownTurnsRemaining > 0` are discarded.
 * - Energy is strictly clamped between 0 and 100 (`coerceIn(0, 100)`).
 * - Supports `ACTIVE`, `PAUSED_CHARGED_MOVE`, and `PAUSED_SWITCH_WINDOW`.
 * - Charged moves ([onChargedMoveSignal]) deduct energy, clear any residual fast-move cooldowns,
 *   and pause the turn clock (`PAUSED_CHARGED_MOVE`) until resolved.
 */
class PokemonBattleEngine {

    var currentPokemonId: String = "default"
        private set

    var state: BattleState = BattleState.ACTIVE
        private set

    var energy: Int = 0
        private set

    var fastMoveCount: Int = 0
        private set

    var totalFastMovesInMatch: Int = 0
        private set

    var cooldownTurnsRemaining: Int = 0
        private set

    var fastMoveDurationTurns: Int = 2
        private set

    var fastMoveEnergyGain: Int = 7
        private set

    var fastMoveName: String = "Fast Move"
        private set

    var cycleIndex: Int = 0
        private set

    var elapsedActiveTurns: Long = 0L
        private set

    var lastChargedMoveName: String? = null
        private set

    private val slotMemory = linkedMapOf<String, SlotEngineState>()
    private var preCutsceneEnergySnapshot: Int = -1
    private var postCutsceneFastEnergyEarned: Int = 0

    /**
     * Advances the battle clock by one discrete 500 ms turn if and only if [state] is [BattleState.ACTIVE].
     */
    fun onTurnTick(): BattleSnapshot {
        if (state != BattleState.ACTIVE) {
            return snapshot()
        }
        elapsedActiveTurns++
        if (cooldownTurnsRemaining > 0) {
            cooldownTurnsRemaining = (cooldownTurnsRemaining - 1).coerceAtLeast(0)
        }
        return snapshot()
    }

    /**
     * Processes a fast-move detection signal.
     *
     * Executes immediately if and only if [state] is [BattleState.ACTIVE] and [cooldownTurnsRemaining] == 0,
     * locking out subsequent signals for [fastMoveDurationTurns] turns (clamped 1..5).
     *
     * @return `true` if the fast move was registered, or `false` if discarded due to cooldown/pause state.
     */
    fun onFastMoveSignal(): Boolean {
        if (state != BattleState.ACTIVE || cooldownTurnsRemaining > 0) {
            return false
        }
        val clampedDuration = fastMoveDurationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        val clampedGain = fastMoveEnergyGain.coerceAtLeast(1)

        energy = (energy + clampedGain).coerceIn(MIN_ENERGY, MAX_ENERGY)
        fastMoveCount = energy / max(1, clampedGain)
        totalFastMovesInMatch++
        if (preCutsceneEnergySnapshot >= 0) {
            postCutsceneFastEnergyEarned += clampedGain
        }
        cooldownTurnsRemaining = clampedDuration
        saveCurrentSlot()
        return true
    }

    /**
     * Deducts charged-move energy, clears any residual fast-move cooldowns, advances the cycle index,
     * and pauses the turn clock in [BattleState.PAUSED_CHARGED_MOVE] until resolved (when [pauseClock] is true).
     */
    fun onChargedMoveSignal(
        cost: Int,
        moveName: String? = null,
        pauseClock: Boolean = true
    ): BattleSnapshot {
        val safeCost = cost.coerceAtLeast(0)
        energy = if (preCutsceneEnergySnapshot >= 0) {
            val baseResidual = (preCutsceneEnergySnapshot - safeCost).coerceIn(MIN_ENERGY, MAX_ENERGY)
            (baseResidual + postCutsceneFastEnergyEarned).coerceIn(MIN_ENERGY, MAX_ENERGY)
        } else {
            (energy - safeCost).coerceIn(MIN_ENERGY, MAX_ENERGY)
        }
        fastMoveCount = energy / max(1, fastMoveEnergyGain)
        cooldownTurnsRemaining = 0
        cycleIndex = (cycleIndex + 1) % 4
        lastChargedMoveName = moveName
        if (pauseClock) {
            state = BattleState.PAUSED_CHARGED_MOVE
        }
        saveCurrentSlot()
        return snapshot()
    }

    /**
     * Reconciles energy when post-cutscene banner OCR identifies a specific Charged Move whose cost
     * differs from the initial cutscene estimate.
     */
    fun reconcileChargedMoveCost(
        previousCost: Int,
        actualCost: Int,
        actualMoveName: String
    ): BattleSnapshot {
        energy = (energy + previousCost.coerceAtLeast(0) - actualCost.coerceAtLeast(0))
            .coerceIn(MIN_ENERGY, MAX_ENERGY)
        fastMoveCount = energy / max(1, fastMoveEnergyGain)
        cooldownTurnsRemaining = 0
        lastChargedMoveName = actualMoveName
        saveCurrentSlot()
        return snapshot()
    }

    /**
     * Restores deducted energy if a cutscene was determined to be the player's own Charged Move.
     */
    fun undoChargedMove(cost: Int): BattleSnapshot {
        energy = (energy + cost.coerceAtLeast(0)).coerceIn(MIN_ENERGY, MAX_ENERGY)
        fastMoveCount = energy / max(1, fastMoveEnergyGain)
        cooldownTurnsRemaining = 0
        cycleIndex = (cycleIndex + 3) % 4
        lastChargedMoveName = null
        saveCurrentSlot()
        return snapshot()
    }

    /**
     * Pauses the turn clock when a Charged Move minigame / cutscene starts and clears residual cooldowns.
     */
    fun onMinigameStart(): BattleSnapshot {
        if (preCutsceneEnergySnapshot < 0) {
            preCutsceneEnergySnapshot = energy
            postCutsceneFastEnergyEarned = 0
        }
        cooldownTurnsRemaining = 0
        state = BattleState.PAUSED_CHARGED_MOVE
        return snapshot()
    }

    /**
     * Resumes the turn clock to [BattleState.ACTIVE] when a Charged Move cutscene finishes.
     */
    fun onMinigameEnd(clearCutsceneSnapshot: Boolean = false): BattleSnapshot {
        cooldownTurnsRemaining = 0
        state = BattleState.ACTIVE
        if (clearCutsceneSnapshot) {
            preCutsceneEnergySnapshot = -1
            postCutsceneFastEnergyEarned = 0
        }
        return snapshot()
    }

    /**
     * Clears the temporary pre-cutscene energy snapshot after the post-cutscene banner window expires.
     */
    fun clearCutsceneEnergySnapshot(): BattleSnapshot {
        preCutsceneEnergySnapshot = -1
        postCutsceneFastEnergyEarned = 0
        return snapshot()
    }

    /**
     * Handles opponent Pokémon switches or regional form locks, preserving benched Pokémon energy
     * and clearing residual fast-move cooldowns.
     */
    fun onSwitch(
        newPokemonId: String,
        durationTurns: Int,
        energyGain: Int,
        moveName: String,
        transferOpeningEnergy: Boolean = false,
        pauseForSwitchWindow: Boolean = false
    ): BattleSnapshot {
        val oldPokemonId = currentPokemonId
        val oldCount = energy / max(1, fastMoveEnergyGain)
        val oldCycle = cycleIndex
        saveCurrentSlot()

        val clampedTurns = durationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        val clampedGain = energyGain.coerceAtLeast(1)

        currentPokemonId = newPokemonId
        fastMoveDurationTurns = clampedTurns
        fastMoveEnergyGain = clampedGain
        fastMoveName = moveName
        cooldownTurnsRemaining = 0
        preCutsceneEnergySnapshot = -1
        postCutsceneFastEnergyEarned = 0

        val existingSlot = slotMemory[newPokemonId]
        if (transferOpeningEnergy && oldCount > 0 && (existingSlot == null || existingSlot.energy == 0)) {
            slotMemory.remove(oldPokemonId)
            energy = (oldCount * clampedGain).coerceIn(MIN_ENERGY, MAX_ENERGY)
            fastMoveCount = energy / max(1, clampedGain)
            cycleIndex = oldCycle
        } else if (existingSlot != null) {
            energy = existingSlot.energy.coerceIn(MIN_ENERGY, MAX_ENERGY)
            fastMoveCount = energy / max(1, clampedGain)
            cycleIndex = existingSlot.cycleIndex
        } else {
            energy = 0
            fastMoveCount = 0
            cycleIndex = 0
        }

        state = if (pauseForSwitchWindow) {
            BattleState.PAUSED_SWITCH_WINDOW
        } else {
            BattleState.ACTIVE
        }
        saveCurrentSlot()
        return snapshot()
    }

    /**
     * Resumes [BattleState.ACTIVE] from [BattleState.PAUSED_SWITCH_WINDOW].
     */
    fun resumeFromSwitchWindow(): BattleSnapshot {
        cooldownTurnsRemaining = 0
        state = BattleState.ACTIVE
        return snapshot()
    }

    /**
     * Configures the active fast move parameters (duration clamped 1..5 turns, energy gain >= 1).
     */
    fun configureFastMove(
        durationTurns: Int,
        energyGain: Int,
        moveName: String = fastMoveName,
        preserveMoveCount: Boolean = true
    ): BattleSnapshot {
        val oldCount = energy / max(1, fastMoveEnergyGain)
        val clampedTurns = durationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        val clampedGain = energyGain.coerceAtLeast(1)

        fastMoveDurationTurns = clampedTurns
        fastMoveEnergyGain = clampedGain
        fastMoveName = moveName

        if (preserveMoveCount && oldCount > 0) {
            energy = (oldCount * clampedGain).coerceIn(MIN_ENERGY, MAX_ENERGY)
        }
        fastMoveCount = energy / max(1, clampedGain)
        if (cooldownTurnsRemaining > clampedTurns) {
            cooldownTurnsRemaining = clampedTurns
        }
        saveCurrentSlot()
        return snapshot()
    }

    /**
     * Manual adjustment via the overlay `[+]` / `[−]` buttons.
     */
    fun adjustFastMovesManually(deltaMoves: Int): BattleSnapshot {
        val clampedGain = fastMoveEnergyGain.coerceAtLeast(1)
        energy = (energy + deltaMoves * clampedGain).coerceIn(MIN_ENERGY, MAX_ENERGY)
        fastMoveCount = energy / max(1, clampedGain)
        totalFastMovesInMatch = (totalFastMovesInMatch + deltaMoves).coerceAtLeast(0)
        saveCurrentSlot()
        return snapshot()
    }

    /**
     * Resets the entire battle engine for a new match.
     */
    fun resetMatch(
        initialPokemonId: String = currentPokemonId,
        durationTurns: Int = fastMoveDurationTurns,
        energyGain: Int = fastMoveEnergyGain,
        moveName: String = fastMoveName
    ): BattleSnapshot {
        slotMemory.clear()
        currentPokemonId = initialPokemonId
        fastMoveDurationTurns = durationTurns.coerceIn(MIN_TURNS, MAX_TURNS)
        fastMoveEnergyGain = energyGain.coerceAtLeast(1)
        fastMoveName = moveName
        state = BattleState.ACTIVE
        energy = 0
        fastMoveCount = 0
        totalFastMovesInMatch = 0
        cooldownTurnsRemaining = 0
        cycleIndex = 0
        elapsedActiveTurns = 0L
        lastChargedMoveName = null
        preCutsceneEnergySnapshot = -1
        postCutsceneFastEnergyEarned = 0
        saveCurrentSlot()
        return snapshot()
    }

    private fun saveCurrentSlot() {
        slotMemory[currentPokemonId] = SlotEngineState(
            pokemonId = currentPokemonId,
            energy = energy,
            fastMoveCount = fastMoveCount,
            cycleIndex = cycleIndex,
            fastMoveDurationTurns = fastMoveDurationTurns,
            fastMoveEnergyGain = fastMoveEnergyGain,
            fastMoveName = fastMoveName
        )
    }

    fun snapshot(): BattleSnapshot {
        return BattleSnapshot(
            pokemonId = currentPokemonId,
            state = state,
            energy = energy,
            fastMoveCount = fastMoveCount,
            totalFastMovesInMatch = totalFastMovesInMatch,
            cooldownTurnsRemaining = cooldownTurnsRemaining,
            fastMoveDurationTurns = fastMoveDurationTurns,
            fastMoveEnergyGain = fastMoveEnergyGain,
            fastMoveName = fastMoveName,
            cycleIndex = cycleIndex,
            elapsedActiveTurns = elapsedActiveTurns,
            lastChargedMoveName = lastChargedMoveName,
            benchedSlots = slotMemory.toMap()
        )
    }

    companion object {
        const val TURN_DURATION_MS = 500L
        const val MIN_TURNS = 1
        const val MAX_TURNS = 5
        const val MIN_ENERGY = 0
        const val MAX_ENERGY = 100
    }
}
