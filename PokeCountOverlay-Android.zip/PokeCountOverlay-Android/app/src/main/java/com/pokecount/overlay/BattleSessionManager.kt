package com.pokecount.overlay

import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Service-bound state manager that owns [PokemonBattleEngine], serializes all state mutations
 * with a [Mutex], emits state updates via [StateFlow], and drives the drift-compensated 500 ms
 * monotonic turn clock using [SystemClock.elapsedRealtime] ONLY while [BattleState.ACTIVE].
 */
class BattleSessionManager(
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {

    private val engine = PokemonBattleEngine()
    private val mutex = Mutex()

    private val _snapshotFlow = MutableStateFlow(engine.snapshot())
    val snapshotFlow: StateFlow<BattleSnapshot> = _snapshotFlow.asStateFlow()

    private var turnLoopJob: Job? = null

    @Volatile
    private var nextTickTargetRealtimeMs: Long = 0L

    @Volatile
    var lastAcceptedFastMoveRealtimeMs: Long = 0L
        private set

    init {
        startTurnClockIfNeeded()
    }

    /**
     * Dispatches a fast-move detection signal to [PokemonBattleEngine].
     * Executes when `cooldownTurnsRemaining == 0`; duplicate signals arriving while
     * `cooldownTurnsRemaining > 0` are deterministically discarded.
     */
    fun onFastMoveSignal(
        allowDuringCutsceneIntro: Boolean = false,
        onResult: ((Boolean, BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            var accepted = false
            val snap = mutex.withLock {
                val now = SystemClock.elapsedRealtime()
                val minTurnLockoutMs =
                    (engine.fastMoveDurationTurns * PokemonBattleEngine.TURN_DURATION_MS - 220L).coerceAtLeast(380L)

                // If on the final turn of cooldown and the turn boundary is imminent (within frame-capture jitter),
                // settle the final turn tick first so back-to-back fast moves are never dropped by 100ms poll jitter
                if (
                    engine.cooldownTurnsRemaining == 1 &&
                    ((nextTickTargetRealtimeMs > 0L && now + 110L >= nextTickTargetRealtimeMs) ||
                        (lastAcceptedFastMoveRealtimeMs > 0L && (now - lastAcceptedFastMoveRealtimeMs) >= minTurnLockoutMs))
                ) {
                    engine.onTurnTick()
                    nextTickTargetRealtimeMs = now + PokemonBattleEngine.TURN_DURATION_MS
                }

                accepted = engine.onFastMoveSignal(allowDuringCutsceneIntro = allowDuringCutsceneIntro)
                if (accepted) {
                    val execTime = SystemClock.elapsedRealtime()
                    lastAcceptedFastMoveRealtimeMs = execTime
                    nextTickTargetRealtimeMs = execTime + PokemonBattleEngine.TURN_DURATION_MS
                    if (engine.state == BattleState.ACTIVE) {
                        startTurnClockIfNeeded()
                    }
                }
                val updated = engine.snapshot()
                _snapshotFlow.value = updated
                updated
            }
            onResult?.invoke(accepted, snap)
        }
    }

    /**
     * Deducts Charged Move energy, clears residual fast-move cooldowns, and pauses the turn clock
     * (`PAUSED_CHARGED_MOVE`) when [pauseClock] is true.
     */
    fun onChargedMoveSignal(
        cost: Int,
        moveName: String? = null,
        pauseClock: Boolean = true,
        onUpdated: ((BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.onChargedMoveSignal(cost, moveName, pauseClock)
                _snapshotFlow.value = updated
                if (updated.state != BattleState.ACTIVE) {
                    stopTurnClockInternal()
                } else {
                    startTurnClockIfNeeded()
                }
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Reconciles Charged Move energy cost when post-cutscene banner OCR reads the exact move name.
     */
    fun reconcileChargedMoveCost(
        previousCost: Int,
        actualCost: Int,
        actualMoveName: String,
        onUpdated: ((BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.reconcileChargedMoveCost(previousCost, actualCost, actualMoveName)
                _snapshotFlow.value = updated
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Restores Charged Move energy if the cutscene was the player's own Charged Move.
     */
    fun undoChargedMove(cost: Int, onUpdated: ((BattleSnapshot) -> Unit)? = null) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.undoChargedMove(cost)
                _snapshotFlow.value = updated
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Pauses the turn clock (`PAUSED_CHARGED_MOVE`) and clears residual fast-move cooldowns.
     */
    fun onMinigameStart(onUpdated: ((BattleSnapshot) -> Unit)? = null) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.onMinigameStart()
                _snapshotFlow.value = updated
                stopTurnClockInternal()
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Resumes `ACTIVE` battle state after a Charged Move minigame / cutscene finishes and restarts
     * the drift-compensated 500 ms turn loop.
     */
    fun onMinigameEnd(
        clearCutsceneSnapshot: Boolean = false,
        onUpdated: ((BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.onMinigameEnd(clearCutsceneSnapshot)
                _snapshotFlow.value = updated
                nextTickTargetRealtimeMs = SystemClock.elapsedRealtime() + PokemonBattleEngine.TURN_DURATION_MS
                startTurnClockIfNeeded()
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Clears the temporary pre-cutscene energy snapshot once the post-cutscene banner window expires.
     */
    fun clearCutsceneEnergySnapshot() {
        scope.launch {
            mutex.withLock {
                _snapshotFlow.value = engine.clearCutsceneEnergySnapshot()
            }
        }
    }

    /**
     * Handles opponent switches or regional form locks, preserving bench energy and clearing residual cooldowns.
     */
    fun onSwitch(
        newPokemonId: String,
        durationTurns: Int = 2,
        energyGain: Int = 7,
        moveName: String = "Fast Move",
        transferOpeningEnergy: Boolean = false,
        pauseForSwitchWindow: Boolean = false,
        onUpdated: ((BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.onSwitch(
                    newPokemonId = newPokemonId,
                    durationTurns = durationTurns,
                    energyGain = energyGain,
                    moveName = moveName,
                    transferOpeningEnergy = transferOpeningEnergy,
                    pauseForSwitchWindow = pauseForSwitchWindow
                )
                _snapshotFlow.value = updated
                if (updated.state == BattleState.ACTIVE) {
                    nextTickTargetRealtimeMs = SystemClock.elapsedRealtime() + PokemonBattleEngine.TURN_DURATION_MS
                    startTurnClockIfNeeded()
                } else {
                    stopTurnClockInternal()
                }
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Resumes `ACTIVE` state from `PAUSED_SWITCH_WINDOW`.
     */
    fun resumeFromSwitchWindow(onUpdated: ((BattleSnapshot) -> Unit)? = null) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.resumeFromSwitchWindow()
                _snapshotFlow.value = updated
                nextTickTargetRealtimeMs = SystemClock.elapsedRealtime() + PokemonBattleEngine.TURN_DURATION_MS
                startTurnClockIfNeeded()
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Configures the opponent's active fast move duration (clamped 1..5 turns) and energy gain.
     */
    fun configureFastMove(
        durationTurns: Int,
        energyGain: Int,
        moveName: String = "",
        preserveMoveCount: Boolean = true,
        onUpdated: ((BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.configureFastMove(
                    durationTurns = durationTurns,
                    energyGain = energyGain,
                    moveName = moveName.ifBlank { engine.fastMoveName },
                    preserveMoveCount = preserveMoveCount
                )
                _snapshotFlow.value = updated
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Manual `[+]` / `[−]` button adjustment on the HUD.
     */
    fun adjustFastMovesManually(
        deltaMoves: Int,
        onUpdated: ((BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            val snap = mutex.withLock {
                val updated = engine.adjustFastMovesManually(deltaMoves)
                _snapshotFlow.value = updated
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Resets the engine for a brand-new battle.
     */
    fun resetMatch(
        initialPokemonId: String = engine.currentPokemonId,
        durationTurns: Int = engine.fastMoveDurationTurns,
        energyGain: Int = engine.fastMoveEnergyGain,
        moveName: String = engine.fastMoveName,
        onUpdated: ((BattleSnapshot) -> Unit)? = null
    ) {
        scope.launch {
            val snap = mutex.withLock {
                lastAcceptedFastMoveRealtimeMs = 0L
                val updated = engine.resetMatch(
                    initialPokemonId = initialPokemonId,
                    durationTurns = durationTurns,
                    energyGain = energyGain,
                    moveName = moveName
                )
                _snapshotFlow.value = updated
                nextTickTargetRealtimeMs = SystemClock.elapsedRealtime() + PokemonBattleEngine.TURN_DURATION_MS
                startTurnClockIfNeeded()
                updated
            }
            onUpdated?.invoke(snap)
        }
    }

    /**
     * Starts the drift-compensated 500 ms monotonic turn loop ONLY when `engine.state == ACTIVE`.
     */
    private fun startTurnClockIfNeeded() {
        if (turnLoopJob?.isActive == true) return
        if (nextTickTargetRealtimeMs <= 0L) {
            nextTickTargetRealtimeMs = SystemClock.elapsedRealtime() + PokemonBattleEngine.TURN_DURATION_MS
        }
        turnLoopJob = scope.launch {
            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                val target = nextTickTargetRealtimeMs
                val sleepMs = (target - now).coerceAtLeast(1L)
                delay(sleepMs)

                var keepRunning = true
                mutex.withLock {
                    if (engine.state == BattleState.ACTIVE) {
                        val tickTime = SystemClock.elapsedRealtime()
                        nextTickTargetRealtimeMs += PokemonBattleEngine.TURN_DURATION_MS
                        if (nextTickTargetRealtimeMs <= tickTime) {
                            nextTickTargetRealtimeMs = tickTime + PokemonBattleEngine.TURN_DURATION_MS
                        }
                        _snapshotFlow.value = engine.onTurnTick()
                    } else {
                        keepRunning = false
                    }
                }
                if (!keepRunning) break
            }
        }
    }

    private fun stopTurnClockInternal() {
        turnLoopJob?.cancel()
        turnLoopJob = null
    }

    fun shutdown() {
        stopTurnClockInternal()
        scope.cancel()
    }
}
