package com.pokecount.overlay

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Identifies which Fast Attack the opponent's Pokémon is using by combining:
 * 1. Strong PvPoke Meta-Prior (+28 baseline to index 0, e.g. Poison Jab on Nidoqueen, Bubble on Azumarill)
 *    so primary meta fast moves never flip to rare moves (like Bite or Rock Smash) on dark arena floors.
 * 2. Foreground Hit-Impact VFX on the Player's Pokémon (x: 8%..44%, y: 22%..66%) weighted on true hit frames.
 * 3. True Hit-Frame Inter-Attack Cadence (only measured on actual HP-drop hit frames, never idle motion).
 * 4. Left-Side Only Dual-Type Effectiveness Callout ("SUPER EFFECTIVE" / "NOT VERY EFFECTIVE").
 */
class FastMoveVisualClassifier {

    private var prevArenaPixels: IntArray? = null
    private var lastHitTimestampMs: Long = 0L
    private val observedHitIntervalsMs = mutableListOf<Long>()
    private val typeVotes = mutableMapOf<String, Int>()

    fun resetForNewOpponent() {
        prevArenaPixels = null
        lastHitTimestampMs = 0L
        observedHitIntervalsMs.clear()
        typeVotes.clear()
    }

    fun analyzeArenaFrame(
        arenaBmp: Bitmap,
        entry: PvPokeEntry,
        currentActiveIdx: Int,
        effectivenessHint: String?,
        playerDefenderTypes: List<String>,
        fastHitsLandedOnCurrentPlayer: Int = 0,
        isHitFrame: Boolean = false
    ): Int? {
        if (entry.fastMoves.size <= 1) return 0

        val w = arenaBmp.width
        val h = arenaBmp.height
        val total = w * h
        val currPixels = IntArray(total)
        arenaBmp.getPixels(currPixels, 0, w, 0, 0, w, h)

        val prev = prevArenaPixels
        prevArenaPixels = currPixels

        if (isHitFrame) {
            val now = System.currentTimeMillis()
            if (lastHitTimestampMs > 0L) {
                val dt = now - lastHitTimestampMs
                if (dt in 380L..2750L) {
                    observedHitIntervalsMs.add(dt)
                    if (observedHitIntervalsMs.size > 6) observedHitIntervalsMs.removeAt(0)
                }
            }
            lastHitTimestampMs = now

            if (prev != null && prev.size == total) {
                val frameTypeCounts = mutableMapOf<String, Int>()
                for (i in 0 until total) {
                    val c1 = currPixels[i]
                    val c0 = prev[i]

                    val r1 = (c1 shr 16) and 0xFF
                    val g1 = (c1 shr 8) and 0xFF
                    val b1 = c1 and 0xFF

                    val r0 = (c0 shr 16) and 0xFF
                    val g0 = (c0 shr 8) and 0xFF
                    val b0 = c0 and 0xFF

                    val delta = abs(r1 - r0) + abs(g1 - g0) + abs(b1 - b0)
                    if (delta > 65) {
                        val detectedTypes = classifyPixelElementalTypes(r1, g1, b1)
                        for (dt in detectedTypes) {
                            frameTypeCounts[dt] = (frameTypeCounts[dt] ?: 0) + 2
                        }
                    }
                }
                for ((tName, cnt) in frameTypeCounts) {
                    if (cnt >= 8) {
                        typeVotes[tName] = (typeVotes[tName] ?: 0) + cnt
                    }
                }
            }
        }

        val estTurns: Int? = if (observedHitIntervalsMs.size >= 3) {
            val avgMs = observedHitIntervalsMs.average()
            (avgMs / 500.0).roundToInt().coerceIn(1, 5)
        } else {
            null
        }

        val scores = IntArray(entry.fastMoves.size)
        var bestIdx = 0
        var bestScore = -999

        for ((idx, fm) in entry.fastMoves.withIndex()) {
            var score = if (idx == 0) 28 else 0 // Strong PvPoke #1 Recommended Meta Fast Move prior

            // Signal A: Elemental particle color votes on verified hit frames
            val colorSupport = typeVotes[fm.type] ?: 0
            score += (colorSupport / 12).coerceAtMost(16)

            // Signal B: Turn duration cadence across >= 3 verified hits
            if (estTurns != null && fm.turns == estTurns) {
                score += 14
            }

            // Signal C: Dual-Type Effectiveness Callout (left-side only) & Neutral-Absence Deduction
            if (playerDefenderTypes.isNotEmpty()) {
                val expectedEff = getDualTypeEffectivenessLabel(fm.type, playerDefenderTypes)
                if (!effectivenessHint.isNullOrBlank()) {
                    if (expectedEff == effectivenessHint) {
                        score += 42
                    } else {
                        score -= 26
                    }
                } else if (fastHitsLandedOnCurrentPlayer >= 4) {
                    if (expectedEff == "neutral") {
                        score += 24
                    } else {
                        score -= 18
                    }
                }
            }

            scores[idx] = score
            if (score > bestScore) {
                bestScore = score
                bestIdx = idx
            }
        }

        val curIdxSafe = currentActiveIdx.coerceIn(0, entry.fastMoves.size - 1)
        val currentScore = scores[curIdxSafe]
        return if (bestIdx != curIdxSafe && bestScore >= 28 && (bestScore - currentScore) >= 18) {
            bestIdx
        } else {
            null
        }
    }

    private fun classifyPixelElementalTypes(r: Int, g: Int, b: Int): List<String> {
        // Fire (Ember / Fire Spin / Incinerate): bright orange-red-amber flame
        if (r > 215 && g in 65..180 && b < 65 && (r - b) > 150) return listOf("fire")
        // Dragon (Dragon Breath): neon cyan-violet / electric indigo-teal stream
        if (b > 200 && r in 110..210 && g in 140..235) return listOf("dragon", "flying")
        // Bug (Bug Bite / Fury Cutter): bright lime-chartreuse green slash
        if (g > 190 && r in 120..205 && b < 90 && g > r + 25) return listOf("bug")
        // Electric: bright yellow
        if (r > 220 && g > 200 && b < 85) return listOf("electric")
        // Water (Bubble / Water Gun): azure / deep cyan-blue
        if (b > 190 && g in 105..205 && r < 90) return listOf("water")
        // Ice: bright frost cyan-white
        if (b > 215 && g > 205 && r in 155..235) return listOf("ice", "flying")
        // Grass: vivid emerald green
        if (g > 165 && g > r + 40 && g > b + 35) return listOf("grass")
        // Poison: vivid purple-magenta
        if (r in 155..235 && b in 155..240 && g < 90) return listOf("poison")
        // Ghost (Lick / Shadow Claw): deep violet-indigo shadow
        if (b in 135..225 && r in 80..165 && g < 70 && b > r) return listOf("ghost")
        // Fairy / Psychic (Psywave): bright pastel pink / magenta wave
        if (r > 210 && b in 150..230 && g in 85..165) return listOf("psychic", "fairy")
        // Flying / Steel / Normal (Peck beak-jab starburst, Wing Attack, Lock-On): bright silver-white flash
        if (r > 205 && g > 205 && b > 205 && abs(r - g) < 20 && abs(g - b) < 20) {
            return listOf("flying", "normal", "steel")
        }
        return emptyList()
    }

    private fun getDualTypeEffectivenessLabel(moveType: String, defenderTypes: List<String>): String {
        val superMap = mapOf(
            "fire" to setOf("grass", "ice", "bug", "steel"),
            "water" to setOf("fire", "ground", "rock"),
            "grass" to setOf("water", "ground", "rock"),
            "electric" to setOf("water", "flying"),
            "ice" to setOf("grass", "ground", "flying", "dragon"),
            "fighting" to setOf("normal", "ice", "rock", "dark", "steel"),
            "poison" to setOf("grass", "fairy"),
            "ground" to setOf("fire", "electric", "poison", "rock", "steel"),
            "flying" to setOf("grass", "fighting", "bug"),
            "psychic" to setOf("fighting", "poison"),
            "bug" to setOf("grass", "psychic", "dark"),
            "rock" to setOf("fire", "ice", "flying", "bug"),
            "ghost" to setOf("psychic", "ghost"),
            "dragon" to setOf("dragon"),
            "dark" to setOf("psychic", "ghost"),
            "steel" to setOf("ice", "rock", "fairy"),
            "fairy" to setOf("fighting", "dragon", "dark")
        )
        val resistMap = mapOf(
            "fire" to setOf("fire", "water", "rock", "dragon"),
            "water" to setOf("water", "grass", "dragon"),
            "grass" to setOf("fire", "grass", "poison", "flying", "bug", "dragon", "steel"),
            "electric" to setOf("electric", "grass", "dragon", "ground"),
            "ice" to setOf("fire", "water", "ice", "steel"),
            "fighting" to setOf("poison", "flying", "psychic", "bug", "fairy", "ghost"),
            "poison" to setOf("poison", "ground", "rock", "ghost", "steel"),
            "ground" to setOf("grass", "bug", "flying"),
            "flying" to setOf("electric", "rock", "steel"),
            "psychic" to setOf("psychic", "steel", "dark"),
            "bug" to setOf("fire", "fighting", "poison", "flying", "ghost", "steel", "fairy"),
            "rock" to setOf("fighting", "ground", "steel"),
            "ghost" to setOf("dark", "normal"),
            "dragon" to setOf("steel", "fairy"),
            "dark" to setOf("fighting", "dark", "fairy"),
            "steel" to setOf("fire", "water", "electric", "steel"),
            "fairy" to setOf("fire", "poison", "steel")
        )

        var netLevel = 0
        for (dt in defenderTypes) {
            if (superMap[moveType]?.contains(dt) == true) netLevel += 1
            if (resistMap[moveType]?.contains(dt) == true) netLevel -= 1
        }
        return when {
            netLevel > 0 -> "super"
            netLevel < 0 -> "not_very"
            else -> "neutral"
        }
    }
}
