package com.pokecount.overlay

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Identifies which Fast Attack the opponent's Pokémon is using by combining:
 * 1. Strong PvPoke Meta-Prior (+26 baseline to index 0, e.g. Psywave on Malamar, Infestation on Araquanid).
 * 2. Foreground Elemental VFX on the Player's Pokémon (x: 8%..44%, y: 22%..66%) on verified hit frames
 *    (excluding generic white hit-sparks so Flying/Normal/Steel moves like Peck never get false color votes).
 * 3. Decisive Hit-Frame Inter-Attack Cadence (+34 for exact turn match, -14 for 1-turn diff, -32 for >=2-turn diff),
 *    with a guard for 1-turn resisted moves whose sub-pixel drops accumulate across 2 turns.
 * 4. Positive-Only Dual-Type Effectiveness Callout ("SUPER EFFECTIVE" / "NOT VERY EFFECTIVE"):
 *    only applied when OCR positively reads an effectiveness banner, never from absence of text.
 */
class FastMoveVisualClassifier {

    private var prevArenaPixels: IntArray? = null
    private var lastHitTimestampMs: Long = 0L
    private val observedHitIntervalsMs = mutableListOf<Long>()
    private val typeVotes = mutableMapOf<String, Int>()
    private val ambientTypeBaseline = mutableMapOf<String, Int>()
    private val staticModelTypeBaseline = mutableMapOf<String, Int>()

    fun resetForNewOpponent() {
        prevArenaPixels = null
        lastHitTimestampMs = 0L
        observedHitIntervalsMs.clear()
        typeVotes.clear()
        ambientTypeBaseline.clear()
        staticModelTypeBaseline.clear()
    }

    fun analyzeArenaFrame(
        arenaBmp: Bitmap,
        entry: PvPokeEntry,
        currentActiveIdx: Int,
        effectivenessHint: String?,
        playerDefenderTypes: List<String>,
        fastHitsLandedOnCurrentPlayer: Int = 0,
        isHitFrame: Boolean = false
    ): Int? {
        if (entry.fastMoves.size <= 1) return 0

        val w = arenaBmp.width
        val h = arenaBmp.height
        val total = w * h
        val currPixels = IntArray(total)
        arenaBmp.getPixels(currPixels, 0, w, 0, 0, w, h)

        val prev = prevArenaPixels
        prevArenaPixels = currPixels

        val frameTypeCounts = mutableMapOf<String, Int>()
        val totalSceneTypeCounts = mutableMapOf<String, Int>()
        if (prev != null && prev.size == total) {
            for (i in 0 until total) {
                val c1 = currPixels[i]
                val c0 = prev[i]

                val r1 = (c1 shr 16) and 0xFF
                val g1 = (c1 shr 8) and 0xFF
                val b1 = c1 and 0xFF

                val detectedTypes = classifyPixelElementalTypes(r1, g1, b1)
                if (detectedTypes.isNotEmpty()) {
                    for (dt in detectedTypes) {
                        totalSceneTypeCounts[dt] = (totalSceneTypeCounts[dt] ?: 0) + 1
                    }
                    val r0 = (c0 shr 16) and 0xFF
                    val g0 = (c0 shr 8) and 0xFF
                    val b0 = c0 and 0xFF
                    val delta = abs(r1 - r0) + abs(g1 - g0) + abs(b1 - b0)
                    if (delta > 65) {
                        for (dt in detectedTypes) {
                            frameTypeCounts[dt] = (frameTypeCounts[dt] ?: 0) + 2
                        }
                    }
                }
            }
        }

        if (isHitFrame) {
            val now = SystemClock.elapsedRealtime()
            if (lastHitTimestampMs > 0L) {
                val dt = now - lastHitTimestampMs
                if (dt in 380L..2850L) {
                    observedHitIntervalsMs.add(dt)
                    if (observedHitIntervalsMs.size > 6) observedHitIntervalsMs.removeAt(0)
                }
            }
            lastHitTimestampMs = now

            for ((tName, cnt) in frameTypeCounts) {
                val ambient = ambientTypeBaseline[tName] ?: 0
                val netMovingBurst = cnt - (ambient * 2)
                // Guard against player Pokémon wing sway / hit-flinch translation (e.g. Altaria's sky-blue body & wings):
                // require that the TOTAL scene pixels of this elemental color also increased above the static model baseline!
                val staticBase = staticModelTypeBaseline[tName] ?: 0
                val curTotal = totalSceneTypeCounts[tName] ?: 0
                val netSceneSpawn = if (staticModelTypeBaseline.isEmpty()) (cnt / 2) else (curTotal - staticBase)
                val effectiveBurst = minOf(netMovingBurst, netSceneSpawn * 2)
                if (cnt >= 14 && effectiveBurst >= 10) {
                    typeVotes[tName] = (typeVotes[tName] ?: 0) + effectiveBurst
                }
            }
        } else if (prev != null) {
            // Track both moving aura baseline (Shadow flames / weather) and static player model palette (e.g. Altaria's blue wings)
            val allTrackedTypes = (ambientTypeBaseline.keys + frameTypeCounts.keys + totalSceneTypeCounts.keys).toSet()
            for (tName in allTrackedTypes) {
                val curMoving = frameTypeCounts[tName] ?: 0
                val oldMoving = ambientTypeBaseline[tName] ?: curMoving
                ambientTypeBaseline[tName] = (oldMoving * 3 + curMoving) / 4

                val curTotal = totalSceneTypeCounts[tName] ?: 0
                val oldTotal = staticModelTypeBaseline[tName] ?: curTotal
                staticModelTypeBaseline[tName] = (oldTotal * 3 + curTotal) / 4
            }
        }

        val curIdxSafe = currentActiveIdx.coerceIn(0, entry.fastMoves.size - 1)
        val currentFm = entry.fastMoves[curIdxSafe]
        val currentTurns = currentFm.turns

        // If the current active move is a 1-turn move (500ms, like Malamar's Psywave) that is resisted by the
        // player's Pokémon (e.g. Psychic vs Dark-type Thievul, 0.391x double-resistance), each 1-turn hit may
        // deal <1px of damage so 2 consecutive hits accumulate to a 2px drop over 1000ms (2 turns).
        val isCurrentOneTurnResisted = currentTurns == 1 &&
            playerDefenderTypes.isNotEmpty() &&
            getDualTypeEffectivenessLabel(currentFm.type, playerDefenderTypes) == "not_very"

        val estTurns: Int? = when {
            observedHitIntervalsMs.size >= 2 -> {
                val avgMs = observedHitIntervalsMs.average()
                val rawTurns = (avgMs / 500.0).roundToInt().coerceIn(1, 5)
                if (isCurrentOneTurnResisted && rawTurns == 2) 1 else rawTurns
            }
            observedHitIntervalsMs.size == 1 -> {
                val singleMs = observedHitIntervalsMs.first()
                val singleTurns = (singleMs / 500.0).roundToInt().coerceIn(1, 5)
                if (abs(singleTurns - currentTurns) >= 2 && abs(singleMs - currentTurns * 500L) >= 700L) {
                    singleTurns
                } else {
                    null
                }
            }
            else -> null
        }

        val scores = IntArray(entry.fastMoves.size)
        var bestIdx = 0
        var bestScore = -999

        for ((idx, fm) in entry.fastMoves.withIndex()) {
            var score = if (idx == 0) 12 else 0
            if (idx == curIdxSafe) score += 8

            // Signal A: Elemental particle color votes on verified hit frames
            val colorSupport = typeVotes[fm.type] ?: 0
            score += (colorSupport / 12).coerceAtMost(18)

            // Signal B: Turn duration cadence
            if (estTurns != null) {
                val turnDiff = abs(fm.turns - estTurns)
                when {
                    turnDiff == 0 -> score += 34
                    turnDiff == 1 -> score -= 14
                    else -> score -= 32
                }
            }

            // Signal C: Positive-Only Dual-Type Effectiveness Callout (never penalize from absence of OCR text!)
            if (playerDefenderTypes.isNotEmpty() && !effectivenessHint.isNullOrBlank()) {
                val expectedEff = getDualTypeEffectivenessLabel(fm.type, playerDefenderTypes)
                if (expectedEff == effectivenessHint) {
                    score += 42
                } else {
                    score -= 26
                }
            }

            scores[idx] = score
            if (score > bestScore) {
                bestScore = score
                bestIdx = idx
            }
        }

        val currentScore = scores[curIdxSafe]
        val bestFm = entry.fastMoves[bestIdx]
        val hasPositiveSwitchSignal =
            (estTurns != null && abs(bestFm.turns - estTurns) < abs(currentFm.turns - estTurns)) ||
                ((typeVotes[bestFm.type] ?: 0) >= 24) ||
                (playerDefenderTypes.isNotEmpty() &&
                    !effectivenessHint.isNullOrBlank() &&
                    getDualTypeEffectivenessLabel(bestFm.type, playerDefenderTypes) == effectivenessHint)

        return if (
            bestIdx != curIdxSafe &&
            hasPositiveSwitchSignal &&
            (bestScore - currentScore) >= 20
        ) {
            bestIdx
        } else {
            null
        }
    }

    private fun classifyPixelElementalTypes(r: Int, g: Int, b: Int): List<String> {
        // Fire (Ember / Fire Spin / Incinerate / Fire Fang): bright orange-red-amber flame
        if (r > 215 && g in 65..180 && b < 65 && (r - b) > 150) return listOf("fire")
        // Dragon (Dragon Breath): neon cyan-violet / electric indigo-teal stream
        if (b > 200 && r in 110..210 && g in 140..235) return listOf("dragon")
        // Bug (Bug Bite / Fury Cutter / Infestation): bright lime-chartreuse green slash
        if (g > 190 && r in 120..205 && b < 90 && g > r + 25) return listOf("bug")
        // Electric: bright yellow
        if (r > 220 && g > 200 && b < 85) return listOf("electric")
        // Water (Bubble / Water Gun / Water Shuriken): azure / deep cyan-blue
        if (b > 190 && g in 105..205 && r < 90) return listOf("water")
        // Ice: bright frost cyan-white
        if (b > 215 && g > 205 && r in 155..225 && (b - r) >= 20) return listOf("ice")
        // Grass: vivid emerald green
        if (g > 165 && g > r + 40 && g > b + 35) return listOf("grass")
        // Poison / Ghost (Shadow Claw / Sludge): vivid purple-magenta
        if (r in 155..235 && b in 155..240 && g < 90) {
            return if (b >= r) listOf("poison", "ghost") else listOf("poison")
        }
        // Ghost (Lick / Shadow Claw / Hex / Astonish): deep violet-indigo shadow
        if (b in 125..245 && r in 75..215 && g < 85 && b >= r - 15) return listOf("ghost", "poison")
        // Fairy / Psychic (Psywave / Fairy Wind / Charm): bright pastel pink / magenta wave
        if (r > 210 && b in 150..230 && g in 85..165) return listOf("psychic", "fairy")
        return emptyList()
    }

    private fun getDualTypeEffectivenessLabel(moveType: String, defenderTypes: List<String>): String {
        val superMap = mapOf(
            "fire" to setOf("grass", "ice", "bug", "steel"),
            "water" to setOf("fire", "ground", "rock"),
            "grass" to setOf("water", "ground", "rock"),
            "electric" to setOf("water", "flying"),
            "ice" to setOf("grass", "ground", "flying", "dragon"),
            "fighting" to setOf("normal", "ice", "rock", "dark", "steel"),
            "poison" to setOf("grass", "fairy"),
            "ground" to setOf("fire", "electric", "poison", "rock", "steel"),
            "flying" to setOf("grass", "fighting", "bug"),
            "psychic" to setOf("fighting", "poison"),
            "bug" to setOf("grass", "psychic", "dark"),
            "rock" to setOf("fire", "ice", "flying", "bug"),
            "ghost" to setOf("psychic", "ghost"),
            "dragon" to setOf("dragon"),
            "dark" to setOf("psychic", "ghost"),
            "steel" to setOf("ice", "rock", "fairy"),
            "fairy" to setOf("fighting", "dragon", "dark")
        )
        val resistMap = mapOf(
            "fire" to setOf("fire", "water", "rock", "dragon"),
            "water" to setOf("water", "grass", "dragon"),
            "grass" to setOf("fire", "grass", "poison", "flying", "bug", "dragon", "steel"),
            "electric" to setOf("electric", "grass", "dragon", "ground"),
            "ice" to setOf("fire", "water", "ice", "steel"),
            "fighting" to setOf("poison", "flying", "psychic", "bug", "fairy", "ghost"),
            "poison" to setOf("poison", "ground", "rock", "ghost", "steel"),
            "ground" to setOf("grass", "bug", "flying"),
            "flying" to setOf("electric", "rock", "steel"),
            "psychic" to setOf("psychic", "steel", "dark"),
            "bug" to setOf("fire", "fighting", "poison", "flying", "ghost", "steel", "fairy"),
            "rock" to setOf("fighting", "ground", "steel"),
            "ghost" to setOf("dark", "normal"),
            "dragon" to setOf("steel", "fairy"),
            "dark" to setOf("fighting", "dark", "fairy"),
            "steel" to setOf("fire", "water", "electric", "steel"),
            "fairy" to setOf("fire", "poison", "steel")
        )

        var netLevel = 0
        for (dt in defenderTypes) {
            if (superMap[moveType]?.contains(dt) == true) netLevel += 1
            if (resistMap[moveType]?.contains(dt) == true) netLevel -= 1
        }
        return when {
            netLevel > 0 -> "super"
            netLevel < 0 -> "not_very"
            else -> "neutral"
        }
    }
}
