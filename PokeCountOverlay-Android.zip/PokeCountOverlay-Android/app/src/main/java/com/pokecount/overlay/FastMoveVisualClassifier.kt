package com.pokecount.overlay

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Identifies which Fast Attack the opponent's Pokémon is using by analyzing:
 * 1. Elemental particle color bursts (RGB/HSV delta between consecutive frames in the arena impact zone).
 * 2. Inter-attack cadence (time delta between attack animation bursts / HP bar drops: 1T=500ms .. 5T=2500ms).
 * 3. Type effectiveness callout ("SUPER EFFECTIVE!" / "NOT VERY EFFECTIVE...") against the player's Pokémon.
 */
class FastMoveVisualClassifier {

    private var prevArenaPixels: IntArray? = null
    private var lastBurstTimestampMs: Long = 0L
    private val observedIntervalsMs = mutableListOf<Long>()
    private val typeVotes = mutableMapOf<String, Int>()

    fun resetForNewOpponent() {
        prevArenaPixels = null
        lastBurstTimestampMs = 0L
        observedIntervalsMs.clear()
        typeVotes.clear()
    }

    /**
     * Analyzes a downsampled crop of the battle arena (x: 20%..72%, y: 30%..64%) to classify
     * newly spawned fast-attack particle colors and measure the time interval between fast attacks.
     * Returns the index of the best-matching FastMove in [entry.fastMoves], or null if only 1 move exists.
     */
    fun analyzeArenaFrame(
        arenaBmp: Bitmap,
        entry: PvPokeEntry,
        effectivenessHint: String?,
        playerPokemonType: String?
    ): Int? {
        if (entry.fastMoves.size <= 1) return 0

        val w = arenaBmp.width
        val h = arenaBmp.height
        val total = w * h
        val currPixels = IntArray(total)
        arenaBmp.getPixels(currPixels, 0, w, 0, 0, w, h)

        val prev = prevArenaPixels
        prevArenaPixels = currPixels
        if (prev == null || prev.size != total) return null

        // Count pixels that changed significantly since the last frame (newly spawned attack particles)
        var changedCount = 0
        val frameTypeCounts = mutableMapOf<String, Int>()

        for (i in 0 until total) {
            val c1 = currPixels[i]
            val c0 = prev[i]

            val r1 = (c1 shr 16) and 0xFF
            val g1 = (c1 shr 8) and 0xFF
            val b1 = c1 and 0xFF

            val r0 = (c0 shr 16) and 0xFF
            val g0 = (c0 shr 8) and 0xFF
            val b0 = c0 and 0xFF

            val delta = abs(r1 - r0) + abs(g1 - g0) + abs(b1 - b0)
            if (delta > 55) {
                changedCount++
                val detectedType = classifyPixelElementalType(r1, g1, b1)
                if (detectedType != null) {
                    frameTypeCounts[detectedType] = (frameTypeCounts[detectedType] ?: 0) + 1
                }
            }
        }

        // If a distinct attack particle burst occurred on this frame
        val burstThreshold = max(18, total / 35)
        val now = System.currentTimeMillis()
        if (changedCount >= burstThreshold) {
            // 1. Accumulate elemental color votes for candidate fast moves
            for ((tName, cnt) in frameTypeCounts) {
                if (cnt >= 6) {
                    typeVotes[tName] = (typeVotes[tName] ?: 0) + cnt
                }
            }

            // 2. Measure time interval since previous attack burst (1T=500ms, 2T=1000ms, 3T=1500ms, 4T=2000ms, 5T=2500ms)
            if (lastBurstTimestampMs > 0L) {
                val dt = now - lastBurstTimestampMs
                if (dt in 420L..2750L) {
                    observedIntervalsMs.add(dt)
                    if (observedIntervalsMs.size > 5) observedIntervalsMs.removeAt(0)
                    lastBurstTimestampMs = now
                } else if (dt > 2750L) {
                    lastBurstTimestampMs = now
                }
            } else {
                lastBurstTimestampMs = now
            }
        }

        // Score each candidate Fast Move in entry.fastMoves
        val estTurns: Int? = if (observedIntervalsMs.size >= 2) {
            val avgMs = observedIntervalsMs.average()
            (avgMs / 500.0).roundToInt().coerceIn(1, 5)
        } else null

        var bestIdx = 0
        var bestScore = -1

        for ((idx, fm) in entry.fastMoves.withIndex()) {
            var score = 0

            // Signal A: Elemental particle color votes
            val colorSupport = typeVotes[fm.type] ?: 0
            score += (colorSupport / 10).coerceAtMost(25)

            // Signal B: Turn duration cadence (if candidate moves have different turn counts)
            if (estTurns != null && fm.turns == estTurns) {
                score += 18
            }

            // Signal C: Effectiveness callout cross-check ("SUPER EFFECTIVE" / "NOT VERY EFFECTIVE")
            if (!effectivenessHint.isNullOrBlank() && !playerPokemonType.isNullOrBlank()) {
                val expectedEff = getTypeEffectivenessLabel(fm.type, playerPokemonType)
                if (expectedEff == effectivenessHint) {
                    score += 30
                }
            }

            if (score > bestScore) {
                bestScore = score
                bestIdx = idx
            }
        }

        return if (bestScore >= 10) bestIdx else null
    }

    private fun classifyPixelElementalType(r: Int, g: Int, b: Int): String? {
        // Fire: bright orange-red-amber
        if (r > 210 && g in 65..185 && b < 70) return "fire"
        // Electric: bright yellow
        if (r > 215 && g > 195 && b < 90) return "electric"
        // Water: azure / deep cyan-blue
        if (b > 190 && g in 105..195 && r < 90) return "water"
        // Ice: bright frost cyan-white
        if (b > 210 && g > 200 && r in 155..235) return "ice"
        // Grass / Bug: vivid emerald or lime green
        if (g > 155 && g > r + 30 && g > b + 30) return "grass"
        // Poison: vivid purple-magenta
        if (r in 145..230 && b in 145..235 && g < 95) return "poison"
        // Ghost / Dark: deep violet-indigo shadow
        if (b in 115..220 && r in 70..165 && g < 75 && b > r) return "ghost"
        if (r in 35..85 && g in 25..70 && b in 55..110) return "dark"
        // Fairy / Psychic: bright pastel pink / rose
        if (r > 205 && b in 145..225 && g in 85..165) return "fairy"
        // Ground / Rock: warm ochre / tan / brown
        if (r in 145..215 && g in 95..165 && b < 85 && r > g + 15) return "ground"
        // Fighting: crimson-orange punch flash
        if (r > 190 && g in 45..110 && b in 35..95) return "fighting"
        // Flying / Steel / Normal: bright silver-white slash or wind blade
        if (r > 195 && g > 195 && b > 195 && abs(r - g) < 20 && abs(g - b) < 20) return "flying"
        return null
    }

    private fun getTypeEffectivenessLabel(moveType: String, defenderType: String): String {
        val superMap = mapOf(
            "fire" to setOf("grass", "ice", "bug", "steel"),
            "water" to setOf("fire", "ground", "rock"),
            "grass" to setOf("water", "ground", "rock"),
            "electric" to setOf("water", "flying"),
            "ice" to setOf("grass", "ground", "flying", "dragon"),
            "fighting" to setOf("normal", "ice", "rock", "dark", "steel"),
            "poison" to setOf("grass", "fairy"),
            "ground" to setOf("fire", "electric", "poison", "rock", "steel"),
            "flying" to setOf("grass", "fighting", "bug"),
            "psychic" to setOf("fighting", "poison"),
            "bug" to setOf("grass", "psychic", "dark"),
            "rock" to setOf("fire", "ice", "flying", "bug"),
            "ghost" to setOf("psychic", "ghost"),
            "dragon" to setOf("dragon"),
            "dark" to setOf("psychic", "ghost"),
            "steel" to setOf("ice", "rock", "fairy"),
            "fairy" to setOf("fighting", "dragon", "dark")
        )
        val resistMap = mapOf(
            "fire" to setOf("fire", "water", "rock", "dragon"),
            "water" to setOf("water", "grass", "dragon"),
            "grass" to setOf("fire", "grass", "poison", "flying", "bug", "dragon", "steel"),
            "electric" to setOf("electric", "grass", "dragon", "ground"),
            "ice" to setOf("fire", "water", "ice", "steel"),
            "fighting" to setOf("poison", "flying", "psychic", "bug", "fairy", "ghost"),
            "poison" to setOf("poison", "ground", "rock", "ghost", "steel"),
            "ground" to setOf("grass", "bug", "flying"),
            "flying" to setOf("electric", "rock", "steel"),
            "psychic" to setOf("psychic", "steel", "dark"),
            "bug" to setOf("fire", "fighting", "poison", "flying", "ghost", "steel", "fairy"),
            "rock" to setOf("fighting", "ground", "steel"),
            "ghost" to setOf("dark", "normal"),
            "dragon" to setOf("steel", "fairy"),
            "dark" to setOf("fighting", "dark", "fairy"),
            "steel" to setOf("fire", "water", "electric", "steel"),
            "fairy" to setOf("fire", "poison", "steel")
        )
        return when {
            superMap[moveType]?.contains(defenderType) == true -> "super"
            resistMap[moveType]?.contains(defenderType) == true -> "not_very"
            else -> "neutral"
        }
    }
}
