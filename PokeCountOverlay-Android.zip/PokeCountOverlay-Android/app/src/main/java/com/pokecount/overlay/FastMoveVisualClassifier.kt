package com.pokecount.overlay

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Identifies which Fast Attack the opponent's Pokémon is using by combining:
 * 1. Foreground Hit-Impact VFX on the Player's Pokémon (x: 8%..44%, y: 22%..66% - never obstructed by Altaria's wings!)
 *    weighted 3x higher on exact HP-drop frames, with full support for Flying (Peck/Wing Attack) vs Fire (Ember).
 * 2. Inter-attack cadence (time delta between attack bursts / HP drops: 1T=500ms .. 5T=2500ms).
 * 3. Dual-Type Effectiveness Callout & Neutral-Absence Deduction:
 *    - Matches "SUPER EFFECTIVE!" / "NOT VERY EFFECTIVE..." callouts above your Pokémon.
 *    - If 2+ fast attacks land with NO effectiveness banner, promotes Neutral (1.0x) moves (e.g. Peck vs Altaria)
 *      and penalizes moves that would have triggered a callout (e.g. Ember [Fire] is resisted by Altaria [Dragon/Flying]).
 */
class FastMoveVisualClassifier {

    private var prevArenaPixels: IntArray? = null
    private var lastBurstTimestampMs: Long = 0L
    private val observedIntervalsMs = mutableListOf<Long>()
    private val typeVotes = mutableMapOf<String, Int>()
    private var consecutiveFastBurstTicks: Int = 0

    fun resetForNewOpponent() {
        prevArenaPixels = null
        lastBurstTimestampMs = 0L
        observedIntervalsMs.clear()
        typeVotes.clear()
        consecutiveFastBurstTicks = 0
    }

    fun analyzeArenaFrame(
        arenaBmp: Bitmap,
        entry: PvPokeEntry,
        effectivenessHint: String?,
        playerDefenderTypes: List<String>,
        fastHitsLandedOnCurrentPlayer: Int = 0,
        isHitFrame: Boolean = false
    ): Int? {
        if (entry.fastMoves.size <= 1) return 0

        val w = arenaBmp.width
        val h = arenaBmp.height
        val total = w * h
        val currPixels = IntArray(total)
        arenaBmp.getPixels(currPixels, 0, w, 0, 0, w, h)

        val prev = prevArenaPixels
        prevArenaPixels = currPixels
        if (prev != null && prev.size == total) {
            var changedCount = 0
            val frameTypeCounts = mutableMapOf<String, Int>()
            val weight = if (isHitFrame) 3 else 1

            for (i in 0 until total) {
                val c1 = currPixels[i]
                val c0 = prev[i]

                val r1 = (c1 shr 16) and 0xFF
                val g1 = (c1 shr 8) and 0xFF
                val b1 = c1 and 0xFF

                val r0 = (c0 shr 16) and 0xFF
                val g0 = (c0 shr 8) and 0xFF
                val b0 = c0 and 0xFF

                val delta = abs(r1 - r0) + abs(g1 - g0) + abs(b1 - b0)
                if (delta > 58) {
                    changedCount++
                    val detectedTypes = classifyPixelElementalTypes(r1, g1, b1)
                    for (dt in detectedTypes) {
                        frameTypeCounts[dt] = (frameTypeCounts[dt] ?: 0) + weight
                    }
                }
            }

            val burstThreshold = max(14, total / 38)
            val now = System.currentTimeMillis()
            if (changedCount >= burstThreshold || isHitFrame) {
                consecutiveFastBurstTicks++
                for ((tName, cnt) in frameTypeCounts) {
                    if (cnt >= 5) {
                        typeVotes[tName] = (typeVotes[tName] ?: 0) + cnt
                    }
                }

                if (lastBurstTimestampMs > 0L) {
                    val dt = now - lastBurstTimestampMs
                    if (dt in 360L..2750L) {
                        observedIntervalsMs.add(dt)
                        if (observedIntervalsMs.size > 6) observedIntervalsMs.removeAt(0)
                        lastBurstTimestampMs = now
                    } else if (dt > 2750L) {
                        lastBurstTimestampMs = now
                    }
                } else {
                    lastBurstTimestampMs = now
                }
            } else {
                consecutiveFastBurstTicks = max(0, consecutiveFastBurstTicks - 1)
            }
        }

        val estTurns: Int? = when {
            consecutiveFastBurstTicks >= 6 -> 1
            observedIntervalsMs.size >= 2 -> {
                val avgMs = observedIntervalsMs.average()
                (avgMs / 500.0).roundToInt().coerceIn(1, 5)
            }
            else -> null
        }

        var bestIdx = 0
        var bestScore = -999

        for ((idx, fm) in entry.fastMoves.withIndex()) {
            var score = 0

            // Signal A: Elemental particle color votes on foreground impact zone
            val colorSupport = typeVotes[fm.type] ?: 0
            score += (colorSupport / 8).coerceAtMost(28)

            // Signal B: Turn duration cadence (1T=500ms vs 2T=1000ms vs 3T=1500ms)
            if (estTurns != null && fm.turns == estTurns) {
                score += 18
            }

            // Signal C: Dual-Type Effectiveness Callout & Neutral-Absence Deduction
            if (playerDefenderTypes.isNotEmpty()) {
                val expectedEff = getDualTypeEffectivenessLabel(fm.type, playerDefenderTypes)
                if (!effectivenessHint.isNullOrBlank()) {
                    if (expectedEff == effectivenessHint) {
                        score += 36
                    } else {
                        score -= 22
                    }
                } else if (fastHitsLandedOnCurrentPlayer >= 2) {
                    // 2+ fast moves landed with NO "Super effective" or "Not very effective" banner!
                    // Moves that are Neutral (1.0x, e.g. Peck vs Altaria) match the absence of banner;
                    // Moves that SHOULD have printed a banner (e.g. Ember [Fire] is Not Very Effective vs Altaria) are penalized!
                    if (expectedEff == "neutral") {
                        score += 28
                    } else {
                        score -= 16
                    }
                }
            }

            if (score > bestScore) {
                bestScore = score
                bestIdx = idx
            }
        }

        return if (bestScore >= 10) bestIdx else null
    }

    private fun classifyPixelElementalTypes(r: Int, g: Int, b: Int): List<String> {
        // Fire (Ember / Fire Spin / Incinerate): bright orange-red-amber flame
        if (r > 212 && g in 60..180 && b < 68 && (r - b) > 145) return listOf("fire")
        // Dragon (Dragon Breath): neon cyan-violet / electric indigo-teal stream
        if (b > 195 && r in 110..210 && g in 140..235) return listOf("dragon", "flying")
        // Bug (Bug Bite / Fury Cutter): bright lime-chartreuse green slash
        if (g > 185 && r in 120..205 && b < 95 && g > r + 20) return listOf("bug")
        // Electric: bright yellow
        if (r > 215 && g > 195 && b < 90) return listOf("electric")
        // Water (Water Gun): azure / deep cyan-blue
        if (b > 190 && g in 105..195 && r < 90) return listOf("water")
        // Ice: bright frost cyan-white
        if (b > 210 && g > 200 && r in 155..235) return listOf("ice", "flying")
        // Grass: vivid emerald green
        if (g > 155 && g > r + 35 && g > b + 30) return listOf("grass")
        // Poison: vivid purple-magenta
        if (r in 145..230 && b in 145..235 && g < 95) return listOf("poison")
        // Ghost (Lick / Shadow Claw): deep violet-indigo shadow
        if (b in 115..220 && r in 70..165 && g < 75 && b > r) return listOf("ghost")
        // Dark (Bite / Snarl): dark obsidian-crimson crunch
        if (r in 35..95 && g in 20..70 && b in 45..110) return listOf("dark")
        // Fairy / Psychic (Psywave): bright pastel pink / magenta wave
        if (r > 205 && b in 145..225 && g in 85..165) return listOf("psychic", "fairy")
        // Ground / Rock (Sand Attack): warm ochre / tan / brown
        if (r in 145..215 && g in 95..165 && b < 85 && r > g + 15) return listOf("ground", "rock")
        // Fighting: crimson-orange punch flash
        if (r > 190 && g in 45..110 && b in 35..95) return listOf("fighting")
        // Flying / Steel / Normal (Peck beak-jab starburst, Wing Attack, Lock-On): bright silver-white or sky-white flash
        if (r > 195 && g > 195 && b > 195 && abs(r - g) < 22 && abs(g - b) < 22) {
            return listOf("flying", "normal", "steel")
        }
        return emptyList()
    }

    private fun getDualTypeEffectivenessLabel(moveType: String, defenderTypes: List<String>): String {
        val superMap = mapOf(
            "fire" to setOf("grass", "ice", "bug", "steel"),
            "water" to setOf("fire", "ground", "rock"),
            "grass" to setOf("water", "ground", "rock"),
            "electric" to setOf("water", "flying"),
            "ice" to setOf("grass", "ground", "flying", "dragon"),
            "fighting" to setOf("normal", "ice", "rock", "dark", "steel"),
            "poison" to setOf("grass", "fairy"),
            "ground" to setOf("fire", "electric", "poison", "rock", "steel"),
            "flying" to setOf("grass", "fighting", "bug"),
            "psychic" to setOf("fighting", "poison"),
            "bug" to setOf("grass", "psychic", "dark"),
            "rock" to setOf("fire", "ice", "flying", "bug"),
            "ghost" to setOf("psychic", "ghost"),
            "dragon" to setOf("dragon"),
            "dark" to setOf("psychic", "ghost"),
            "steel" to setOf("ice", "rock", "fairy"),
            "fairy" to setOf("fighting", "dragon", "dark")
        )
        val resistMap = mapOf(
            "fire" to setOf("fire", "water", "rock", "dragon"),
            "water" to setOf("water", "grass", "dragon"),
            "grass" to setOf("fire", "grass", "poison", "flying", "bug", "dragon", "steel"),
            "electric" to setOf("electric", "grass", "dragon", "ground"),
            "ice" to setOf("fire", "water", "ice", "steel"),
            "fighting" to setOf("poison", "flying", "psychic", "bug", "fairy", "ghost"),
            "poison" to setOf("poison", "ground", "rock", "ghost", "steel"),
            "ground" to setOf("grass", "bug", "flying"),
            "flying" to setOf("electric", "rock", "steel"),
            "psychic" to setOf("psychic", "steel", "dark"),
            "bug" to setOf("fire", "fighting", "poison", "flying", "ghost", "steel", "fairy"),
            "rock" to setOf("fighting", "ground", "steel"),
            "ghost" to setOf("dark", "normal"),
            "dragon" to setOf("steel", "fairy"),
            "dark" to setOf("fighting", "dark", "fairy"),
            "steel" to setOf("fire", "water", "electric", "steel"),
            "fairy" to setOf("fire", "poison", "steel")
        )

        var netLevel = 0
        for (dt in defenderTypes) {
            if (superMap[moveType]?.contains(dt) == true) netLevel += 1
            if (resistMap[moveType]?.contains(dt) == true) netLevel -= 1
        }
        return when {
            netLevel > 0 -> "super"
            netLevel < 0 -> "not_very"
            else -> "neutral"
        }
    }
}
