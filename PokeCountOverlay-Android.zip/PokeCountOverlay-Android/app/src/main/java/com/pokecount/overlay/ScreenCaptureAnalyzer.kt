package com.pokecount.overlay

import android.graphics.Bitmap
import android.media.Image
import android.os.SystemClock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Bounding rectangle of the floating overlay HUD in capture-image coordinates,
 * used to mask out the overlay itself during OCR and pixel telemetry.
 */
data class OverlayImageRect(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    fun contains(x: Int, y: Int): Boolean = x in left..right && y in top..bottom
}

/**
 * Per-frame visual telemetry extracted from the MediaProjection capture buffer.
 */
data class FrameVisualTelemetry(
    val isFrameNonBlack: Boolean,
    val isBattleHudVisible: Boolean,
    val isShieldPromptVisible: Boolean,
    val hasTopCountdownCircle: Boolean,
    val barLenPx: Int,
    val playerHpFillPx: Int,
    val playerHpBarY: Int,
    val playerHpStage: Int,
    val orangeDrainPx: Int,
    val emptyAfterFillPx: Int,
    val centeredHpFillPx: Int,
    val centeredOrangeDrainPx: Int,
    val opponentBadgeTypes: Set<String>
)

/**
 * Pure detection & telemetry layer (`ScreenCaptureAnalyzer`).
 *
 * Inspects screen capture frames and OCR text and dispatches clean, high-level signals
 * (`onFastMoveSignal()`, `onChargedMoveSignal(cost)`, `onMinigameStart()`, `onMinigameEnd()`,
 * `onSwitch()`, `configureFastMove()`) to [BattleSessionManager].
 */
class ScreenCaptureAnalyzer(
    private val sessionManager: BattleSessionManager,
    private val overlayVersion: String,
    private val onUiStateChanged: () -> Unit
) {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()

    val seenOpponentPokemon = linkedMapOf<String, PvPokeEntry>()
    val slotFastMoveIdx = mutableMapOf<String, Int>()
    val manualFormOverrideByBase = mutableMapOf<String, String>()

    var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
        private set

    var inActiveMatch: Boolean = false
        private set

    var statusMessage: String = "● $overlayVersion Engine Ready"
        private set

    private var hasLockedFirstRealOpponentInMatch = false
    private var pendingDynOpponentId: String? = null
    private var pendingDynConfirmTicks: Int = 0
    private var currentPlayerPokemonId: String? = null
    private var currentPlayerPokemonName: String? = null
    private var playerDefenderTypes: List<String> = emptyList()
    private var latestEffectivenessHint: String? = null
    private var fastHitsLandedOnCurrentPlayer: Int = 0

    // Battle & Cutscene detection flags
    private var isBattleHudCurrentlyVisible = false
    private var hudCompletelyMissingDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var playerUsedChargedMoveDuringZoom = false
    private var playerOwnChargedBannerLockUntilMs = 0L
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var hasDispatchedChargedMoveForCurrentCutscene = false
    private var hasCountedCutsceneIntroFastMove = false
    private var lastDispatchedChargedMove: ChargedMove? = null
    private var lastDispatchedChargedPokemonId: String? = null
    private var lastDispatchedChargedTimestampMs = 0L
    private var postCutsceneBannerTicks = 0

    // Player floating HP bar baseline & pre-Charged-Move baseline (to catch Fast Move Sneaks)
    private var matchStartRealtimeMs: Long = 0L
    private var refPlayerHpFillPx: Int? = null
    private var refPlayerHpBarY: Int = -1
    private var refPlayerHpStage: Int = 1
    private var preChargedMoveHpPx: Int? = null
    private var preChargedMoveHpBarY: Int = -1
    private var postOpponentCutsceneHpPx: Int? = null
    private var prevOrangeDrainPx: Int = 0
    private var higherHpConfirmTicks: Int = 0
    private var sustainedOnePxDropTicks: Int = 0
    private var onePxDropStartRealtimeMs: Long = 0L
    private var zeroOrangeDropTicks: Int = 0
    private var zeroOrangeDropStartRealtimeMs: Long = 0L
    private var lastZeroOrangeHpPx: Int = -1
    private var observedSingleHitDropPx: Int = 0
    private var hpBarOccludedTicks: Int = 0
    private var hpBarOccludedSinceRealtimeMs: Long = 0L
    private var lastPlayerOwnChargedCutsceneEndMs: Long = 0L
    private var postCutsceneDrainSettleUntilMs: Long = 0L
    private var lastAcceptedFastMoveHadOrange: Boolean = true
    private var lastAcceptedFastMoveWallMs: Long = 0L

    // OCR concurrency & throttling
    private var isOcrBusy = false
    private var lastOcrStartRealtimeMs = 0L
    private var lastOcrCompletedRealtimeMs = 0L

    private val lowDamageTwoTurnMoveNames = setOf(
        "Poison Sting", "Mud Shot", "Thunder Shock", "Fairy Wind", "Psycho Cut"
    )

    fun getActiveFastMove(entry: PvPokeEntry = currentPokemon): FastMove {
        val idx = (slotFastMoveIdx[entry.id] ?: 0).coerceIn(0, max(0, entry.fastMoves.size - 1))
        return entry.fastMoves[idx]
    }

    fun setStatusText(msg: String) {
        statusMessage = msg
        onUiStateChanged()
    }

    fun markMatchActiveForManualInput() {
        if (!inActiveMatch) {
            inActiveMatch = true
            matchStartRealtimeMs = SystemClock.elapsedRealtime() - 1000L
        }
    }

    fun resetAnalyzerAndSession(statusMsg: String, preLockedHpPx: Int? = null, preLockedBarY: Int = -1) {
        seenOpponentPokemon.clear()
        manualFormOverrideByBase.clear()
        hasLockedFirstRealOpponentInMatch = false
        pendingDynOpponentId = null
        pendingDynConfirmTicks = 0
        refPlayerHpFillPx = preLockedHpPx
        refPlayerHpBarY = preLockedBarY
        refPlayerHpStage = 1
        preChargedMoveHpPx = preLockedHpPx
        preChargedMoveHpBarY = preLockedBarY
        postOpponentCutsceneHpPx = null
        prevOrangeDrainPx = 0
        higherHpConfirmTicks = 0
        sustainedOnePxDropTicks = 0
        onePxDropStartRealtimeMs = 0L
        zeroOrangeDropTicks = 0
        zeroOrangeDropStartRealtimeMs = 0L
        lastZeroOrangeHpPx = -1
        observedSingleHitDropPx = 0
        hpBarOccludedTicks = 0
        hpBarOccludedSinceRealtimeMs = 0L
        lastPlayerOwnChargedCutsceneEndMs = 0L
        postCutsceneDrainSettleUntilMs = 0L
        lastAcceptedFastMoveHadOrange = true
        lastAcceptedFastMoveWallMs = 0L
        fastHitsLandedOnCurrentPlayer = 0
        latestEffectivenessHint = null
        chargedAttackDetectedDuringPause = false
        playerUsedChargedMoveDuringZoom = false
        playerOwnChargedBannerLockUntilMs = 0L
        specificMoveDetectedDuringPause = null
        hasDispatchedChargedMoveForCurrentCutscene = false
        hasCountedCutsceneIntroFastMove = false
        lastDispatchedChargedMove = null
        lastDispatchedChargedPokemonId = null
        lastDispatchedChargedTimestampMs = 0L
        postCutsceneBannerTicks = 0
        statusMessage = statusMsg

        val activeFm = getActiveFastMove()
        sessionManager.resetMatch(
            initialPokemonId = currentPokemon.id,
            durationTurns = activeFm.turns,
            energyGain = activeFm.energyGain,
            moveName = activeFm.name
        ) {
            onUiStateChanged()
        }
        onUiStateChanged()
    }

    /**
     * Cycles the opponent's fast move or regional sibling form when the user taps `[⇄Fast]`.
     */
    fun cycleFastMoveOrForm() {
        val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)

        if (curIdx + 1 < currentPokemon.fastMoves.size) {
            slotFastMoveIdx[currentPokemon.id] = curIdx + 1
            val newFm = getActiveFastMove()
            statusMessage = "Fast: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        } else if (siblings.size > 1) {
            val curFormIdx = siblings.indexOfFirst { it.id == currentPokemon.id }.coerceAtLeast(0)
            val nextForm = siblings[(curFormIdx + 1) % siblings.size]
            seenOpponentPokemon.remove(currentPokemon.id)
            seenOpponentPokemon[nextForm.id] = nextForm
            slotFastMoveIdx[nextForm.id] = 0
            val nextFm = nextForm.fastMoves.first()
            val baseKey = nextForm.name.substringBefore("(").trim().lowercase()
            manualFormOverrideByBase[baseKey] = nextForm.id
            currentPokemon = nextForm
            hasDispatchedChargedMoveForCurrentCutscene = false
            lastDispatchedChargedMove = null
            lastDispatchedChargedPokemonId = null
            statusMessage = "Form: ${nextForm.name}"
            sessionManager.onSwitch(
                newPokemonId = nextForm.id,
                durationTurns = nextFm.turns,
                energyGain = nextFm.energyGain,
                moveName = nextFm.name,
                transferOpeningEnergy = true,
                pauseForSwitchWindow = false
            ) {
                onUiStateChanged()
            }
        } else if (currentPokemon.fastMoves.size > 1) {
            slotFastMoveIdx[currentPokemon.id] = 0
            val newFm = getActiveFastMove()
            statusMessage = "Fast: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        }
    }

    /**
     * Dispatches a manual Charged Move badge tap to [BattleSessionManager].
     */
    fun onManualChargedMoveBadgeTap(cm: ChargedMove) {
        upgradeToSiblingFormIfMoveMatches(cm)
        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(cm.energyCost)
        statusMessage = "▼ Subtracted ${cm.name}"
        sessionManager.onChargedMoveSignal(
            cost = cm.energyCost,
            moveName = cm.name,
            pauseClock = false,
            forceManualTap = true
        ) {
            onUiStateChanged()
        }
    }

    private fun autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(requiredEnergy: Int? = null) {
        if (currentPokemon.fastMoves.size <= 1) return
        val snap = sessionManager.snapshotFlow.value
        val curCount = snap.displayedFastMoveCount
        if (curCount <= 0) return

        val minChargedCost = requiredEnergy
            ?: currentPokemon.chargedMoves.minOfOrNull { it.energyCost }
            ?: 35

        val activeFm = getActiveFastMove()
        if (snap.energy >= minChargedCost) return

        val matchingIdx = currentPokemon.fastMoves.indexOfFirst { candFm ->
            candFm.name != activeFm.name && (curCount * candFm.energyGain) >= minChargedCost
        }
        if (matchingIdx >= 0) {
            slotFastMoveIdx[currentPokemon.id] = matchingIdx
            val newFm = currentPokemon.fastMoves[matchingIdx]
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        }
    }

    private fun upgradeToSiblingFormIfMoveMatches(usedMove: ChargedMove) {
        if (currentPokemon.chargedMoves.any { it.name == usedMove.name }) return
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)
        val matchingSibling = siblings.firstOrNull { sib ->
            sib.chargedMoves.any { it.name == usedMove.name }
        } ?: return

        seenOpponentPokemon.remove(currentPokemon.id)
        seenOpponentPokemon[matchingSibling.id] = matchingSibling
        val newFm = getActiveFastMove(matchingSibling)
        val baseKey = matchingSibling.name.substringBefore("(").trim().lowercase()
        manualFormOverrideByBase[baseKey] = matchingSibling.id
        currentPokemon = matchingSibling

        sessionManager.onSwitch(
            newPokemonId = matchingSibling.id,
            durationTurns = newFm.turns,
            energyGain = newFm.energyGain,
            moveName = newFm.name,
            transferOpeningEnergy = true,
            pauseForSwitchWindow = false
        ) {
            onUiStateChanged()
        }
    }

    private fun dispatchChargedMoveSignal(cm: ChargedMove, pauseClock: Boolean) {
        upgradeToSiblingFormIfMoveMatches(cm)
        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(cm.energyCost)
        val now = SystemClock.elapsedRealtime()
        lastDispatchedChargedTimestampMs = now
        lastDispatchedChargedMove = cm
        lastDispatchedChargedPokemonId = currentPokemon.id
        hasDispatchedChargedMoveForCurrentCutscene = true
        statusMessage = "▼ Subtracted ${cm.name}"
        sessionManager.onChargedMoveSignal(
            cost = cm.energyCost,
            moveName = cm.name,
            pauseClock = pauseClock
        ) {
            onUiStateChanged()
        }
    }

    /**
     * Undoes a false opponent Charged Move subtraction ONLY if one was actually dispatched
     * during the current cutscene on the current opponent Pokémon.
     */
    private fun undoFalsePlayerChargedMoveIfNeeded() {
        val now = SystemClock.elapsedRealtime()
        val prevSub = lastDispatchedChargedMove ?: return
        if (
            hasDispatchedChargedMoveForCurrentCutscene &&
            lastDispatchedChargedPokemonId == currentPokemon.id &&
            (now - lastDispatchedChargedTimestampMs) <= 8000L
        ) {
            lastDispatchedChargedMove = null
            lastDispatchedChargedPokemonId = null
            lastDispatchedChargedTimestampMs = 0L
            hasDispatchedChargedMoveForCurrentCutscene = false
            sessionManager.undoChargedMove(prevSub.energyCost) {
                onUiStateChanged()
            }
        }
    }

    private fun handleDetectedPlayerOwnChargedMove(rawBannerText: String) {
        val now = SystemClock.elapsedRealtime()
        val bannerPlayerPoke = PvPokeRepository.matchPlayerPokemonFromOwnBanner(rawBannerText, currentPokemon.name)
        if (bannerPlayerPoke != null && bannerPlayerPoke.id != currentPlayerPokemonId) {
            currentPlayerPokemonId = bannerPlayerPoke.id
            currentPlayerPokemonName = bannerPlayerPoke.name
            playerDefenderTypes = PvPokeRepository.getDefenderTypes(bannerPlayerPoke)
        }
        if (refPlayerHpFillPx != null) {
            preChargedMoveHpPx = refPlayerHpFillPx
            preChargedMoveHpBarY = refPlayerHpBarY
        }
        playerUsedChargedMoveDuringZoom = true
        playerOwnChargedBannerLockUntilMs = max(playerOwnChargedBannerLockUntilMs, now + 1500L)
        chargedAttackDetectedDuringPause = false
        specificMoveDetectedDuringPause = null
        sustainedOnePxDropTicks = 0
        undoFalsePlayerChargedMoveIfNeeded()
        sessionManager.onMinigameStart {
            onUiStateChanged()
        }
        if (!statusMessage.startsWith("⚡")) {
            statusMessage = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
        }
        onUiStateChanged()
    }

    private fun reconcileChargedMoveFromBanner(actualMove: ChargedMove, pauseClock: Boolean) {
        upgradeToSiblingFormIfMoveMatches(actualMove)
        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(actualMove.energyCost)
        val now = SystemClock.elapsedRealtime()
        val prevSub = lastDispatchedChargedMove
        if (
            hasDispatchedChargedMoveForCurrentCutscene ||
            (prevSub != null && lastDispatchedChargedPokemonId == currentPokemon.id && (now - lastDispatchedChargedTimestampMs) <= 12000L)
        ) {
            if (prevSub != null && prevSub.name != actualMove.name) {
                lastDispatchedChargedMove = actualMove
                statusMessage = "▼ Used ${actualMove.name}!"
                sessionManager.reconcileChargedMoveCost(
                    previousCost = prevSub.energyCost,
                    actualCost = actualMove.energyCost,
                    actualMoveName = actualMove.name
                ) {
                    onUiStateChanged()
                }
            } else {
                statusMessage = "▼ Used ${actualMove.name}!"
                onUiStateChanged()
            }
        } else if ((now - lastDispatchedChargedTimestampMs) > 3500L) {
            dispatchChargedMoveSignal(actualMove, pauseClock = pauseClock)
        }
    }

    /**
     * Checks if the player's centered HP bar during the player's own Charged Move shows an uncounted
     * Fast Move Sneak from the opponent.
     */
    private fun checkCenteredHpBarForFastMoveSneak(
        barLen: Int,
        centeredHpPx: Int,
        centeredOrangePx: Int,
        nowRealtimeMs: Long
    ) {
        if (centeredHpPx <= 0 || hasCountedCutsceneIntroFastMove || chargedAttackDetectedDuringPause) return
        if (nowRealtimeMs < sessionManager.nextAllowedFastMoveRealtimeMs) return

        val preHp = preChargedMoveHpPx ?: refPlayerHpFillPx
        val isSneakDetected = if (preHp != null) {
            val drop = preHp - centeredHpPx
            drop in 2..(barLen * 0.35f).toInt()
        } else {
            centeredOrangePx in 4..(barLen * 0.28f).toInt()
        }

        if (isSneakDetected) {
            val activeFm = getActiveFastMove()
            sessionManager.onFastMoveSignal(allowDuringCutsceneIntro = true, count = 1) { accepted, updatedSnap ->
                if (accepted) {
                    hasCountedCutsceneIntroFastMove = true
                    preChargedMoveHpPx = centeredHpPx
                    refPlayerHpFillPx = centeredHpPx
                    fastHitsLandedOnCurrentPlayer++
                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                    statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (Sneak · ${updatedSnap.energy}E)"
                    onUiStateChanged()
                }
            }
        }
    }

    /**
     * Evaluates whether the player's floating HP bar dropped and dispatches `sessionManager.onFastMoveSignal()`.
     */
    private fun evaluatePlayerHpBarAndDispatchSignal(
        barLen: Int,
        hpPx: Int,
        hpBarY: Int,
        hpStage: Int,
        orangeDrainPx: Int,
        emptyAfterFillPx: Int,
        nowRealtimeMs: Long,
        allowDuringCutsceneIntro: Boolean = false
    ): Boolean {
        if (hpPx <= 0 || hpBarY <= 0) return false

        if (!allowDuringCutsceneIntro && (playerUsedChargedMoveDuringZoom || nowRealtimeMs < playerOwnChargedBannerLockUntilMs)) {
            return false
        }

        if (!allowDuringCutsceneIntro && nowRealtimeMs < postCutsceneDrainSettleUntilMs) {
            refPlayerHpFillPx = if (refPlayerHpFillPx == null) hpPx else min(refPlayerHpFillPx!!, hpPx)
            refPlayerHpBarY = hpBarY
            refPlayerHpStage = hpStage
            preChargedMoveHpPx = refPlayerHpFillPx
            preChargedMoveHpBarY = hpBarY
            prevOrangeDrainPx = orangeDrainPx
            higherHpConfirmTicks = 0
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        val snapshot = sessionManager.snapshotFlow.value
        val activeFm = getActiveFastMove()
        val isOneTurnMove = (activeFm.turns == 1)
        val isTwoTurnMove = (activeFm.turns == 2)
        val hasOrangeSignal = (orangeDrainPx >= 1 || prevOrangeDrainPx >= 1)
        val maxFastDropPx = when {
            isOneTurnMove -> (barLen * 0.36f).toInt()
            isTwoTurnMove -> (barLen * 0.52f).toInt()
            else -> (barLen * 0.72f).toInt()
        }

        val prevHpPx = refPlayerHpFillPx
        if (prevHpPx == null) {
            refPlayerHpFillPx = hpPx
            refPlayerHpBarY = hpBarY
            refPlayerHpStage = hpStage
            preChargedMoveHpPx = hpPx
            preChargedMoveHpBarY = hpBarY
            prevOrangeDrainPx = orangeDrainPx
            higherHpConfirmTicks = 0
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        // Adaptive vertical camera sway / tall-vs-short Pokémon switch re-anchor
        val maxCameraSwayY = max(34, (barLen * 0.28f).toInt())
        if (refPlayerHpBarY > 0 && abs(hpBarY - refPlayerHpBarY) > maxCameraSwayY) {
            val candidateDrop = prevHpPx - hpPx
            val isSameOrNextStageFastDrop =
                hpStage in refPlayerHpStage..(refPlayerHpStage + 1) &&
                    candidateDrop in 1..maxFastDropPx &&
                    abs(hpBarY - refPlayerHpBarY) <= max(54, (barLen * 0.42f).toInt())
            if (!isSameOrNextStageFastDrop) {
                refPlayerHpFillPx = hpPx
                refPlayerHpBarY = hpBarY
                refPlayerHpStage = hpStage
                preChargedMoveHpPx = hpPx
                preChargedMoveHpBarY = hpBarY
                prevOrangeDrainPx = orangeDrainPx
                higherHpConfirmTicks = 0
                sustainedOnePxDropTicks = 0
                onePxDropStartRealtimeMs = 0L
                observedSingleHitDropPx = 0
                return false
            }
        }

        // Allow direct Stage 1 (Green) -> Stage 3 (Red) jumps when a super-effective attack deals heavy damage
        if (refPlayerHpStage == 1 && hpStage == 3 && prevHpPx > (barLen * 0.78f).toInt() && !hasOrangeSignal) {
            return false
        }

        val prevBarY = refPlayerHpBarY
        refPlayerHpBarY = hpBarY
        refPlayerHpStage = hpStage

        // Move-Turn-Scaled Opening Camera-Settle Guard:
        // Follow current settled hpPx (NOT max(prevHpPx, hpPx)) so zoomed-in "GO!" peak width is never pinned!
        val openingSettleMs = if (orangeDrainPx >= 2) {
            max(650L, activeFm.turns * 450L)
        } else {
            max(1250L, activeFm.turns * 500L + 350L)
        }
        if ((nowRealtimeMs - matchStartRealtimeMs) < openingSettleMs) {
            refPlayerHpFillPx = hpPx
            preChargedMoveHpPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        // Upward Re-Lock when switching in a healthier Pokémon OR recovering from a partial bar occlusion (>=3px)
        val isLargeSwitchUp = hpPx > prevHpPx + max(6, barLen / 14)
        val isSmallOcclusionRecovery = hpPx >= prevHpPx + 3 && orangeDrainPx == 0 && hpStage <= refPlayerHpStage
        if (isLargeSwitchUp || isSmallOcclusionRecovery) {
            higherHpConfirmTicks++
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            if (higherHpConfirmTicks >= 2) {
                refPlayerHpFillPx = hpPx
                preChargedMoveHpPx = hpPx
                prevOrangeDrainPx = orangeDrainPx
                higherHpConfirmTicks = 0
                if (isLargeSwitchUp) {
                    observedSingleHitDropPx = 0
                }
            }
            return false
        } else {
            higherHpConfirmTicks = 0
        }

        val dropPx = prevHpPx - hpPx

        // 100% Full-Bar Unbroken-Green Guard: when green fill still touches the right white border (emptyAfterFillPx <= 3)
        // with zero orange drain, any 1..4px change is purely left/right border anti-aliasing on an undamaged full HP bar!
        if (
            dropPx in 1..4 &&
            hpPx >= barLen - max(5, barLen / 22) &&
            emptyAfterFillPx <= 3 &&
            orangeDrainPx == 0 &&
            prevOrangeDrainPx == 0
        ) {
            refPlayerHpFillPx = hpPx
            preChargedMoveHpPx = hpPx
            prevOrangeDrainPx = 0
            zeroOrangeDropTicks = 0
            return false
        }

        // During cutscene zoom-in (allowDuringCutsceneIntro == true), the camera pans/zooms and foreshortens the HP bar
        // by 1..4px with 0 orange drain (e.g. when Nidoqueen starts her Charged Move in 18760.jpg).
        // Require active orange drain (orangeDrainPx >= 2) for any cutscene-intro fast move!
        if (allowDuringCutsceneIntro && orangeDrainPx < 2 && dropPx < 5) {
            prevOrangeDrainPx = orangeDrainPx
            zeroOrangeDropTicks = 0
            return false
        }

        // Ignore massive single-frame drops exceeding maxFastDropPx
        if (dropPx > maxFastDropPx) {
            refPlayerHpFillPx = hpPx
            preChargedMoveHpPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        val lastAcceptMs = sessionManager.lastAcceptedFastMoveRealtimeMs
        val elapsedSinceLastAccept = nowRealtimeMs - lastAcceptMs
        val sameHitSettleWindowMs = when (activeFm.turns) {
            1 -> 220L
            2 -> 360L
            else -> 420L
        }

        // Absorb multi-frame HP bar / orange drain settling ONLY during the first 220..420ms after a registered hit!
        // NEVER overwrite refPlayerHpFillPx after sameHitSettleWindowMs while waiting for nextAllowedMs,
        // otherwise a slightly late confirmation on Volt Switch #1 swallows Volt Switch #2!
        if (sameHitSettleWindowMs > 0L && lastAcceptMs > 0L && elapsedSinceLastAccept < sameHitSettleWindowMs) {
            if (dropPx in 1..maxFastDropPx) {
                val isGenuineSettle =
                    dropPx <= 5 || orangeDrainPx > 0 || prevOrangeDrainPx > 0 ||
                        (zeroOrangeDropTicks >= 1 && hpPx <= lastZeroOrangeHpPx + 1 && abs(hpPx - lastZeroOrangeHpPx) <= 4)
                if (isGenuineSettle) {
                    refPlayerHpFillPx = hpPx
                    preChargedMoveHpPx = hpPx
                    if (observedSingleHitDropPx > 0) {
                        observedSingleHitDropPx = min(maxFastDropPx, observedSingleHitDropPx + dropPx)
                    }
                    zeroOrangeDropTicks = 0
                } else {
                    zeroOrangeDropTicks = 1
                    zeroOrangeDropStartRealtimeMs = nowRealtimeMs
                    lastZeroOrangeHpPx = hpPx
                }
            } else {
                zeroOrangeDropTicks = 0
            }
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            return false
        }

        val nextAllowedMs = sessionManager.nextAllowedFastMoveRealtimeMs
        if (!allowDuringCutsceneIntro && nowRealtimeMs < nextAllowedMs) {
            prevOrangeDrainPx = orangeDrainPx
            return false
        }

        val moveDurationMs = activeFm.turns * 500L
        val canDispatchNow =
            snapshot.state == BattleState.ACTIVE ||
                (allowDuringCutsceneIntro && !hasCountedCutsceneIntroFastMove)

        if (dropPx <= 0) {
            // Sub-pixel <1px extremely resisted hit into super-bulky Pokémon (e.g. Azumarill 192 HP, Bastiodon 142 HP):
            // When integer hpPx rounds to the same pixel (dropPx == 0) but a fresh 1..4px orange drain pulse appears
            // at the tip after a full move period, credit the 1-HP resisted hit!
            if (
                canDispatchNow &&
                dropPx == 0 &&
                orangeDrainPx in 1..4 &&
                prevOrangeDrainPx == 0 &&
                observedSingleHitDropPx <= 2 &&
                (lastAcceptMs == 0L || elapsedSinceLastAccept >= (moveDurationMs * 0.88f).toLong())
            ) {
                prevOrangeDrainPx = orangeDrainPx
                sustainedOnePxDropTicks = 0
                onePxDropStartRealtimeMs = 0L
                if (observedSingleHitDropPx == 0) {
                    observedSingleHitDropPx = 1
                }
                sessionManager.onFastMoveSignal(
                    allowDuringCutsceneIntro = allowDuringCutsceneIntro,
                    count = 1,
                    advanceTimestampByMs = nowRealtimeMs
                ) { accepted, updatedSnap ->
                    if (accepted) {
                        refPlayerHpFillPx = hpPx
                        preChargedMoveHpPx = hpPx
                        fastHitsLandedOnCurrentPlayer += 1
                        if (allowDuringCutsceneIntro) {
                            hasCountedCutsceneIntroFastMove = true
                            autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                        }
                        statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (${updatedSnap.energy}E)"
                        onUiStateChanged()
                    }
                }
                return true
            }

            if (
                snapshot.totalFastMovesInMatch == 0 &&
                emptyAfterFillPx <= 2 &&
                orangeDrainPx == 0 &&
                hpPx > prevHpPx
            ) {
                refPlayerHpFillPx = hpPx
                preChargedMoveHpPx = hpPx
            }
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        // Handle 1px drops:
        // - For 3/4/5-turn moves (Volt Switch, Incinerate, Snarl, etc.), a 1px change with 0 orange drain is ALWAYS anti-aliasing jitter.
        // - For 1/2-turn moves (Dragon Breath, Poison Sting, Fairy Wind), accept immediately if orangeDrainPx >= 1,
        //   or after 3 sustained ticks (300ms) with effectiveHitTimeMs backdated to tick 1 (onePxDropStartRealtimeMs)
        //   so zero lockout drift ever accumulates!
        var effectiveHitTimeMs = nowRealtimeMs
        if (dropPx == 1) {
            zeroOrangeDropTicks = 0
            if (orangeDrainPx == 0 && prevOrangeDrainPx == 0) {
                if (activeFm.turns >= 3) {
                    prevOrangeDrainPx = 0
                    return false
                }
                if (sustainedOnePxDropTicks == 0) {
                    onePxDropStartRealtimeMs = nowRealtimeMs
                }
                sustainedOnePxDropTicks++
                if (sustainedOnePxDropTicks < 3) {
                    prevOrangeDrainPx = orangeDrainPx
                    return false
                }
                effectiveHitTimeMs = onePxDropStartRealtimeMs
            }
        } else {
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            // When dropPx >= 6 with ZERO orange drain on both current and previous frame, require 2 consecutive
            // ticks (hpPx <= lastZeroOrangeHpPx + 1 and within 4px) to reject transient dark obstructions
            // (e.g. a Pokémon's dark ear/wing poking through the bar, dark Shadow smoke puffs, or rock/mud debris),
            // while allowing 2..5px fast-move steps (such as Dragon Breath or Fairy Wind under cyan/purple particle
            // tint) to fire immediately on Tick 1 and backdating >=6px hits to zeroOrangeDropStartRealtimeMs!
            // Same-Height Damaged Switch-In Guard: if the player switches in a previously damaged Pokémon of similar
            // height, the HP bar jumps down by >= 14px (and > 2x observedSingleHitDropPx + 4) with ZERO orange drain
            // on both frames and without a long multi-move wing occlusion -> re-anchor without firing a false hit!
            if (
                dropPx >= max(14, barLen / 11) &&
                orangeDrainPx == 0 &&
                prevOrangeDrainPx == 0 &&
                hpBarOccludedTicks < 5 &&
                observedSingleHitDropPx in 1..6 &&
                dropPx > observedSingleHitDropPx * 2 + 4
            ) {
                refPlayerHpFillPx = hpPx
                preChargedMoveHpPx = hpPx
                prevOrangeDrainPx = 0
                zeroOrangeDropTicks = 0
                observedSingleHitDropPx = 0
                return false
            }

            if (dropPx >= 2 && orangeDrainPx == 0 && prevOrangeDrainPx == 0 && !allowDuringCutsceneIntro && hpBarOccludedTicks < 2) {
                val isCameraPanningY = prevBarY > 0 && abs(hpBarY - prevBarY) >= 5
                if (isCameraPanningY || zeroOrangeDropTicks == 0 || hpPx > lastZeroOrangeHpPx + 1 || abs(hpPx - lastZeroOrangeHpPx) > 4) {
                    zeroOrangeDropTicks = if (isCameraPanningY) 0 else 1
                    zeroOrangeDropStartRealtimeMs = nowRealtimeMs
                    lastZeroOrangeHpPx = hpPx
                    prevOrangeDrainPx = orangeDrainPx
                    return false
                }
                zeroOrangeDropTicks++
                effectiveHitTimeMs = zeroOrangeDropStartRealtimeMs
            } else {
                zeroOrangeDropTicks = 0
            }
        }

        // If the HP bar was temporarily occluded during active combat (e.g. by the player's Altaria wings swaying
        // across the HP bar for >= 2 ticks) and reappears with a drop, backdate effectiveHitTimeMs to the cadence
        // window inside [hpBarOccludedSinceRealtimeMs .. nowRealtimeMs] so the NEXT fast move is never swallowed!
        val wasWingOccluded = hpBarOccludedTicks >= 2 && hpBarOccludedSinceRealtimeMs > 0L
        if (wasWingOccluded && lastAcceptMs > 0L && !allowDuringCutsceneIntro) {
            val cadenceTargetMs = lastAcceptMs + moveDurationMs
            effectiveHitTimeMs = max(hpBarOccludedSinceRealtimeMs, min(effectiveHitTimeMs, cadenceTargetMs))
        }

        prevOrangeDrainPx = orangeDrainPx

        if (canDispatchNow) {
            val defaultStepPx = max(2, (barLen * 0.022f).roundToInt())
            val movesToCredit: Int
            val nextRefHp: Int
            val newAcceptTimestampMs: Long

            if (isOneTurnMove && !allowDuringCutsceneIntro) {
                if (lastAcceptMs <= 0L || elapsedSinceLastAccept < 900L) {
                    movesToCredit = 1
                    nextRefHp = hpPx
                    newAcceptTimestampMs = effectiveHitTimeMs
                    if (observedSingleHitDropPx == 0) {
                        observedSingleHitDropPx = dropPx.coerceIn(1, maxFastDropPx)
                    }
                } else if (observedSingleHitDropPx == 1 && dropPx in 1..2 && elapsedSinceLastAccept in 880L..1450L) {
                    movesToCredit = 2
                    nextRefHp = hpPx
                    newAcceptTimestampMs = effectiveHitTimeMs
                } else {
                    val turnPeriodMs = 450L
                    val nominalPeriodMs = 480L
                    val maxCatchUp = 4
                    val stepPx = max(defaultStepPx, observedSingleHitDropPx)
                    val turnsByElapsed = max(1, (elapsedSinceLastAccept / turnPeriodMs).toInt())
                    val turnsByDrop = max(1, (dropPx.toFloat() / stepPx.toFloat()).roundToInt())
                    movesToCredit = min(turnsByElapsed, turnsByDrop).coerceIn(1, maxCatchUp)
                    nextRefHp = if (movesToCredit < turnsByDrop) {
                        max(hpPx, prevHpPx - movesToCredit * stepPx)
                    } else {
                        hpPx
                    }
                    newAcceptTimestampMs = min(
                        effectiveHitTimeMs,
                        max(effectiveHitTimeMs - turnPeriodMs, lastAcceptMs + movesToCredit * nominalPeriodMs)
                    )
                }
            } else {
                // For 2+ turn moves:
                // 1) Catch up 2 moves when the HP bar was occluded by wings/animations for >= 5 ticks and 2 full move periods elapsed
                //    with a drop of >= 2 * observedSingleHitDropPx - 1.
                // 2) Catch up 2 moves when an ultra-resisted (<1px/hit, observedSingleHitDropPx == 1) move accumulated across 2 periods.
                val effElapsedFromLast = nowRealtimeMs - lastAcceptMs
                if (
                    !allowDuringCutsceneIntro &&
                    lastAcceptMs > 0L &&
                    hpBarOccludedTicks >= 5 &&
                    observedSingleHitDropPx >= 2 &&
                    effElapsedFromLast >= (2 * moveDurationMs - 150L) &&
                    dropPx >= (observedSingleHitDropPx * 2 - 1)
                ) {
                    movesToCredit = min(3, (dropPx.toFloat() / observedSingleHitDropPx.toFloat()).roundToInt().coerceAtLeast(2))
                    effectiveHitTimeMs = min(
                        nowRealtimeMs,
                        max(hpBarOccludedSinceRealtimeMs, lastAcceptMs + movesToCredit * moveDurationMs)
                    )
                } else if (
                    !allowDuringCutsceneIntro &&
                    lastAcceptMs > 0L &&
                    observedSingleHitDropPx == 1 &&
                    dropPx in 1..2 &&
                    effElapsedFromLast in (2 * moveDurationMs - 180L)..(2 * moveDurationMs + 450L)
                ) {
                    movesToCredit = 2
                } else {
                    movesToCredit = 1
                }
                nextRefHp = hpPx
                newAcceptTimestampMs = effectiveHitTimeMs
                if (observedSingleHitDropPx == 0) {
                    observedSingleHitDropPx = dropPx.coerceIn(1, maxFastDropPx)
                }
            }

            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0

            val hitHadOrange = hasOrangeSignal
            sessionManager.onFastMoveSignal(
                allowDuringCutsceneIntro = allowDuringCutsceneIntro,
                count = movesToCredit,
                advanceTimestampByMs = newAcceptTimestampMs
            ) { accepted, updatedSnap ->
                if (accepted) {
                    refPlayerHpFillPx = nextRefHp
                    preChargedMoveHpPx = nextRefHp
                    fastHitsLandedOnCurrentPlayer += movesToCredit
                    lastAcceptedFastMoveHadOrange = hitHadOrange
                    lastAcceptedFastMoveWallMs = nowRealtimeMs
                    if (allowDuringCutsceneIntro) {
                        hasCountedCutsceneIntroFastMove = true
                        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                    }
                    statusMessage = "⚡ [$overlayVersion] +$movesToCredit ${activeFm.name} (${updatedSnap.energy}E)"
                    onUiStateChanged()
                }
            }
            return true
        }

        return false
    }

    private fun isPlayerBubbleMinigameText(rawText: String): Boolean {
        val lower = rawText.lowercase()
        return lower.contains("nice!") ||
            lower.contains("great!") ||
            lower.contains("excellent!") ||
            lower.contains("swipe")
    }

    /**
     * Analyzes the latest captured frame and dispatches battle state / move signals to [sessionManager].
     */
    fun processFrame(image: Image, overlayRect: OverlayImageRect?, tickMs: Long) {
        val nowRealtimeMs = SystemClock.elapsedRealtime()
        if (isOcrBusy && nowRealtimeMs - lastOcrStartRealtimeMs > 2500L) {
            isOcrBusy = false
        }

        var telemetry = FrameVisualTelemetry(
            true, false, false, false, 66, -1, -1, 0, 0, 99, -1, 0, emptySet()
        )
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var aboveHpEffBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        val shouldRunOcrThisTick = !isOcrBusy && (nowRealtimeMs - lastOcrCompletedRealtimeMs >= 300L)

        try {
            telemetry = analyzeFrameVisualTelemetry(image, overlayRect)
            val isWideArenaCombat = telemetry.isBattleHudVisible && telemetry.playerHpFillPx > 0

            if (telemetry.isFrameNonBlack) {
                if (isWideArenaCombat) {
                    if (currentPokemon.fastMoves.size > 1) {
                        arenaVisualBmp = cropRegionFromImage(image, 0.05f, 0.16f, 0.48f, 0.78f, step = 2)
                    }
                    if (shouldRunOcrThisTick) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.095f, step = 1)
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.46f, 0.110f, step = 1)
                        if (postCutsceneBannerTicks > 0) {
                            bannerBmp = cropRegionFromImage(
                                image, 0.06f, 0.18f, 0.92f, 0.42f, step = 1, maskOverlayRect = null
                            )
                        } else if (telemetry.playerHpBarY > 10 && currentPokemon.fastMoves.size > 1) {
                            val hpYRatio = telemetry.playerHpBarY.toFloat() / image.height
                            val effTop = max(0.02f, hpYRatio - 0.050f)
                            val effBot = max(effTop + 0.02f, hpYRatio - 0.003f)
                            aboveHpEffBmp = cropRegionFromImage(
                                image, 0.02f, effTop, 0.50f, effBot, step = 1, maskOverlayRect = overlayRect
                            )
                        }
                    }
                } else if (shouldRunOcrThisTick) {
                    bannerBmp = if (telemetry.isBattleHudVisible) {
                        cropRegionFromImage(
                            image, 0.06f, 0.18f, 0.92f, 0.46f, step = 1, maskOverlayRect = null
                        )
                    } else {
                        cropRegionFromImage(
                            image, 0.06f, 0.18f, 0.92f, 0.88f, step = 1, maskOverlayRect = null
                        )
                    }
                    if (telemetry.isBattleHudVisible) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.095f, step = 1)
                    }
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        if (!telemetry.isFrameNonBlack) {
            return
        }

        val badgeTypesThisFrame = telemetry.opponentBadgeTypes

        if (telemetry.isBattleHudVisible) {
            if (postCutsceneBannerTicks > 0) {
                postCutsceneBannerTicks--
                if (postCutsceneBannerTicks == 0) {
                    sessionManager.clearCutsceneEnergySnapshot()
                    hasDispatchedChargedMoveForCurrentCutscene = false
                }
            }

            if (!inActiveMatch) {
                inActiveMatch = true
                matchStartRealtimeMs = nowRealtimeMs
                val initialHp = telemetry.playerHpFillPx.takeIf { it > 0 }
                val initialY = if (initialHp != null) telemetry.playerHpBarY else -1
                resetAnalyzerAndSession(
                    statusMsg = "● [$overlayVersion] Battle Active",
                    preLockedHpPx = initialHp,
                    preLockedBarY = initialY
                )
            } else if (!isBattleHudCurrentlyVisible && hudCompletelyMissingDurationMs >= 1000L) {
                postCutsceneBannerTicks = 28

                val wasOpponentChargedMove =
                    !playerUsedChargedMoveDuringZoom &&
                        nowRealtimeMs >= playerOwnChargedBannerLockUntilMs &&
                        (chargedAttackDetectedDuringPause ||
                            specificMoveDetectedDuringPause != null ||
                            hasDispatchedChargedMoveForCurrentCutscene)

                postCutsceneDrainSettleUntilMs = nowRealtimeMs + 1250L

                if (wasOpponentChargedMove) {
                    playerUsedChargedMoveDuringZoom = false
                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(specificMoveDetectedDuringPause?.energyCost)
                    if (!hasDispatchedChargedMoveForCurrentCutscene) {
                        val snapEnergy = sessionManager.snapshotFlow.value.energy
                        val moveToSub = specificMoveDetectedDuringPause ?: run {
                            currentPokemon.chargedMoves.firstOrNull { snapEnergy >= it.energyCost }
                                ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                        }
                        if (moveToSub != null && nowRealtimeMs - lastDispatchedChargedTimestampMs > 3000L) {
                            dispatchChargedMoveSignal(moveToSub, pauseClock = false)
                        }
                    }
                    refPlayerHpFillPx = null
                    refPlayerHpBarY = -1
                    preChargedMoveHpPx = null
                    postOpponentCutsceneHpPx = null
                    prevOrangeDrainPx = 0
                    higherHpConfirmTicks = 0
                    sustainedOnePxDropTicks = 0
                    hasCountedCutsceneIntroFastMove = false
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = false) {
                        onUiStateChanged()
                    }
                } else {
                    if (playerUsedChargedMoveDuringZoom) {
                        lastPlayerOwnChargedCutsceneEndMs = nowRealtimeMs
                    }
                    if (preChargedMoveHpPx != null) {
                        refPlayerHpFillPx = preChargedMoveHpPx
                        refPlayerHpBarY = preChargedMoveHpBarY
                    }
                    hasDispatchedChargedMoveForCurrentCutscene = false
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = true) {
                        onUiStateChanged()
                    }
                }

                chargedAttackDetectedDuringPause = false
                if (telemetry.playerHpFillPx > 0 && nowRealtimeMs >= playerOwnChargedBannerLockUntilMs) {
                    playerUsedChargedMoveDuringZoom = false
                    hasCountedCutsceneIntroFastMove = false
                }
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudCompletelyMissingDurationMs = 0L

            if (telemetry.playerHpFillPx <= 0 && telemetry.centeredHpFillPx > 0) {
                checkCenteredHpBarForFastMoveSneak(
                    barLen = telemetry.barLenPx,
                    centeredHpPx = telemetry.centeredHpFillPx,
                    centeredOrangePx = telemetry.centeredOrangeDrainPx,
                    nowRealtimeMs = nowRealtimeMs
                )
            }

            if (
                nowRealtimeMs >= playerOwnChargedBannerLockUntilMs &&
                sessionManager.snapshotFlow.value.state != BattleState.ACTIVE
            ) {
                playerUsedChargedMoveDuringZoom = false
                sessionManager.onMinigameEnd(clearCutsceneSnapshot = false) {
                    onUiStateChanged()
                }
            }

            if (telemetry.playerHpFillPx <= 0) {
                if (hpBarOccludedTicks == 0) {
                    hpBarOccludedSinceRealtimeMs = nowRealtimeMs
                }
                hpBarOccludedTicks++
            }

            if (telemetry.playerHpFillPx > 0 && nowRealtimeMs >= playerOwnChargedBannerLockUntilMs) {
                if (playerUsedChargedMoveDuringZoom) {
                    playerUsedChargedMoveDuringZoom = false
                    lastPlayerOwnChargedCutsceneEndMs = nowRealtimeMs
                    val preHp = preChargedMoveHpPx
                    val minSneakPx = if (observedSingleHitDropPx == 1) 1 else 2
                    val maxSneakPx = (telemetry.barLenPx * 0.72f).toInt()
                    if (
                        !hasCountedCutsceneIntroFastMove &&
                        preHp != null &&
                        (preHp - telemetry.playerHpFillPx) in minSneakPx..maxSneakPx
                    ) {
                        hasCountedCutsceneIntroFastMove = true
                        val activeFm = getActiveFastMove()
                        sessionManager.onFastMoveSignal(allowDuringCutsceneIntro = true, count = 1) { accepted, updatedSnap ->
                            if (accepted) {
                                fastHitsLandedOnCurrentPlayer++
                                autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                                statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (Sneak · ${updatedSnap.energy}E)"
                                onUiStateChanged()
                            }
                        }
                    }
                    hasCountedCutsceneIntroFastMove = false
                    refPlayerHpFillPx = telemetry.playerHpFillPx
                    refPlayerHpBarY = telemetry.playerHpBarY
                    refPlayerHpStage = telemetry.playerHpStage
                    preChargedMoveHpPx = telemetry.playerHpFillPx
                    preChargedMoveHpBarY = telemetry.playerHpBarY
                    prevOrangeDrainPx = telemetry.orangeDrainPx
                    higherHpConfirmTicks = 0
                    sustainedOnePxDropTicks = 0
                } else {
                    val justDispatchedHit = evaluatePlayerHpBarAndDispatchSignal(
                        barLen = telemetry.barLenPx,
                        hpPx = telemetry.playerHpFillPx,
                        hpBarY = telemetry.playerHpBarY,
                        hpStage = telemetry.playerHpStage,
                        orangeDrainPx = telemetry.orangeDrainPx,
                        emptyAfterFillPx = telemetry.emptyAfterFillPx,
                        nowRealtimeMs = nowRealtimeMs,
                        allowDuringCutsceneIntro = false
                    )
                    hpBarOccludedTicks = 0
                    hpBarOccludedSinceRealtimeMs = 0L

                    if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                        val curActiveIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                        val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                            arenaVisualBmp,
                            currentPokemon,
                            curActiveIdx,
                            latestEffectivenessHint,
                            playerDefenderTypes,
                            fastHitsLandedOnCurrentPlayer,
                            justDispatchedHit
                        )
                        if (detectedFmIdx != null && detectedFmIdx != curActiveIdx) {
                            slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                            val newFm = getActiveFastMove()
                            statusMessage = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                            sessionManager.configureFastMove(
                                durationTurns = newFm.turns,
                                energyGain = newFm.energyGain,
                                moveName = newFm.name,
                                preserveMoveCount = true
                            ) {
                                onUiStateChanged()
                            }
                        }
                    }
                }
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartRealtimeMs = nowRealtimeMs
                recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        var matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text, badgeTypesThisFrame)
                        if (matchedPoke != null) {
                            val baseKey = matchedPoke.name.substringBefore("(").trim().lowercase()
                            val manualId = manualFormOverrideByBase[baseKey]
                            if (manualId != null) {
                                val manualEntry = PvPokeRepository.getSiblingForms(matchedPoke).firstOrNull { it.id == manualId }
                                if (manualEntry != null) matchedPoke = manualEntry
                            }

                            val isRealPoke = !matchedPoke.id.startsWith("dyn_")
                            if (!isRealPoke && hasLockedFirstRealOpponentInMatch) {
                                val curBase = currentPokemon.name.substringBefore("(").trim().lowercase()
                                if (baseKey == curBase || baseKey.length < 4) {
                                    return@addOnSuccessListener
                                }
                                if (pendingDynOpponentId == matchedPoke.id) {
                                    pendingDynConfirmTicks++
                                } else {
                                    pendingDynOpponentId = matchedPoke.id
                                    pendingDynConfirmTicks = 1
                                }
                                if (pendingDynConfirmTicks < 2) {
                                    return@addOnSuccessListener
                                }
                            } else {
                                pendingDynOpponentId = null
                                pendingDynConfirmTicks = 0
                            }

                            seenOpponentPokemon[matchedPoke.id] = matchedPoke

                            val wasFirstLock = !hasLockedFirstRealOpponentInMatch && isRealPoke
                            if (wasFirstLock) {
                                hasLockedFirstRealOpponentInMatch = true
                                if (matchedPoke.id != currentPokemon.id) {
                                    seenOpponentPokemon.remove(currentPokemon.id)
                                }
                            }

                            if (matchedPoke.id != currentPokemon.id) {
                                val prevBaseKey = currentPokemon.name.substringBefore("(").trim().lowercase()
                                val isSameBaseOrOpeningSwap =
                                    wasFirstLock || (prevBaseKey == baseKey)
                                if (isSameBaseOrOpeningSwap) {
                                    seenOpponentPokemon.remove(currentPokemon.id)
                                }
                                currentPokemon = matchedPoke
                                fastHitsLandedOnCurrentPlayer = 0
                                observedSingleHitDropPx = 0
                                latestEffectivenessHint = null
                                hasDispatchedChargedMoveForCurrentCutscene = false
                                lastDispatchedChargedMove = null
                                lastDispatchedChargedPokemonId = null
                                visualClassifier.resetForNewOpponent()

                                val newFm = getActiveFastMove(matchedPoke)
                                val elapsedSinceMatchStart = SystemClock.elapsedRealtime() - matchStartRealtimeMs
                                val canTransferOnFirstLock =
                                    (prevBaseKey == baseKey) ||
                                        (wasFirstLock && elapsedSinceMatchStart >= max(1400L, newFm.turns * 500L + 400L))
                                sessionManager.onSwitch(
                                    newPokemonId = matchedPoke.id,
                                    durationTurns = newFm.turns,
                                    energyGain = newFm.energyGain,
                                    moveName = newFm.name,
                                    transferOpeningEnergy = canTransferOnFirstLock,
                                    pauseForSwitchWindow = false
                                ) { snap ->
                                    statusMessage = if (snap.energy > 0) {
                                        "🔄 Restored ${matchedPoke.name}: ${snap.displayedFastMoveCount} Fast (${snap.energy}E)"
                                    } else {
                                        "● Locked: ${matchedPoke.name}"
                                    }
                                    onUiStateChanged()
                                }
                            } else if (
                                !statusMessage.startsWith("⚡") &&
                                !statusMessage.startsWith("▼") &&
                                !statusMessage.startsWith("🔄")
                            ) {
                                statusMessage = "● [$overlayVersion] Watching ${matchedPoke.name}"
                                onUiStateChanged()
                            }
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val rawLeft = leftText.text
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(rawLeft)
                                    if (
                                        playerPoke != null &&
                                        playerPoke.id != currentPlayerPokemonId
                                    ) {
                                        currentPlayerPokemonId = playerPoke.id
                                        currentPlayerPokemonName = playerPoke.name
                                        playerDefenderTypes = PvPokeRepository.getDefenderTypes(playerPoke)
                                        fastHitsLandedOnCurrentPlayer = 0
                                        observedSingleHitDropPx = 0
                                        latestEffectivenessHint = null
                                    }
                                }
                                .addOnCompleteListener {
                                    val nextBmp = bannerBmp ?: aboveHpEffBmp
                                    val isBannerCrop = (bannerBmp != null)
                                    if (nextBmp != null) {
                                        recognizer.process(InputImage.fromBitmap(nextBmp, 0))
                                            .addOnSuccessListener { subText ->
                                                val rawS = subText.text
                                                if (!isBannerCrop) {
                                                    val (_, _, effH) =
                                                        PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    if (effH != null) latestEffectivenessHint = effH
                                                } else if (
                                                    isPlayerBubbleMinigameText(rawS) ||
                                                    PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                                        rawS,
                                                        currentPlayerPokemonName,
                                                        currentPokemon.name
                                                    )
                                                ) {
                                                    handleDetectedPlayerOwnChargedMove(rawS)
                                                } else {
                                                    val (_, specificMove, _) =
                                                        PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    val recentlyFinishedOwnMove =
                                                        (SystemClock.elapsedRealtime() - lastPlayerOwnChargedCutsceneEndMs) < 2500L
                                                    if (specificMove != null && !recentlyFinishedOwnMove) {
                                                        reconcileChargedMoveFromBanner(specificMove, pauseClock = false)
                                                        postCutsceneBannerTicks = 0
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                                lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                                isOcrBusy = false
                                            }
                                    } else {
                                        lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                        isOcrBusy = false
                                    }
                                }
                        } else if (bannerBmp != null) {
                            recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                                .addOnSuccessListener { bText ->
                                    val rawB = bText.text
                                    if (
                                        isPlayerBubbleMinigameText(rawB) ||
                                        PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                            rawB,
                                            currentPlayerPokemonName,
                                            currentPokemon.name
                                        )
                                    ) {
                                        handleDetectedPlayerOwnChargedMove(rawB)
                                    } else {
                                        val (_, specificMove, _) =
                                            PvPokeRepository.detectChargedAttackAndEffectiveness(rawB, currentPokemon)
                                        val recentlyFinishedOwnMove =
                                            (SystemClock.elapsedRealtime() - lastPlayerOwnChargedCutsceneEndMs) < 2500L
                                        if (specificMove != null && !recentlyFinishedOwnMove) {
                                            reconcileChargedMoveFromBanner(specificMove, pauseClock = false)
                                            postCutsceneBannerTicks = 0
                                        }
                                    }
                                }
                                .addOnCompleteListener {
                                    lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                    isOcrBusy = false
                                }
                        } else {
                            lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            if (!inActiveMatch) {
                refPlayerHpFillPx = null
                refPlayerHpBarY = -1
                preChargedMoveHpPx = null
                preChargedMoveHpBarY = -1
            }

            if (isBattleHudCurrentlyVisible && inActiveMatch) {
                if (refPlayerHpFillPx != null) {
                    preChargedMoveHpPx = refPlayerHpFillPx
                    preChargedMoveHpBarY = refPlayerHpBarY
                }
                postOpponentCutsceneHpPx = null
                hasDispatchedChargedMoveForCurrentCutscene = false
                hasCountedCutsceneIntroFastMove = false
            }
            isBattleHudCurrentlyVisible = false
            hudCompletelyMissingDurationMs += tickMs

            // Only pause the battle engine once the HUD has been missing for >= 300ms or a shield prompt / banner is active,
            // so a 1-2 frame bright lightning flash over the top name pills never triggers a false 450ms post-minigame lockout!
            if (
                inActiveMatch &&
                (hudCompletelyMissingDurationMs >= 300L ||
                    telemetry.isShieldPromptVisible ||
                    chargedAttackDetectedDuringPause ||
                    playerUsedChargedMoveDuringZoom) &&
                sessionManager.snapshotFlow.value.state == BattleState.ACTIVE
            ) {
                sessionManager.onMinigameStart {
                    onUiStateChanged()
                }
            }

            if (
                inActiveMatch &&
                !telemetry.isShieldPromptVisible &&
                !telemetry.hasTopCountdownCircle &&
                hudCompletelyMissingDurationMs >= 1200L &&
                telemetry.centeredHpFillPx > 0 &&
                telemetry.centeredOrangeDrainPx == 0
            ) {
                val prevSettled = postOpponentCutsceneHpPx
                postOpponentCutsceneHpPx = if (prevSettled == null) {
                    telemetry.centeredHpFillPx
                } else {
                    min(prevSettled, telemetry.centeredHpFillPx)
                }
            }

            // Evaluate pre-Charged-Move fast move drops (requires dropPx >= 5 or orangeDrainPx >= 2 when allowDuringCutsceneIntro = true,
            // catching Forretress's 3rd Volt Switch in 18901.jpg and Houndoom's 3rd Incinerate in 17318.jpg while ignoring 1..4px zoom pans).
            if (
                inActiveMatch &&
                !playerUsedChargedMoveDuringZoom &&
                telemetry.playerHpFillPx > 0 &&
                !hasCountedCutsceneIntroFastMove &&
                (telemetry.isShieldPromptVisible || telemetry.hasTopCountdownCircle || hudCompletelyMissingDurationMs < 350L)
            ) {
                evaluatePlayerHpBarAndDispatchSignal(
                    barLen = telemetry.barLenPx,
                    hpPx = telemetry.playerHpFillPx,
                    hpBarY = telemetry.playerHpBarY,
                    hpStage = telemetry.playerHpStage,
                    orangeDrainPx = telemetry.orangeDrainPx,
                    emptyAfterFillPx = telemetry.emptyAfterFillPx,
                    nowRealtimeMs = nowRealtimeMs,
                    allowDuringCutsceneIntro = true
                )
            } else if (
                inActiveMatch &&
                !telemetry.isShieldPromptVisible &&
                !chargedAttackDetectedDuringPause &&
                telemetry.centeredHpFillPx > 0 &&
                !hasCountedCutsceneIntroFastMove
            ) {
                checkCenteredHpBarForFastMoveSneak(
                    barLen = telemetry.barLenPx,
                    centeredHpPx = telemetry.centeredHpFillPx,
                    centeredOrangePx = telemetry.centeredOrangeDrainPx,
                    nowRealtimeMs = nowRealtimeMs
                )
            }

            // Top countdown circle WITHOUT a shield prompt during a cutscene means the player is popping bubbles
            // in their own Charged Move minigame (protects Mirror Matches before OCR runs!)
            if (
                inActiveMatch &&
                telemetry.hasTopCountdownCircle &&
                !telemetry.isShieldPromptVisible &&
                !chargedAttackDetectedDuringPause &&
                hudCompletelyMissingDurationMs in 300L..4200L
            ) {
                playerUsedChargedMoveDuringZoom = true
            }

            // A magenta Shield Prompt ONLY appears when the opponent is throwing a Charged Move (including the 2nd
            // half of a CMP tie right after the player's own Charged Move!), so always clear playerUsedChargedMoveDuringZoom!
            if (inActiveMatch && telemetry.isShieldPromptVisible) {
                val wasFirstShieldFrame = !chargedAttackDetectedDuringPause
                playerUsedChargedMoveDuringZoom = false
                playerOwnChargedBannerLockUntilMs = 0L
                if (hasDispatchedChargedMoveForCurrentCutscene && (nowRealtimeMs - lastDispatchedChargedTimestampMs) > 4800L) {
                    hasDispatchedChargedMoveForCurrentCutscene = false
                }
                chargedAttackDetectedDuringPause = true



                autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                sessionManager.onMinigameStart()
                if (!statusMessage.startsWith("▼")) {
                    statusMessage = "⚠️ Attack Incoming!"
                    onUiStateChanged()
                }
            }

            if (hudCompletelyMissingDurationMs >= 10000L && inActiveMatch) {
                inActiveMatch = false
                resetAnalyzerAndSession("● [$overlayVersion] Waiting for battle...")
            } else if (inActiveMatch && hudCompletelyMissingDurationMs >= 450L) {
                if (
                    !statusMessage.startsWith("⚠️") &&
                    !statusMessage.startsWith("🛡️") &&
                    !statusMessage.startsWith("▼") &&
                    !statusMessage.startsWith("⚡")
                ) {
                    statusMessage = "⏸ [$overlayVersion] Paused (Cutscene)"
                    onUiStateChanged()
                }
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartRealtimeMs = nowRealtimeMs
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        if (!telemetry.isShieldPromptVisible && PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetAnalyzerAndSession("● [$overlayVersion] Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            if (
                                isPlayerBubbleMinigameText(rawBanner) ||
                                PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                    rawBanner,
                                    currentPlayerPokemonName,
                                    currentPokemon.name
                                )
                            ) {
                                if (!chargedAttackDetectedDuringPause) {
                                    handleDetectedPlayerOwnChargedMove(rawBanner)
                                }
                            } else {
                                val (isIncoming, specificMove, _) =
                                    PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                                val pBase = currentPlayerPokemonName?.substringBefore("(")?.trim()?.lowercase()
                                val oBase = currentPokemon.name.substringBefore("(").trim().lowercase()
                                val isSameSpeciesMirror = !pBase.isNullOrBlank() && pBase == oBase
                                val isLikelyOwnMoveInMirror =
                                    (playerUsedChargedMoveDuringZoom || isSameSpeciesMirror && telemetry.hasTopCountdownCircle) &&
                                        !chargedAttackDetectedDuringPause &&
                                        !telemetry.isShieldPromptVisible

                                if (specificMove != null && !isLikelyOwnMoveInMirror) {
                                    playerUsedChargedMoveDuringZoom = false
                                    upgradeToSiblingFormIfMoveMatches(specificMove)
                                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(specificMove.energyCost)
                                    specificMoveDetectedDuringPause = specificMove
                                    chargedAttackDetectedDuringPause = true
                                    if (hasDispatchedChargedMoveForCurrentCutscene && (nowRealtimeMs - lastDispatchedChargedTimestampMs) > 4800L) {
                                        hasDispatchedChargedMoveForCurrentCutscene = false
                                    }
                                    if (
                                        !hasDispatchedChargedMoveForCurrentCutscene &&
                                        nowRealtimeMs - lastDispatchedChargedTimestampMs > 3000L
                                    ) {
                                        dispatchChargedMoveSignal(specificMove, pauseClock = true)
                                    } else {
                                        reconcileChargedMoveFromBanner(specificMove, pauseClock = true)
                                    }
                                } else if (isIncoming) {
                                    playerUsedChargedMoveDuringZoom = false
                                    chargedAttackDetectedDuringPause = true
                                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                                    sessionManager.onMinigameStart()
                                    if (!statusMessage.startsWith("⚡") && !statusMessage.startsWith("▼")) {
                                        statusMessage = "⚠️ Attack Incoming!"
                                        onUiStateChanged()
                                    }
                                }
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun analyzeFrameVisualTelemetry(image: Image, overlayRect: OverlayImageRect?): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val barLen = max(20, (width * 0.272f).roundToInt())

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(
                    false, false, false, false, barLen, -1, -1, 0, 0, 99, -1, 0, emptySet()
                )
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float, ignoreOverlay: Boolean): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.015f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.108f).toInt().coerceIn(y0 + 1, height)

                var maxRowWhiteRatio = 0f
                var pokeballIndicatorDots = 0
                var darkTextPixels = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        if (ignoreOverlay && overlayRect != null && overlayRect.contains(x, y)) {
                            x += max(2, width / 160)
                            continue
                        }
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 175 && g >= 185 && b >= 200) {
                                rowWhite++
                            }
                            if (r > 170 && g < 98 && b < 98) {
                                pokeballIndicatorDots++
                            }
                            if (r < 115 && g < 115 && b < 125) {
                                darkTextPixels++
                            }
                        }
                        x += max(2, width / 160)
                    }
                    if (rowTotal >= 6) {
                        val ratio = rowWhite.toFloat() / rowTotal
                        if (ratio > maxRowWhiteRatio) maxRowWhiteRatio = ratio
                    }
                    y += max(1, height / 700)
                }
                return (maxRowWhiteRatio > 0.40f && darkTextPixels >= 3 && pokeballIndicatorDots >= 1) ||
                    (maxRowWhiteRatio > 0.50f && darkTextPixels >= 5 && pokeballIndicatorDots >= 1)
            }

            val leftPillVisible = checkBattlePillSide(0.02f, 0.42f, ignoreOverlay = true)
            val rightPillVisible = checkBattlePillSide(0.58f, 0.98f, ignoreOverlay = true)
            val hudPillsVisible = leftPillVisible && rightPillVisible

            var shieldMagentaCount = 0
            var shieldSampleTotal = 0
            val sx0 = (width * 0.38f).toInt().coerceIn(0, width - 2)
            val sx1 = (width * 0.62f).toInt().coerceIn(sx0 + 1, width)
            val sy0 = (height * 0.73f).toInt().coerceIn(0, height - 2)
            val sy1 = (height * 0.91f).toInt().coerceIn(sy0 + 1, height)
            var sy = sy0
            while (sy < sy1) {
                val rOff = sy * rowStride
                var sx = sx0
                while (sx < sx1) {
                    val off = rOff + sx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        shieldSampleTotal++
                        if (r >= 175 && b >= 195 && g in 110..235 && (b - g) >= 15) {
                            shieldMagentaCount++
                        }
                    }
                    sx += max(2, width / 120)
                }
                sy += max(2, height / 250)
            }
            val shieldMagentaRatio = if (shieldSampleTotal > 0) shieldMagentaCount.toFloat() / shieldSampleTotal else 0f

            var countdownSlateCount = 0
            var countdownWhiteCount = 0
            var countdownSampleTotal = 0
            if (!hudPillsVisible) {
                val cx0 = (width * 0.43f).toInt().coerceIn(0, width - 2)
                val cx1 = (width * 0.57f).toInt().coerceIn(cx0 + 1, width)
                val cy0 = (height * 0.01f).toInt().coerceIn(0, height - 2)
                val cy1 = (height * 0.07f).toInt().coerceIn(cy0 + 1, height)
                var cy = cy0
                while (cy < cy1) {
                    val rOff = cy * rowStride
                    var cx = cx0
                    while (cx < cx1) {
                        val off = rOff + cx * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            countdownSampleTotal++
                            if (r in 75..135 && g in 95..145 && b in 105..150 && (b - r) <= 40 && abs(g - b) <= 20) {
                                countdownSlateCount++
                            } else if (r >= 230 && g >= 230 && b >= 230 && abs(r - b) <= 15) {
                                countdownWhiteCount++
                            }
                        }
                        cx += max(2, width / 160)
                    }
                    cy += max(2, height / 300)
                }
            }
            val countdownSlateRatio =
                if (countdownSampleTotal > 0) countdownSlateCount.toFloat() / countdownSampleTotal else 0f
            val countdownWhiteRatio =
                if (countdownSampleTotal > 0) countdownWhiteCount.toFloat() / countdownSampleTotal else 0f
            val hasTopCountdownCircle = countdownSlateRatio >= 0.25f && countdownWhiteRatio >= 0.05f

            val detectedBadgeTypes = mutableSetOf<String>()
            if (hudPillsVisible) {
                val bx0 = (width * 0.88f).toInt().coerceIn(0, width - 2)
                val bx1 = (width * 0.985f).toInt().coerceIn(bx0 + 1, width)
                val by1 = max(4, (height * 0.015f).toInt()).coerceIn(1, height)
                val badgeCounts = mutableMapOf<String, Int>()
                for (by in 0 until by1) {
                    val rOff = by * rowStride
                    for (bx in bx0 until bx1) {
                        val off = rOff + bx * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            val bType = when {
                                r > 215 && g in 130..222 && b > 195 && (r - g) >= 20 && (b - g) >= 20 -> "fairy"
                                r in 155..220 && g in 60..130 && b in 165..235 && (r - g) > 55 && (b - g) > 65 -> "poison"
                                r > 225 && g in 135..195 && b in 45..110 && (r - b) > 120 -> "fire"
                                r > 195 && g in 45..105 && b in 50..115 && (r - g) > 100 -> "fighting"
                                r in 75..150 && g in 150..210 && b > 205 && (b - r) > 70 -> "water"
                                r in 80..205 && g > 190 && b > 185 && abs(g - b) < 25 && (g - r) >= 28 -> "ice"
                                r in 85..135 && g in 135..175 && b in 155..200 && (b - r) in 40..80 -> "steel"
                                r > 210 && g in 115..160 && b in 60..105 && (r - b) > 110 -> "ground"
                                r > 230 && g > 200 && b in 40..105 && (r - b) > 135 -> "electric"
                                r in 70..135 && g > 175 && b in 70..135 && (g - r) > 55 -> "grass"
                                r > 220 && g in 95..145 && b in 120..175 && (r - g) > 85 -> "psychic"
                                r in 85..125 && g in 70..110 && b in 145..195 && (b - g) > 55 && (r - g) > 10 -> "ghost"
                                r in 65..105 && g in 55..95 && b in 65..105 && abs(r - g) < 16 && abs(b - g) < 18 -> "dark"
                                else -> null
                            }
                            if (bType != null) {
                                badgeCounts[bType] = (badgeCounts[bType] ?: 0) + 1
                            }
                        }
                    }
                }
                for ((tName, cnt) in badgeCounts) {
                    if (cnt >= 6) detectedBadgeTypes.add(tName)
                }
            }

            fun isOrangeDrainPixel(r: Int, g: Int, b: Int): Boolean {
                return r >= 98 && g in 60..215 && b <= 115 && (r - b) >= 50 && (r - g) >= 14 && (g - b) >= 25
            }

            fun classifyHpPixel(r: Int, g: Int, b: Int): Int {
                if (isOrangeDrainPixel(r, g, b)) return 0
                return when {
                    g >= 195 && r <= 172 && b in 75..225 && (g - r) >= 38 && (g - b) >= 24 -> 1
                    r >= 180 && g >= 200 && b in 40..185 && (r - b) >= 50 && abs(r - g) <= 28 -> 2
                    r >= 175 && g in 15..165 && b in 15..160 && (r - g) >= 70 && abs(g - b) <= 30 -> 3
                    (r < 122 && g < 112 && b < 148 && (r + g + b) <= 330) ||
                        (r in 25..135 && g <= 108 && b in 55..175 && ((b - g) >= 20 || (b - r) >= 35) && (r + g + b) <= 355) -> 4
                    else -> 0
                }
            }

            val maxBorderDy = max(5, (height * 0.012f).toInt())
            val borderStepX = max(2, barLen / 22)

            fun hasHorizontalBoxBorder(py: Int, absStartX: Int): Boolean {
                var topBest = 0
                var botBest = 0
                var rightTopBest = 0
                var rightBotBest = 0
                var totalCols = 0
                var rightCols = 0
                val endX = min(width - 1, absStartX + barLen)
                val midX = absStartX + (barLen / 2)
                var x = absStartX
                while (x < endX) {
                    totalCols++
                    if (x >= midX) rightCols++
                    x += borderStepX
                }
                if (totalCols <= 4) return false
                val reqBright = (totalCols * 0.52f).toInt()
                val reqRightBright = max(2, (rightCols * 0.42f).toInt())

                for (dy in 1..maxBorderDy) {
                    val ty = py - dy
                    if (ty >= 0) {
                        val rOff = ty * rowStride
                        var cnt = 0
                        var rCnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 320 && max(r, max(g, b)) >= 135) {
                                    cnt++
                                    if (cx >= midX) rCnt++
                                }
                            }
                            cx += borderStepX
                        }
                        if (cnt > topBest) topBest = cnt
                        if (rCnt > rightTopBest) rightTopBest = rCnt
                    }
                    val by = py + dy
                    if (by < height) {
                        val rOff = by * rowStride
                        var cnt = 0
                        var rCnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 320 && max(r, max(g, b)) >= 135) {
                                    cnt++
                                    if (cx >= midX) rCnt++
                                }
                            }
                            cx += borderStepX
                        }
                        if (cnt > botBest) botBest = cnt
                        if (rCnt > rightBotBest) rightBotBest = rCnt
                    }
                }
                return topBest >= reqBright &&
                    botBest >= reqBright &&
                    rightTopBest >= reqRightBright &&
                    rightBotBest >= reqRightBright
            }

            val hx0 = (width * 0.020f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.46f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.14f).toInt().coerceIn(4, height - 5)
            val hy1 = (height * 0.80f).toInt().coerceIn(hy0 + 1, height - 4)

            val scanW = hx1 - hx0
            val minValidInBar = (barLen * 0.60f).toInt()
            val minSmoothInBar = (barLen * 0.68f).toInt()
            val minStartScreenX = (width * 0.025f).toInt()
            val maxStartScreenX = (width * 0.165f).toInt()

            val minGreenFill = max(12, (barLen * 0.44f).toInt())
            val minYellowFill = max(6, (barLen * 0.15f).toInt())
            val maxYellowFill = (barLen * 0.58f).toInt()
            val maxRedFill = max(6, (barLen * 0.28f).toInt())

            var bestGreenFillPx = -1
            var bestGreenY = -1
            var bestGreenOrangePx = 0
            var bestGreenEmptyPx = 99
            var bestYellowFillPx = -1
            var bestYellowY = -1
            var bestYellowOrangePx = 0
            var bestYellowEmptyPx = 99
            var bestRedFillPx = -1
            var bestRedY = -1
            var bestRedOrangePx = 0
            var bestRedEmptyPx = 99

            val rowTypes = IntArray(scanW)
            val rowOrange = BooleanArray(scanW)
            val smoothPrefix = IntArray(scanW)

            val prev1FirstCol = IntArray(4) { -1 }
            val prev1FillCnt = IntArray(4) { -1 }
            val prev1RowY = IntArray(4) { -1 }

            val maxOrangeTipSpan = max(6, barLen / 11)

            if (scanW > barLen) {
                for (py in hy0 until hy1) {
                    val rOff = py * rowStride
                    var gFirst = -1
                    var yFirst = -1
                    var rFirst = -1

                    var prevR = 0
                    var prevG = 0
                    var prevB = 0
                    var sSum = 0

                    for (col in 0 until scanW) {
                        val absX = hx0 + col
                        if (overlayRect != null && overlayRect.contains(absX, py)) {
                            rowTypes[col] = 0
                            rowOrange[col] = false
                            smoothPrefix[col] = sSum
                            continue
                        }
                        val off = rOff + absX * pixelStride
                        var t = 0
                        var isOrg = false
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF

                            if (col > 0) {
                                val diff = abs(r - prevR) + abs(g - prevG) + abs(b - prevB)
                                if (diff <= 22) sSum++
                            }
                            smoothPrefix[col] = sSum
                            prevR = r
                            prevG = g
                            prevB = b

                            t = classifyHpPixel(r, g, b)
                            isOrg = isOrangeDrainPixel(r, g, b)
                        } else {
                            smoothPrefix[col] = sSum
                        }
                        rowTypes[col] = t
                        rowOrange[col] = isOrg
                    }

                    val minStartCol = (minStartScreenX - hx0).coerceAtLeast(0)
                    val maxStartCol = (maxStartScreenX - hx0).coerceAtMost(scanW - barLen)
                    for (col in minStartCol..maxStartCol) {
                        val rt = rowTypes[col]
                        if (
                            rt in 1..3 &&
                            col + 3 < scanW &&
                            rowTypes[col + 1] == rt &&
                            rowTypes[col + 2] == rt &&
                            rowTypes[col + 3] == rt
                        ) {
                            when (rt) {
                                1 -> if (gFirst < 0) gFirst = col
                                2 -> if (yFirst < 0) yFirst = col
                                3 -> if (rFirst < 0) rFirst = col
                            }
                        }
                    }

                    fun evalStageRow(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int): Triple<Int, Int, Int> {
                        if (firstCol < 0 || firstCol + barLen > scanW) return Triple(-1, 0, 99)
                        val absStartX = hx0 + firstCol
                        if (absStartX !in minStartScreenX..maxStartScreenX) return Triple(-1, 0, 99)

                        val smoothCnt = smoothPrefix[firstCol + barLen - 1] - smoothPrefix[firstCol]
                        if (smoothCnt < minSmoothInBar) return Triple(-1, 0, 99)

                        var fillCnt = 0
                        var gap = 0
                        var fillStopped = false
                        var emptyCnt = 0
                        val barEndCol = firstCol + barLen
                        for (c in firstCol until barEndCol) {
                            val rt = rowTypes[c]
                            if (!fillStopped) {
                                if (rt == stageCode) {
                                    fillCnt += (1 + gap)
                                    gap = 0
                                } else {
                                    gap++
                                    if (gap >= 3) {
                                        var resumes = false
                                        if (gap <= 5 && c + 3 < barEndCol) {
                                            if (
                                                rowTypes[c + 1] == stageCode &&
                                                rowTypes[c + 2] == stageCode &&
                                                rowTypes[c + 3] == stageCode
                                            ) {
                                                resumes = true
                                            }
                                        }
                                        if (!resumes) {
                                            fillStopped = true
                                            if (rt == 4 || rowOrange[c]) emptyCnt++
                                        }
                                    } else if (rt == 4 || rowOrange[c]) {
                                        emptyCnt++
                                    }
                                }
                            } else if (rt == 4 || rowOrange[c]) {
                                emptyCnt++
                            }
                        }
                        if (fillCnt !in minFill..maxFill || (fillCnt + emptyCnt) < minValidInBar) {
                            return Triple(-1, 0, 99)
                        }
                        if (fillCnt < (barLen * 0.85f).toInt() && emptyCnt < 6) {
                            return Triple(-1, 0, 99)
                        }

                        if (!hasHorizontalBoxBorder(py, absStartX)) {
                            return Triple(-1, 0, 99)
                        }

                        val tipStart = (firstCol + fillCnt).coerceAtMost(scanW - 1)

                        var orgCnt = 0
                        val tipEnd = min(firstCol + barLen, firstCol + fillCnt + maxOrangeTipSpan)
                        for (c in tipStart until tipEnd) {
                            if (rowOrange[c]) orgCnt++
                        }
                        return Triple(fillCnt, orgCnt, emptyCnt)
                    }

                    fun updateStageHistoryAndBest(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int) {
                        val (fillCnt, orgCnt, emptyCnt) = evalStageRow(firstCol, stageCode, minFill, maxFill)
                        if (fillCnt > 0) {
                            if (
                                prev1RowY[stageCode] > 0 &&
                                (py - prev1RowY[stageCode]) in 1..3 &&
                                abs(prev1FirstCol[stageCode] - firstCol) <= 2 &&
                                abs(prev1FillCnt[stageCode] - fillCnt) <= 3
                            ) {
                                val avgFill = max(fillCnt, prev1FillCnt[stageCode])
                                when (stageCode) {
                                    1 -> if (avgFill > bestGreenFillPx || (avgFill == bestGreenFillPx && orgCnt > bestGreenOrangePx)) {
                                        bestGreenFillPx = avgFill
                                        bestGreenY = py
                                        bestGreenOrangePx = max(bestGreenOrangePx, orgCnt)
                                        bestGreenEmptyPx = emptyCnt
                                    }
                                    2 -> if (avgFill > bestYellowFillPx || (avgFill == bestYellowFillPx && orgCnt > bestYellowOrangePx)) {
                                        bestYellowFillPx = avgFill
                                        bestYellowY = py
                                        bestYellowOrangePx = max(bestYellowOrangePx, orgCnt)
                                        bestYellowEmptyPx = emptyCnt
                                    }
                                    3 -> if (avgFill > bestRedFillPx || (avgFill == bestRedFillPx && orgCnt > bestRedOrangePx)) {
                                        bestRedFillPx = avgFill
                                        bestRedY = py
                                        bestRedOrangePx = max(bestRedOrangePx, orgCnt)
                                        bestRedEmptyPx = emptyCnt
                                    }
                                }
                            }
                            prev1RowY[stageCode] = py
                            prev1FirstCol[stageCode] = firstCol
                            prev1FillCnt[stageCode] = fillCnt
                        }
                    }

                    updateStageHistoryAndBest(gFirst, 1, minGreenFill, barLen)
                    updateStageHistoryAndBest(yFirst, 2, minYellowFill, maxYellowFill)
                    updateStageHistoryAndBest(rFirst, 3, 4, maxRedFill)
                }
            }

            val hpFillPx: Int
            val hpBarY: Int
            val hpStage: Int
            val orangeDrainPx: Int
            val emptyAfterFillPx: Int
            when {
                bestGreenFillPx > 0 -> {
                    hpFillPx = bestGreenFillPx
                    hpBarY = bestGreenY
                    hpStage = 1
                    orangeDrainPx = bestGreenOrangePx
                    emptyAfterFillPx = bestGreenEmptyPx
                }
                bestYellowFillPx > 0 -> {
                    hpFillPx = bestYellowFillPx
                    hpBarY = bestYellowY
                    hpStage = 2
                    orangeDrainPx = bestYellowOrangePx
                    emptyAfterFillPx = bestYellowEmptyPx
                }
                bestRedFillPx > 0 -> {
                    hpFillPx = bestRedFillPx
                    hpBarY = bestRedY
                    hpStage = 3
                    orangeDrainPx = bestRedOrangePx
                    emptyAfterFillPx = bestRedEmptyPx
                }
                else -> {
                    hpFillPx = -1
                    hpBarY = -1
                    hpStage = 0
                    orangeDrainPx = 0
                    emptyAfterFillPx = 99
                }
            }

            var centeredHpFillPx = -1
            var centeredOrangeDrainPx = 0
            if (hpFillPx <= 0) {
                val ccx0 = (width * 0.33f).toInt().coerceIn(0, width - 2)
                val ccx1 = (width * 0.80f).toInt().coerceIn(ccx0 + 1, width)
                val ccy0 = (height * 0.38f).toInt().coerceIn(4, height - 5)
                val ccy1 = (height * 0.63f).toInt().coerceIn(ccy0 + 1, height - 4)
                val cScanW = ccx1 - ccx0
                val minCenterStartX = (width * 0.345f).toInt()
                val maxCenterStartX = (width * 0.51f).toInt()

                if (cScanW > barLen) {
                    val cRowTypes = IntArray(cScanW)
                    val cRowOrange = BooleanArray(cScanW)
                    val cPrevRowY = IntArray(4) { -1 }
                    val cPrevFirstCol = IntArray(4) { -1 }
                    val cPrevFillCnt = IntArray(4) { -1 }

                    for (py in ccy0 until ccy1) {
                        val rOff = py * rowStride
                        var gF = -1
                        var yF = -1
                        var rF = -1
                        for (col in 0 until cScanW) {
                            val absX = ccx0 + col
                            if (overlayRect != null && overlayRect.contains(absX, py)) {
                                cRowTypes[col] = 0
                                cRowOrange[col] = false
                                continue
                            }
                            val off = rOff + absX * pixelStride
                            var t = 0
                            var isOrg = false
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                t = classifyHpPixel(r, g, b)
                                isOrg = isOrangeDrainPixel(r, g, b)
                            }
                            cRowTypes[col] = t
                            cRowOrange[col] = isOrg
                        }

                        val minCCol = (minCenterStartX - ccx0).coerceAtLeast(0)
                        val maxCCol = (maxCenterStartX - ccx0).coerceAtMost(cScanW - barLen)
                        for (col in minCCol..maxCCol) {
                            val rt = cRowTypes[col]
                            if (
                                rt in 1..3 &&
                                col + 3 < cScanW &&
                                cRowTypes[col + 1] == rt &&
                                cRowTypes[col + 2] == rt &&
                                cRowTypes[col + 3] == rt
                            ) {
                                when (rt) {
                                    1 -> if (gF < 0) gF = col
                                    2 -> if (yF < 0) yF = col
                                    3 -> if (rF < 0) rF = col
                                }
                            }
                        }

                        fun evalCenterStage(fc: Int, st: Int, minF: Int, maxF: Int) {
                            if (fc < 0 || fc + barLen > cScanW) return
                            val absStartX = ccx0 + fc
                            if (absStartX !in minCenterStartX..maxCenterStartX) return
                            if (!hasHorizontalBoxBorder(py, absStartX)) return

                            var fillCnt = 0
                            var gap = 0
                            var fillStopped = false
                            var emptyCnt = 0
                            for (c in fc until fc + barLen) {
                                val rt = cRowTypes[c]
                                if (!fillStopped) {
                                    if (rt == st) {
                                        fillCnt += (1 + gap)
                                        gap = 0
                                    } else {
                                        gap++
                                        if (gap >= 3) {
                                            fillStopped = true
                                            if (rt == 4 || cRowOrange[c]) emptyCnt++
                                        }
                                    }
                                } else if (rt == 4 || cRowOrange[c]) {
                                    emptyCnt++
                                }
                            }
                            if (fillCnt !in minF..maxF) return

                            var orgCnt = 0
                            val tipStart = (fc + fillCnt).coerceAtMost(cScanW - 1)
                            val tipEnd = min(cScanW, fc + fillCnt + max(8, barLen / 4))
                            for (c in tipStart until tipEnd) {
                                if (cRowOrange[c]) orgCnt++
                            }

                            if (orgCnt < 3 && emptyCnt < 12) return

                            if (
                                cPrevRowY[st] > 0 &&
                                (py - cPrevRowY[st]) in 1..3 &&
                                abs(cPrevFirstCol[st] - fc) <= 2 &&
                                abs(cPrevFillCnt[st] - fillCnt) <= 3
                            ) {
                                val avgFill = max(fillCnt, cPrevFillCnt[st])
                                if (avgFill > centeredHpFillPx || (avgFill == centeredHpFillPx && orgCnt > centeredOrangeDrainPx)) {
                                    centeredHpFillPx = avgFill
                                    centeredOrangeDrainPx = max(centeredOrangeDrainPx, orgCnt)
                                }
                            }
                            cPrevRowY[st] = py
                            cPrevFirstCol[st] = fc
                            cPrevFillCnt[st] = fillCnt
                        }

                        evalCenterStage(gF, 1, minGreenFill, barLen)
                        evalCenterStage(yF, 2, minYellowFill, maxYellowFill)
                        evalCenterStage(rF, 3, 4, maxRedFill)
                    }
                }
            }

            val isShieldPromptVisible = !hudPillsVisible && shieldMagentaRatio >= 0.16f
            val effectiveHudVisible = hudPillsVisible ||
                (inActiveMatch && (leftPillVisible || rightPillVisible) && hpFillPx > 0 && !isShieldPromptVisible && !hasTopCountdownCircle)

            FrameVisualTelemetry(
                isFrameNonBlack = true,
                isBattleHudVisible = effectiveHudVisible,
                isShieldPromptVisible = isShieldPromptVisible,
                hasTopCountdownCircle = hasTopCountdownCircle,
                barLenPx = barLen,
                playerHpFillPx = hpFillPx,
                playerHpBarY = hpBarY,
                playerHpStage = hpStage,
                orangeDrainPx = orangeDrainPx,
                emptyAfterFillPx = emptyAfterFillPx,
                centeredHpFillPx = centeredHpFillPx,
                centeredOrangeDrainPx = centeredOrangeDrainPx,
                opponentBadgeTypes = detectedBadgeTypes
            )
        } catch (_: Exception) {
            FrameVisualTelemetry(
                true, false, false, false, 66, -1, -1, 0, 0, 99, -1, 0, emptySet()
            )
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1,
        maskOverlayRect: OverlayImageRect? = null
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    if (maskOverlayRect != null && maskOverlayRect.contains(x, y)) {
                        pixels[py * outW + px] = 0xFF000000.toInt()
                    } else {
                        val offset = rowOffset + x * pixelStride
                        if (offset >= 0 && offset + 3 < bufLimit) {
                            val r = buf.get(offset).toInt() and 0xFF
                            val g = buf.get(offset + 1).toInt() and 0xFF
                            val b = buf.get(offset + 2).toInt() and 0xFF
                            pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                        }
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }
}
