package com.pokecount.overlay

import android.graphics.Bitmap
import android.media.Image
import android.os.SystemClock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Bounding rectangle of the floating overlay HUD in capture-image coordinates,
 * used to mask out the overlay itself during OCR and pixel telemetry.
 */
data class OverlayImageRect(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    fun contains(x: Int, y: Int): Boolean = x in left..right && y in top..bottom
}

/**
 * Per-frame visual telemetry extracted from the MediaProjection capture buffer.
 */
data class FrameVisualTelemetry(
    val isFrameNonBlack: Boolean,
    val isBattleHudVisible: Boolean,
    val isShieldPromptVisible: Boolean,
    val hasTopCountdownCircle: Boolean,
    val barLenPx: Int,
    val playerHpFillPx: Int,
    val playerHpBarY: Int,
    val playerHpStage: Int,
    val orangeDrainPx: Int,
    val emptyAfterFillPx: Int,
    val centeredHpFillPx: Int,
    val centeredOrangeDrainPx: Int,
    val opponentBadgeTypes: Set<String>,
    val isRightPillVisible: Boolean = false
)

/**
 * Pure detection & telemetry layer (`ScreenCaptureAnalyzer`).
 *
 * Inspects screen capture frames and OCR text and dispatches clean, high-level signals
 * (`onFastMoveSignal()`, `onChargedMoveSignal(cost)`, `onMinigameStart()`, `onMinigameEnd()`,
 * `onSwitch()`, `configureFastMove()`) to [BattleSessionManager].
 */
class ScreenCaptureAnalyzer(
    private val sessionManager: BattleSessionManager,
    private val overlayVersion: String,
    private val onUiStateChanged: () -> Unit
) {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()

    val seenOpponentPokemon = linkedMapOf<String, PvPokeEntry>()
    val slotFastMoveIdx = mutableMapOf<String, Int>()
    val manualFormOverrideByBase = mutableMapOf<String, String>()
    private val manualFastMoveLockedIds = mutableSetOf<String>()

    var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
        private set

    var inActiveMatch: Boolean = false
        private set

    var statusMessage: String = "● $overlayVersion Engine Ready"
        private set

    private var hasLockedFirstRealOpponentInMatch = false
    private var pendingDynOpponentId: String? = null
    private var pendingDynConfirmTicks: Int = 0
    private var currentPlayerPokemonId: String? = null
    private var currentPlayerPokemonName: String? = null
    private var playerDefenderTypes: List<String> = emptyList()
    private var latestEffectivenessHint: String? = null
    private var fastHitsLandedOnCurrentPlayer: Int = 0

    // Battle & Cutscene detection flags
    private var isBattleHudCurrentlyVisible = false
    private var consecutiveHudVisibleTicks = 0
    private var hudCompletelyMissingDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var playerUsedChargedMoveDuringZoom = false
    private var playerOwnChargedBannerLockUntilMs = 0L
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var hasDispatchedChargedMoveForCurrentCutscene = false
    private var hasCountedCutsceneIntroFastMove = false
    private var lastDispatchedChargedMove: ChargedMove? = null
    private var lastDispatchedChargedPokemonId: String? = null
    private var lastDispatchedChargedTimestampMs = 0L
    private var postCutsceneBannerTicks = 0

    // Player floating HP bar baseline & pre-Charged-Move baseline (to catch Fast Move Sneaks)
    private var matchStartRealtimeMs: Long = 0L
    private var refPlayerHpFillPx: Int? = null
    private var lastCountedMoveHpPx: Int? = null
    private var lastCutsceneEndRealtimeMs: Long = 0L
    private var ignoreAboveHpEffUntilRealtimeMs: Long = 0L
    private var refPlayerHpBarY: Int = -1
    private var refPlayerHpStage: Int = 1
    private var preChargedMoveHpPx: Int? = null
    private var preChargedMoveHpBarY: Int = -1
    private var postOpponentCutsceneHpPx: Int? = null
    private var prevOrangeDrainPx: Int = 0
    private var higherHpConfirmTicks: Int = 0
    private var sustainedOnePxDropTicks: Int = 0
    private var onePxDropStartRealtimeMs: Long = 0L
    private var zeroOrangeDropTicks: Int = 0
    private var zeroOrangeDropStartRealtimeMs: Long = 0L
    private var lastZeroOrangeHpPx: Int = -1
    private var observedSingleHitDropPx: Int = 0
    private var hpBarOccludedTicks: Int = 0
    private var hpBarOccludedSinceRealtimeMs: Long = 0L
    private var lastPlayerOwnChargedCutsceneEndMs: Long = 0L
    private var postCutsceneDrainSettleUntilMs: Long = 0L
    private var lastAcceptedFastMoveHadOrange: Boolean = true
    private var lastAcceptedFastMoveWallMs: Long = 0L
    private var wasRightPillVisibleLastTick: Boolean = false
    private var lastOpponentSendOutRealtimeMs: Long = 0L
    private var lastSeenOpponentBadgeTypes: Set<String> = emptySet()

    @Volatile
    private var latestLiveTelemetry: FrameVisualTelemetry? = null

    // OCR concurrency & throttling
    private var isOcrBusy = false
    private var lastOcrStartRealtimeMs = 0L
    private var lastOcrCompletedRealtimeMs = 0L

    private val lowDamageTwoTurnMoveNames = setOf(
        "Poison Sting", "Mud Shot", "Thunder Shock", "Fairy Wind", "Psycho Cut"
    )

    fun getActiveFastMove(entry: PvPokeEntry = currentPokemon): FastMove {
        val idx = (slotFastMoveIdx[entry.id] ?: 0).coerceIn(0, max(0, entry.fastMoves.size - 1))
        return entry.fastMoves[idx]
    }

    fun setStatusText(msg: String) {
        statusMessage = msg
        onUiStateChanged()
    }

    fun markMatchActiveForManualInput() {
        if (!inActiveMatch) {
            inActiveMatch = true
            matchStartRealtimeMs = SystemClock.elapsedRealtime() - 1000L
        }
    }

    fun resetAnalyzerAndSession(statusMsg: String, preLockedHpPx: Int? = null, preLockedBarY: Int = -1) {
        seenOpponentPokemon.clear()
        manualFormOverrideByBase.clear()
        manualFastMoveLockedIds.clear()
        hasLockedFirstRealOpponentInMatch = false
        pendingDynOpponentId = null
        pendingDynConfirmTicks = 0
        refPlayerHpFillPx = preLockedHpPx
        lastCountedMoveHpPx = preLockedHpPx
        lastCutsceneEndRealtimeMs = 0L
        ignoreAboveHpEffUntilRealtimeMs = 0L
        refPlayerHpBarY = preLockedBarY
        refPlayerHpStage = 1
        preChargedMoveHpPx = preLockedHpPx
        preChargedMoveHpBarY = preLockedBarY
        postOpponentCutsceneHpPx = null
        prevOrangeDrainPx = 0
        higherHpConfirmTicks = 0
        sustainedOnePxDropTicks = 0
        onePxDropStartRealtimeMs = 0L
        zeroOrangeDropTicks = 0
        zeroOrangeDropStartRealtimeMs = 0L
        lastZeroOrangeHpPx = -1
        observedSingleHitDropPx = 0
        hpBarOccludedTicks = 0
        hpBarOccludedSinceRealtimeMs = 0L
        lastPlayerOwnChargedCutsceneEndMs = 0L
        postCutsceneDrainSettleUntilMs = 0L
        lastAcceptedFastMoveHadOrange = true
        lastAcceptedFastMoveWallMs = 0L
        wasRightPillVisibleLastTick = false
        lastOpponentSendOutRealtimeMs = 0L
        lastSeenOpponentBadgeTypes = emptySet()
        latestLiveTelemetry = null
        fastHitsLandedOnCurrentPlayer = 0
        latestEffectivenessHint = null
        consecutiveHudVisibleTicks = 0
        chargedAttackDetectedDuringPause = false
        playerUsedChargedMoveDuringZoom = false
        playerOwnChargedBannerLockUntilMs = 0L
        specificMoveDetectedDuringPause = null
        hasDispatchedChargedMoveForCurrentCutscene = false
        hasCountedCutsceneIntroFastMove = false
        lastDispatchedChargedMove = null
        lastDispatchedChargedPokemonId = null
        lastDispatchedChargedTimestampMs = 0L
        postCutsceneBannerTicks = 0
        statusMessage = statusMsg

        val activeFm = getActiveFastMove()
        sessionManager.resetMatch(
            initialPokemonId = currentPokemon.id,
            durationTurns = activeFm.turns,
            energyGain = activeFm.energyGain,
            moveName = activeFm.name
        ) {
            onUiStateChanged()
        }
        onUiStateChanged()
    }

    /**
     * Cycles the opponent's fast move or regional sibling form when the user taps `[⇄Fast]`.
     */
    fun cycleFastMoveOrForm() {
        manualFastMoveLockedIds.add(currentPokemon.id)
        val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)

        if (curIdx + 1 < currentPokemon.fastMoves.size) {
            slotFastMoveIdx[currentPokemon.id] = curIdx + 1
            val newFm = getActiveFastMove()
            statusMessage = "Fast: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        } else if (siblings.size > 1) {
            val curFormIdx = siblings.indexOfFirst { it.id == currentPokemon.id }.coerceAtLeast(0)
            val nextForm = siblings[(curFormIdx + 1) % siblings.size]
            seenOpponentPokemon.remove(currentPokemon.id)
            seenOpponentPokemon[nextForm.id] = nextForm
            slotFastMoveIdx[nextForm.id] = 0
            val nextFm = nextForm.fastMoves.first()
            val baseKey = nextForm.name.substringBefore("(").trim().lowercase()
            manualFormOverrideByBase[baseKey] = nextForm.id
            currentPokemon = nextForm
            hasDispatchedChargedMoveForCurrentCutscene = false
            lastDispatchedChargedMove = null
            lastDispatchedChargedPokemonId = null
            statusMessage = "Form: ${nextForm.name}"
            sessionManager.onSwitch(
                newPokemonId = nextForm.id,
                durationTurns = nextFm.turns,
                energyGain = nextFm.energyGain,
                moveName = nextFm.name,
                transferOpeningEnergy = true,
                pauseForSwitchWindow = false
            ) {
                onUiStateChanged()
            }
        } else if (currentPokemon.fastMoves.size > 1) {
            slotFastMoveIdx[currentPokemon.id] = 0
            val newFm = getActiveFastMove()
            statusMessage = "Fast: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        }
    }

    /**
     * Dispatches a manual Charged Move badge tap to [BattleSessionManager].
     */
    fun onManualChargedMoveBadgeTap(cm: ChargedMove) {
        upgradeToSiblingFormIfMoveMatches(cm)
        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(cm.energyCost)
        statusMessage = "▼ Subtracted ${cm.name}"
        sessionManager.onChargedMoveSignal(
            cost = cm.energyCost,
            moveName = cm.name,
            pauseClock = false,
            forceManualTap = true
        ) {
            onUiStateChanged()
        }
    }

    private fun autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(requiredEnergy: Int? = null) {
        if (true) return
        if (currentPokemon.fastMoves.size <= 1) return
        val snap = sessionManager.snapshotFlow.value
        val curCount = snap.displayedFastMoveCount
        if (curCount <= 0) return

        val minChargedCost = requiredEnergy
            ?: currentPokemon.chargedMoves.minOfOrNull { it.energyCost }
            ?: 35

        val activeFm = getActiveFastMove()
        if (snap.energy >= minChargedCost) return

        val matchingIdx = currentPokemon.fastMoves.indexOfFirst { candFm ->
            candFm.name != activeFm.name && (curCount * candFm.energyGain) >= minChargedCost
        }
        if (matchingIdx >= 0) {
            slotFastMoveIdx[currentPokemon.id] = matchingIdx
            val newFm = currentPokemon.fastMoves[matchingIdx]
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        }
    }

    private fun upgradeToSiblingFormIfMoveMatches(usedMove: ChargedMove) {
        if (currentPokemon.chargedMoves.any { it.name == usedMove.name }) return
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)
        val matchingSibling = siblings.firstOrNull { sib ->
            sib.chargedMoves.any { it.name == usedMove.name }
        } ?: return

        seenOpponentPokemon.remove(currentPokemon.id)
        seenOpponentPokemon[matchingSibling.id] = matchingSibling
        val newFm = getActiveFastMove(matchingSibling)
        val baseKey = matchingSibling.name.substringBefore("(").trim().lowercase()
        manualFormOverrideByBase[baseKey] = matchingSibling.id
        currentPokemon = matchingSibling

        sessionManager.onSwitch(
            newPokemonId = matchingSibling.id,
            durationTurns = newFm.turns,
            energyGain = newFm.energyGain,
            moveName = newFm.name,
            transferOpeningEnergy = true,
            pauseForSwitchWindow = false
        ) {
            onUiStateChanged()
        }
    }

    private fun dispatchChargedMoveSignal(cm: ChargedMove, pauseClock: Boolean) {
        upgradeToSiblingFormIfMoveMatches(cm)
        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(cm.energyCost)
        if (!hasDispatchedChargedMoveForCurrentCutscene) {
            val snap = sessionManager.snapshotFlow.value
            val activeFm = getActiveFastMove()
            val missingMoves = if (snap.energy < cm.energyCost) {
                ceil((cm.energyCost - snap.energy).toDouble() / max(1, activeFm.energyGain)).toInt().coerceIn(1, 5)
            } else {
                0
            }
            if (missingMoves > 0) {
                sessionManager.onFastMoveSignal(
                    allowDuringCutsceneIntro = true,
                    count = missingMoves
                )
            }
        }
        val now = SystemClock.elapsedRealtime()
        lastDispatchedChargedTimestampMs = now
        lastDispatchedChargedMove = cm
        lastDispatchedChargedPokemonId = currentPokemon.id
        hasDispatchedChargedMoveForCurrentCutscene = true
        statusMessage = "▼ Subtracted ${cm.name}"
        sessionManager.onChargedMoveSignal(
            cost = cm.energyCost,
            moveName = cm.name,
            pauseClock = pauseClock
        ) {
            onUiStateChanged()
        }
    }

    /**
     * Undoes a false opponent Charged Move subtraction ONLY if one was actually dispatched
     * during the current cutscene on the current opponent Pokémon.
     */
    private fun undoFalsePlayerChargedMoveIfNeeded() {
        val now = SystemClock.elapsedRealtime()
        val prevSub = lastDispatchedChargedMove ?: return
        if (
            hasDispatchedChargedMoveForCurrentCutscene &&
            lastDispatchedChargedPokemonId == currentPokemon.id &&
            (now - lastDispatchedChargedTimestampMs) <= 8000L
        ) {
            lastDispatchedChargedMove = null
            lastDispatchedChargedPokemonId = null
            lastDispatchedChargedTimestampMs = 0L
            hasDispatchedChargedMoveForCurrentCutscene = false
            sessionManager.undoChargedMove(prevSub.energyCost) {
                onUiStateChanged()
            }
        }
    }

    private fun handleDetectedPlayerOwnChargedMove(rawBannerText: String) {
        val now = SystemClock.elapsedRealtime()
        val bannerPlayerPoke = PvPokeRepository.matchPlayerPokemonFromOwnBanner(rawBannerText, currentPokemon.name)
        if (bannerPlayerPoke != null && bannerPlayerPoke.id != currentPlayerPokemonId) {
            currentPlayerPokemonId = bannerPlayerPoke.id
            currentPlayerPokemonName = bannerPlayerPoke.name
            playerDefenderTypes = PvPokeRepository.getDefenderTypes(bannerPlayerPoke)
        }
        if (refPlayerHpFillPx != null) {
            preChargedMoveHpPx = refPlayerHpFillPx
            preChargedMoveHpBarY = refPlayerHpBarY
        }
        playerUsedChargedMoveDuringZoom = true
        playerOwnChargedBannerLockUntilMs = max(playerOwnChargedBannerLockUntilMs, now + 5500L)
        chargedAttackDetectedDuringPause = false
        specificMoveDetectedDuringPause = null
        sustainedOnePxDropTicks = 0
        undoFalsePlayerChargedMoveIfNeeded()
        sessionManager.onMinigameStart {
            onUiStateChanged()
        }
        if (!statusMessage.startsWith("⚡")) {
            statusMessage = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
        }
        onUiStateChanged()
    }

    private fun reconcileChargedMoveFromBanner(actualMove: ChargedMove, pauseClock: Boolean) {
        upgradeToSiblingFormIfMoveMatches(actualMove)
        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(actualMove.energyCost)
        val now = SystemClock.elapsedRealtime()
        val prevSub = lastDispatchedChargedMove
        if (
            hasDispatchedChargedMoveForCurrentCutscene ||
            (prevSub != null && lastDispatchedChargedPokemonId == currentPokemon.id && (now - lastDispatchedChargedTimestampMs) <= 12000L)
        ) {
            if (prevSub != null && prevSub.name != actualMove.name) {
                lastDispatchedChargedMove = actualMove
                statusMessage = "▼ Used ${actualMove.name}!"
                sessionManager.reconcileChargedMoveCost(
                    previousCost = prevSub.energyCost,
                    actualCost = actualMove.energyCost,
                    actualMoveName = actualMove.name
                ) {
                    onUiStateChanged()
                }
            } else {
                statusMessage = "▼ Used ${actualMove.name}!"
                onUiStateChanged()
            }
        } else if ((now - lastDispatchedChargedTimestampMs) > 3500L) {
            dispatchChargedMoveSignal(actualMove, pauseClock = pauseClock)
        }
    }

    /**
     * Checks if the player's centered HP bar during the player's own Charged Move shows an uncounted
     * Fast Move Sneak from the opponent.
     */
    private fun checkCenteredHpBarForFastMoveSneak(
        barLen: Int,
        centeredHpPx: Int,
        centeredOrangePx: Int,
        nowRealtimeMs: Long
    ) {
        if (true) return
        if (centeredHpPx <= 0 || hasCountedCutsceneIntroFastMove || chargedAttackDetectedDuringPause) return
        if (nowRealtimeMs < sessionManager.nextAllowedFastMoveRealtimeMs) return

        val preHp = preChargedMoveHpPx ?: refPlayerHpFillPx
        val isSneakDetected = if (preHp != null) {
            val drop = preHp - centeredHpPx
            drop in 2..(barLen * 0.35f).toInt()
        } else {
            centeredOrangePx in 4..(barLen * 0.28f).toInt()
        }

        if (isSneakDetected) {
            val activeFm = getActiveFastMove()
            sessionManager.onFastMoveSignal(allowDuringCutsceneIntro = true, count = 1) { accepted, updatedSnap ->
                if (accepted) {
                    hasCountedCutsceneIntroFastMove = true
                    preChargedMoveHpPx = centeredHpPx
                    refPlayerHpFillPx = centeredHpPx
                    lastCountedMoveHpPx = centeredHpPx
                    fastHitsLandedOnCurrentPlayer++
                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                    statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (Sneak · ${updatedSnap.energy}E)"
                    onUiStateChanged()
                }
            }
        }
    }

    /**
     * Evaluates whether the player's floating HP bar dropped and dispatches `sessionManager.onFastMoveSignal()`.
     */
    private fun evaluatePlayerHpBarAndDispatchSignal(
        barLen: Int,
        hpPx: Int,
        hpBarY: Int,
        hpStage: Int,
        orangeDrainPx: Int,
        emptyAfterFillPx: Int,
        nowRealtimeMs: Long,
        allowDuringCutsceneIntro: Boolean = false
    ): Boolean {
        if (hpPx <= 0 || hpBarY <= 0) return false

        if (!allowDuringCutsceneIntro && (playerUsedChargedMoveDuringZoom || nowRealtimeMs < playerOwnChargedBannerLockUntilMs)) {
            return false
        }

        if (!allowDuringCutsceneIntro && nowRealtimeMs < postCutsceneDrainSettleUntilMs) {
            refPlayerHpFillPx = if (refPlayerHpFillPx == null) hpPx else min(refPlayerHpFillPx!!, hpPx)
            lastCountedMoveHpPx = refPlayerHpFillPx
            refPlayerHpBarY = hpBarY
            refPlayerHpStage = hpStage
            preChargedMoveHpPx = refPlayerHpFillPx
            preChargedMoveHpBarY = hpBarY
            prevOrangeDrainPx = orangeDrainPx
            higherHpConfirmTicks = 0
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        val snapshot = sessionManager.snapshotFlow.value
        val activeFm = getActiveFastMove()
        val moveDurationMs = activeFm.turns * 500L
        val isOneTurnMove = (activeFm.turns == 1)
        val isTwoTurnMove = (activeFm.turns == 2)
        val hasOrangeSignal = (orangeDrainPx >= 1 || prevOrangeDrainPx >= 1)
        val maxFastDropPx = when {
            isOneTurnMove -> (barLen * 0.36f).toInt()
            isTwoTurnMove -> (barLen * 0.52f).toInt()
            else -> (barLen * 0.72f).toInt()
        }

        val prevHpPx = refPlayerHpFillPx
        if (prevHpPx == null) {
            refPlayerHpFillPx = hpPx
            lastCountedMoveHpPx = hpPx
            refPlayerHpBarY = hpBarY
            refPlayerHpStage = hpStage
            preChargedMoveHpPx = hpPx
            preChargedMoveHpBarY = hpBarY
            prevOrangeDrainPx = orangeDrainPx
            higherHpConfirmTicks = 0
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        // Adaptive vertical camera sway / tall-vs-short Pokémon switch re-anchor
        val maxCameraSwayY = max(34, (barLen * 0.28f).toInt())
        if (refPlayerHpBarY > 0 && abs(hpBarY - refPlayerHpBarY) > maxCameraSwayY) {
            val candidateDrop = prevHpPx - hpPx
            val isSameOrNextStageFastDrop =
                hpStage in refPlayerHpStage..(refPlayerHpStage + 1) &&
                    candidateDrop in 1..maxFastDropPx &&
                    abs(hpBarY - refPlayerHpBarY) <= max(54, (barLen * 0.42f).toInt())
            if (!isSameOrNextStageFastDrop) {
                refPlayerHpFillPx = hpPx
                lastCountedMoveHpPx = hpPx
                refPlayerHpBarY = hpBarY
                refPlayerHpStage = hpStage
                preChargedMoveHpPx = hpPx
                preChargedMoveHpBarY = hpBarY
                prevOrangeDrainPx = orangeDrainPx
                higherHpConfirmTicks = 0
                sustainedOnePxDropTicks = 0
                onePxDropStartRealtimeMs = 0L
                zeroOrangeDropTicks = 0
                observedSingleHitDropPx = 0
                return false
            }
        }

        if (refPlayerHpStage == 1 && hpStage == 3 && prevHpPx > (barLen * 0.78f).toInt() && !hasOrangeSignal) {
            return false
        }

        val prevBarY = refPlayerHpBarY
        refPlayerHpBarY = hpBarY
        refPlayerHpStage = hpStage

        // Opening Camera-Settle Guard (< 650ms after battle HUD pills first appear at match start):
        val openingSettleMs = if (orangeDrainPx >= 1) 450L else 680L
        if ((nowRealtimeMs - matchStartRealtimeMs) < openingSettleMs) {
            refPlayerHpFillPx = hpPx
            lastCountedMoveHpPx = hpPx
            preChargedMoveHpPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        // Upward Re-Lock when switching in a healthier Pokémon OR recovering from a partial bar occlusion (>=3px)
        val isLargeSwitchUp = hpPx > prevHpPx + max(6, barLen / 14)
        val isSmallOcclusionRecovery = hpPx >= prevHpPx + 3 && orangeDrainPx == 0 && hpStage <= refPlayerHpStage
        if (isLargeSwitchUp || isSmallOcclusionRecovery) {
            higherHpConfirmTicks++
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            if (higherHpConfirmTicks >= 2) {
                refPlayerHpFillPx = hpPx
                lastCountedMoveHpPx = hpPx
                preChargedMoveHpPx = hpPx
                prevOrangeDrainPx = orangeDrainPx
                higherHpConfirmTicks = 0
                if (isLargeSwitchUp) {
                    observedSingleHitDropPx = 0
                }
            }
            return false
        } else {
            higherHpConfirmTicks = 0
        }

        val lastAcceptMs = sessionManager.lastAcceptedFastMoveRealtimeMs
        val elapsedSinceLastAccept = nowRealtimeMs - lastAcceptMs
        val nextAllowedMs = sessionManager.nextAllowedFastMoveRealtimeMs

        val cumulativeUncreditedDropPx = (lastCountedMoveHpPx ?: prevHpPx) - hpPx
        var dropPx = prevHpPx - hpPx
        if (
            !allowDuringCutsceneIntro &&
            nowRealtimeMs >= nextAllowedMs &&
            (cumulativeUncreditedDropPx >= 2 ||
                (cumulativeUncreditedDropPx >= 1 && (lastAcceptMs == 0L || elapsedSinceLastAccept >= moveDurationMs - 100L)))
        ) {
            dropPx = max(dropPx, cumulativeUncreditedDropPx)
        }

        // True 100% Undamaged Full-Bar Guard: ONLY ignore a 1px flicker when emptyAfterFillPx == 0 (zero empty pixels at the right border)
        // and WITHOUT overwriting refPlayerHpFillPx! As soon as emptyAfterFillPx >= 1 (e.g. Incineroar Double Kick into Mimikyu
        // at 129/132 with empty = 3 in 18980.jpg), evaluate the drop normally!
        if (
            dropPx == 1 &&
            emptyAfterFillPx == 0 &&
            orangeDrainPx == 0 &&
            prevOrangeDrainPx == 0
        ) {
            prevOrangeDrainPx = 0
            sustainedOnePxDropTicks = 0
            zeroOrangeDropTicks = 0
            return false
        }

        // During cutscene/Shield-Prompt intro (allowDuringCutsceneIntro == true):
        // 1) Never double-count if a fast move was ALREADY counted in Wide-Arena combat within (moveDurationMs - 180ms)
        //    (prevents Greninja in 18976.jpg from getting a 2nd count when pressing its Charged Move as its fast move finishes!).
        // 2) Require dropPx >= 5 or orangeDrainPx >= 2 so 1..4px zero-orange camera zoom foreshortening is ignored.
        if (allowDuringCutsceneIntro) {
            if (lastAcceptMs > 0L && elapsedSinceLastAccept < (moveDurationMs - 280L)) {
                prevOrangeDrainPx = orangeDrainPx
                return false
            }
            if (orangeDrainPx < 2 && dropPx < 4) {
                prevOrangeDrainPx = orangeDrainPx
                return false
            }
        }

        // Ignore massive single-frame drops exceeding maxFastDropPx
        if (dropPx > maxFastDropPx) {
            refPlayerHpFillPx = hpPx
            lastCountedMoveHpPx = hpPx
            preChargedMoveHpPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        // Turn-scaled same-hit drain settle window:
        // Limit cumulative zero-orange pixels absorbed after a counted hit to at most 2px so sameHitSettleWindowMs
        // NEVER absorbs a new hit's drop!
        val sameHitSettleWindowMs = when (activeFm.turns) {
            1 -> 90L
            2 -> 520L
            3 -> 820L
            else -> 920L // 4-turn (Volt Switch) & 5-turn (Incinerate)
        }

        if (!allowDuringCutsceneIntro && lastAcceptMs > 0L && elapsedSinceLastAccept < sameHitSettleWindowMs) {
            if (dropPx in 1..maxFastDropPx) {
                val isGenuineSettle = orangeDrainPx > 0 || prevOrangeDrainPx > 0
                if (isGenuineSettle) {
                    refPlayerHpFillPx = hpPx
                    if (!isOneTurnMove) {
                        lastCountedMoveHpPx = hpPx
                    }
                    preChargedMoveHpPx = hpPx
                    if (observedSingleHitDropPx > 0) {
                        observedSingleHitDropPx = min(maxFastDropPx, observedSingleHitDropPx + dropPx)
                    }
                    zeroOrangeDropTicks = 0
                } else {
                    zeroOrangeDropTicks = 1
                    zeroOrangeDropStartRealtimeMs = nowRealtimeMs
                    lastZeroOrangeHpPx = hpPx
                }
            } else {
                zeroOrangeDropTicks = 0
            }
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            return false
        }

        if (!allowDuringCutsceneIntro && nowRealtimeMs < nextAllowedMs) {
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            prevOrangeDrainPx = orangeDrainPx
            return false
        }

        val canDispatchNow =
            snapshot.state == BattleState.ACTIVE ||
                (allowDuringCutsceneIntro && !hasCountedCutsceneIntroFastMove)

        if (dropPx <= 0) {
            // Sub-pixel <1px extremely resisted hit where integer hpPx rounds to 0 drop but a fresh 1..4px orange pulse appears:
            if (
                canDispatchNow &&
                dropPx == 0 &&
                orangeDrainPx in 1..4 &&
                prevOrangeDrainPx == 0 &&
                (lastAcceptMs == 0L || elapsedSinceLastAccept >= (moveDurationMs * 0.88f).toLong())
            ) {
                prevOrangeDrainPx = orangeDrainPx
                sustainedOnePxDropTicks = 0
                onePxDropStartRealtimeMs = 0L
                zeroOrangeDropTicks = 0
                sessionManager.onFastMoveSignal(
                    allowDuringCutsceneIntro = allowDuringCutsceneIntro,
                    count = 1,
                    advanceTimestampByMs = nowRealtimeMs
                ) { accepted, updatedSnap ->
                    if (accepted) {
                        refPlayerHpFillPx = hpPx
                        lastCountedMoveHpPx = hpPx
                        preChargedMoveHpPx = hpPx
                        fastHitsLandedOnCurrentPlayer += 1
                        if (allowDuringCutsceneIntro) {
                            hasCountedCutsceneIntroFastMove = true
                            autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                        }
                        statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (${updatedSnap.energy}E)"
                        onUiStateChanged()
                    }
                }
                return true
            }

            if (
                snapshot.totalFastMovesInMatch == 0 &&
                emptyAfterFillPx <= 2 &&
                orangeDrainPx == 0 &&
                hpPx > prevHpPx
            ) {
                refPlayerHpFillPx = hpPx
                lastCountedMoveHpPx = hpPx
                preChargedMoveHpPx = hpPx
            }
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            return false
        }

        // UNIFIED MONOTONIC DROP CONFIRMATION & TURN-CADENCE AUTO-CONFIRM ON ESTABLISHED RHYTHM:
        val isEstablishedCombatRhythm =
            fastHitsLandedOnCurrentPlayer >= 1 ||
                (lastOpponentSendOutRealtimeMs > 0L &&
                    (nowRealtimeMs - lastOpponentSendOutRealtimeMs) >= (moveDurationMs + 150L)) ||
                (isBattleHudCurrentlyVisible &&
                    lastCutsceneEndRealtimeMs > 0L &&
                    (nowRealtimeMs - lastCutsceneEndRealtimeMs) >= (moveDurationMs + 150L))

        var effectiveHitTimeMs = nowRealtimeMs
        if (!allowDuringCutsceneIntro && !hasOrangeSignal) {
            val isCameraPanningY = prevBarY > 0 && abs(hpBarY - prevBarY) >= 5
            if (isCameraPanningY) {
                sustainedOnePxDropTicks = 0
                zeroOrangeDropTicks = 0
                prevOrangeDrainPx = orangeDrainPx
                return false
            }

            if (sustainedOnePxDropTicks == 0 || abs(hpPx - lastZeroOrangeHpPx) > 4) {
                sustainedOnePxDropTicks = 1
                onePxDropStartRealtimeMs = nowRealtimeMs
                lastZeroOrangeHpPx = hpPx
                zeroOrangeDropTicks = dropPx // track max dropPx seen in this streak
            } else {
                sustainedOnePxDropTicks++
                lastZeroOrangeHpPx = hpPx
                if (dropPx > zeroOrangeDropTicks) {
                    zeroOrangeDropTicks = dropPx
                }
            }

            val isOneTurnActiveCadence =
                isOneTurnMove &&
                    fastHitsLandedOnCurrentPlayer >= 1 &&
                    nowRealtimeMs >= nextAllowedMs &&
                    (dropPx >= 1 || cumulativeUncreditedDropPx >= 1 || orangeDrainPx >= 1)
            val isCadenceAutoConfirm =
                isEstablishedCombatRhythm &&
                    nowRealtimeMs >= nextAllowedMs &&
                    (cumulativeUncreditedDropPx >= 1 || orangeDrainPx >= 1)
            val isPhaseLockedOnePxCadence =
                fastHitsLandedOnCurrentPlayer >= 1 &&
                    lastAcceptMs > 0L &&
                    elapsedSinceLastAccept in (moveDurationMs - 140L)..(moveDurationMs + 320L)
            val reqTicks = when {
                isOneTurnActiveCadence || isCadenceAutoConfirm -> 1
                zeroOrangeDropTicks >= 2 || isPhaseLockedOnePxCadence || (nowRealtimeMs - matchStartRealtimeMs) >= moveDurationMs -> 2
                else -> 3
            }
            if (sustainedOnePxDropTicks < reqTicks) {
                prevOrangeDrainPx = orangeDrainPx
                return false
            }
            effectiveHitTimeMs = onePxDropStartRealtimeMs
        } else {
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
        }

        if (hpBarOccludedTicks in 1..10 && hpBarOccludedSinceRealtimeMs > 0L && !allowDuringCutsceneIntro) {
            effectiveHitTimeMs = max(lastAcceptMs + moveDurationMs - 150L, hpBarOccludedSinceRealtimeMs)
        }

        prevOrangeDrainPx = orangeDrainPx

        if (canDispatchNow) {
            sustainedOnePxDropTicks = 0
            onePxDropStartRealtimeMs = 0L
            zeroOrangeDropTicks = 0
            if (observedSingleHitDropPx == 0) {
                observedSingleHitDropPx = dropPx.coerceIn(1, maxFastDropPx)
            }

            val hitHadOrange = hasOrangeSignal
            val moveCountToCredit = if (
                !allowDuringCutsceneIntro &&
                isOneTurnMove &&
                lastAcceptMs > 0L &&
                elapsedSinceLastAccept in 900L..1650L &&
                (cumulativeUncreditedDropPx >= 2 || (cumulativeUncreditedDropPx >= 1 && orangeDrainPx >= 1))
            ) {
                2
            } else {
                1
            }
            sessionManager.onFastMoveSignal(
                allowDuringCutsceneIntro = allowDuringCutsceneIntro,
                count = moveCountToCredit,
                advanceTimestampByMs = effectiveHitTimeMs
            ) { accepted, updatedSnap ->
                if (accepted) {
                    refPlayerHpFillPx = hpPx
                    lastCountedMoveHpPx = hpPx
                    preChargedMoveHpPx = hpPx
                    fastHitsLandedOnCurrentPlayer += moveCountToCredit
                    lastAcceptedFastMoveHadOrange = hitHadOrange
                    lastAcceptedFastMoveWallMs = nowRealtimeMs
                    if (allowDuringCutsceneIntro) {
                        hasCountedCutsceneIntroFastMove = true
                        autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                    }
                    statusMessage = "⚡ [$overlayVersion] +$moveCountToCredit ${activeFm.name} (${updatedSnap.energy}E)"
                    onUiStateChanged()
                }
            }
            return true
        }

        return false
    }

    private fun isPlayerBubbleMinigameText(rawText: String): Boolean {
        val lower = rawText.lowercase()
        return lower.contains("nice!") ||
            lower.contains("great!") ||
            lower.contains("excellent!") ||
            lower.contains("swipe")
    }

    private fun prepareHudPillForOcr(bmp: Bitmap): Bitmap {
        return try {
            Bitmap.createScaledBitmap(bmp, max(1, bmp.width * 2), max(1, bmp.height * 2), true)
        } catch (_: Exception) {
            bmp
        }
    }

    private fun lockOpponentFromGoBanner(rawBanner: String, badgeTypesThisFrame: Set<String>) {
        var goOpponent = PvPokeRepository.matchOpponentFromGoBanner(rawBanner, badgeTypesThisFrame) ?: return
        if (goOpponent.id == currentPlayerPokemonId) return
        val baseKey = goOpponent.name.substringBefore("(").trim().lowercase()
        val manualId = manualFormOverrideByBase[baseKey]
        if (manualId != null) {
            val manualEntry = PvPokeRepository.getSiblingForms(goOpponent).firstOrNull { it.id == manualId }
            if (manualEntry != null) goOpponent = manualEntry
        }
        seenOpponentPokemon[goOpponent.id] = goOpponent
        if (!hasLockedFirstRealOpponentInMatch) {
            hasLockedFirstRealOpponentInMatch = true
            if (goOpponent.id != currentPokemon.id) {
                seenOpponentPokemon.remove(currentPokemon.id)
            }
        }
        if (goOpponent.id != currentPokemon.id) {
            currentPokemon = goOpponent
            fastHitsLandedOnCurrentPlayer = 0
            observedSingleHitDropPx = 0
            latestEffectivenessHint = null
            hasDispatchedChargedMoveForCurrentCutscene = false
            lastDispatchedChargedMove = null
            lastDispatchedChargedPokemonId = null
            visualClassifier.resetForNewOpponent()
            val newFm = getActiveFastMove(goOpponent)
            sessionManager.onSwitch(
                newPokemonId = goOpponent.id,
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                transferOpeningEnergy = false,
                pauseForSwitchWindow = false
            ) {
                statusMessage = "● Locked: " + goOpponent.name
                onUiStateChanged()
            }
        }
    }

    private fun handleMatchedOpponentPokemon(
        matchedInput: PvPokeEntry,
         telemetry: FrameVisualTelemetry,
        ocrCropRealtimeMs: Long
    ) {
        var matchedPoke = matchedInput
        val baseKey = matchedPoke.name.substringBefore("(").trim().lowercase()
        val manualId = manualFormOverrideByBase[baseKey]
        if (manualId != null) {
            val manualEntry = PvPokeRepository.getSiblingForms(matchedPoke).firstOrNull { it.id == manualId }
            if (manualEntry != null) matchedPoke = manualEntry
        }

        val isRealPoke = !matchedPoke.id.startsWith("dyn_")
        if (!isRealPoke && hasLockedFirstRealOpponentInMatch) {
            val curBase = currentPokemon.name.substringBefore("(").trim().lowercase()
            if (baseKey == curBase || baseKey.length < 4) {
                return
            }
            if (pendingDynOpponentId == matchedPoke.id) {
                pendingDynConfirmTicks++
            } else {
                pendingDynOpponentId = matchedPoke.id
                pendingDynConfirmTicks = 1
            }
            if (pendingDynConfirmTicks < 2) {
                return
            }
        } else {
            pendingDynOpponentId = null
            pendingDynConfirmTicks = 0
        }

        seenOpponentPokemon[matchedPoke.id] = matchedPoke

        val wasFirstLock = !hasLockedFirstRealOpponentInMatch && isRealPoke
        if (wasFirstLock) {
            hasLockedFirstRealOpponentInMatch = true
            if (matchedPoke.id != currentPokemon.id) {
                seenOpponentPokemon.remove(currentPokemon.id)
            }
        }

        if (matchedPoke.id != currentPokemon.id) {
            val prevBaseKey = currentPokemon.name.substringBefore("(").trim().lowercase()
            val isSameBaseOrOpeningSwap =
                wasFirstLock || (prevBaseKey == baseKey)
            val nowSwitchMs = SystemClock.elapsedRealtime()
            var shouldCreditOpeningMoveToNewPoke = false
            val stolenMoveTimestampMs = lastAcceptedFastMoveWallMs

            if (isSameBaseOrOpeningSwap) {
                seenOpponentPokemon.remove(currentPokemon.id)
            } else {
                lastOpponentSendOutRealtimeMs = nowSwitchMs
                if (
                    lastAcceptedFastMoveWallMs > 0L &&
                    (nowSwitchMs - lastAcceptedFastMoveWallMs) <= 550L &&
                    lastAcceptedFastMoveWallMs >= (ocrCropRealtimeMs - 250L)
                ) {
                    sessionManager.adjustFastMovesManually(-1)
                    shouldCreditOpeningMoveToNewPoke = true
                }

                val liveTelem = latestLiveTelemetry ?: telemetry
                val liveHp = liveTelem.playerHpFillPx
                val activeDropInProgress =
                    sustainedOnePxDropTicks >= 1 ||
                        (liveHp > 0 && refPlayerHpFillPx != null && (refPlayerHpFillPx!! - liveHp) >= 2)
                if (!activeDropInProgress) {
                    sustainedOnePxDropTicks = 0
                    onePxDropStartRealtimeMs = 0L
                    zeroOrangeDropTicks = 0
                    higherHpConfirmTicks = 0
                    prevOrangeDrainPx = 0
                    if (liveHp > 0) {
                        refPlayerHpFillPx = liveHp
                        lastCountedMoveHpPx = liveHp
                    }
                }
            }
            currentPokemon = matchedPoke
            fastHitsLandedOnCurrentPlayer = 0
            observedSingleHitDropPx = 0
            latestEffectivenessHint = null
            hasDispatchedChargedMoveForCurrentCutscene = false
            lastDispatchedChargedMove = null
            lastDispatchedChargedPokemonId = null
            visualClassifier.resetForNewOpponent()

            val newFm = getActiveFastMove(matchedPoke)
            val elapsedSinceMatchStart = nowSwitchMs - matchStartRealtimeMs
            val canTransferOnFirstLock =
                (prevBaseKey == baseKey) ||
                    (wasFirstLock && elapsedSinceMatchStart >= max(1400L, newFm.turns * 500L + 400L))
            sessionManager.onSwitch(
                newPokemonId = matchedPoke.id,
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                transferOpeningEnergy = canTransferOnFirstLock,
                pauseForSwitchWindow = false
            ) { snap ->
                statusMessage = if (snap.energy > 0) {
                    "🔄 Restored ${matchedPoke.name}: ${snap.displayedFastMoveCount} Fast (${snap.energy}E)"
                } else {
                    "● Locked: ${matchedPoke.name}"
                }
                onUiStateChanged()
            }
            if (shouldCreditOpeningMoveToNewPoke) {
                sessionManager.onFastMoveSignal(
                    allowDuringCutsceneIntro = false,
                    count = 1,
                    advanceTimestampByMs = stolenMoveTimestampMs
                ) { accepted, updatedSnap ->
                    if (accepted) {
                        fastHitsLandedOnCurrentPlayer += 1
                        statusMessage = "⚡ [$overlayVersion] +1 ${newFm.name} (${updatedSnap.energy}E)"
                        onUiStateChanged()
                    }
                }
            }
        } else if (
            !statusMessage.startsWith("⚡") &&
            !statusMessage.startsWith("▼") &&
            !statusMessage.startsWith("🔄")
        ) {
            statusMessage = "● [$overlayVersion] Watching ${matchedPoke.name}"
            onUiStateChanged()
        }
    }

    /**
     * Turn-Cadence Safety-Net Auto-Ticker: requires `nowRealtimeMs >= nextAllowedFastMoveRealtimeMs`,
     * full turn duration (`activeFm.turns * 500L + 60L` buffer) elapsed, AND real HP drop telemetry
     * (`cumulativeUncreditedDropPx >= 2` or `cumulativeUncreditedDropPx >= 1 && orangeDrainPx >= 1`)
     * so it NEVER fires early or credits an extra move purely on elapsed time.
     */
    private fun checkTurnCadenceSafetyNet(nowRealtimeMs: Long, currentHpPx: Int, orangeDrainPx: Int) {
        if (!inActiveMatch || !isBattleHudCurrentlyVisible || currentHpPx <= 0) return
        if ((nowRealtimeMs - matchStartRealtimeMs) < 1200L) return
        if (playerUsedChargedMoveDuringZoom || nowRealtimeMs < playerOwnChargedBannerLockUntilMs) return
        if (nowRealtimeMs < postCutsceneDrainSettleUntilMs) return
        if (sessionManager.snapshotFlow.value.state != BattleState.ACTIVE) return
        if (nowRealtimeMs < sessionManager.nextAllowedFastMoveRealtimeMs) return

        val activeFm = getActiveFastMove()
        val baseHpPx = lastCountedMoveHpPx ?: refPlayerHpFillPx ?: return
        val cumulativeUncreditedDropPx = baseHpPx - currentHpPx
        val hasVerifiedDropTelemetry = cumulativeUncreditedDropPx >= 1 || orangeDrainPx >= 1
        if (!hasVerifiedDropTelemetry) return

        val minRequiredElapsedMs = if (activeFm.turns == 1) {
            480L
        } else {
            activeFm.turns * 500L + 150L
        }
        val lastAcceptMs = sessionManager.lastAcceptedFastMoveRealtimeMs
        val anchorMs = if (lastAcceptMs > 0L) {
            lastAcceptMs
        } else {
            max(matchStartRealtimeMs + 450L, lastCutsceneEndRealtimeMs + 400L)
        }

        if ((nowRealtimeMs - anchorMs) >= minRequiredElapsedMs) {
            val advanceTs = if (activeFm.turns == 1 && lastAcceptMs > 0L && (nowRealtimeMs - lastAcceptMs) in 480L..750L) {
                lastAcceptMs + 500L
            } else {
                nowRealtimeMs
            }
            sessionManager.onFastMoveSignal(
                allowDuringCutsceneIntro = false,
                count = 1,
                advanceTimestampByMs = advanceTs
            ) { accepted, updatedSnap ->
                if (accepted) {
                    refPlayerHpFillPx = currentHpPx
                    lastCountedMoveHpPx = currentHpPx
                    preChargedMoveHpPx = currentHpPx
                    fastHitsLandedOnCurrentPlayer += 1
                    lastAcceptedFastMoveWallMs = nowRealtimeMs
                    statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (${updatedSnap.energy}E)"
                    onUiStateChanged()
                }
            }
        }
    }

    /**
     * Analyzes the latest captured frame and dispatches battle state / move signals to [sessionManager].
     */
    fun processFrame(image: Image, overlayRect: OverlayImageRect?, tickMs: Long) {
        val nowRealtimeMs = SystemClock.elapsedRealtime()
        if (isOcrBusy && nowRealtimeMs - lastOcrStartRealtimeMs > 2500L) {
            isOcrBusy = false
        }

        var telemetry = FrameVisualTelemetry(
            true, false, false, false, 66, -1, -1, 0, 0, 99, -1, 0, emptySet()
        )
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var aboveHpEffBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        var ocrCropRealtimeMs = nowRealtimeMs
        val ocrThrottleMs = if (!hasLockedFirstRealOpponentInMatch || (nowRealtimeMs - lastOpponentSendOutRealtimeMs) < 2000L) 150L else 300L
        var shouldRunOcrThisTick = !isOcrBusy && (nowRealtimeMs - lastOcrCompletedRealtimeMs >= ocrThrottleMs)

        try {
            telemetry = analyzeFrameVisualTelemetry(image, overlayRect)
            latestLiveTelemetry = telemetry
            if (inActiveMatch && telemetry.isFrameNonBlack) {
                val rightPillReturned = !wasRightPillVisibleLastTick && telemetry.isRightPillVisible
                val badgesChanged =
                    telemetry.opponentBadgeTypes.isNotEmpty() &&
                        telemetry.opponentBadgeTypes != lastSeenOpponentBadgeTypes
                if (rightPillReturned || badgesChanged) {
                    lastOpponentSendOutRealtimeMs = nowRealtimeMs
                    lastOcrCompletedRealtimeMs = 0L
                }
                wasRightPillVisibleLastTick = telemetry.isRightPillVisible
                if (telemetry.opponentBadgeTypes.isNotEmpty()) {
                    lastSeenOpponentBadgeTypes = telemetry.opponentBadgeTypes
                }
            }
            val updatedOcrThrottleMs = if (!hasLockedFirstRealOpponentInMatch || (nowRealtimeMs - lastOpponentSendOutRealtimeMs) < 2000L) 150L else 300L
            shouldRunOcrThisTick = !isOcrBusy && (nowRealtimeMs - lastOcrCompletedRealtimeMs >= updatedOcrThrottleMs)
            val isWideArenaCombat = telemetry.isBattleHudVisible && telemetry.playerHpFillPx > 0
            val height = image.height
            val overlayTopRatio = if (overlayRect != null && height > 0) (overlayRect.top.toFloat() / height.toFloat()) else 0.090f
            val safeTopRightBottom = min(0.092f, (overlayTopRatio - 0.004f).coerceAtLeast(0.068f))

            if (telemetry.isFrameNonBlack) {
                if (isWideArenaCombat && currentPokemon.fastMoves.size > 1) {
                    arenaVisualBmp = cropRegionFromImage(image, 0.05f, 0.16f, 0.48f, 0.78f, step = 2)
                }
                if (shouldRunOcrThisTick) {
                    ocrCropRealtimeMs = nowRealtimeMs
                    if (telemetry.isBattleHudVisible || telemetry.isRightPillVisible) {
                        topRightBmp = cropRegionFromImage(image, 0.50f, 0.015f, 0.99f, safeTopRightBottom, step = 1, maskOverlayRect = overlayRect)
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.46f, 0.140f, step = 1, maskOverlayRect = overlayRect)
                    }
                    if (
                        telemetry.isBattleHudVisible &&
                        postCutsceneBannerTicks <= 0 &&
                        telemetry.playerHpBarY > 10 &&
                        currentPokemon.fastMoves.size > 1 &&
                        nowRealtimeMs >= ignoreAboveHpEffUntilRealtimeMs
                    ) {
                        val hpYRatio = telemetry.playerHpBarY.toFloat() / image.height
                        val effTop = max(0.02f, hpYRatio - 0.050f)
                        val effBot = max(effTop + 0.02f, hpYRatio - 0.003f)
                        aboveHpEffBmp = cropRegionFromImage(
                            image, 0.02f, effTop, 0.50f, effBot, step = 1, maskOverlayRect = overlayRect
                        )
                    }
                    if (!telemetry.isBattleHudVisible || postCutsceneBannerTicks > 0 || telemetry.playerHpFillPx <= 0) {
                        bannerBmp = if (telemetry.isBattleHudVisible) {
                            cropRegionFromImage(
                                image, 0.06f, 0.08f, 0.92f, 0.46f, step = 1, maskOverlayRect = null
                            )
                        } else {
                            cropRegionFromImage(
                                image, 0.06f, 0.08f, 0.92f, 0.88f, step = 1, maskOverlayRect = null
                            )
                        }
                    }
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        processCapturedTelemetryAndCrops(
            nowRealtimeMs = nowRealtimeMs,
            tickMs = tickMs,
            telemetry = telemetry,
            arenaVisualBmp = arenaVisualBmp,
            topRightBmp = topRightBmp,
            topLeftBmp = topLeftBmp,
            aboveHpEffBmp = aboveHpEffBmp,
            bannerBmp = bannerBmp,
            shouldRunOcrThisTick = shouldRunOcrThisTick,
            ocrCropRealtimeMs = ocrCropRealtimeMs
        )
    }

    /**
     * Processes a software [Bitmap] captured via [PokeCountAccessibilityService.captureAccessibilityFrame]
     * when Samsung's native Screen Recorder (or another recorder) is using MediaProjection.
     */
    fun processBitmapFrame(bitmap: Bitmap, overlayRect: OverlayImageRect?, tickMs: Long) {
        val nowRealtimeMs = SystemClock.elapsedRealtime()
        if (isOcrBusy && nowRealtimeMs - lastOcrStartRealtimeMs > 2500L) {
            isOcrBusy = false
        }

        var telemetry = FrameVisualTelemetry(
            true, false, false, false, 66, -1, -1, 0, 0, 99, -1, 0, emptySet()
        )
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var aboveHpEffBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        var ocrCropRealtimeMs = nowRealtimeMs
        val ocrThrottleMs = if (!hasLockedFirstRealOpponentInMatch || (nowRealtimeMs - lastOpponentSendOutRealtimeMs) < 2000L) 150L else 300L
        var shouldRunOcrThisTick = !isOcrBusy && (nowRealtimeMs - lastOcrCompletedRealtimeMs >= ocrThrottleMs)

        try {
            val width = bitmap.width
            val height = bitmap.height
            val rowStride = width * 4
            val byteBuf = java.nio.ByteBuffer.allocate(bitmap.byteCount)
            bitmap.copyPixelsToBuffer(byteBuf)
            byteBuf.rewind()

            telemetry = analyzeBufferVisualTelemetry(byteBuf, width, height, 4, rowStride, overlayRect)
            latestLiveTelemetry = telemetry
            if (inActiveMatch && telemetry.isFrameNonBlack) {
                val rightPillReturned = !wasRightPillVisibleLastTick && telemetry.isRightPillVisible
                val badgesChanged =
                    telemetry.opponentBadgeTypes.isNotEmpty() &&
                        telemetry.opponentBadgeTypes != lastSeenOpponentBadgeTypes
                if (rightPillReturned || badgesChanged) {
                    lastOpponentSendOutRealtimeMs = nowRealtimeMs
                    lastOcrCompletedRealtimeMs = 0L
                }
                wasRightPillVisibleLastTick = telemetry.isRightPillVisible
                if (telemetry.opponentBadgeTypes.isNotEmpty()) {
                    lastSeenOpponentBadgeTypes = telemetry.opponentBadgeTypes
                }
            }
            val updatedOcrThrottleMs = if (!hasLockedFirstRealOpponentInMatch || (nowRealtimeMs - lastOpponentSendOutRealtimeMs) < 2000L) 150L else 300L
            shouldRunOcrThisTick = !isOcrBusy && (nowRealtimeMs - lastOcrCompletedRealtimeMs >= updatedOcrThrottleMs)
            val isWideArenaCombat = telemetry.isBattleHudVisible && telemetry.playerHpFillPx > 0
            val overlayTopRatio = if (overlayRect != null && height > 0) (overlayRect.top.toFloat() / height.toFloat()) else 0.090f
            val safeTopRightBottom = min(0.092f, (overlayTopRatio - 0.004f).coerceAtLeast(0.068f))

            if (telemetry.isFrameNonBlack) {
                if (isWideArenaCombat && currentPokemon.fastMoves.size > 1) {
                    arenaVisualBmp = cropRegionFromBuffer(
                        byteBuf, width, height, 4, rowStride, 0.05f, 0.16f, 0.48f, 0.78f, step = 2
                    )
                }
                if (shouldRunOcrThisTick) {
                    ocrCropRealtimeMs = nowRealtimeMs
                    if (telemetry.isBattleHudVisible || telemetry.isRightPillVisible) {
                        topRightBmp = cropRegionFromBuffer(
                            byteBuf, width, height, 4, rowStride, 0.50f, 0.015f, 0.99f, safeTopRightBottom, step = 1, maskOverlayRect = overlayRect
                        )
                        topLeftBmp = cropRegionFromBuffer(
                            byteBuf, width, height, 4, rowStride, 0.02f, 0.015f, 0.46f, 0.140f, step = 1, maskOverlayRect = overlayRect
                        )
                    }
                    if (
                        telemetry.isBattleHudVisible &&
                        postCutsceneBannerTicks <= 0 &&
                        telemetry.playerHpBarY > 10 &&
                        currentPokemon.fastMoves.size > 1 &&
                        nowRealtimeMs >= ignoreAboveHpEffUntilRealtimeMs
                    ) {
                        val hpYRatio = telemetry.playerHpBarY.toFloat() / height
                        val effTop = max(0.02f, hpYRatio - 0.050f)
                        val effBot = max(effTop + 0.02f, hpYRatio - 0.003f)
                        aboveHpEffBmp = cropRegionFromBuffer(
                            byteBuf, width, height, 4, rowStride, 0.02f, effTop, 0.50f, effBot, step = 1, maskOverlayRect = overlayRect
                        )
                    }
                    if (!telemetry.isBattleHudVisible || postCutsceneBannerTicks > 0 || telemetry.playerHpFillPx <= 0) {
                        bannerBmp = if (telemetry.isBattleHudVisible) {
                            cropRegionFromBuffer(
                                byteBuf, width, height, 4, rowStride, 0.06f, 0.08f, 0.92f, 0.46f, step = 1, maskOverlayRect = null
                            )
                        } else {
                            cropRegionFromBuffer(
                                byteBuf, width, height, 4, rowStride, 0.06f, 0.08f, 0.92f, 0.88f, step = 1, maskOverlayRect = null
                            )
                        }
                    }
                }
            }
        } finally {
            try {
                bitmap.recycle()
            } catch (_: Exception) {
            }
        }

        processCapturedTelemetryAndCrops(
            nowRealtimeMs = nowRealtimeMs,
            tickMs = tickMs,
            telemetry = telemetry,
            arenaVisualBmp = arenaVisualBmp,
            topRightBmp = topRightBmp,
            topLeftBmp = topLeftBmp,
            aboveHpEffBmp = aboveHpEffBmp,
            bannerBmp = bannerBmp,
            shouldRunOcrThisTick = shouldRunOcrThisTick,
            ocrCropRealtimeMs = ocrCropRealtimeMs
        )
    }

    private fun processCapturedTelemetryAndCrops(
        nowRealtimeMs: Long,
        tickMs: Long,
        telemetry: FrameVisualTelemetry,
        arenaVisualBmp: Bitmap?,
        topRightBmp: Bitmap?,
        topLeftBmp: Bitmap?,
        aboveHpEffBmp: Bitmap?,
        bannerBmp: Bitmap?,
        shouldRunOcrThisTick: Boolean,
        ocrCropRealtimeMs: Long
    ) {
        if (!telemetry.isFrameNonBlack) {
            return
        }

        val badgeTypesThisFrame = telemetry.opponentBadgeTypes

        if (telemetry.isBattleHudVisible) {
            consecutiveHudVisibleTicks++
            if (postCutsceneBannerTicks > 0) {
                postCutsceneBannerTicks--
                if (postCutsceneBannerTicks == 0) {
                    sessionManager.clearCutsceneEnergySnapshot()
                    hasDispatchedChargedMoveForCurrentCutscene = false
                }
            }

            if (!inActiveMatch) {
                inActiveMatch = true
                matchStartRealtimeMs = nowRealtimeMs
                val initialHp = telemetry.playerHpFillPx.takeIf { it > 0 }
                val initialY = if (initialHp != null) telemetry.playerHpBarY else -1
                resetAnalyzerAndSession(
                    statusMsg = "● [$overlayVersion] Battle Active",
                    preLockedHpPx = initialHp,
                    preLockedBarY = initialY
                )
            } else if (!isBattleHudCurrentlyVisible && hudCompletelyMissingDurationMs >= 1000L) {
                postCutsceneBannerTicks = 28

                val wasOpponentChargedMove =
                    !playerUsedChargedMoveDuringZoom &&
                        nowRealtimeMs >= playerOwnChargedBannerLockUntilMs &&
                        (chargedAttackDetectedDuringPause ||
                            specificMoveDetectedDuringPause != null ||
                            hasDispatchedChargedMoveForCurrentCutscene)

                lastCutsceneEndRealtimeMs = nowRealtimeMs
                ignoreAboveHpEffUntilRealtimeMs = nowRealtimeMs + 2800L
                latestEffectivenessHint = null

                sustainedOnePxDropTicks = 0
                onePxDropStartRealtimeMs = 0L
                zeroOrangeDropTicks = 0
                higherHpConfirmTicks = 0
                prevOrangeDrainPx = 0

                if (wasOpponentChargedMove) {
                    postCutsceneDrainSettleUntilMs = nowRealtimeMs + 400L
                    playerUsedChargedMoveDuringZoom = false
                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(specificMoveDetectedDuringPause?.energyCost)
                    if (!hasDispatchedChargedMoveForCurrentCutscene) {
                        val snapEnergy = sessionManager.snapshotFlow.value.energy
                        val moveToSub = specificMoveDetectedDuringPause ?: run {
                            currentPokemon.chargedMoves.firstOrNull { snapEnergy >= it.energyCost }
                                ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                        }
                        if (moveToSub != null && nowRealtimeMs - lastDispatchedChargedTimestampMs > 3000L) {
                            dispatchChargedMoveSignal(moveToSub, pauseClock = false)
                        }
                    }
                    val returnHp = telemetry.playerHpFillPx.takeIf { it > 0 }
                    refPlayerHpFillPx = returnHp
                    lastCountedMoveHpPx = returnHp
                    refPlayerHpBarY = if (returnHp != null) telemetry.playerHpBarY else -1
                    preChargedMoveHpPx = returnHp
                    postOpponentCutsceneHpPx = null
                    hasCountedCutsceneIntroFastMove = false
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = false) {
                        onUiStateChanged()
                    }
                } else if (playerUsedChargedMoveDuringZoom && hudCompletelyMissingDurationMs <= 6500L) {
                    postCutsceneDrainSettleUntilMs = nowRealtimeMs + 400L
                    playerUsedChargedMoveDuringZoom = true
                    lastPlayerOwnChargedCutsceneEndMs = nowRealtimeMs
                    if (preChargedMoveHpPx != null) {
                        refPlayerHpFillPx = preChargedMoveHpPx
                        lastCountedMoveHpPx = preChargedMoveHpPx
                        refPlayerHpBarY = preChargedMoveHpBarY
                    }
                    hasDispatchedChargedMoveForCurrentCutscene = false
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = true) {
                        onUiStateChanged()
                    }
                } else {
                    postCutsceneDrainSettleUntilMs = nowRealtimeMs + 400L
                    playerUsedChargedMoveDuringZoom = false
                    val returnHp = telemetry.playerHpFillPx.takeIf { it > 0 }
                    refPlayerHpFillPx = returnHp
                    lastCountedMoveHpPx = returnHp
                    refPlayerHpBarY = if (returnHp != null) telemetry.playerHpBarY else -1
                    preChargedMoveHpPx = returnHp
                    hasDispatchedChargedMoveForCurrentCutscene = false
                    lastOpponentSendOutRealtimeMs = nowRealtimeMs
                    lastOcrCompletedRealtimeMs = 0L
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = true) {
                        onUiStateChanged()
                    }
                }

                chargedAttackDetectedDuringPause = false
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudCompletelyMissingDurationMs = 0L

            if (telemetry.playerHpFillPx <= 0 && telemetry.centeredHpFillPx > 0) {
                checkCenteredHpBarForFastMoveSneak(
                    barLen = telemetry.barLenPx,
                    centeredHpPx = telemetry.centeredHpFillPx,
                    centeredOrangePx = telemetry.centeredOrangeDrainPx,
                    nowRealtimeMs = nowRealtimeMs
                )
            }

            if (
                nowRealtimeMs >= playerOwnChargedBannerLockUntilMs &&
                sessionManager.snapshotFlow.value.state != BattleState.ACTIVE
            ) {
                playerUsedChargedMoveDuringZoom = false
                sessionManager.onMinigameEnd(clearCutsceneSnapshot = false) {
                    onUiStateChanged()
                }
            }

            if (telemetry.playerHpFillPx <= 0) {
                if (hpBarOccludedTicks == 0) {
                    hpBarOccludedSinceRealtimeMs = nowRealtimeMs
                }
                hpBarOccludedTicks++
            }

            if (telemetry.playerHpFillPx > 0 && nowRealtimeMs >= playerOwnChargedBannerLockUntilMs) {
                if (playerUsedChargedMoveDuringZoom) {
                    playerUsedChargedMoveDuringZoom = false
                    lastPlayerOwnChargedCutsceneEndMs = nowRealtimeMs
                    val preHp = preChargedMoveHpPx
                    val minSneakPx = if (observedSingleHitDropPx == 1) 1 else 2
                    val maxSneakPx = (telemetry.barLenPx * 0.72f).toInt()
                    if (
                        !hasCountedCutsceneIntroFastMove &&
                        preHp != null &&
                        (preHp - telemetry.playerHpFillPx) in minSneakPx..maxSneakPx
                    ) {
                        hasCountedCutsceneIntroFastMove = true
                        val activeFm = getActiveFastMove()
                        sessionManager.onFastMoveSignal(
                            allowDuringCutsceneIntro = true,
                            count = 1,
                            advanceTimestampByMs = nowRealtimeMs - (activeFm.turns * 500L - 350L)
                        ) { accepted, updatedSnap ->
                            if (accepted) {
                                fastHitsLandedOnCurrentPlayer++
                                autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                                statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (Sneak · ${updatedSnap.energy}E)"
                                onUiStateChanged()
                            }
                        }
                    }
                    hasCountedCutsceneIntroFastMove = false
                    refPlayerHpFillPx = telemetry.playerHpFillPx
                    lastCountedMoveHpPx = telemetry.playerHpFillPx
                    refPlayerHpBarY = telemetry.playerHpBarY
                    refPlayerHpStage = telemetry.playerHpStage
                    preChargedMoveHpPx = telemetry.playerHpFillPx
                    preChargedMoveHpBarY = telemetry.playerHpBarY
                    prevOrangeDrainPx = telemetry.orangeDrainPx
                    higherHpConfirmTicks = 0
                    sustainedOnePxDropTicks = 0
                    onePxDropStartRealtimeMs = 0L
                    zeroOrangeDropTicks = 0
                } else {
                    val justDispatchedHit = evaluatePlayerHpBarAndDispatchSignal(
                        barLen = telemetry.barLenPx,
                        hpPx = telemetry.playerHpFillPx,
                        hpBarY = telemetry.playerHpBarY,
                        hpStage = telemetry.playerHpStage,
                        orangeDrainPx = telemetry.orangeDrainPx,
                        emptyAfterFillPx = telemetry.emptyAfterFillPx,
                        nowRealtimeMs = nowRealtimeMs,
                        allowDuringCutsceneIntro = false
                    )
                    hpBarOccludedTicks = 0
                    hpBarOccludedSinceRealtimeMs = 0L

                    if (
                        arenaVisualBmp != null &&
                        currentPokemon.fastMoves.size > 1 &&
                        !manualFastMoveLockedIds.contains(currentPokemon.id)
                    ) {
                        val curActiveIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                        val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                            arenaVisualBmp,
                            currentPokemon,
                            curActiveIdx,
                            latestEffectivenessHint,
                            playerDefenderTypes,
                            fastHitsLandedOnCurrentPlayer,
                            justDispatchedHit
                        )
                        if (detectedFmIdx != null && detectedFmIdx != curActiveIdx) {
                            slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                            val newFm = getActiveFastMove()
                            statusMessage = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                            sessionManager.configureFastMove(
                                durationTurns = newFm.turns,
                                energyGain = newFm.energyGain,
                                moveName = newFm.name,
                                preserveMoveCount = true
                            ) {
                                onUiStateChanged()
                            }
                        }
                    }
                }
            }

            if (sessionManager.snapshotFlow.value.state == BattleState.ACTIVE) {
                checkTurnCadenceSafetyNet(nowRealtimeMs, telemetry.playerHpFillPx, telemetry.orangeDrainPx)
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartRealtimeMs = nowRealtimeMs
                val scaledRightBmp = prepareHudPillForOcr(topRightBmp)
                recognizer.process(InputImage.fromBitmap(scaledRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        val matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text, badgeTypesThisFrame)
                        if (matchedPoke != null) {
                            handleMatchedOpponentPokemon(matchedPoke, telemetry, ocrCropRealtimeMs)
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            val scaledLeftBmp = prepareHudPillForOcr(topLeftBmp)
                            recognizer.process(InputImage.fromBitmap(scaledLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val rawLeft = leftText.text
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(rawLeft)
                                    if (
                                        playerPoke != null &&
                                        playerPoke.id != currentPlayerPokemonId
                                    ) {
                                        currentPlayerPokemonId = playerPoke.id
                                        currentPlayerPokemonName = playerPoke.name
                                        playerDefenderTypes = PvPokeRepository.getDefenderTypes(playerPoke)
                                        fastHitsLandedOnCurrentPlayer = 0
                                        observedSingleHitDropPx = 0
                                        latestEffectivenessHint = null
                                    }
                                }
                                .addOnCompleteListener {
                                    val nextBmp = aboveHpEffBmp ?: bannerBmp
                                    val isBannerCrop = (aboveHpEffBmp == null && bannerBmp != null)
                                    if (nextBmp != null) {
                                        recognizer.process(InputImage.fromBitmap(nextBmp, 0))
                                            .addOnSuccessListener { subText ->
                                                val rawS = subText.text
                                                if (!isBannerCrop) {
                                                    if (SystemClock.elapsedRealtime() >= ignoreAboveHpEffUntilRealtimeMs) {
                                                        val (_, _, effH) =
                                                            PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                        if (effH != null) {
                                                            latestEffectivenessHint = effH
                                                            if (
                                                                currentPokemon.fastMoves.size > 1 &&
                                                                !manualFastMoveLockedIds.contains(currentPokemon.id) &&
                                                                playerDefenderTypes.isNotEmpty()
                                                            ) {
                                                                val curActiveIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                                                                val detectedFmIdx = visualClassifier.matchFastMoveByEffectiveness(
                                                                    currentPokemon,
                                                                    curActiveIdx,
                                                                    effH,
                                                                    playerDefenderTypes
                                                                )
                                                                if (detectedFmIdx != null && detectedFmIdx != curActiveIdx) {
                                                                    slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                                                                    val newFm = getActiveFastMove()
                                                                    statusMessage = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                                                                    sessionManager.configureFastMove(
                                                                        durationTurns = newFm.turns,
                                                                        energyGain = newFm.energyGain,
                                                                        moveName = newFm.name,
                                                                        preserveMoveCount = true
                                                                    ) {
                                                                        onUiStateChanged()
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    lockOpponentFromGoBanner(rawS, badgeTypesThisFrame)
                                                    if (
                                                        isPlayerBubbleMinigameText(rawS) ||
                                                    PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                                        rawS,
                                                        currentPlayerPokemonName,
                                                        currentPokemon.name
                                                    )
                                                ) {
                                                    handleDetectedPlayerOwnChargedMove(rawS)
                                                } else {
                                                    val (_, specificMove, _) =
                                                        PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    val recentlyFinishedOwnMove =
                                                        (SystemClock.elapsedRealtime() - lastPlayerOwnChargedCutsceneEndMs) < 2500L
                                                    if (specificMove != null && !recentlyFinishedOwnMove) {
                                                        ignoreAboveHpEffUntilRealtimeMs = SystemClock.elapsedRealtime() + 2800L
                                                        reconcileChargedMoveFromBanner(specificMove, pauseClock = false)
                                                    }
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                                lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                                isOcrBusy = false
                                            }
                                    } else {
                                        lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                        isOcrBusy = false
                                    }
                                }
                        } else if (bannerBmp != null) {
                            recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                                .addOnSuccessListener { bText ->
                                    val rawB = bText.text
                                    lockOpponentFromGoBanner(rawB, badgeTypesThisFrame)
                                    if (
                                        isPlayerBubbleMinigameText(rawB) ||
                                        PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                            rawB,
                                            currentPlayerPokemonName,
                                            currentPokemon.name
                                        )
                                    ) {
                                        handleDetectedPlayerOwnChargedMove(rawB)
                                    } else {
                                        val (_, specificMove, _) =
                                            PvPokeRepository.detectChargedAttackAndEffectiveness(rawB, currentPokemon)
                                        val recentlyFinishedOwnMove =
                                            (SystemClock.elapsedRealtime() - lastPlayerOwnChargedCutsceneEndMs) < 2500L
                                        if (specificMove != null && !recentlyFinishedOwnMove) {
                                            ignoreAboveHpEffUntilRealtimeMs = SystemClock.elapsedRealtime() + 2800L
                                            reconcileChargedMoveFromBanner(specificMove, pauseClock = false)
                                        }
                                    }
                                }
                                .addOnCompleteListener {
                                    lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                    isOcrBusy = false
                                }
                        } else {
                            lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            consecutiveHudVisibleTicks = 0
            if (!inActiveMatch) {
                refPlayerHpFillPx = null
                lastCountedMoveHpPx = null
                refPlayerHpBarY = -1
                preChargedMoveHpPx = null
                preChargedMoveHpBarY = -1
            }

            if (isBattleHudCurrentlyVisible && inActiveMatch) {
                if (refPlayerHpFillPx != null) {
                    preChargedMoveHpPx = refPlayerHpFillPx
                    preChargedMoveHpBarY = refPlayerHpBarY
                }
                postOpponentCutsceneHpPx = null
                hasDispatchedChargedMoveForCurrentCutscene = false
                hasCountedCutsceneIntroFastMove = false
            }
            isBattleHudCurrentlyVisible = false
            hudCompletelyMissingDurationMs += tickMs

            // Only pause the battle engine once the HUD has been missing for >= 300ms or a shield prompt / banner is active,
            // so a 1-2 frame bright lightning flash over the top name pills never triggers a false 450ms post-minigame lockout!
            if (
                inActiveMatch &&
                (hudCompletelyMissingDurationMs >= 300L ||
                    telemetry.isShieldPromptVisible ||
                    chargedAttackDetectedDuringPause ||
                    playerUsedChargedMoveDuringZoom) &&
                sessionManager.snapshotFlow.value.state == BattleState.ACTIVE
            ) {
                sessionManager.onMinigameStart {
                    onUiStateChanged()
                }
            }

            if (
                inActiveMatch &&
                !telemetry.isShieldPromptVisible &&
                !telemetry.hasTopCountdownCircle &&
                hudCompletelyMissingDurationMs >= 1200L &&
                telemetry.centeredHpFillPx > 0 &&
                telemetry.centeredOrangeDrainPx == 0
            ) {
                val prevSettled = postOpponentCutsceneHpPx
                postOpponentCutsceneHpPx = if (prevSettled == null) {
                    telemetry.centeredHpFillPx
                } else {
                    min(prevSettled, telemetry.centeredHpFillPx)
                }
            }

            // Evaluate pre-Charged-Move fast move drops when telemetry.isShieldPromptVisible or hudCompletelyMissingDurationMs < 300L
            if (
                inActiveMatch &&
                !playerUsedChargedMoveDuringZoom &&
                telemetry.playerHpFillPx > 0 &&
                !hasCountedCutsceneIntroFastMove &&
                telemetry.isShieldPromptVisible
            ) {
                evaluatePlayerHpBarAndDispatchSignal(
                    barLen = telemetry.barLenPx,
                    hpPx = telemetry.playerHpFillPx,
                    hpBarY = telemetry.playerHpBarY,
                    hpStage = telemetry.playerHpStage,
                    orangeDrainPx = telemetry.orangeDrainPx,
                    emptyAfterFillPx = telemetry.emptyAfterFillPx,
                    nowRealtimeMs = nowRealtimeMs,
                    allowDuringCutsceneIntro = true
                )
            } else if (
                inActiveMatch &&
                !telemetry.isShieldPromptVisible &&
                !chargedAttackDetectedDuringPause &&
                telemetry.centeredHpFillPx > 0 &&
                !hasCountedCutsceneIntroFastMove
            ) {
                checkCenteredHpBarForFastMoveSneak(
                    barLen = telemetry.barLenPx,
                    centeredHpPx = telemetry.centeredHpFillPx,
                    centeredOrangePx = telemetry.centeredOrangeDrainPx,
                    nowRealtimeMs = nowRealtimeMs
                )
            }

            if (hudCompletelyMissingDurationMs > 6500L && !chargedAttackDetectedDuringPause) {
                playerUsedChargedMoveDuringZoom = false
            }

            // A magenta Shield Prompt ONLY appears when the opponent is throwing a Charged Move (including the 2nd
            // half of a CMP tie right after the player's own Charged Move!), so always clear playerUsedChargedMoveDuringZoom!
            if (inActiveMatch && telemetry.isShieldPromptVisible) {
                playerUsedChargedMoveDuringZoom = false
                playerOwnChargedBannerLockUntilMs = 0L
                if (hasDispatchedChargedMoveForCurrentCutscene && (nowRealtimeMs - lastDispatchedChargedTimestampMs) > 4800L) {
                    hasDispatchedChargedMoveForCurrentCutscene = false
                }
                chargedAttackDetectedDuringPause = true

                autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                val snap = sessionManager.snapshotFlow.value
                val activeFm = getActiveFastMove()
                val refCm = specificMoveDetectedDuringPause ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                val minCmCost = refCm?.energyCost ?: 35
                val currentEnergy = snap.energy

                val missingMoves = if (currentEnergy < minCmCost) {
                    ceil((minCmCost - currentEnergy).toDouble() / max(1, activeFm.energyGain)).toInt().coerceIn(1, 5)
                } else {
                    0
                }
                if (!hasDispatchedChargedMoveForCurrentCutscene && missingMoves > 0) {
                    sessionManager.onFastMoveSignal(
                        allowDuringCutsceneIntro = true,
                        count = missingMoves
                    ) { accepted, _ ->
                        if (accepted) {
                            hasCountedCutsceneIntroFastMove = true
                            fastHitsLandedOnCurrentPlayer += missingMoves
                        }
                    }
                }
                sessionManager.onMinigameStart()
                if (!statusMessage.startsWith("▼")) {
                    statusMessage = "⚠️ Attack Incoming!"
                    onUiStateChanged()
                }
            }

            if (hudCompletelyMissingDurationMs >= 10000L && inActiveMatch) {
                inActiveMatch = false
                resetAnalyzerAndSession("● [$overlayVersion] Waiting for battle...")
            } else if (inActiveMatch && hudCompletelyMissingDurationMs >= 450L) {
                if (
                    !statusMessage.startsWith("⚠️") &&
                    !statusMessage.startsWith("🛡️") &&
                    !statusMessage.startsWith("▼") &&
                    !statusMessage.startsWith("⚡")
                ) {
                    statusMessage = "⏸ [$overlayVersion] Paused (Cutscene)"
                    onUiStateChanged()
                }
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartRealtimeMs = nowRealtimeMs
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        lockOpponentFromGoBanner(rawBanner, badgeTypesThisFrame)
                        if (!telemetry.isShieldPromptVisible && PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetAnalyzerAndSession("● [$overlayVersion] Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            if (
                                isPlayerBubbleMinigameText(rawBanner) ||
                                (!chargedAttackDetectedDuringPause &&
                                    PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                        rawBanner,
                                        currentPlayerPokemonName,
                                        currentPokemon.name
                                    ))
                            ) {
                                handleDetectedPlayerOwnChargedMove(rawBanner)
                            } else {
                                val (isIncoming, specificMove, _) =
                                    PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                                val pBase = currentPlayerPokemonName?.substringBefore("(")?.trim()?.lowercase()
                                val oBase = currentPokemon.name.substringBefore("(").trim().lowercase()
                                val isSameSpeciesMirror = !pBase.isNullOrBlank() && pBase == oBase
                                val isLikelyOwnMoveInMirror =
                                    (playerUsedChargedMoveDuringZoom || isSameSpeciesMirror && telemetry.hasTopCountdownCircle) &&
                                        !chargedAttackDetectedDuringPause &&
                                        !telemetry.isShieldPromptVisible

                                if (specificMove != null && !isLikelyOwnMoveInMirror) {
                                    playerUsedChargedMoveDuringZoom = false
                                    upgradeToSiblingFormIfMoveMatches(specificMove)
                                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy(specificMove.energyCost)
                                    specificMoveDetectedDuringPause = specificMove
                                    chargedAttackDetectedDuringPause = true
                                    if (hasDispatchedChargedMoveForCurrentCutscene && (nowRealtimeMs - lastDispatchedChargedTimestampMs) > 4800L) {
                                        hasDispatchedChargedMoveForCurrentCutscene = false
                                    }
                                    if (
                                        !hasDispatchedChargedMoveForCurrentCutscene &&
                                        nowRealtimeMs - lastDispatchedChargedTimestampMs > 3000L
                                    ) {
                                        dispatchChargedMoveSignal(specificMove, pauseClock = true)
                                    } else {
                                        reconcileChargedMoveFromBanner(specificMove, pauseClock = true)
                                    }
                                } else if (isIncoming) {
                                    playerUsedChargedMoveDuringZoom = false
                                    chargedAttackDetectedDuringPause = true
                                    autoUpgradeFastMoveIfChargedMoveRequiresMoreEnergy()
                                    sessionManager.onMinigameStart()
                                    if (!statusMessage.startsWith("⚡") && !statusMessage.startsWith("▼")) {
                                        statusMessage = "⚠️ Attack Incoming!"
                                        onUiStateChanged()
                                    }
                                }
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun analyzeFrameVisualTelemetry(image: Image, overlayRect: OverlayImageRect?): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            analyzeBufferVisualTelemetry(
                buf = plane.buffer,
                width = image.width,
                height = image.height,
                pixelStride = plane.pixelStride,
                rowStride = plane.rowStride,
                overlayRect = overlayRect
            )
        } catch (_: Exception) {
            FrameVisualTelemetry(
                true, false, false, false, 66, -1, -1, 0, 0, 99, -1, 0, emptySet()
            )
        }
    }

    private fun analyzeBufferVisualTelemetry(
        buf: java.nio.ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int,
        overlayRect: OverlayImageRect?
    ): FrameVisualTelemetry {
        return try {
            val bufLimit = buf.limit()
            val barLen = max(20, (width * 0.272f).roundToInt())

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(
                    false, false, false, false, barLen, -1, -1, 0, 0, 99, -1, 0, emptySet()
                )
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float, ignoreOverlay: Boolean): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.020f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.115f).toInt().coerceIn(y0 + 1, height)

                var highWhiteRows = 0
                var darkTextPixelsInWhiteRows = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowDark = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        if (ignoreOverlay && overlayRect != null && overlayRect.contains(x, y)) {
                            x += max(2, width / 160)
                            continue
                        }
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 215 && g >= 215 && b >= 215 && abs(r - g) <= 14 && abs(b - r) <= 18) {
                                rowWhite++
                            }
                            if (r < 95 && g < 95 && b < 105) {
                                rowDark++
                            }
                        }
                        x += max(2, width / 160)
                    }
                    if (rowTotal >= 6) {
                        val rowWhiteRatio = rowWhite.toFloat() / rowTotal
                        if (rowWhiteRatio >= 0.55f) {
                            highWhiteRows++
                        }
                        if (rowWhiteRatio >= 0.35f) {
                            darkTextPixelsInWhiteRows += rowDark
                        }
                    }
                    y += max(1, height / 700)
                }
                return highWhiteRows >= 4 && darkTextPixelsInWhiteRows >= 6
            }

            val leftPillVisible = checkBattlePillSide(0.02f, 0.42f, ignoreOverlay = true)
            val rightPillVisible = checkBattlePillSide(0.58f, 0.98f, ignoreOverlay = true)
            val hudPillsVisible = leftPillVisible && rightPillVisible

            var shieldMagentaCount = 0
            var shieldSampleTotal = 0
            val sx0 = (width * 0.38f).toInt().coerceIn(0, width - 2)
            val sx1 = (width * 0.62f).toInt().coerceIn(sx0 + 1, width)
            val sy0 = (height * 0.73f).toInt().coerceIn(0, height - 2)
            val sy1 = (height * 0.91f).toInt().coerceIn(sy0 + 1, height)
            var sy = sy0
            while (sy < sy1) {
                val rOff = sy * rowStride
                var sx = sx0
                while (sx < sx1) {
                    val off = rOff + sx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        shieldSampleTotal++
                        if (r >= 180 && b >= 195 && g in 110..220 && (r - g) >= 18 && (b - g) >= 20) {
                            shieldMagentaCount++
                        }
                    }
                    sx += max(2, width / 120)
                }
                sy += max(2, height / 250)
            }
            val shieldMagentaRatio = if (shieldSampleTotal > 0) shieldMagentaCount.toFloat() / shieldSampleTotal else 0f

            var flankDarkCount = 0
            var flankSampleTotal = 0
            val fy0 = (height * 0.76f).toInt().coerceIn(0, height - 2)
            val fy1 = (height * 0.90f).toInt().coerceIn(fy0 + 1, height)
            val lx0 = (width * 0.06f).toInt().coerceIn(0, width - 2)
            val lx1 = (width * 0.24f).toInt().coerceIn(lx0 + 1, width)
            val rx0 = (width * 0.76f).toInt().coerceIn(0, width - 2)
            val rx1 = (width * 0.94f).toInt().coerceIn(rx0 + 1, width)
            var fy = fy0
            while (fy < fy1) {
                val rOff = fy * rowStride
                var fx = lx0
                while (fx < lx1) {
                    val off = rOff + fx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        flankSampleTotal++
                        if (r < 65 && g < 65 && b < 75) flankDarkCount++
                    }
                    fx += max(2, width / 120)
                }
                fx = rx0
                while (fx < rx1) {
                    val off = rOff + fx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        flankSampleTotal++
                        if (r < 65 && g < 65 && b < 75) flankDarkCount++
                    }
                    fx += max(2, width / 120)
                }
                fy += max(2, height / 250)
            }
            val flankDarkRatio = if (flankSampleTotal > 0) flankDarkCount.toFloat() / flankSampleTotal else 0f

            var countdownSlateCount = 0
            var countdownWhiteCount = 0
            var countdownSampleTotal = 0
            if (!hudPillsVisible) {
                val cx0 = (width * 0.43f).toInt().coerceIn(0, width - 2)
                val cx1 = (width * 0.57f).toInt().coerceIn(cx0 + 1, width)
                val cy0 = (height * 0.01f).toInt().coerceIn(0, height - 2)
                val cy1 = (height * 0.07f).toInt().coerceIn(cy0 + 1, height)
                var cy = cy0
                while (cy < cy1) {
                    val rOff = cy * rowStride
                    var cx = cx0
                    while (cx < cx1) {
                        val off = rOff + cx * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            countdownSampleTotal++
                            if (r in 75..135 && g in 95..145 && b in 105..150 && (b - r) <= 40 && abs(g - b) <= 20) {
                                countdownSlateCount++
                            } else if (r >= 230 && g >= 230 && b >= 230 && abs(r - b) <= 15) {
                                countdownWhiteCount++
                            }
                        }
                        cx += max(2, width / 160)
                    }
                    cy += max(2, height / 300)
                }
            }
            val countdownSlateRatio =
                if (countdownSampleTotal > 0) countdownSlateCount.toFloat() / countdownSampleTotal else 0f
            val countdownWhiteRatio =
                if (countdownSampleTotal > 0) countdownWhiteCount.toFloat() / countdownSampleTotal else 0f
            val hasTopCountdownCircle = countdownSlateRatio >= 0.25f && countdownWhiteRatio >= 0.05f

            val detectedBadgeTypes = mutableSetOf<String>()
            if (hudPillsVisible) {
                val bx0 = (width * 0.86f).toInt().coerceIn(0, width - 2)
                val bx1 = (width * 0.99f).toInt().coerceIn(bx0 + 1, width)
                val by0 = (height * 0.012f).toInt().coerceIn(0, height - 2)
                val by1 = (height * 0.115f).toInt().coerceIn(by0 + 1, height)
                val badgeCounts = mutableMapOf<String, Int>()
                for (by in by0 until by1) {
                    val rOff = by * rowStride
                    for (bx in bx0 until bx1) {
                        val off = rOff + bx * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            val bType = when {
                                r > 215 && g in 130..222 && b > 195 && (r - g) >= 20 && (b - g) >= 20 -> "fairy"
                                r in 155..220 && g in 60..130 && b in 165..235 && (r - g) > 55 && (b - g) > 65 -> "poison"
                                r > 225 && g in 135..195 && b in 45..110 && (r - b) > 120 -> "fire"
                                r > 195 && g in 45..105 && b in 50..115 && (r - g) > 100 -> "fighting"
                                r in 75..150 && g in 150..210 && b > 205 && (b - r) > 70 -> "water"
                                r in 80..205 && g > 190 && b > 185 && abs(g - b) < 25 && (g - r) >= 28 -> "ice"
                                r in 85..135 && g in 135..175 && b in 155..200 && (b - r) in 40..80 -> "steel"
                                r > 210 && g in 115..160 && b in 60..105 && (r - b) > 110 -> "ground"
                                r > 230 && g > 200 && b in 40..105 && (r - b) > 135 -> "electric"
                                r in 70..135 && g > 175 && b in 70..135 && (g - r) > 55 -> "grass"
                                r > 220 && g in 95..145 && b in 120..175 && (r - g) > 85 -> "psychic"
                                r in 85..125 && g in 70..110 && b in 145..195 && (b - g) > 55 && (r - g) > 10 -> "ghost"
                                r in 65..105 && g in 55..95 && b in 65..105 && abs(r - g) < 16 && abs(b - g) < 18 -> "dark"
                                else -> null
                            }
                            if (bType != null) {
                                badgeCounts[bType] = (badgeCounts[bType] ?: 0) + 1
                            }
                        }
                    }
                }
                for ((tName, cnt) in badgeCounts) {
                    if (cnt >= 6) detectedBadgeTypes.add(tName)
                }
            }

            fun isOrangeDrainPixel(r: Int, g: Int, b: Int): Boolean {
                return r >= 135 && g in 60..168 && b <= 105 && (r - b) >= 55 && (r - g) >= 38 && (g - b) >= 25
            }

            fun classifyHpPixel(r: Int, g: Int, b: Int): Int {
                if (isOrangeDrainPixel(r, g, b)) return 0
                return when {
                    g >= 185 && r <= 182 && b in 65..225 && (g - r) >= 18 && (g - b) >= 22 -> 1
                    r >= 175 && g >= 170 && b in 20..185 && (r - b) >= 50 && (g - b) >= 35 && (r - g) in -20..64 -> 2
                    r >= 170 && g in 15..158 && b in 15..160 && (r - g) >= 65 && abs(g - b) <= 35 -> 3
                    (r < 122 && g < 112 && b < 148 && (r + g + b) <= 330) ||
                        (r in 25..135 && g <= 108 && b in 55..175 && ((b - g) >= 20 || (b - r) >= 35) && (r + g + b) <= 355) -> 4
                    else -> 0
                }
            }

            val maxBorderDy = max(5, (height * 0.012f).toInt())
            val borderStepX = max(2, barLen / 22)

            fun hasHorizontalBoxBorder(py: Int, absStartX: Int): Boolean {
                var topBest = 0
                var botBest = 0
                var rightTopBest = 0
                var rightBotBest = 0
                var totalCols = 0
                var rightCols = 0
                val endX = min(width - 1, absStartX + barLen)
                val midX = absStartX + (barLen / 2)
                var x = absStartX
                while (x < endX) {
                    totalCols++
                    if (x >= midX) rightCols++
                    x += borderStepX
                }
                if (totalCols <= 4) return false
                val reqBright = (totalCols * 0.52f).toInt()
                val reqRightBright = max(2, (rightCols * 0.42f).toInt())

                for (dy in 1..maxBorderDy) {
                    val ty = py - dy
                    if (ty >= 0) {
                        val rOff = ty * rowStride
                        var cnt = 0
                        var rCnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 320 && max(r, max(g, b)) >= 135) {
                                    cnt++
                                    if (cx >= midX) rCnt++
                                }
                            }
                            cx += borderStepX
                        }
                        if (cnt > topBest) topBest = cnt
                        if (rCnt > rightTopBest) rightTopBest = rCnt
                    }
                    val by = py + dy
                    if (by < height) {
                        val rOff = by * rowStride
                        var cnt = 0
                        var rCnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 320 && max(r, max(g, b)) >= 135) {
                                    cnt++
                                    if (cx >= midX) rCnt++
                                }
                            }
                            cx += borderStepX
                        }
                        if (cnt > botBest) botBest = cnt
                        if (rCnt > rightBotBest) rightBotBest = rCnt
                    }
                }
                return topBest >= reqBright &&
                    botBest >= reqBright &&
                    rightTopBest >= reqRightBright &&
                    rightBotBest >= reqRightBright
            }

            val hx0 = (width * 0.020f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.46f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.14f).toInt().coerceIn(4, height - 5)
            val hy1 = (height * 0.80f).toInt().coerceIn(hy0 + 1, height - 4)

            val scanW = hx1 - hx0
            val minValidInBar = (barLen * 0.60f).toInt()
            val minSmoothInBar = (barLen * 0.56f).toInt()
            val minStartScreenX = (width * 0.025f).toInt()
            val maxStartScreenX = (width * 0.165f).toInt()

            val minGreenFill = max(10, (barLen * 0.38f).toInt())
            val minYellowFill = max(6, (barLen * 0.15f).toInt())
            val maxYellowFill = (barLen * 0.64f).toInt()
            val maxRedFill = max(6, (barLen * 0.28f).toInt())

            var bestGreenFillPx = -1
            var bestGreenY = -1
            var bestGreenOrangePx = 0
            var bestGreenEmptyPx = 99
            var bestYellowFillPx = -1
            var bestYellowY = -1
            var bestYellowOrangePx = 0
            var bestYellowEmptyPx = 99
            var bestRedFillPx = -1
            var bestRedY = -1
            var bestRedOrangePx = 0
            var bestRedEmptyPx = 99

            val rowTypes = IntArray(scanW)
            val rowOrange = BooleanArray(scanW)
            val smoothPrefix = IntArray(scanW)

            val prev1FirstCol = IntArray(4) { -1 }
            val prev1FillCnt = IntArray(4) { -1 }
            val prev1RowY = IntArray(4) { -1 }

            val maxOrangeTipSpan = max(6, barLen / 11)

            if (scanW > barLen) {
                for (py in hy0 until hy1) {
                    val rOff = py * rowStride
                    var gFirst = -1
                    var yFirst = -1
                    var rFirst = -1

                    var prevR = 0
                    var prevG = 0
                    var prevB = 0
                    var sSum = 0

                    for (col in 0 until scanW) {
                        val absX = hx0 + col
                        if (overlayRect != null && overlayRect.contains(absX, py)) {
                            rowTypes[col] = 0
                            rowOrange[col] = false
                            smoothPrefix[col] = sSum
                            continue
                        }
                        val off = rOff + absX * pixelStride
                        var t = 0
                        var isOrg = false
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF

                            if (col > 0) {
                                val diff = abs(r - prevR) + abs(g - prevG) + abs(b - prevB)
                                if (diff <= 22) sSum++
                            }
                            smoothPrefix[col] = sSum
                            prevR = r
                            prevG = g
                            prevB = b

                            t = classifyHpPixel(r, g, b)
                            isOrg = isOrangeDrainPixel(r, g, b)
                        } else {
                            smoothPrefix[col] = sSum
                        }
                        rowTypes[col] = t
                        rowOrange[col] = isOrg
                    }

                    val minStartCol = (minStartScreenX - hx0).coerceAtLeast(0)
                    val maxStartCol = (maxStartScreenX - hx0).coerceAtMost(scanW - barLen)
                    for (col in minStartCol..maxStartCol) {
                        val rt = rowTypes[col]
                        if (
                            rt in 1..3 &&
                            col + 3 < scanW &&
                            rowTypes[col + 1] == rt &&
                            rowTypes[col + 2] == rt &&
                            rowTypes[col + 3] == rt
                        ) {
                            when (rt) {
                                1 -> if (gFirst < 0) gFirst = col
                                2 -> if (yFirst < 0) yFirst = col
                                3 -> if (rFirst < 0) rFirst = col
                            }
                        }
                    }

                    fun evalStageRow(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int): Triple<Int, Int, Int> {
                        if (firstCol < 0 || firstCol + barLen > scanW) return Triple(-1, 0, 99)
                        val absStartX = hx0 + firstCol
                        if (absStartX !in minStartScreenX..maxStartScreenX) return Triple(-1, 0, 99)

                        val smoothCnt = smoothPrefix[firstCol + barLen - 1] - smoothPrefix[firstCol]
                        if (smoothCnt < minSmoothInBar) return Triple(-1, 0, 99)

                        var fillCnt = 0
                        var gap = 0
                        var fillStopped = false
                        var emptyCnt = 0
                        val barEndCol = firstCol + barLen
                        for (c in firstCol until barEndCol) {
                            val rt = rowTypes[c]
                            if (!fillStopped) {
                                if (rt == stageCode) {
                                    fillCnt += (1 + gap)
                                    gap = 0
                                } else {
                                    gap++
                                    if (gap >= 3) {
                                        var resumes = false
                                        if (gap <= 5 && c + 3 < barEndCol) {
                                            if (
                                                rowTypes[c + 1] == stageCode &&
                                                rowTypes[c + 2] == stageCode &&
                                                rowTypes[c + 3] == stageCode
                                            ) {
                                                resumes = true
                                            }
                                        }
                                        if (!resumes) {
                                            fillStopped = true
                                            if (rt == 4 || rowOrange[c] || rt == 0) emptyCnt++
                                        }
                                    } else if (rt == 4 || rowOrange[c]) {
                                        emptyCnt++
                                    }
                                }
                            } else if (rt == 4 || rowOrange[c] || rt == 0) {
                                emptyCnt++
                            }
                        }
                        if (fillCnt !in minFill..maxFill || (fillCnt + emptyCnt) < minValidInBar) {
                            return Triple(-1, 0, 99)
                        }
                        if (fillCnt < (barLen * 0.85f).toInt() && emptyCnt < 4) {
                            return Triple(-1, 0, 99)
                        }

                        if (!hasHorizontalBoxBorder(py, absStartX)) {
                            return Triple(-1, 0, 99)
                        }

                        val tipStart = (firstCol + fillCnt).coerceAtMost(scanW - 1)

                        var orgCnt = 0
                        val tipEnd = min(firstCol + barLen, firstCol + fillCnt + maxOrangeTipSpan)
                        for (c in tipStart until tipEnd) {
                            if (rowOrange[c]) orgCnt++
                        }
                        return Triple(fillCnt, orgCnt, emptyCnt)
                    }

                    fun updateStageHistoryAndBest(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int) {
                        val (fillCnt, orgCnt, emptyCnt) = evalStageRow(firstCol, stageCode, minFill, maxFill)
                        if (fillCnt > 0) {
                            if (
                                prev1RowY[stageCode] > 0 &&
                                (py - prev1RowY[stageCode]) in 1..3 &&
                                abs(prev1FirstCol[stageCode] - firstCol) <= 2 &&
                                abs(prev1FillCnt[stageCode] - fillCnt) <= 3
                            ) {
                                val avgFill = max(fillCnt, prev1FillCnt[stageCode])
                                when (stageCode) {
                                    1 -> if (avgFill > bestGreenFillPx || (avgFill == bestGreenFillPx && orgCnt > bestGreenOrangePx)) {
                                        bestGreenFillPx = avgFill
                                        bestGreenY = py
                                        bestGreenOrangePx = max(bestGreenOrangePx, orgCnt)
                                        bestGreenEmptyPx = emptyCnt
                                    }
                                    2 -> if (avgFill > bestYellowFillPx || (avgFill == bestYellowFillPx && orgCnt > bestYellowOrangePx)) {
                                        bestYellowFillPx = avgFill
                                        bestYellowY = py
                                        bestYellowOrangePx = max(bestYellowOrangePx, orgCnt)
                                        bestYellowEmptyPx = emptyCnt
                                    }
                                    3 -> if (avgFill > bestRedFillPx || (avgFill == bestRedFillPx && orgCnt > bestRedOrangePx)) {
                                        bestRedFillPx = avgFill
                                        bestRedY = py
                                        bestRedOrangePx = max(bestRedOrangePx, orgCnt)
                                        bestRedEmptyPx = emptyCnt
                                    }
                                }
                            }
                            prev1RowY[stageCode] = py
                            prev1FirstCol[stageCode] = firstCol
                            prev1FillCnt[stageCode] = fillCnt
                        }
                    }

                    updateStageHistoryAndBest(gFirst, 1, minGreenFill, barLen)
                    updateStageHistoryAndBest(yFirst, 2, minYellowFill, maxYellowFill)
                    updateStageHistoryAndBest(rFirst, 3, 4, maxRedFill)
                }
            }

            val hpFillPx: Int
            val hpBarY: Int
            val hpStage: Int
            val orangeDrainPx: Int
            val emptyAfterFillPx: Int
            when {
                bestGreenFillPx > 0 -> {
                    hpFillPx = bestGreenFillPx
                    hpBarY = bestGreenY
                    hpStage = 1
                    orangeDrainPx = bestGreenOrangePx
                    emptyAfterFillPx = bestGreenEmptyPx
                }
                bestYellowFillPx > 0 -> {
                    hpFillPx = bestYellowFillPx
                    hpBarY = bestYellowY
                    hpStage = 2
                    orangeDrainPx = bestYellowOrangePx
                    emptyAfterFillPx = bestYellowEmptyPx
                }
                bestRedFillPx > 0 -> {
                    hpFillPx = bestRedFillPx
                    hpBarY = bestRedY
                    hpStage = 3
                    orangeDrainPx = bestRedOrangePx
                    emptyAfterFillPx = bestRedEmptyPx
                }
                else -> {
                    hpFillPx = -1
                    hpBarY = -1
                    hpStage = 0
                    orangeDrainPx = 0
                    emptyAfterFillPx = 99
                }
            }

            var centeredHpFillPx = -1
            var centeredOrangeDrainPx = 0
            if (hpFillPx <= 0) {
                val ccx0 = (width * 0.33f).toInt().coerceIn(0, width - 2)
                val ccx1 = (width * 0.80f).toInt().coerceIn(ccx0 + 1, width)
                val ccy0 = (height * 0.38f).toInt().coerceIn(4, height - 5)
                val ccy1 = (height * 0.63f).toInt().coerceIn(ccy0 + 1, height - 4)
                val cScanW = ccx1 - ccx0
                val minCenterStartX = (width * 0.345f).toInt()
                val maxCenterStartX = (width * 0.51f).toInt()

                if (cScanW > barLen) {
                    val cRowTypes = IntArray(cScanW)
                    val cRowOrange = BooleanArray(cScanW)
                    val cPrevRowY = IntArray(4) { -1 }
                    val cPrevFirstCol = IntArray(4) { -1 }
                    val cPrevFillCnt = IntArray(4) { -1 }

                    for (py in ccy0 until ccy1) {
                        val rOff = py * rowStride
                        var gF = -1
                        var yF = -1
                        var rF = -1
                        for (col in 0 until cScanW) {
                            val absX = ccx0 + col
                            if (overlayRect != null && overlayRect.contains(absX, py)) {
                                cRowTypes[col] = 0
                                cRowOrange[col] = false
                                continue
                            }
                            val off = rOff + absX * pixelStride
                            var t = 0
                            var isOrg = false
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                t = classifyHpPixel(r, g, b)
                                isOrg = isOrangeDrainPixel(r, g, b)
                            }
                            cRowTypes[col] = t
                            cRowOrange[col] = isOrg
                        }

                        val minCCol = (minCenterStartX - ccx0).coerceAtLeast(0)
                        val maxCCol = (maxCenterStartX - ccx0).coerceAtMost(cScanW - barLen)
                        for (col in minCCol..maxCCol) {
                            val rt = cRowTypes[col]
                            if (
                                rt in 1..3 &&
                                col + 3 < cScanW &&
                                cRowTypes[col + 1] == rt &&
                                cRowTypes[col + 2] == rt &&
                                cRowTypes[col + 3] == rt
                            ) {
                                when (rt) {
                                    1 -> if (gF < 0) gF = col
                                    2 -> if (yF < 0) yF = col
                                    3 -> if (rF < 0) rF = col
                                }
                            }
                        }

                        fun evalCenterStage(fc: Int, st: Int, minF: Int, maxF: Int) {
                            if (fc < 0 || fc + barLen > cScanW) return
                            val absStartX = ccx0 + fc
                            if (absStartX !in minCenterStartX..maxCenterStartX) return
                            if (!hasHorizontalBoxBorder(py, absStartX)) return

                            var fillCnt = 0
                            var gap = 0
                            var fillStopped = false
                            var emptyCnt = 0
                            for (c in fc until fc + barLen) {
                                val rt = cRowTypes[c]
                                if (!fillStopped) {
                                    if (rt == st) {
                                        fillCnt += (1 + gap)
                                        gap = 0
                                    } else {
                                        gap++
                                        if (gap >= 3) {
                                            fillStopped = true
                                            if (rt == 4 || cRowOrange[c]) emptyCnt++
                                        }
                                    }
                                } else if (rt == 4 || cRowOrange[c]) {
                                    emptyCnt++
                                }
                            }
                            if (fillCnt !in minF..maxF) return

                            var orgCnt = 0
                            val tipStart = (fc + fillCnt).coerceAtMost(cScanW - 1)
                            val tipEnd = min(cScanW, fc + fillCnt + max(8, barLen / 4))
                            for (c in tipStart until tipEnd) {
                                if (cRowOrange[c]) orgCnt++
                            }

                            if (orgCnt < 3 && emptyCnt < 12) return

                            if (
                                cPrevRowY[st] > 0 &&
                                (py - cPrevRowY[st]) in 1..3 &&
                                abs(cPrevFirstCol[st] - fc) <= 2 &&
                                abs(cPrevFillCnt[st] - fillCnt) <= 3
                            ) {
                                val avgFill = max(fillCnt, cPrevFillCnt[st])
                                if (avgFill > centeredHpFillPx || (avgFill == centeredHpFillPx && orgCnt > centeredOrangeDrainPx)) {
                                    centeredHpFillPx = avgFill
                                    centeredOrangeDrainPx = max(centeredOrangeDrainPx, orgCnt)
                                }
                            }
                            cPrevRowY[st] = py
                            cPrevFirstCol[st] = fc
                            cPrevFillCnt[st] = fillCnt
                        }

                        evalCenterStage(gF, 1, minGreenFill, barLen)
                        evalCenterStage(yF, 2, minYellowFill, maxYellowFill)
                        evalCenterStage(rF, 3, 4, maxRedFill)
                    }
                }
            }

            var noShieldDarkCount = 0
            var noShieldWhiteCount = 0
            var noShieldSampleTotal = 0
            if (!hudPillsVisible && hasTopCountdownCircle) {
                val nsx0 = (width * 0.22f).toInt().coerceIn(0, width - 2)
                val nsx1 = (width * 0.78f).toInt().coerceIn(nsx0 + 1, width)
                val nsy0 = (height * 0.41f).toInt().coerceIn(0, height - 2)
                val nsy1 = (height * 0.47f).toInt().coerceIn(nsy0 + 1, height)
                var nsy = nsy0
                while (nsy < nsy1) {
                    val rOff = nsy * rowStride
                    var nsx = nsx0
                    while (nsx < nsx1) {
                        val off = rOff + nsx * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            noShieldSampleTotal++
                            if (r < 55 && g < 55 && b < 60) {
                                noShieldDarkCount++
                            } else if (r >= 210 && g >= 210 && b >= 210) {
                                noShieldWhiteCount++
                            }
                        }
                        nsx += max(2, width / 160)
                    }
                    nsy += max(2, height / 350)
                }
            }
            val noShieldDarkRatio = if (noShieldSampleTotal > 0) noShieldDarkCount.toFloat() / noShieldSampleTotal else 0f
            val noShieldWhiteRatio = if (noShieldSampleTotal > 0) noShieldWhiteCount.toFloat() / noShieldSampleTotal else 0f
            val isNoShieldsRemainingBannerVisible =
                !hudPillsVisible && hasTopCountdownCircle && noShieldDarkRatio >= 0.60f && noShieldWhiteRatio >= 0.04f

            val nowMs = SystemClock.elapsedRealtime()
            val isPurpleShieldPrompt =
                !hudPillsVisible && !leftPillVisible && shieldMagentaRatio >= 0.16f && flankDarkRatio >= 0.52f
            val isShieldPromptVisible = isPurpleShieldPrompt || isNoShieldsRemainingBannerVisible
            val effectiveHudVisible = hudPillsVisible ||
                (inActiveMatch &&
                    leftPillVisible &&
                    !isShieldPromptVisible &&
                    !hasTopCountdownCircle &&
                    !playerUsedChargedMoveDuringZoom &&
                    nowMs >= playerOwnChargedBannerLockUntilMs)

            FrameVisualTelemetry(
                isFrameNonBlack = true,
                isBattleHudVisible = effectiveHudVisible,
                isShieldPromptVisible = isShieldPromptVisible,
                hasTopCountdownCircle = hasTopCountdownCircle,
                barLenPx = barLen,
                playerHpFillPx = hpFillPx,
                playerHpBarY = hpBarY,
                playerHpStage = hpStage,
                orangeDrainPx = orangeDrainPx,
                emptyAfterFillPx = emptyAfterFillPx,
                centeredHpFillPx = centeredHpFillPx,
                centeredOrangeDrainPx = centeredOrangeDrainPx,
                opponentBadgeTypes = detectedBadgeTypes,
                isRightPillVisible = rightPillVisible
            )
        } catch (_: Exception) {
            FrameVisualTelemetry(
                true, false, false, false, 66, -1, -1, 0, 0, 99, -1, 0, emptySet()
            )
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1,
        maskOverlayRect: OverlayImageRect? = null
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            cropRegionFromBuffer(
                buf = plane.buffer,
                width = image.width,
                height = image.height,
                pixelStride = plane.pixelStride,
                rowStride = plane.rowStride,
                leftRatio = leftRatio,
                topRatio = topRatio,
                rightRatio = rightRatio,
                bottomRatio = bottomRatio,
                step = step,
                maskOverlayRect = maskOverlayRect
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun cropRegionFromBuffer(
        buf: java.nio.ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1,
        maskOverlayRect: OverlayImageRect? = null
    ): Bitmap? {
        return try {
            val bufLimit = buf.limit()

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    if (maskOverlayRect != null && maskOverlayRect.contains(x, y)) {
                        pixels[py * outW + px] = 0xFF000000.toInt()
                    } else {
                        val offset = rowOffset + x * pixelStride
                        if (offset >= 0 && offset + 3 < bufLimit) {
                            val r = buf.get(offset).toInt() and 0xFF
                            val g = buf.get(offset + 1).toInt() and 0xFF
                            val b = buf.get(offset + 2).toInt() and 0xFF
                            pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                        }
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }
}
