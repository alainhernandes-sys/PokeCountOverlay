package com.pokecount.overlay

import android.graphics.Bitmap
import android.media.Image
import android.os.SystemClock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Bounding rectangle of the floating overlay HUD in capture-image coordinates,
 * used to mask out the overlay itself during OCR and pixel telemetry.
 */
data class OverlayImageRect(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    fun contains(x: Int, y: Int): Boolean = x in left..right && y in top..bottom
}

/**
 * Per-frame visual telemetry extracted from the MediaProjection capture buffer.
 */
data class FrameVisualTelemetry(
    val isFrameNonBlack: Boolean,
    val isBattleHudVisible: Boolean,
    val isShieldPromptVisible: Boolean,
    val barLenPx: Int,
    val playerHpFillPx: Int,
    val playerHpBarY: Int,
    val playerHpStage: Int,
    val orangeDrainPx: Int,
    val emptyAfterFillPx: Int,
    val opponentBadgeTypes: Set<String>
)

/**
 * Pure detection & telemetry layer (`ScreenCaptureAnalyzer`).
 *
 * Inspects screen capture frames and OCR text and dispatches clean, high-level signals
 * (`onFastMoveSignal()`, `onChargedMoveSignal(cost)`, `onMinigameStart()`, `onMinigameEnd()`,
 * `onSwitch()`, `configureFastMove()`) to [BattleSessionManager].
 *
 * Contains ZERO direct counter increments, ZERO raw energy math, and ZERO ad-hoc cooldown timers.
 */
class ScreenCaptureAnalyzer(
    private val sessionManager: BattleSessionManager,
    private val overlayVersion: String,
    private val onUiStateChanged: () -> Unit
) {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()

    val seenOpponentPokemon = linkedMapOf<String, PvPokeEntry>()
    val slotFastMoveIdx = mutableMapOf<String, Int>()
    val manualFormOverrideByBase = mutableMapOf<String, String>()

    var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
        private set

    var inActiveMatch: Boolean = false
        private set

    var statusMessage: String = "● $overlayVersion Engine Ready"
        private set

    private var hasLockedFirstRealOpponentInMatch = false
    private var currentPlayerPokemonId: String? = null
    private var currentPlayerPokemonName: String? = null
    private var playerDefenderTypes: List<String> = emptyList()
    private var latestEffectivenessHint: String? = null
    private var fastHitsLandedOnCurrentPlayer: Int = 0

    // Battle & Cutscene detection flags
    private var isBattleHudCurrentlyVisible = false
    private var hudCompletelyMissingDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var playerUsedChargedMoveDuringZoom = false
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var hasDispatchedChargedMoveForCurrentCutscene = false
    private var hasCountedCutsceneIntroFastMove = false
    private var lastDispatchedChargedMove: ChargedMove? = null
    private var lastDispatchedChargedTimestampMs = 0L
    private var postCutsceneBannerTicks = 0

    // Player floating HP bar baseline (purely spatial; turn cooldowns are enforced by PokemonBattleEngine)
    private var matchStartRealtimeMs: Long = 0L
    private var refPlayerHpFillPx: Int? = null
    private var refPlayerHpBarY: Int = -1
    private var prevOrangeDrainPx: Int = 0
    private var higherHpConfirmTicks: Int = 0
    private var sustainedOnePxDropTicks: Int = 0

    // OCR concurrency & throttling
    private var isOcrBusy = false
    private var lastOcrStartRealtimeMs = 0L
    private var lastOcrCompletedRealtimeMs = 0L

    fun getActiveFastMove(entry: PvPokeEntry = currentPokemon): FastMove {
        val idx = (slotFastMoveIdx[entry.id] ?: 0).coerceIn(0, max(0, entry.fastMoves.size - 1))
        return entry.fastMoves[idx]
    }

    fun setStatusText(msg: String) {
        statusMessage = msg
        onUiStateChanged()
    }

    fun markMatchActiveForManualInput() {
        if (!inActiveMatch) {
            inActiveMatch = true
            matchStartRealtimeMs = SystemClock.elapsedRealtime() - 1000L
        }
    }

    fun resetAnalyzerAndSession(statusMsg: String, preLockedHpPx: Int? = null, preLockedBarY: Int = -1) {
        seenOpponentPokemon.clear()
        manualFormOverrideByBase.clear()
        hasLockedFirstRealOpponentInMatch = false
        refPlayerHpFillPx = preLockedHpPx
        refPlayerHpBarY = preLockedBarY
        prevOrangeDrainPx = 0
        higherHpConfirmTicks = 0
        sustainedOnePxDropTicks = 0
        fastHitsLandedOnCurrentPlayer = 0
        latestEffectivenessHint = null
        chargedAttackDetectedDuringPause = false
        playerUsedChargedMoveDuringZoom = false
        specificMoveDetectedDuringPause = null
        hasDispatchedChargedMoveForCurrentCutscene = false
        hasCountedCutsceneIntroFastMove = false
        lastDispatchedChargedMove = null
        lastDispatchedChargedTimestampMs = 0L
        postCutsceneBannerTicks = 0
        statusMessage = statusMsg

        val activeFm = getActiveFastMove()
        sessionManager.resetMatch(
            initialPokemonId = currentPokemon.id,
            durationTurns = activeFm.turns,
            energyGain = activeFm.energyGain,
            moveName = activeFm.name
        ) {
            onUiStateChanged()
        }
        onUiStateChanged()
    }

    /**
     * Cycles the opponent's fast move or regional sibling form when the user taps `[⇄Fast]`.
     */
    fun cycleFastMoveOrForm() {
        val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)

        if (curIdx + 1 < currentPokemon.fastMoves.size) {
            slotFastMoveIdx[currentPokemon.id] = curIdx + 1
            val newFm = getActiveFastMove()
            statusMessage = "Fast: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        } else if (siblings.size > 1) {
            val curFormIdx = siblings.indexOfFirst { it.id == currentPokemon.id }.coerceAtLeast(0)
            val nextForm = siblings[(curFormIdx + 1) % siblings.size]
            seenOpponentPokemon.remove(currentPokemon.id)
            seenOpponentPokemon[nextForm.id] = nextForm
            slotFastMoveIdx[nextForm.id] = 0
            val nextFm = nextForm.fastMoves.first()
            val baseKey = nextForm.name.substringBefore("(").trim().lowercase()
            manualFormOverrideByBase[baseKey] = nextForm.id
            currentPokemon = nextForm
            statusMessage = "Form: ${nextForm.name}"
            sessionManager.onSwitch(
                newPokemonId = nextForm.id,
                durationTurns = nextFm.turns,
                energyGain = nextFm.energyGain,
                moveName = nextFm.name,
                transferOpeningEnergy = true,
                pauseForSwitchWindow = false
            ) {
                onUiStateChanged()
            }
        } else if (currentPokemon.fastMoves.size > 1) {
            slotFastMoveIdx[currentPokemon.id] = 0
            val newFm = getActiveFastMove()
            statusMessage = "Fast: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
            sessionManager.configureFastMove(
                durationTurns = newFm.turns,
                energyGain = newFm.energyGain,
                moveName = newFm.name,
                preserveMoveCount = true
            ) {
                onUiStateChanged()
            }
        }
    }

    /**
     * Dispatches a manual Charged Move badge tap to [BattleSessionManager].
     */
    fun onManualChargedMoveBadgeTap(cm: ChargedMove) {
        upgradeToSiblingFormIfMoveMatches(cm)
        statusMessage = "▼ Subtracted ${cm.name}"
        sessionManager.onChargedMoveSignal(
            cost = cm.energyCost,
            moveName = cm.name,
            pauseClock = false
        ) {
            onUiStateChanged()
        }
    }

    private fun upgradeToSiblingFormIfMoveMatches(usedMove: ChargedMove) {
        if (currentPokemon.chargedMoves.any { it.name == usedMove.name }) return
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)
        val matchingSibling = siblings.firstOrNull { sib ->
            sib.chargedMoves.any { it.name == usedMove.name }
        } ?: return

        seenOpponentPokemon.remove(currentPokemon.id)
        seenOpponentPokemon[matchingSibling.id] = matchingSibling
        val newFm = getActiveFastMove(matchingSibling)
        val baseKey = matchingSibling.name.substringBefore("(").trim().lowercase()
        manualFormOverrideByBase[baseKey] = matchingSibling.id
        currentPokemon = matchingSibling

        sessionManager.onSwitch(
            newPokemonId = matchingSibling.id,
            durationTurns = newFm.turns,
            energyGain = newFm.energyGain,
            moveName = newFm.name,
            transferOpeningEnergy = true,
            pauseForSwitchWindow = false
        ) {
            onUiStateChanged()
        }
    }

    private fun dispatchChargedMoveSignal(cm: ChargedMove, pauseClock: Boolean) {
        upgradeToSiblingFormIfMoveMatches(cm)
        val now = SystemClock.elapsedRealtime()
        lastDispatchedChargedTimestampMs = now
        lastDispatchedChargedMove = cm
        hasDispatchedChargedMoveForCurrentCutscene = true
        statusMessage = "▼ Subtracted ${cm.name}"
        sessionManager.onChargedMoveSignal(
            cost = cm.energyCost,
            moveName = cm.name,
            pauseClock = pauseClock
        ) {
            onUiStateChanged()
        }
    }

    private fun undoFalsePlayerChargedMoveIfNeeded() {
        val now = SystemClock.elapsedRealtime()
        val prevSub = lastDispatchedChargedMove ?: return
        if ((now - lastDispatchedChargedTimestampMs) <= 12000L) {
            lastDispatchedChargedMove = null
            lastDispatchedChargedTimestampMs = 0L
            hasDispatchedChargedMoveForCurrentCutscene = false
            sessionManager.undoChargedMove(prevSub.energyCost) {
                onUiStateChanged()
            }
        }
    }

    private fun reconcileChargedMoveFromBanner(actualMove: ChargedMove, pauseClock: Boolean) {
        upgradeToSiblingFormIfMoveMatches(actualMove)
        val now = SystemClock.elapsedRealtime()
        val prevSub = lastDispatchedChargedMove
        if (
            hasDispatchedChargedMoveForCurrentCutscene ||
            (prevSub != null && (now - lastDispatchedChargedTimestampMs) <= 12000L)
        ) {
            if (prevSub != null && prevSub.name != actualMove.name) {
                lastDispatchedChargedMove = actualMove
                statusMessage = "▼ Used ${actualMove.name}!"
                sessionManager.reconcileChargedMoveCost(
                    previousCost = prevSub.energyCost,
                    actualCost = actualMove.energyCost,
                    actualMoveName = actualMove.name
                ) {
                    onUiStateChanged()
                }
            } else {
                statusMessage = "▼ Used ${actualMove.name}!"
                onUiStateChanged()
            }
        } else if ((now - lastDispatchedChargedTimestampMs) > 3500L) {
            dispatchChargedMoveSignal(actualMove, pauseClock = pauseClock)
        }
    }

    /**
     * Evaluates whether the player's floating HP bar dropped and dispatches `sessionManager.onFastMoveSignal()`.
     *
     * Key v32 fixes so zero fast moves are ever missed:
     * 1. Never ratchets `refPlayerHpFillPx` down on an uncounted `dropPx == 1` frame! When a low-damage
     *    fast move (e.g. Tinkaton's Fairy Wind) drains `2px` across two 100ms frames (`100 -> 99 -> 98`),
     *    preserving `refPlayerHpFillPx = 100` on frame 1 ensures frame 2 sees `100 - 98 = 2px` and counts it!
     * 2. Only slides `refPlayerHpFillPx` down with the orange drain during the first `360ms` after a
     *    registered hit (`nowRealtimeMs - lastAcceptedFastMoveRealtimeMs < 360L`), NEVER across the entire
     *    `cooldownTurnsRemaining > 0` window (so an incoming move landing near the end of cooldown is never swallowed).
     * 3. Supports `allowDuringCutsceneIntro = true` during the first `1200ms` of the Shield Prompt zoom-in
     *    so the final Fast Move before an opponent's Charged Move (e.g. Greninja's 3rd Water Shuriken) is always counted.
     */
    private fun evaluatePlayerHpBarAndDispatchSignal(
        barLen: Int,
        hpPx: Int,
        hpBarY: Int,
        orangeDrainPx: Int,
        emptyAfterFillPx: Int,
        nowRealtimeMs: Long,
        allowDuringCutsceneIntro: Boolean = false
    ): Boolean {
        if (hpPx <= 0 || hpBarY <= 0) return false

        val snapshot = sessionManager.snapshotFlow.value
        val prevHpPx = refPlayerHpFillPx
        if (prevHpPx == null) {
            refPlayerHpFillPx = hpPx
            refPlayerHpBarY = hpBarY
            prevOrangeDrainPx = orangeDrainPx
            higherHpConfirmTicks = 0
            sustainedOnePxDropTicks = 0
            return false
        }

        refPlayerHpBarY = hpBarY

        // Opening Camera-Settle Guard (< 550ms after battle HUD pills slide in):
        // Track the settling wide-arena 100% HP bar width without firing a false opening signal.
        if ((nowRealtimeMs - matchStartRealtimeMs) < 550L && orangeDrainPx < 3) {
            refPlayerHpFillPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            return false
        }

        // Upward Re-Lock when switching in a healthier Pokémon
        if (hpPx > prevHpPx + max(4, barLen / 16)) {
            higherHpConfirmTicks++
            sustainedOnePxDropTicks = 0
            if (higherHpConfirmTicks >= 2) {
                refPlayerHpFillPx = hpPx
                prevOrangeDrainPx = orangeDrainPx
                higherHpConfirmTicks = 0
            }
            return false
        } else {
            higherHpConfirmTicks = 0
        }

        val dropPx = prevHpPx - hpPx

        // 100% Full-Health Bar Guard at Match Start:
        // If no fast moves have been registered in the match yet and the green fill still reaches the right
        // white border (emptyAfterFillPx <= 2 and orangeDrainPx == 0), absorb 1..4px subpixel border shifts.
        if (
            snapshot.totalFastMovesInMatch == 0 &&
            emptyAfterFillPx <= 2 &&
            orangeDrainPx == 0 &&
            dropPx in 1..4
        ) {
            refPlayerHpFillPx = hpPx
            prevOrangeDrainPx = 0
            sustainedOnePxDropTicks = 0
            return false
        }

        // Ignore massive single-frame drops (>50% of bar) from unflagged Charged Move damage
        if (dropPx > (barLen * 0.50f).toInt()) {
            refPlayerHpFillPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            return false
        }

        val elapsedSinceLastAccept = nowRealtimeMs - sessionManager.lastAcceptedFastMoveRealtimeMs

        // Follow the orange drain slide to its settled plateau ONLY during the first 360ms after a registered hit!
        // Never overwrite refPlayerHpFillPx after 360ms even if cooldownTurnsRemaining > 0, so a subsequent fast move
        // landing near the end of the turn cooldown is never swallowed!
        if (sessionManager.lastAcceptedFastMoveRealtimeMs > 0L && elapsedSinceLastAccept < 360L) {
            if (dropPx in 1..18) {
                refPlayerHpFillPx = hpPx
            }
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            return false
        }

        if (dropPx <= 0) {
            if (
                snapshot.totalFastMovesInMatch == 0 &&
                emptyAfterFillPx <= 2 &&
                orangeDrainPx == 0 &&
                hpPx > prevHpPx
            ) {
                refPlayerHpFillPx = hpPx
            }
            prevOrangeDrainPx = orangeDrainPx
            sustainedOnePxDropTicks = 0
            return false
        }

        // Handle 1px drops WITHOUT overwriting refPlayerHpFillPx on a single frame:
        // - If a 2px/3px move drains 1px on Frame 1 and 1px on Frame 2 (100 -> 99 -> 98), keeping
        //   refPlayerHpFillPx = 100 on Frame 1 means Frame 2 sees dropPx = 100 - 98 = 2 and counts it!
        // - If a super low-damage move genuinely drops only 1px total, it either shows orangeDrainPx >= 1
        //   or stays at 99 for 3 consecutive ticks (300ms) after the 100% full-health bar has already been broken.
        if (dropPx == 1) {
            val hasOrangeFlash = orangeDrainPx >= 1 && prevOrangeDrainPx == 0
            if (!hasOrangeFlash) {
                sustainedOnePxDropTicks++
                if (sustainedOnePxDropTicks < 3 || emptyAfterFillPx <= 3) {
                    prevOrangeDrainPx = orangeDrainPx
                    return false
                }
            }
        } else {
            sustainedOnePxDropTicks = 0
        }

        prevOrangeDrainPx = orangeDrainPx

        val canDispatchNow =
            snapshot.state == BattleState.ACTIVE ||
                (allowDuringCutsceneIntro && !hasCountedCutsceneIntroFastMove)

        if (canDispatchNow) {
            val activeFm = getActiveFastMove()
            sessionManager.onFastMoveSignal(allowDuringCutsceneIntro = allowDuringCutsceneIntro) { accepted, updatedSnap ->
                if (accepted) {
                    // Only commit the new HP baseline once the engine accepts the move!
                    refPlayerHpFillPx = hpPx
                    sustainedOnePxDropTicks = 0
                    fastHitsLandedOnCurrentPlayer++
                    if (allowDuringCutsceneIntro) {
                        hasCountedCutsceneIntroFastMove = true
                    }
                    statusMessage = "⚡ [$overlayVersion] +1 ${activeFm.name} (${updatedSnap.energy}E)"
                    onUiStateChanged()
                }
            }
            return true
        }

        return false
    }

    private fun isPlayerBubbleMinigameText(rawText: String): Boolean {
        val lower = rawText.lowercase()
        return lower.contains("nice!") ||
            lower.contains("great!") ||
            lower.contains("excellent!") ||
            lower.contains("swipe")
    }

    /**
     * Analyzes the latest captured frame and dispatches battle state / move signals to [sessionManager].
     */
    fun processFrame(image: Image, overlayRect: OverlayImageRect?, tickMs: Long) {
        val nowRealtimeMs = SystemClock.elapsedRealtime()
        if (isOcrBusy && nowRealtimeMs - lastOcrStartRealtimeMs > 2500L) {
            isOcrBusy = false
        }

        var telemetry = FrameVisualTelemetry(true, false, false, 66, -1, -1, 0, 0, 99, emptySet())
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var aboveHpEffBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        val shouldRunOcrThisTick = !isOcrBusy && (nowRealtimeMs - lastOcrCompletedRealtimeMs >= 300L)

        try {
            telemetry = analyzeFrameVisualTelemetry(image, overlayRect)
            val isWideArenaCombat = telemetry.isBattleHudVisible && telemetry.playerHpFillPx > 0

            if (telemetry.isFrameNonBlack) {
                if (isWideArenaCombat) {
                    if (currentPokemon.fastMoves.size > 1) {
                        arenaVisualBmp = cropRegionFromImage(image, 0.08f, 0.20f, 0.46f, 0.66f, step = 2)
                    }
                    if (shouldRunOcrThisTick) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.095f, step = 1)
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.46f, 0.110f, step = 1)
                        if (postCutsceneBannerTicks > 0) {
                            bannerBmp = cropRegionFromImage(
                                image, 0.06f, 0.16f, 0.92f, 0.40f, step = 1, maskOverlayRect = overlayRect
                            )
                        } else if (telemetry.playerHpBarY > 10 && currentPokemon.fastMoves.size > 1) {
                            val hpYRatio = telemetry.playerHpBarY.toFloat() / image.height
                            val effTop = max(0.11f, hpYRatio - 0.048f)
                            val effBot = max(effTop + 0.02f, hpYRatio - 0.003f)
                            aboveHpEffBmp = cropRegionFromImage(
                                image, 0.03f, effTop, 0.42f, effBot, step = 1, maskOverlayRect = overlayRect
                            )
                        }
                    }
                } else if (shouldRunOcrThisTick) {
                    bannerBmp = if (telemetry.isBattleHudVisible) {
                        cropRegionFromImage(
                            image, 0.06f, 0.16f, 0.92f, 0.44f, step = 1, maskOverlayRect = overlayRect
                        )
                    } else {
                        cropRegionFromImage(
                            image, 0.06f, 0.16f, 0.92f, 0.88f, step = 1, maskOverlayRect = overlayRect
                        )
                    }
                    if (telemetry.isBattleHudVisible) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.095f, step = 1)
                    }
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        if (!telemetry.isFrameNonBlack) {
            return
        }

        val badgeTypesThisFrame = telemetry.opponentBadgeTypes

        if (telemetry.isBattleHudVisible) {
            if (postCutsceneBannerTicks > 0) {
                postCutsceneBannerTicks--
                if (postCutsceneBannerTicks == 0) {
                    sessionManager.clearCutsceneEnergySnapshot()
                    hasDispatchedChargedMoveForCurrentCutscene = false
                }
            }

            if (!inActiveMatch) {
                inActiveMatch = true
                matchStartRealtimeMs = nowRealtimeMs
                val initialHp = telemetry.playerHpFillPx.takeIf { it > 0 }
                val initialY = if (initialHp != null) telemetry.playerHpBarY else -1
                resetAnalyzerAndSession(
                    statusMsg = "● [$overlayVersion] Battle Active",
                    preLockedHpPx = initialHp,
                    preLockedBarY = initialY
                )
            } else if (!isBattleHudCurrentlyVisible && hudCompletelyMissingDurationMs >= 1000L) {
                postCutsceneBannerTicks = 28
                hasCountedCutsceneIntroFastMove = false

                val wasOpponentChargedMove = !playerUsedChargedMoveDuringZoom && (
                    chargedAttackDetectedDuringPause ||
                        specificMoveDetectedDuringPause != null ||
                        hasDispatchedChargedMoveForCurrentCutscene
                    )

                if (playerUsedChargedMoveDuringZoom) {
                    // Player used their own Charged Move: preserve refPlayerHpFillPx so any Fast Move that
                    // snuck through on the Charged Move turn is immediately detected when returning to ACTIVE!
                    hasDispatchedChargedMoveForCurrentCutscene = false
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = true) {
                        onUiStateChanged()
                    }
                } else if (wasOpponentChargedMove) {
                    if (!hasDispatchedChargedMoveForCurrentCutscene) {
                        val snapEnergy = sessionManager.snapshotFlow.value.energy
                        val moveToSub = specificMoveDetectedDuringPause ?: run {
                            currentPokemon.chargedMoves.firstOrNull { snapEnergy >= it.energyCost }
                                ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                        }
                        if (moveToSub != null && nowRealtimeMs - lastDispatchedChargedTimestampMs > 3000L) {
                            dispatchChargedMoveSignal(moveToSub, pauseClock = false)
                        }
                    }
                    // Opponent threw a Charged Move: re-lock HP baseline on the post-Charged-Move HP bar
                    refPlayerHpFillPx = null
                    refPlayerHpBarY = -1
                    prevOrangeDrainPx = 0
                    higherHpConfirmTicks = 0
                    sustainedOnePxDropTicks = 0
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = false) {
                        onUiStateChanged()
                    }
                } else {
                    // Resume ACTIVE turn clock after camera zoom
                    sessionManager.onMinigameEnd(clearCutsceneSnapshot = true) {
                        onUiStateChanged()
                    }
                }

                chargedAttackDetectedDuringPause = false
                playerUsedChargedMoveDuringZoom = false
                specificMoveDetectedDuringPause = null
            } else if (sessionManager.snapshotFlow.value.state != BattleState.ACTIVE) {
                hasCountedCutsceneIntroFastMove = false
                sessionManager.onMinigameEnd(clearCutsceneSnapshot = false) {
                    onUiStateChanged()
                }
            }

            isBattleHudCurrentlyVisible = true
            hudCompletelyMissingDurationMs = 0L

            if (telemetry.playerHpFillPx > 0) {
                val justDispatchedHit = evaluatePlayerHpBarAndDispatchSignal(
                    barLen = telemetry.barLenPx,
                    hpPx = telemetry.playerHpFillPx,
                    hpBarY = telemetry.playerHpBarY,
                    orangeDrainPx = telemetry.orangeDrainPx,
                    emptyAfterFillPx = telemetry.emptyAfterFillPx,
                    nowRealtimeMs = nowRealtimeMs,
                    allowDuringCutsceneIntro = false
                )

                if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                    val curActiveIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                    val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                        arenaVisualBmp,
                        currentPokemon,
                        curActiveIdx,
                        latestEffectivenessHint,
                        playerDefenderTypes,
                        fastHitsLandedOnCurrentPlayer,
                        justDispatchedHit
                    )
                    if (detectedFmIdx != null && detectedFmIdx != curActiveIdx) {
                        slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                        val newFm = getActiveFastMove()
                        statusMessage = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                        sessionManager.configureFastMove(
                            durationTurns = newFm.turns,
                            energyGain = newFm.energyGain,
                            moveName = newFm.name,
                            preserveMoveCount = true
                        ) {
                            onUiStateChanged()
                        }
                    }
                }
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartRealtimeMs = nowRealtimeMs
                recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        var matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text, badgeTypesThisFrame)
                        if (matchedPoke != null) {
                            val baseKey = matchedPoke.name.substringBefore("(").trim().lowercase()
                            val manualId = manualFormOverrideByBase[baseKey]
                            if (manualId != null) {
                                val manualEntry = PvPokeRepository.getSiblingForms(matchedPoke).firstOrNull { it.id == manualId }
                                if (manualEntry != null) matchedPoke = manualEntry
                            }

                            val isRealPoke = !matchedPoke.id.startsWith("dyn_")
                            if (!isRealPoke && hasLockedFirstRealOpponentInMatch) {
                                return@addOnSuccessListener
                            }

                            if (isRealPoke) {
                                seenOpponentPokemon[matchedPoke.id] = matchedPoke
                            }

                            val wasFirstLock = !hasLockedFirstRealOpponentInMatch && isRealPoke
                            if (wasFirstLock) {
                                hasLockedFirstRealOpponentInMatch = true
                                if (matchedPoke.id != currentPokemon.id) {
                                    seenOpponentPokemon.remove(currentPokemon.id)
                                }
                            }

                            if (matchedPoke.id != currentPokemon.id) {
                                val prevBaseKey = currentPokemon.name.substringBefore("(").trim().lowercase()
                                val isSameBaseOrOpeningSwap =
                                    wasFirstLock || (prevBaseKey == baseKey) || currentPokemon.id.startsWith("dyn_")
                                if (isSameBaseOrOpeningSwap) {
                                    seenOpponentPokemon.remove(currentPokemon.id)
                                }
                                currentPokemon = matchedPoke
                                fastHitsLandedOnCurrentPlayer = 0
                                latestEffectivenessHint = null
                                visualClassifier.resetForNewOpponent()

                                val newFm = getActiveFastMove(matchedPoke)
                                sessionManager.onSwitch(
                                    newPokemonId = matchedPoke.id,
                                    durationTurns = newFm.turns,
                                    energyGain = newFm.energyGain,
                                    moveName = newFm.name,
                                    transferOpeningEnergy = isSameBaseOrOpeningSwap,
                                    pauseForSwitchWindow = false
                                ) { snap ->
                                    statusMessage = if (snap.energy > 0) {
                                        "🔄 Restored ${matchedPoke.name}: ${snap.fastMoveCount} Fast (${snap.energy}E)"
                                    } else {
                                        "● Locked: ${matchedPoke.name}"
                                    }
                                    onUiStateChanged()
                                }
                            } else if (
                                !statusMessage.startsWith("⚡") &&
                                !statusMessage.startsWith("▼") &&
                                !statusMessage.startsWith("🔄")
                            ) {
                                statusMessage = "● [$overlayVersion] Watching ${matchedPoke.name}"
                                onUiStateChanged()
                            }
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val rawLeft = leftText.text
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(rawLeft)
                                    if (
                                        playerPoke != null &&
                                        !playerPoke.id.startsWith("dyn_") &&
                                        playerPoke.id != currentPlayerPokemonId
                                    ) {
                                        currentPlayerPokemonId = playerPoke.id
                                        currentPlayerPokemonName = playerPoke.name
                                        playerDefenderTypes = PvPokeRepository.getDefenderTypes(playerPoke)
                                        fastHitsLandedOnCurrentPlayer = 0
                                        latestEffectivenessHint = null
                                    }
                                }
                                .addOnCompleteListener {
                                    val nextBmp = bannerBmp ?: aboveHpEffBmp
                                    val isBannerCrop = (bannerBmp != null)
                                    if (nextBmp != null) {
                                        recognizer.process(InputImage.fromBitmap(nextBmp, 0))
                                            .addOnSuccessListener { subText ->
                                                val rawS = subText.text
                                                if (!isBannerCrop) {
                                                    val (_, _, effH) =
                                                        PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    if (effH != null) latestEffectivenessHint = effH
                                                } else if (
                                                    isPlayerBubbleMinigameText(rawS) ||
                                                    PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                                        rawS,
                                                        currentPlayerPokemonName,
                                                        currentPokemon.name
                                                    )
                                                ) {
                                                    playerUsedChargedMoveDuringZoom = true
                                                    undoFalsePlayerChargedMoveIfNeeded()
                                                    statusMessage = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                                    onUiStateChanged()
                                                } else {
                                                    val (_, specificMove, _) =
                                                        PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    if (specificMove != null) {
                                                        reconcileChargedMoveFromBanner(specificMove, pauseClock = false)
                                                        postCutsceneBannerTicks = 0
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                                lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                                isOcrBusy = false
                                            }
                                    } else {
                                        lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                        isOcrBusy = false
                                    }
                                }
                        } else if (bannerBmp != null) {
                            recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                                .addOnSuccessListener { bText ->
                                    val rawB = bText.text
                                    if (
                                        isPlayerBubbleMinigameText(rawB) ||
                                        PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                            rawB,
                                            currentPlayerPokemonName,
                                            currentPokemon.name
                                        )
                                    ) {
                                        playerUsedChargedMoveDuringZoom = true
                                        undoFalsePlayerChargedMoveIfNeeded()
                                        statusMessage = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                        onUiStateChanged()
                                    } else {
                                        val (_, specificMove, _) =
                                            PvPokeRepository.detectChargedAttackAndEffectiveness(rawB, currentPokemon)
                                        if (specificMove != null) {
                                            reconcileChargedMoveFromBanner(specificMove, pauseClock = false)
                                            postCutsceneBannerTicks = 0
                                        }
                                    }
                                }
                                .addOnCompleteListener {
                                    lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                                    isOcrBusy = false
                                }
                        } else {
                            lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            if (!inActiveMatch) {
                refPlayerHpFillPx = null
                refPlayerHpBarY = -1
            }

            if (isBattleHudCurrentlyVisible && inActiveMatch) {
                hasDispatchedChargedMoveForCurrentCutscene = false
                hasCountedCutsceneIntroFastMove = false
                sessionManager.onMinigameStart {
                    onUiStateChanged()
                }
            }
            isBattleHudCurrentlyVisible = false
            hudCompletelyMissingDurationMs += tickMs

            // During the first 1400ms after the top HUD pills slide off (e.g. as "Attack incoming! Use a Protect Shield?"
            // appears on screen), the Charged Move has NOT been thrown yet, and your Pokémon's floating HP bar is still
            // visible! Check if the opponent's final Fast Move before the Charged Move just dropped your HP bar!
            if (
                inActiveMatch &&
                hudCompletelyMissingDurationMs <= 1400L &&
                telemetry.playerHpFillPx > 0 &&
                !hasCountedCutsceneIntroFastMove
            ) {
                evaluatePlayerHpBarAndDispatchSignal(
                    barLen = telemetry.barLenPx,
                    hpPx = telemetry.playerHpFillPx,
                    hpBarY = telemetry.playerHpBarY,
                    orangeDrainPx = telemetry.orangeDrainPx,
                    emptyAfterFillPx = telemetry.emptyAfterFillPx,
                    nowRealtimeMs = nowRealtimeMs,
                    allowDuringCutsceneIntro = true
                )
            }

            if (inActiveMatch && telemetry.isShieldPromptVisible) {
                chargedAttackDetectedDuringPause = true
                sessionManager.onMinigameStart()
                if (!statusMessage.startsWith("▼") && !statusMessage.startsWith("⚡")) {
                    statusMessage = "⚠️ Attack Incoming!"
                    onUiStateChanged()
                }
            }

            if (hudCompletelyMissingDurationMs >= 10000L && inActiveMatch) {
                inActiveMatch = false
                resetAnalyzerAndSession("● [$overlayVersion] Waiting for battle...")
            } else if (inActiveMatch && hudCompletelyMissingDurationMs >= 450L) {
                if (
                    !statusMessage.startsWith("⚠️") &&
                    !statusMessage.startsWith("🛡️") &&
                    !statusMessage.startsWith("▼") &&
                    !statusMessage.startsWith("⚡")
                ) {
                    statusMessage = "⏸ [$overlayVersion] Paused (Cutscene)"
                    onUiStateChanged()
                }
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartRealtimeMs = nowRealtimeMs
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        if (!telemetry.isShieldPromptVisible && PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetAnalyzerAndSession("● [$overlayVersion] Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            if (
                                isPlayerBubbleMinigameText(rawBanner) ||
                                PvPokeRepository.isPlayerOwnChargedMoveBanner(
                                    rawBanner,
                                    currentPlayerPokemonName,
                                    currentPokemon.name
                                )
                            ) {
                                playerUsedChargedMoveDuringZoom = true
                                undoFalsePlayerChargedMoveIfNeeded()
                                statusMessage = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                onUiStateChanged()
                            } else {
                                val (isIncoming, specificMove, _) =
                                    PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                                if (specificMove != null) {
                                    upgradeToSiblingFormIfMoveMatches(specificMove)
                                    specificMoveDetectedDuringPause = specificMove
                                    chargedAttackDetectedDuringPause = true
                                    if (
                                        !hasDispatchedChargedMoveForCurrentCutscene &&
                                        nowRealtimeMs - lastDispatchedChargedTimestampMs > 3000L
                                    ) {
                                        dispatchChargedMoveSignal(specificMove, pauseClock = true)
                                    } else {
                                        reconcileChargedMoveFromBanner(specificMove, pauseClock = true)
                                    }
                                } else if (isIncoming) {
                                    chargedAttackDetectedDuringPause = true
                                    sessionManager.onMinigameStart()
                                    if (!statusMessage.startsWith("⚡")) {
                                        statusMessage = "⚠️ Attack Incoming!"
                                        onUiStateChanged()
                                    }
                                }
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedRealtimeMs = SystemClock.elapsedRealtime()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun analyzeFrameVisualTelemetry(image: Image, overlayRect: OverlayImageRect?): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val barLen = max(20, (width * 0.272f).roundToInt())

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(false, false, false, barLen, -1, -1, 0, 0, 99, emptySet())
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float, ignoreOverlay: Boolean): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.015f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.108f).toInt().coerceIn(y0 + 1, height)

                var maxRowWhiteRatio = 0f
                var pokeballIndicatorDots = 0
                var darkTextPixels = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        if (ignoreOverlay && overlayRect != null && overlayRect.contains(x, y)) {
                            x += max(2, width / 160)
                            continue
                        }
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 175 && g >= 185 && b >= 200) {
                                rowWhite++
                            }
                            if (r > 170 && g < 98 && b < 98) {
                                pokeballIndicatorDots++
                            }
                            if (r < 115 && g < 115 && b < 125) {
                                darkTextPixels++
                            }
                        }
                        x += max(2, width / 160)
                    }
                    if (rowTotal >= 6) {
                        val ratio = rowWhite.toFloat() / rowTotal
                        if (ratio > maxRowWhiteRatio) maxRowWhiteRatio = ratio
                    }
                    y += max(1, height / 700)
                }
                return (maxRowWhiteRatio > 0.40f && darkTextPixels >= 3 && pokeballIndicatorDots >= 1) ||
                    (maxRowWhiteRatio > 0.50f && darkTextPixels >= 5 && pokeballIndicatorDots >= 1)
            }

            val leftPillVisible = checkBattlePillSide(0.02f, 0.42f, ignoreOverlay = false)
            val rightPillVisible = checkBattlePillSide(0.58f, 0.98f, ignoreOverlay = true)
            val hudPillsVisible = leftPillVisible && rightPillVisible

            var shieldMagentaCount = 0
            var shieldSampleTotal = 0
            val sx0 = (width * 0.38f).toInt().coerceIn(0, width - 2)
            val sx1 = (width * 0.62f).toInt().coerceIn(sx0 + 1, width)
            val sy0 = (height * 0.73f).toInt().coerceIn(0, height - 2)
            val sy1 = (height * 0.91f).toInt().coerceIn(sy0 + 1, height)
            var sy = sy0
            while (sy < sy1) {
                val rOff = sy * rowStride
                var sx = sx0
                while (sx < sx1) {
                    val off = rOff + sx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        shieldSampleTotal++
                        if (r >= 175 && b >= 195 && g in 110..235 && (b - g) >= 15) {
                            shieldMagentaCount++
                        }
                    }
                    sx += max(2, width / 120)
                }
                sy += max(2, height / 250)
            }
            val shieldMagentaRatio = if (shieldSampleTotal > 0) shieldMagentaCount.toFloat() / shieldSampleTotal else 0f
            val isShieldPromptVisible = !hudPillsVisible && shieldMagentaRatio >= 0.16f

            val detectedBadgeTypes = mutableSetOf<String>()
            if (hudPillsVisible) {
                val bx0 = (width * 0.88f).toInt().coerceIn(0, width - 2)
                val bx1 = (width * 0.985f).toInt().coerceIn(bx0 + 1, width)
                val by1 = max(4, (height * 0.015f).toInt()).coerceIn(1, height)
                val badgeCounts = mutableMapOf<String, Int>()
                for (by in 0 until by1) {
                    val rOff = by * rowStride
                    for (bx in bx0 until bx1) {
                        val off = rOff + bx * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            val bType = when {
                                r > 215 && g in 130..222 && b > 195 && (r - g) >= 20 && (b - g) >= 20 -> "fairy"
                                r in 155..220 && g in 60..130 && b in 165..235 && (r - g) > 55 && (b - g) > 65 -> "poison"
                                r > 225 && g in 135..195 && b in 45..110 && (r - b) > 120 -> "fire"
                                r > 195 && g in 45..105 && b in 50..115 && (r - g) > 100 -> "fighting"
                                r in 75..150 && g in 150..210 && b > 205 && (b - r) > 70 -> "water"
                                r in 80..205 && g > 190 && b > 185 && abs(g - b) < 25 && (g - r) >= 28 -> "ice"
                                r in 85..135 && g in 135..175 && b in 155..200 && (b - r) in 40..80 -> "steel"
                                r > 210 && g in 115..160 && b in 60..105 && (r - b) > 110 -> "ground"
                                r > 230 && g > 200 && b in 40..105 && (r - b) > 135 -> "electric"
                                r in 70..135 && g > 175 && b in 70..135 && (g - r) > 55 -> "grass"
                                r > 220 && g in 95..145 && b in 120..175 && (r - g) > 85 -> "psychic"
                                r in 85..125 && g in 70..110 && b in 145..195 && (b - g) > 55 && (r - g) > 10 -> "ghost"
                                r in 65..105 && g in 55..95 && b in 65..105 && abs(r - g) < 16 && abs(b - g) < 18 -> "dark"
                                else -> null
                            }
                            if (bType != null) {
                                badgeCounts[bType] = (badgeCounts[bType] ?: 0) + 1
                            }
                        }
                    }
                }
                for ((tName, cnt) in badgeCounts) {
                    if (cnt >= 6) detectedBadgeTypes.add(tName)
                }
            }

            fun classifyHpPixel(r: Int, g: Int, b: Int): Int {
                return when {
                    g >= 185 && r <= 105 && b in 110..215 && (g - r) >= 95 && (g - b) >= 32 -> 1
                    r >= 205 && g >= 185 && b in 60..180 && (r - b) >= 60 && abs(r - g) <= 45 -> 2
                    r >= 175 && g in 15..115 && b in 15..115 && (r - g) >= 85 && abs(g - b) <= 35 -> 3
                    (r < 98 && g < 98 && b < 118 && (r + g + b) <= 275) ||
                        (r >= 138 && g in 95..195 && b < 68 && (r - b) >= 80) -> 4
                    else -> 0
                }
            }

            val maxBorderDy = max(5, (height * 0.013f).toInt())
            val borderStepX = max(2, barLen / 22)

            fun hasHorizontalBoxBorder(py: Int, absStartX: Int): Boolean {
                var topBest = 0
                var botBest = 0
                var totalCols = 0
                val endX = min(width - 1, absStartX + barLen)
                var x = absStartX
                while (x < endX) {
                    totalCols++
                    x += borderStepX
                }
                if (totalCols <= 4) return false
                val reqBright = (totalCols * 0.48f).toInt()

                for (dy in 1..maxBorderDy) {
                    val ty = py - dy
                    if (ty >= 0) {
                        val rOff = ty * rowStride
                        var cnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 240 && max(r, max(g, b)) >= 88) cnt++
                            }
                            cx += borderStepX
                        }
                        if (cnt > topBest) topBest = cnt
                    }
                    val by = py + dy
                    if (by < height) {
                        val rOff = by * rowStride
                        var cnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 240 && max(r, max(g, b)) >= 88) cnt++
                            }
                            cx += borderStepX
                        }
                        if (cnt > botBest) botBest = cnt
                    }
                }
                return topBest >= reqBright && botBest >= reqBright
            }

            val hx0 = (width * 0.035f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.42f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.15f).toInt().coerceIn(4, height - 5)
            val hy1 = (height * 0.75f).toInt().coerceIn(hy0 + 1, height - 4)

            val scanW = hx1 - hx0
            val minValidInBar = (barLen * 0.76f).toInt()
            val minSmoothInBar = (barLen * 0.72f).toInt()
            val minStartScreenX = (width * 0.048f).toInt()
            val maxStartScreenX = (width * 0.098f).toInt()

            val minGreenFill = max(12, (barLen * 0.44f).toInt())
            val minYellowFill = max(6, (barLen * 0.15f).toInt())
            val maxYellowFill = (barLen * 0.58f).toInt()
            val maxRedFill = max(6, (barLen * 0.26f).toInt())

            var bestGreenFillPx = -1
            var bestGreenY = -1
            var bestGreenOrangePx = 0
            var bestGreenEmptyPx = 99
            var bestYellowFillPx = -1
            var bestYellowY = -1
            var bestYellowOrangePx = 0
            var bestYellowEmptyPx = 99
            var bestRedFillPx = -1
            var bestRedY = -1
            var bestRedOrangePx = 0
            var bestRedEmptyPx = 99

            val rowTypes = IntArray(scanW)
            val rowOrange = BooleanArray(scanW)
            val smoothPrefix = IntArray(scanW)

            val prev1FirstCol = IntArray(4) { -1 }
            val prev1FillCnt = IntArray(4) { -1 }
            val prev1RowY = IntArray(4) { -1 }

            val maxOrangeTipSpan = max(6, barLen / 11)

            // Always scan the player's floating HP bar (even when the Shield Prompt appears) so that a Fast Move
            // landing right on the transition into "Attack incoming! Use a Protect Shield?" is never missed!
            if (scanW > barLen) {
                for (py in hy0 until hy1) {
                    val rOff = py * rowStride
                    var gFirst = -1
                    var yFirst = -1
                    var rFirst = -1

                    var prevR = 0
                    var prevG = 0
                    var prevB = 0
                    var sSum = 0

                    for (col in 0 until scanW) {
                        val absX = hx0 + col
                        if (overlayRect != null && overlayRect.contains(absX, py)) {
                            rowTypes[col] = 0
                            rowOrange[col] = false
                            smoothPrefix[col] = sSum
                            continue
                        }
                        val off = rOff + absX * pixelStride
                        var t = 0
                        var isOrg = false
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF

                            if (col > 0) {
                                val diff = abs(r - prevR) + abs(g - prevG) + abs(b - prevB)
                                if (diff <= 22) sSum++
                            }
                            smoothPrefix[col] = sSum
                            prevR = r
                            prevG = g
                            prevB = b

                            t = classifyHpPixel(r, g, b)
                            when (t) {
                                1 -> if (gFirst < 0) gFirst = col
                                2 -> if (yFirst < 0) yFirst = col
                                3 -> if (rFirst < 0) rFirst = col
                            }

                            if (r >= 175 && g in 110..195 && b <= 62 && (r - b) >= 115 && r >= g + 14) {
                                isOrg = true
                            }
                        } else {
                            smoothPrefix[col] = sSum
                        }
                        rowTypes[col] = t
                        rowOrange[col] = isOrg
                    }

                    fun evalStageRow(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int): Triple<Int, Int, Int> {
                        if (firstCol < 0 || firstCol + barLen > scanW) return Triple(-1, 0, 99)
                        val absStartX = hx0 + firstCol
                        if (absStartX !in minStartScreenX..maxStartScreenX) return Triple(-1, 0, 99)

                        val smoothCnt = smoothPrefix[firstCol + barLen - 1] - smoothPrefix[firstCol]
                        if (smoothCnt < minSmoothInBar) return Triple(-1, 0, 99)

                        var fillCnt = 0
                        var gap = 0
                        var fillStopped = false
                        var emptyCnt = 0
                        val barEndCol = firstCol + barLen
                        for (c in firstCol until barEndCol) {
                            val rt = rowTypes[c]
                            if (!fillStopped) {
                                if (rt == stageCode) {
                                    fillCnt += (1 + gap)
                                    gap = 0
                                } else {
                                    gap++
                                    if (gap >= 3) {
                                        var resumes = false
                                        if (gap <= 5 && c + 3 < barEndCol) {
                                            if (
                                                rowTypes[c + 1] == stageCode &&
                                                rowTypes[c + 2] == stageCode &&
                                                rowTypes[c + 3] == stageCode
                                            ) {
                                                resumes = true
                                            }
                                        }
                                        if (!resumes) {
                                            fillStopped = true
                                            if (rt == 4) emptyCnt++
                                        }
                                    } else if (rt == 4) {
                                        emptyCnt++
                                    }
                                }
                            } else if (rt == 4) {
                                emptyCnt++
                            }
                        }
                        if (fillCnt !in minFill..maxFill || (fillCnt + emptyCnt) < minValidInBar) {
                            return Triple(-1, 0, 99)
                        }

                        if (!hasHorizontalBoxBorder(py, absStartX)) {
                            return Triple(-1, 0, 99)
                        }

                        var orgCnt = 0
                        val tipStart = (firstCol + fillCnt).coerceAtMost(scanW - 1)
                        val tipEnd = min(firstCol + barLen, firstCol + fillCnt + maxOrangeTipSpan)
                        for (c in tipStart until tipEnd) {
                            if (rowOrange[c]) orgCnt++
                        }
                        return Triple(fillCnt, orgCnt, emptyCnt)
                    }

                    fun updateStageHistoryAndBest(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int) {
                        val (fillCnt, orgCnt, emptyCnt) = evalStageRow(firstCol, stageCode, minFill, maxFill)
                        if (fillCnt > 0) {
                            if (
                                prev1RowY[stageCode] == py - 1 &&
                                abs(prev1FirstCol[stageCode] - firstCol) <= 2 &&
                                abs(prev1FillCnt[stageCode] - fillCnt) <= 3
                            ) {
                                val avgFill = max(fillCnt, prev1FillCnt[stageCode])
                                when (stageCode) {
                                    1 -> if (avgFill > bestGreenFillPx || (avgFill == bestGreenFillPx && orgCnt > bestGreenOrangePx)) {
                                        bestGreenFillPx = avgFill
                                        bestGreenY = py
                                        bestGreenOrangePx = max(bestGreenOrangePx, orgCnt)
                                        bestGreenEmptyPx = emptyCnt
                                    }
                                    2 -> if (avgFill > bestYellowFillPx || (avgFill == bestYellowFillPx && orgCnt > bestYellowOrangePx)) {
                                        bestYellowFillPx = avgFill
                                        bestYellowY = py
                                        bestYellowOrangePx = max(bestYellowOrangePx, orgCnt)
                                        bestYellowEmptyPx = emptyCnt
                                    }
                                    3 -> if (avgFill > bestRedFillPx || (avgFill == bestRedFillPx && orgCnt > bestRedOrangePx)) {
                                        bestRedFillPx = avgFill
                                        bestRedY = py
                                        bestRedOrangePx = max(bestRedOrangePx, orgCnt)
                                        bestRedEmptyPx = emptyCnt
                                    }
                                }
                            }
                            prev1RowY[stageCode] = py
                            prev1FirstCol[stageCode] = firstCol
                            prev1FillCnt[stageCode] = fillCnt
                        }
                    }

                    updateStageHistoryAndBest(gFirst, 1, minGreenFill, barLen)
                    updateStageHistoryAndBest(yFirst, 2, minYellowFill, maxYellowFill)
                    updateStageHistoryAndBest(rFirst, 3, 2, maxRedFill)
                }
            }

            val hpFillPx: Int
            val hpBarY: Int
            val hpStage: Int
            val orangeDrainPx: Int
            val emptyAfterFillPx: Int
            when {
                bestGreenFillPx > 0 -> {
                    hpFillPx = bestGreenFillPx
                    hpBarY = bestGreenY
                    hpStage = 1
                    orangeDrainPx = bestGreenOrangePx
                    emptyAfterFillPx = bestGreenEmptyPx
                }
                bestYellowFillPx > 0 -> {
                    hpFillPx = bestYellowFillPx
                    hpBarY = bestYellowY
                    hpStage = 2
                    orangeDrainPx = bestYellowOrangePx
                    emptyAfterFillPx = bestYellowEmptyPx
                }
                bestRedFillPx > 0 -> {
                    hpFillPx = bestRedFillPx
                    hpBarY = bestRedY
                    hpStage = 3
                    orangeDrainPx = bestRedOrangePx
                    emptyAfterFillPx = bestRedEmptyPx
                }
                else -> {
                    hpFillPx = -1
                    hpBarY = -1
                    hpStage = 0
                    orangeDrainPx = 0
                    emptyAfterFillPx = 99
                }
            }

            FrameVisualTelemetry(
                isFrameNonBlack = true,
                isBattleHudVisible = hudPillsVisible,
                isShieldPromptVisible = isShieldPromptVisible,
                barLenPx = barLen,
                playerHpFillPx = hpFillPx,
                playerHpBarY = hpBarY,
                playerHpStage = hpStage,
                orangeDrainPx = orangeDrainPx,
                emptyAfterFillPx = emptyAfterFillPx,
                opponentBadgeTypes = detectedBadgeTypes
            )
        } catch (_: Exception) {
            FrameVisualTelemetry(true, false, false, 66, -1, -1, 0, 0, 99, emptySet())
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1,
        maskOverlayRect: OverlayImageRect? = null
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    if (maskOverlayRect != null && maskOverlayRect.contains(x, y)) {
                        pixels[py * outW + px] = 0xFF000000.toInt()
                    } else {
                        val offset = rowOffset + x * pixelStride
                        if (offset >= 0 && offset + 3 < bufLimit) {
                            val r = buf.get(offset).toInt() and 0xFF
                            val g = buf.get(offset + 1).toInt() and 0xFF
                            val b = buf.get(offset + 2).toInt() and 0xFF
                            pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                        }
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }
}
