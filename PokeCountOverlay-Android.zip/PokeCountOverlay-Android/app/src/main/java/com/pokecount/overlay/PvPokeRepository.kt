package com.pokecount.overlay

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

data class FastMove(val name: String, val type: String, val energyGain: Int, val turns: Int)
data class ChargedMove(val name: String, val type: String, val energyCost: Int)
data class PvPokeEntry(
    val id: String,
    val name: String,
    val fastMove: FastMove,
    val chargedMoves: List<ChargedMove>
) {
    /**
     * Computes PvPoke's exact "Fast Move Count: 4 - 4 - 4 - 4" or "5 - 4 - 5 - 4" sequence
     * for a given Charged Move, accounting for leftover residual energy after each throw.
     */
    fun getPvPokeMoveCounts(chargedMove: ChargedMove, cycles: Int = 4): List<Int> {
        val counts = mutableListOf<Int>()
        var residual = 0
        val eFast = max(1, fastMove.energyGain)
        for (i in 0 until cycles) {
            val needed = max(0, chargedMove.energyCost - residual)
            val moves = ceil(needed.toDouble() / eFast).toInt()
            counts.add(moves)
            residual = (residual + moves * eFast) - chargedMove.energyCost
        }
        return counts
    }
}

object PvPokeRepository {
    private fun fm(name: String, type: String, e: Int, t: Int) = FastMove(name, type, e, t)
    private fun cm(name: String, type: String, cost: Int) = ChargedMove(name, type, cost)

    // Built-in comprehensive Great League + All-League PvPoke Roster (works 100% offline immediately)
    val BUILT_IN_POKEMON: List<PvPokeEntry> = listOf(
        PvPokeEntry("melmetal", "Melmetal", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Double Iron Bash*", "steel", 35), cm("Superpower", "fighting", 40), cm("Rock Slide", "rock", 45), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("clodsire", "Clodsire", fm("Poison Sting", "poison", 10, 2), listOf(cm("Earthquake", "ground", 65), cm("Stone Edge", "rock", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("feraligatr", "Feraligatr", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Hydro Cannon*", "water", 40), cm("Ice Beam", "ice", 55), cm("Crunch", "dark", 45))),
        PvPokeEntry("mandibuzz", "Mandibuzz", fm("Snarl", "dark", 13, 3), listOf(cm("Dark Pulse", "dark", 50), cm("Aerial Ace", "flying", 40), cm("Foul Play", "dark", 45))),
        PvPokeEntry("azumarill", "Azumarill", fm("Bubble", "water", 11, 3), listOf(cm("Ice Beam", "ice", 55), cm("Play Rough", "fairy", 60), cm("Hydro Pump", "water", 75))),
        PvPokeEntry("gastrodon", "Gastrodon", fm("Mud Slap", "ground", 10, 3), listOf(cm("Body Slam", "normal", 35), cm("Earth Power", "ground", 55), cm("Water Pulse", "water", 55))),
        PvPokeEntry("jumpluff", "Jumpluff", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Aerial Ace", "flying", 40), cm("Energy Ball", "grass", 55), cm("Acrobatics", "flying", 60))),
        PvPokeEntry("dunsparce", "Dunsparce", fm("Rollout", "rock", 13, 3), listOf(cm("Drill Run", "ground", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("annihilape", "Annihilape", fm("Karate Chop", "fighting", 9, 2), listOf(cm("Rage Fist*", "ghost", 35), cm("Ice Punch", "ice", 40), cm("Close Combat", "fighting", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("primeape", "Primeape", fm("Karate Chop", "fighting", 9, 2), listOf(cm("Rage Fist*", "ghost", 35), cm("Close Combat", "fighting", 45), cm("Night Slash", "dark", 35))),
        PvPokeEntry("corsola_galarian", "Corsola (Galarian)", fm("Astonish", "ghost", 10, 3), listOf(cm("Night Shade", "ghost", 55), cm("Power Gem", "rock", 60))),
        PvPokeEntry("cursola", "Cursola", fm("Astonish", "ghost", 10, 3), listOf(cm("Night Shade", "ghost", 55), cm("Rock Blast", "rock", 40))),
        PvPokeEntry("corviknight", "Corviknight", fm("Sand Attack", "ground", 4, 1), listOf(cm("Sky Attack", "flying", 55), cm("Iron Head", "steel", 50), cm("Payback", "dark", 60))),
        PvPokeEntry("morpeko", "Morpeko", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Aura Wheel", "electric", 45), cm("Psychic Fangs", "psychic", 35), cm("Seed Bomb", "grass", 45))),
        PvPokeEntry("serperior", "Serperior", fm("Vine Whip", "grass", 8, 2), listOf(cm("Frenzy Plant*", "grass", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("lickilicky", "Lickilicky", fm("Rollout", "rock", 13, 3), listOf(cm("Body Slam", "normal", 35), cm("Shadow Ball", "ghost", 55), cm("Earthquake", "ground", 65))),
        PvPokeEntry("lickitung", "Lickitung", fm("Lick", "ghost", 3, 1), listOf(cm("Body Slam", "normal", 35), cm("Power Whip", "grass", 50))),
        PvPokeEntry("wigglytuff", "Wigglytuff", fm("Charm", "fairy", 6, 3), listOf(cm("Icy Wind", "ice", 45), cm("Swift", "normal", 35), cm("Disarming Voice", "fairy", 45))),
        PvPokeEntry("clefable", "Clefable", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Meteor Mash*", "steel", 50), cm("Swift", "normal", 35), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("drapion", "Drapion", fm("Poison Sting", "poison", 10, 2), listOf(cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("skuntank", "Skuntank", fm("Poison Jab", "poison", 7, 2), listOf(cm("Crunch", "dark", 45), cm("Trailblaze", "grass", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("overqwil", "Overqwil", fm("Poison Jab", "poison", 7, 2), listOf(cm("Aqua Tail", "water", 35), cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("qwilfish", "Qwilfish", fm("Poison Sting", "poison", 10, 2), listOf(cm("Aqua Tail", "water", 35), cm("Ice Beam", "ice", 55), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("qwilfish_hisuian", "Qwilfish (Hisuian)", fm("Poison Jab", "poison", 7, 2), listOf(cm("Aqua Tail", "water", 35), cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("dewgong", "Dewgong", fm("Ice Shard", "ice", 10, 3), listOf(cm("Icy Wind", "ice", 45), cm("Drill Run", "ground", 45))),
        PvPokeEntry("toxapex", "Toxapex", fm("Poison Jab", "poison", 7, 2), listOf(cm("Brine", "water", 40), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("sandslash_alolan", "Sandslash (Alolan)", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Ice Punch", "ice", 40), cm("Drill Run", "ground", 45))),
        PvPokeEntry("sandslash", "Sandslash", fm("Mud Shot", "ground", 9, 2), listOf(cm("Night Slash", "dark", 35), cm("Scorching Sands", "ground", 50), cm("Earthquake", "ground", 65))),
        PvPokeEntry("ninetales_alolan", "Ninetales (Alolan)", fm("Powder Snow", "ice", 8, 2), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Dazzling Gleam", "fairy", 70), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("ninetales", "Ninetales", fm("Fire Spin", "fire", 10, 3), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Scorching Sands", "ground", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("carbink", "Carbink", fm("Rock Throw", "rock", 5, 2), listOf(cm("Rock Slide", "rock", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("talonflame", "Talonflame", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Fly", "flying", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("malamar", "Malamar", fm("Psywave", "psychic", 4, 1), listOf(cm("Superpower", "fighting", 40), cm("Foul Play", "dark", 45), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("diggersby", "Diggersby", fm("Quick Attack", "normal", 8, 2), listOf(cm("Fire Punch", "fire", 40), cm("Scorching Sands", "ground", 50), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("marowak", "Marowak", fm("Mud Slap", "ground", 10, 3), listOf(cm("Bone Club", "ground", 35), cm("Rock Slide", "rock", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("marowak_alolan", "Marowak (Alolan)", fm("Fire Spin", "fire", 10, 3), listOf(cm("Bone Club", "ground", 35), cm("Shadow Bone", "ghost", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("stunfisk", "Stunfisk", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Mud Bomb", "ground", 40), cm("Discharge", "electric", 45))),
        PvPokeEntry("stunfisk_galarian", "Stunfisk (Galarian)", fm("Mud Shot", "ground", 9, 2), listOf(cm("Rock Slide", "rock", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("chesnaught", "Chesnaught", fm("Vine Whip", "grass", 8, 2), listOf(cm("Superpower", "fighting", 40), cm("Frenzy Plant*", "grass", 45))),
        PvPokeEntry("abomasnow", "Abomasnow", fm("Powder Snow", "ice", 8, 2), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Energy Ball", "grass", 55), cm("Icy Wind", "ice", 45))),
        PvPokeEntry("bastiodon", "Bastiodon", fm("Smack Down", "rock", 8, 3), listOf(cm("Stone Edge", "rock", 55), cm("Flamethrower", "fire", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("probopass", "Probopass", fm("Spark", "electric", 7, 2), listOf(cm("Rock Slide", "rock", 45), cm("Magnet Bomb", "steel", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("cresselia", "Cresselia", fm("Psycho Cut", "psychic", 9, 2), listOf(cm("Grass Knot", "grass", 50), cm("Moonblast", "fairy", 60), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("registeel", "Registeel", fm("Lock On", "normal", 5, 1), listOf(cm("Focus Blast", "fighting", 75), cm("Zap Cannon", "electric", 80), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("regirock", "Regirock", fm("Lock On", "normal", 5, 1), listOf(cm("Stone Edge", "rock", 55), cm("Focus Blast", "fighting", 75), cm("Earthquake", "ground", 65))),
        PvPokeEntry("regice", "Regice", fm("Lock On", "normal", 5, 1), listOf(cm("Blizzard", "ice", 75), cm("Earthquake", "ground", 65), cm("Thunder", "electric", 60))),
        PvPokeEntry("skarmory", "Skarmory", fm("Steel Wing", "steel", 6, 2), listOf(cm("Sky Attack", "flying", 55), cm("Brave Bird", "flying", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("medicham", "Medicham", fm("Counter", "fighting", 6, 2), listOf(cm("Ice Punch", "ice", 40), cm("Dynamic Punch", "fighting", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("sableye", "Sableye", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Foul Play", "dark", 45), cm("Power Gem", "rock", 60), cm("Return", "normal", 70))),
        PvPokeEntry("umbreon", "Umbreon", fm("Snarl", "dark", 13, 3), listOf(cm("Foul Play", "dark", 45), cm("Last Resort*", "normal", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("sylveon", "Sylveon", fm("Charm", "fairy", 6, 3), listOf(cm("Psyshock", "psychic", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("vaporeon", "Vaporeon", fm("Water Gun", "water", 3, 1), listOf(cm("Aqua Tail", "water", 35), cm("Last Resort*", "normal", 55), cm("Scald", "water", 55))),
        PvPokeEntry("jolteon", "Jolteon", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Discharge", "electric", 45), cm("Last Resort*", "normal", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("flareon", "Flareon", fm("Fire Spin", "fire", 10, 3), listOf(cm("Flamethrower", "fire", 55), cm("Superpower", "fighting", 40), cm("Last Resort*", "normal", 55))),
        PvPokeEntry("espeon", "Espeon", fm("Confusion", "psychic", 12, 4), listOf(cm("Psychic Fangs", "psychic", 35), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("leafeon", "Leafeon", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Leaf Blade", "grass", 35), cm("Last Resort*", "normal", 55))),
        PvPokeEntry("glaceon", "Glaceon", fm("Ice Shard", "ice", 10, 3), listOf(cm("Icy Wind", "ice", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("deoxys_defense", "Deoxys (Defense)", fm("Counter", "fighting", 6, 2), listOf(cm("Psycho Boost", "psychic", 35), cm("Rock Slide", "rock", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("lanturn", "Lanturn", fm("Spark", "electric", 7, 2), listOf(cm("Surf", "water", 40), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("swampert", "Swampert", fm("Mud Shot", "ground", 9, 2), listOf(cm("Hydro Cannon*", "water", 40), cm("Earthquake", "ground", 65), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("marshtomp", "Marshtomp", fm("Mud Shot", "ground", 9, 2), listOf(cm("Surf", "water", 40), cm("Mud Bomb", "ground", 40), cm("Sludge", "poison", 40))),
        PvPokeEntry("whiscash", "Whiscash", fm("Mud Shot", "ground", 9, 2), listOf(cm("Mud Bomb", "ground", 40), cm("Scald", "water", 55), cm("Blizzard", "ice", 75))),
        PvPokeEntry("quagsire", "Quagsire", fm("Mud Shot", "ground", 9, 2), listOf(cm("Aqua Tail", "water", 35), cm("Mud Bomb", "ground", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("pelipper", "Pelipper", fm("Wing Attack", "flying", 8, 2), listOf(cm("Weather Ball (Water)", "water", 35), cm("Hurricane", "flying", 65))),
        PvPokeEntry("mantine", "Mantine", fm("Wing Attack", "flying", 8, 2), listOf(cm("Aerial Ace", "flying", 40), cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("altaria", "Altaria", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Sky Attack", "flying", 55), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("pidgeot", "Pidgeot", fm("Wing Attack", "flying", 8, 2), listOf(cm("Feather Dance", "flying", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("noctowl", "Noctowl", fm("Wing Attack", "flying", 8, 2), listOf(cm("Sky Attack", "flying", 55), cm("Shadow Ball", "ghost", 55), cm("Night Shade", "ghost", 55))),
        PvPokeEntry("staraptor", "Staraptor", fm("Wing Attack", "flying", 8, 2), listOf(cm("Fly", "flying", 45), cm("Close Combat", "fighting", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("swellow", "Swellow", fm("Wing Attack", "flying", 8, 2), listOf(cm("Aerial Ace", "flying", 40), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("fearow", "Fearow", fm("Peck", "flying", 5, 2), listOf(cm("Drill Run", "ground", 45), cm("Sky Attack", "flying", 55), cm("Drill Peck", "flying", 40))),
        PvPokeEntry("dodrio", "Dodrio", fm("Peck", "flying", 5, 2), listOf(cm("Drill Peck", "flying", 40), cm("Trailblaze", "grass", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("toucannon", "Toucannon", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Drill Peck", "flying", 40), cm("Rock Blast", "rock", 40))),
        PvPokeEntry("vigoroth", "Vigoroth", fm("Counter", "fighting", 6, 2), listOf(cm("Body Slam", "normal", 35), cm("Rock Slide", "rock", 45), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("slaking", "Slaking", fm("Yawn", "normal", 12, 4), listOf(cm("Body Slam", "normal", 35), cm("Play Rough", "fairy", 60), cm("Earthquake", "ground", 65))),
        PvPokeEntry("obstagoon", "Obstagoon", fm("Counter", "fighting", 6, 2), listOf(cm("Night Slash", "dark", 35), cm("Cross Chop", "fighting", 35), cm("Obstruct", "dark", 40))),
        PvPokeEntry("linoone_galarian", "Linoone (Galarian)", fm("Snarl", "dark", 13, 3), listOf(cm("Body Slam", "normal", 35), cm("Dig", "ground", 50))),
        PvPokeEntry("linoone", "Linoone", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Grass Knot", "grass", 50), cm("Thunder", "electric", 60), cm("Dig", "ground", 50))),
        PvPokeEntry("dubwool", "Dubwool", fm("Double Kick", "fighting", 12, 3), listOf(cm("Body Slam", "normal", 35), cm("Wild Charge", "electric", 45), cm("Payback", "dark", 60))),
        PvPokeEntry("greedent", "Greedent", fm("Mud Shot", "ground", 9, 2), listOf(cm("Body Slam", "normal", 35), cm("Crunch", "dark", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("oinkologne", "Oinkologne", fm("Tackle", "normal", 3, 1), listOf(cm("Body Slam", "normal", 35), cm("Trailblaze", "grass", 45), cm("Dig", "ground", 50))),
        PvPokeEntry("miltank", "Miltank", fm("Rollout", "rock", 13, 3), listOf(cm("Body Slam", "normal", 35), cm("Ice Beam", "ice", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("tauros", "Tauros", fm("Tackle", "normal", 3, 1), listOf(cm("Horn Attack", "normal", 35), cm("Earthquake", "ground", 65), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("tauros_combat", "Tauros (Combat)", fm("Double Kick", "fighting", 12, 3), listOf(cm("Close Combat", "fighting", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("tauros_blaze", "Tauros (Blaze)", fm("Double Kick", "fighting", 12, 3), listOf(cm("Flame Charge", "fire", 50), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("tauros_aqua", "Tauros (Aqua)", fm("Double Kick", "fighting", 12, 3), listOf(cm("Liquidation", "water", 45), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("bouffalant", "Bouffalant", fm("Mud Shot", "ground", 9, 2), listOf(cm("Stomp", "normal", 40), cm("Superpower", "fighting", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("kangaskhan", "Kangaskhan", fm("Mud Slap", "ground", 10, 3), listOf(cm("Power-Up Punch", "fighting", 35), cm("Outrage", "dragon", 60), cm("Crunch", "dark", 45))),
        PvPokeEntry("snorlax", "Snorlax", fm("Lick", "ghost", 3, 1), listOf(cm("Body Slam", "normal", 35), cm("Superpower", "fighting", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("munchlax", "Munchlax", fm("Tackle", "normal", 3, 1), listOf(cm("Body Slam", "normal", 35), cm("Bulldoze", "ground", 60), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("zangoose", "Zangoose", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Night Slash", "dark", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("oranguru", "Oranguru", fm("Confusion", "psychic", 12, 4), listOf(cm("Brutal Swing", "dark", 40), cm("Trailblaze", "grass", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("girafarig", "Girafarig", fm("Double Kick", "fighting", 12, 3), listOf(cm("Psychic Fangs", "psychic", 35), cm("Thunderbolt", "electric", 55), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("farigiraf", "Farigiraf", fm("Double Kick", "fighting", 12, 3), listOf(cm("Foul Play", "dark", 45), cm("Trailblaze", "grass", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("bibarel", "Bibarel", fm("Rollout", "rock", 13, 3), listOf(cm("Surf", "water", 40), cm("Hyper Fang", "normal", 50))),
        PvPokeEntry("raticate_alolan", "Raticate (Alolan)", fm("Quick Attack", "normal", 8, 2), listOf(cm("Crunch", "dark", 45), cm("Return", "normal", 70), cm("Hyper Fang", "normal", 50))),
        PvPokeEntry("furret", "Furret", fm("Sucker Punch", "dark", 7, 2), listOf(cm("Brick Break", "fighting", 40), cm("Trailblaze", "grass", 45), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("castform", "Castform", fm("Hex", "ghost", 11, 3), listOf(cm("Weather Ball (Rock)", "rock", 35), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("castform_sunny", "Castform (Sunny)", fm("Ember", "fire", 7, 2), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("castform_rainy", "Castform (Rainy)", fm("Water Gun", "water", 3, 1), listOf(cm("Weather Ball (Water)", "water", 35), cm("Thunder", "electric", 60))),
        PvPokeEntry("castform_snowy", "Castform (Snowy)", fm("Powder Snow", "ice", 8, 2), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Blizzard", "ice", 75))),
        PvPokeEntry("cherrim_sunny", "Cherrim (Sunny)", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("scrafty", "Scrafty", fm("Counter", "fighting", 6, 2), listOf(cm("Thunder Punch", "electric", 40), cm("Power-Up Punch", "fighting", 35), cm("Foul Play", "dark", 45))),
        PvPokeEntry("pangoro", "Pangoro", fm("Karate Chop", "fighting", 9, 2), listOf(cm("Night Slash", "dark", 35), cm("Close Combat", "fighting", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("guzzlord", "Guzzlord", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Dragon Claw", "dragon", 35), cm("Brutal Swing", "dark", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("zweilous", "Zweilous", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Body Slam", "normal", 35), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("hydreigon", "Hydreigon", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Brutal Swing", "dark", 40), cm("Dragon Pulse", "dragon", 60))),
        PvPokeEntry("goodra", "Goodra", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Aqua Tail", "water", 35), cm("Thunder Punch", "electric", 40), cm("Power Whip", "grass", 50))),
        PvPokeEntry("sliggoo", "Sliggoo", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Aqua Tail", "water", 35), cm("Muddy Water", "water", 35))),
        PvPokeEntry("dragonair", "Dragonair", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Aqua Tail", "water", 35), cm("Body Slam", "normal", 35), cm("Dragon Pulse", "dragon", 60))),
        PvPokeEntry("dragonite", "Dragonite", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Dragon Claw", "dragon", 35), cm("Superpower", "fighting", 40), cm("Hurricane", "flying", 65))),
        PvPokeEntry("hakamo-o", "Hakamo-o", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Dragon Claw", "dragon", 35), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("kommo-o", "Kommo-o", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Dragon Claw", "dragon", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("haxorus", "Haxorus", fm("Counter", "fighting", 6, 2), listOf(cm("Breaking Swipe", "dragon", 35), cm("Night Slash", "dark", 35), cm("Earthquake", "ground", 65))),
        PvPokeEntry("fraxure", "Fraxure", fm("Counter", "fighting", 6, 2), listOf(cm("Aqua Tail", "water", 35), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("flygon", "Flygon", fm("Mud Shot", "ground", 9, 2), listOf(cm("Dragon Claw", "dragon", 35), cm("Scorching Sands", "ground", 50), cm("Boomburst", "normal", 70))),
        PvPokeEntry("vibrava", "Vibrava", fm("Mud Shot", "ground", 9, 2), listOf(cm("Sand Tomb", "ground", 40), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("garchomp", "Garchomp", fm("Mud Shot", "ground", 9, 2), listOf(cm("Sand Tomb", "ground", 40), cm("Outrage", "dragon", 60), cm("Earth Power", "ground", 55))),
        PvPokeEntry("gabite", "Gabite", fm("Mud Shot", "ground", 9, 2), listOf(cm("Sand Tomb", "ground", 40), cm("Twister", "dragon", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("kingdra", "Kingdra", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Octazooka", "water", 50), cm("Outrage", "dragon", 60))),
        PvPokeEntry("dragalge", "Dragalge", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Aqua Tail", "water", 35), cm("Outrage", "dragon", 60), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("turtonator", "Turtonator", fm("Incinerate", "fire", 20, 5), listOf(cm("Dragon Pulse", "dragon", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("drampa", "Drampa", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Fly", "flying", 45), cm("Dragon Pulse", "dragon", 60))),
        PvPokeEntry("baxcalibur", "Baxcalibur", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("arctibax", "Arctibax", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("frigibax", "Frigibax", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("dragapult", "Dragapult", fm("Astonish", "ghost", 10, 3), listOf(cm("Breaking Swipe", "dragon", 35), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("venusaur", "Venusaur", fm("Vine Whip", "grass", 8, 2), listOf(cm("Frenzy Plant*", "grass", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("ivysaur", "Ivysaur", fm("Vine Whip", "grass", 8, 2), listOf(cm("Power Whip", "grass", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("charizard", "Charizard", fm("Wing Attack", "flying", 8, 2), listOf(cm("Dragon Claw", "dragon", 35), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("charmeleon", "Charmeleon", fm("Fire Fang", "fire", 8, 2), listOf(cm("Fire Punch", "fire", 40), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("blastoise", "Blastoise", fm("Rollout", "rock", 13, 3), listOf(cm("Hydro Cannon*", "water", 40), cm("Ice Beam", "ice", 55), cm("Skull Bash", "normal", 75))),
        PvPokeEntry("wartortle", "Wartortle", fm("Water Gun", "water", 3, 1), listOf(cm("Aqua Jet", "water", 45), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("meganium", "Meganium", fm("Vine Whip", "grass", 8, 2), listOf(cm("Frenzy Plant*", "grass", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("bayleef", "Bayleef", fm("Razor Leaf", "grass", 4, 2), listOf(cm("Grass Knot", "grass", 50), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("typhlosion", "Typhlosion", fm("Incinerate", "fire", 20, 5), listOf(cm("Thunder Punch", "electric", 40), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("typhlosion_hisuian", "Typhlosion (Hisuian)", fm("Hex", "ghost", 11, 3), listOf(cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("quilava", "Quilava", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Dig", "ground", 50))),
        PvPokeEntry("croconaw", "Croconaw", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Crunch", "dark", 45), cm("Ice Punch", "ice", 40))),
        PvPokeEntry("sceptile", "Sceptile", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Leaf Blade", "grass", 35), cm("Breaking Swipe", "dragon", 35), cm("Earthquake", "ground", 65))),
        PvPokeEntry("grovyle", "Grovyle", fm("Quick Attack", "normal", 8, 2), listOf(cm("Leaf Blade", "grass", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("blaziken", "Blaziken", fm("Counter", "fighting", 6, 2), listOf(cm("Blaze Kick", "fire", 40), cm("Blast Burn*", "fire", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("combusken", "Combusken", fm("Peck", "flying", 5, 2), listOf(cm("Flame Charge", "fire", 50), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("torterra", "Torterra", fm("Mud Slap", "ground", 10, 3), listOf(cm("Frenzy Plant*", "grass", 45), cm("Sand Tomb", "ground", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("grotle", "Grotle", fm("Bite", "dark", 4, 1), listOf(cm("Body Slam", "normal", 35), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("infernape", "Infernape", fm("Fire Spin", "fire", 10, 3), listOf(cm("Close Combat", "fighting", 45), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("monferno", "Monferno", fm("Ember", "fire", 7, 2), listOf(cm("Flame Wheel", "fire", 55), cm("Low Sweep", "fighting", 40))),
        PvPokeEntry("empoleon", "Empoleon", fm("Steel Wing", "steel", 6, 2), listOf(cm("Hydro Cannon*", "water", 40), cm("Drill Peck", "flying", 40))),
        PvPokeEntry("prinplup", "Prinplup", fm("Metal Claw", "steel", 7, 2), listOf(cm("Bubble Beam", "water", 40), cm("Icy Wind", "ice", 45))),
        PvPokeEntry("servine", "Servine", fm("Vine Whip", "grass", 8, 2), listOf(cm("Grass Knot", "grass", 50), cm("Wrap", "normal", 45))),
        PvPokeEntry("emboar", "Emboar", fm("Ember", "fire", 7, 2), listOf(cm("Blast Burn*", "fire", 50), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("pignite", "Pignite", fm("Tackle", "normal", 3, 1), listOf(cm("Flame Charge", "fire", 50), cm("Rock Tomb", "rock", 60))),
        PvPokeEntry("samurott", "Samurott", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Hydro Cannon*", "water", 40), cm("Megahorn", "bug", 55), cm("Razor Shell", "water", 35))),
        PvPokeEntry("samurott_hisuian", "Samurott (Hisuian)", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Icy Wind", "ice", 45), cm("Dark Pulse", "dark", 50), cm("Razor Shell", "water", 35))),
        PvPokeEntry("dewott", "Dewott", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Aqua Tail", "water", 35), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("quilladin", "Quilladin", fm("Vine Whip", "grass", 8, 2), listOf(cm("Body Slam", "normal", 35), cm("Gyro Ball", "steel", 60))),
        PvPokeEntry("delphox", "Delphox", fm("Fire Spin", "fire", 10, 3), listOf(cm("Mystical Fire", "fire", 45), cm("Blast Burn*", "fire", 50), cm("Psychic", "psychic", 55))),
        PvPokeEntry("braixen", "Braixen", fm("Ember", "fire", 7, 2), listOf(cm("Flame Charge", "fire", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("greninja", "Greninja", fm("Water Shuriken", "water", 14, 3), listOf(cm("Night Slash", "dark", 35), cm("Hydro Cannon*", "water", 40))),
        PvPokeEntry("frogadier", "Frogadier", fm("Bubble", "water", 11, 3), listOf(cm("Surf", "water", 40), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("decidueye", "Decidueye", fm("Astonish", "ghost", 10, 3), listOf(cm("Frenzy Plant*", "grass", 45), cm("Spirit Shackle", "ghost", 40), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("decidueye_hisuian", "Decidueye (Hisuian)", fm("Psycho Cut", "psychic", 9, 2), listOf(cm("Aura Sphere", "fighting", 55), cm("Trailblaze", "grass", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("dartrix", "Dartrix", fm("Peck", "flying", 5, 2), listOf(cm("Seed Bomb", "grass", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("incineroar", "Incineroar", fm("Snarl", "dark", 13, 3), listOf(cm("Blast Burn*", "fire", 50), cm("Darkest Lariat", "dark", 60), cm("Blaze Kick", "fire", 40))),
        PvPokeEntry("torracat", "Torracat", fm("Ember", "fire", 7, 2), listOf(cm("Flame Charge", "fire", 50), cm("Crunch", "dark", 45))),
        PvPokeEntry("primarina", "Primarina", fm("Charm", "fairy", 6, 3), listOf(cm("Hydro Cannon*", "water", 40), cm("Disarming Voice", "fairy", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("brionne", "Brionne", fm("Charm", "fairy", 6, 3), listOf(cm("Aqua Jet", "water", 45), cm("Disarming Voice", "fairy", 45))),
        PvPokeEntry("rillaboom", "Rillaboom", fm("Scratch", "normal", 2, 1), listOf(cm("Grass Knot", "grass", 50), cm("Earth Power", "ground", 55))),
        PvPokeEntry("cinderace", "Cinderace", fm("Tackle", "normal", 3, 1), listOf(cm("Flame Charge", "fire", 50), cm("Flamethrower", "fire", 55), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("inteleon", "Inteleon", fm("Water Gun", "water", 3, 1), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("meowscarada", "Meowscarada", fm("Leafage", "grass", 7, 2), listOf(cm("Night Slash", "dark", 35), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("skeledirge", "Skeledirge", fm("Incinerate", "fire", 20, 5), listOf(cm("Disarming Voice", "fairy", 45), cm("Shadow Ball", "ghost", 55), cm("Torch Song", "fire", 45))),
        PvPokeEntry("crocalor", "Crocalor", fm("Incinerate", "fire", 20, 5), listOf(cm("Disarming Voice", "fairy", 45), cm("Crunch", "dark", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("quaquaval", "Quaquaval", fm("Wing Attack", "flying", 8, 2), listOf(cm("Aqua Jet", "water", 45), cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("victreebel", "Victreebel", fm("Magical Leaf", "grass", 10, 3), listOf(cm("Leaf Blade", "grass", 35), cm("Sludge Bomb", "poison", 50), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("weepinbell", "Weepinbell", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Power Whip", "grass", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("vileplume", "Vileplume", fm("Razor Leaf", "grass", 4, 2), listOf(cm("Sludge Bomb", "poison", 50), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("bellossom", "Bellossom", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Leaf Blade", "grass", 35), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("tropius", "Tropius", fm("Air Slash", "flying", 9, 3), listOf(cm("Leaf Blade", "grass", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("cradily", "Cradily", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Rock Slide", "rock", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("lileep", "Lileep", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Ancient Power", "rock", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("ferrothorn", "Ferrothorn", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Power Whip", "grass", 50), cm("Thunder", "electric", 60), cm("Mirror Shot", "steel", 35))),
        PvPokeEntry("trevenant", "Trevenant", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Seed Bomb", "grass", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("phantump", "Phantump", fm("Astonish", "ghost", 10, 3), listOf(cm("Seed Bomb", "grass", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("gourgeist", "Gourgeist", fm("Hex", "ghost", 11, 3), listOf(cm("Seed Bomb", "grass", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("pumpkaboo", "Pumpkaboo", fm("Astonish", "ghost", 10, 3), listOf(cm("Seed Bomb", "grass", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("lurantis", "Lurantis", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Leaf Blade", "grass", 35), cm("Superpower", "fighting", 40))),
        PvPokeEntry("tsareena", "Tsareena", fm("Magical Leaf", "grass", 10, 3), listOf(cm("Triple Axel", "ice", 45), cm("High Jump Kick", "fighting", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("roserade", "Roserade", fm("Poison Jab", "poison", 7, 2), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Leaf Storm", "grass", 55))),
        PvPokeEntry("shiftry", "Shiftry", fm("Snarl", "dark", 13, 3), listOf(cm("Leaf Blade", "grass", 35), cm("Foul Play", "dark", 45), cm("Hurricane", "flying", 65))),
        PvPokeEntry("cacturne", "Cacturne", fm("Sucker Punch", "dark", 7, 2), listOf(cm("Dynamic Punch", "fighting", 45), cm("Grass Knot", "grass", 50), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("whimsicott", "Whimsicott", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Seed Bomb", "grass", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("cottonee", "Cottonee", fm("Charm", "fairy", 6, 3), listOf(cm("Seed Bomb", "grass", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("amoonguss", "Amoonguss", fm("Astonish", "ghost", 10, 3), listOf(cm("Grass Knot", "grass", 50), cm("Foul Play", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("tangrowth", "Tangrowth", fm("Vine Whip", "grass", 8, 2), listOf(cm("Rock Slide", "rock", 45), cm("Power Whip", "grass", 50))),
        PvPokeEntry("sunflora", "Sunflora", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Leaf Storm", "grass", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("cherrim", "Cherrim", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("wormadam_trash", "wormadam (Trash)", fm("Bug Bite", "bug", 3, 1), listOf(cm("Iron Head", "steel", 50), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("wormadam_plant", "Wormadam (Plant)", fm("Bug Bite", "bug", 3, 1), listOf(cm("Energy Ball", "grass", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("forretress", "Forretress", fm("Volt Switch", "electric", 16, 4), listOf(cm("Mirror Shot", "steel", 35), cm("Earthquake", "ground", 65), cm("Rock Tomb", "rock", 60))),
        PvPokeEntry("scizor", "Scizor", fm("Bullet Punch", "steel", 7, 2), listOf(cm("Night Slash", "dark", 35), cm("Iron Head", "steel", 50), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("scyther", "Scyther", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Night Slash", "dark", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("kleavor", "Kleavor", fm("Quick Attack", "normal", 8, 2), listOf(cm("X-Scissor", "bug", 40), cm("Rock Slide", "rock", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("pinsir", "Pinsir", fm("Fury Cutter", "bug", 4, 1), listOf(cm("X-Scissor", "bug", 40), cm("Close Combat", "fighting", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("heracross", "Heracross", fm("Counter", "fighting", 6, 2), listOf(cm("Rock Blast", "rock", 40), cm("Megahorn", "bug", 55), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("escavalier", "Escavalier", fm("Counter", "fighting", 6, 2), listOf(cm("Drill Run", "ground", 45), cm("Megahorn", "bug", 55), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("shelmet", "Shelmet", fm("Infestation", "bug", 12, 3), listOf(cm("Body Slam", "normal", 35), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("accelgor", "Accelgor", fm("Water Shuriken", "water", 14, 3), listOf(cm("Body Slam", "normal", 35), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("galvantula", "Galvantula", fm("Volt Switch", "electric", 16, 4), listOf(cm("Lunge", "bug", 45), cm("Discharge", "electric", 45), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("ariados", "Ariados", fm("Poison Sting", "poison", 10, 2), listOf(cm("Lunge", "bug", 45), cm("Trailblaze", "grass", 45), cm("Megahorn", "bug", 55))),
        PvPokeEntry("beedrill", "Beedrill", fm("Poison Jab", "poison", 7, 2), listOf(cm("Drill Run", "ground", 45), cm("X-Scissor", "bug", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("venomoth", "Venomoth", fm("Confusion", "psychic", 12, 4), listOf(cm("Poison Fang", "poison", 40), cm("Bug Buzz", "bug", 60), cm("Silver Wind", "bug", 45))),
        PvPokeEntry("ledian", "Ledian", fm("Counter", "fighting", 6, 2), listOf(cm("Dynamic Punch", "fighting", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("yanmega", "Yanmega", fm("Wing Attack", "flying", 8, 2), listOf(cm("Ancient Power", "rock", 45), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("leavanny", "Leavanny", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Leaf Blade", "grass", 35), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("scolipede", "Scolipede", fm("Poison Jab", "poison", 7, 2), listOf(cm("X-Scissor", "bug", 40), cm("Sludge Bomb", "poison", 50), cm("Megahorn", "bug", 55))),
        PvPokeEntry("crustle", "Crustle", fm("Smack Down", "rock", 8, 3), listOf(cm("Rock Slide", "rock", 45), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("durant", "Durant", fm("Metal Claw", "steel", 7, 2), listOf(cm("X-Scissor", "bug", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("genesect", "Genesect", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Techno Blast", "normal", 55), cm("X-Scissor", "bug", 40), cm("Magnet Bomb", "steel", 45))),
        PvPokeEntry("araquanid", "Araquanid", fm("Bug Bite", "bug", 3, 1), listOf(cm("Bubble Beam", "water", 40), cm("Bug Buzz", "bug", 60), cm("Water Pulse", "water", 55))),
        PvPokeEntry("dewpider", "Dewpider", fm("Bug Bite", "bug", 3, 1), listOf(cm("Bubble Beam", "water", 40), cm("Mirror Coat", "psychic", 55))),
        PvPokeEntry("golisopod", "Golisopod", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Liquidation", "water", 45), cm("X-Scissor", "bug", 40), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("charjabug", "Charjabug", fm("Volt Switch", "electric", 16, 4), listOf(cm("X-Scissor", "bug", 40), cm("Discharge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("vikavolt", "Vikavolt", fm("Volt Switch", "electric", 16, 4), listOf(cm("Fly", "flying", 45), cm("Discharge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("ribombee", "Ribombee", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Dazzling Gleam", "fairy", 70), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("lokix", "Lokix", fm("Sucker Punch", "dark", 7, 2), listOf(cm("Trailblaze", "grass", 45), cm("X-Scissor", "bug", 40), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("buzzwole", "Buzzwole", fm("Counter", "fighting", 6, 2), listOf(cm("Lunge", "bug", 45), cm("Superpower", "fighting", 40), cm("Power-Up Punch", "fighting", 35))),
        PvPokeEntry("machamp", "Machamp", fm("Counter", "fighting", 6, 2), listOf(cm("Cross Chop", "fighting", 35), cm("Rock Slide", "rock", 45), cm("Payback", "dark", 60))),
        PvPokeEntry("machoke", "Machoke", fm("Karate Chop", "fighting", 9, 2), listOf(cm("Cross Chop", "fighting", 35), cm("Brick Break", "fighting", 40), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("hariyama", "Hariyama", fm("Force Palm", "fighting", 13, 3), listOf(cm("Dynamic Punch", "fighting", 45), cm("Upper Hand", "fighting", 40), cm("Superpower", "fighting", 40))),
        PvPokeEntry("hitmonchan", "Hitmonchan", fm("Counter", "fighting", 6, 2), listOf(cm("Ice Punch", "ice", 40), cm("Thunder Punch", "electric", 40), cm("Fire Punch", "fire", 40), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("hitmontop", "Hitmontop", fm("Counter", "fighting", 6, 2), listOf(cm("Triple Axel", "ice", 45), cm("Close Combat", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("hitmonlee", "Hitmonlee", fm("Double Kick", "fighting", 12, 3), listOf(cm("Close Combat", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("poliwrath", "Poliwrath", fm("Counter", "fighting", 6, 2), listOf(cm("Icy Wind", "ice", 45), cm("Scald", "water", 55), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("politoed", "Politoed", fm("Mud Shot", "ground", 9, 2), listOf(cm("Weather Ball (Water)", "water", 35), cm("Earthquake", "ground", 65), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("toxicroak", "Toxicroak", fm("Counter", "fighting", 6, 2), listOf(cm("Mud Bomb", "ground", 40), cm("Shadow Ball", "ghost", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("sneasler", "Sneasler", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("sneasel_hisuian", "Sneasel (Hisuian)", fm("Poison Jab", "poison", 7, 2), listOf(cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("sneasel", "Sneasel", fm("Ice Shard", "ice", 10, 3), listOf(cm("Avalanche", "ice", 45), cm("Triple Axel", "ice", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("weavile", "Weavile", fm("Snarl", "dark", 13, 3), listOf(cm("Triple Axel", "ice", 45), cm("Avalanche", "ice", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("sirfetchd", "Sirfetch'd", fm("Counter", "fighting", 6, 2), listOf(cm("Leaf Blade", "grass", 35), cm("Night Slash", "dark", 35), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("lucario", "Lucario", fm("Force Palm", "fighting", 13, 3), listOf(cm("Thunder Punch", "electric", 40), cm("Shadow Ball", "ghost", 55), cm("Power-Up Punch", "fighting", 35))),
        PvPokeEntry("gallade", "Gallade", fm("Psycho Cut", "psychic", 9, 2), listOf(cm("Leaf Blade", "grass", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("gardevoir", "Gardevoir", fm("Charm", "fairy", 6, 3), listOf(cm("Shadow Ball", "ghost", 55), cm("Triple Axel", "ice", 45), cm("Synchronoise", "psychic", 50))),
        PvPokeEntry("conkeldurr", "Conkeldurr", fm("Counter", "fighting", 6, 2), listOf(cm("Brutal Swing", "dark", 40), cm("Dynamic Punch", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("gurdurr", "Gurdurr", fm("Counter", "fighting", 6, 2), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("throh", "Throh", fm("Low Kick", "fighting", 5, 2), listOf(cm("Body Slam", "normal", 35), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("sawk", "Sawk", fm("Poison Jab", "poison", 7, 2), listOf(cm("Body Slam", "normal", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("mienfoo", "Mienfoo", fm("Force Palm", "fighting", 13, 3), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("mienshao", "Mienshao", fm("Force Palm", "fighting", 13, 3), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55), cm("Blaze Kick", "fire", 40))),
        PvPokeEntry("hawlucha", "Hawlucha", fm("Wing Attack", "flying", 8, 2), listOf(cm("Flying Press", "fighting", 40), cm("Sky Attack", "flying", 55), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("bewear", "Bewear", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Superpower", "fighting", 40), cm("Stomp", "normal", 40), cm("Payback", "dark", 60))),
        PvPokeEntry("stufful", "Stufful", fm("Tackle", "normal", 3, 1), listOf(cm("Body Slam", "normal", 35), cm("Superpower", "fighting", 40))),
        PvPokeEntry("passimian", "Passimian", fm("Counter", "fighting", 6, 2), listOf(cm("Brutal Swing", "dark", 40), cm("Close Combat", "fighting", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("falinks", "Falinks", fm("Counter", "fighting", 6, 2), listOf(cm("Superpower", "fighting", 40), cm("Brick Break", "fighting", 40), cm("Megahorn", "bug", 55))),
        PvPokeEntry("pawmot", "Pawmot", fm("Spark", "electric", 7, 2), listOf(cm("Thunder Punch", "electric", 40), cm("Close Combat", "fighting", 45), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("pawmo", "Pawmo", fm("Spark", "electric", 7, 2), listOf(cm("Thunder Punch", "electric", 40), cm("Discharge", "electric", 45))),
        PvPokeEntry("jellicent", "Jellicent", fm("Hex", "ghost", 11, 3), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55), cm("Bubble Beam", "water", 40))),
        PvPokeEntry("frillish", "Frillish", fm("Hex", "ghost", 11, 3), listOf(cm("Ominous Wind", "ghost", 45), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("gengar", "Gengar", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Shadow Punch", "ghost", 35), cm("Sludge Bomb", "poison", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("haunter", "Haunter", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Shadow Punch", "ghost", 35), cm("Sludge Bomb", "poison", 50), cm("Ice Punch", "ice", 40))),
        PvPokeEntry("drifblim", "Drifblim", fm("Astonish", "ghost", 10, 3), listOf(cm("Icy Wind", "ice", 45), cm("Mystical Fire", "fire", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("froslass", "Froslass", fm("Powder Snow", "ice", 8, 2), listOf(cm("Avalanche", "ice", 45), cm("Triple Axel", "ice", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("spiritomb", "Spiritomb", fm("Sucker Punch", "dark", 7, 2), listOf(cm("Rock Tomb", "rock", 60), cm("Shadow Ball", "ghost", 55), cm("Ominous Wind", "ghost", 45))),
        PvPokeEntry("dusknoir", "Dusknoir", fm("Astonish", "ghost", 10, 3), listOf(cm("Shadow Punch", "ghost", 35), cm("Dynamic Punch", "fighting", 45), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("dusclops", "Dusclops", fm("Hex", "ghost", 11, 3), listOf(cm("Ice Punch", "ice", 40), cm("Shadow Punch", "ghost", 35), cm("Poltergeist", "ghost", 75))),
        PvPokeEntry("banette", "Banette", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Shadow Ball", "ghost", 55), cm("Thunder", "electric", 60), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("mismagius", "Mismagius", fm("Hex", "ghost", 11, 3), listOf(cm("Shadow Ball", "ghost", 55), cm("Mystical Fire", "fire", 45), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("misdreavus", "Misdreavus", fm("Hex", "ghost", 11, 3), listOf(cm("Ominous Wind", "ghost", 45), cm("Shadow Sneak", "ghost", 45))),
        PvPokeEntry("cofagrigus", "Cofagrigus", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50), cm("Psychic", "psychic", 55))),
        PvPokeEntry("runerigus", "Runerigus", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Brutal Swing", "dark", 40), cm("Sand Tomb", "ground", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("chandelure", "Chandelure", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55), cm("Overheat", "fire", 55))),
        PvPokeEntry("lampent", "Lampent", fm("Astonish", "ghost", 10, 3), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("golurk", "Golurk", fm("Mud Slap", "ground", 10, 3), listOf(cm("Shadow Punch", "ghost", 35), cm("Earth Power", "ground", 55), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("golett", "Golett", fm("Mud Slap", "ground", 10, 3), listOf(cm("Shadow Punch", "ghost", 35), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("aegislash", "Aegislash", fm("Psycho Cut", "psychic", 9, 2), listOf(cm("Shadow Ball", "ghost", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("palossand", "Palossand", fm("Mud Shot", "ground", 9, 2), listOf(cm("Scorching Sands", "ground", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("mimikyu", "Mimikyu", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Play Rough", "fairy", 60), cm("Shadow Sneak", "ghost", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("gholdengo", "Gholdengo", fm("Hex", "ghost", 11, 3), listOf(cm("Shadow Ball", "ghost", 55), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("houndstone", "Houndstone", fm("Lick", "ghost", 3, 1), listOf(cm("Psychic Fangs", "psychic", 35), cm("Shadow Ball", "ghost", 55), cm("Dig", "ground", 50))),
        PvPokeEntry("ceruledge", "Ceruledge", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("armarouge", "Armarouge", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("hypno", "Hypno", fm("Confusion", "psychic", 12, 4), listOf(cm("Thunder Punch", "electric", 40), cm("Ice Punch", "ice", 40), cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("alakazam", "Alakazam", fm("Counter", "fighting", 6, 2), listOf(cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowbro", "Slowbro", fm("Confusion", "psychic", 12, 4), listOf(cm("Surf", "water", 40), cm("Ice Beam", "ice", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowbro_galarian", "Slowbro (Galarian)", fm("Poison Jab", "poison", 7, 2), listOf(cm("Brutal Swing", "dark", 40), cm("Surf", "water", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("slowking", "Slowking", fm("Confusion", "psychic", 12, 4), listOf(cm("Surf", "water", 40), cm("Blizzard", "ice", 75), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowking_galarian", "Slowking (Galarian)", fm("Hex", "ghost", 11, 3), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("starmie", "Starmie", fm("Quick Attack", "normal", 8, 2), listOf(cm("Surf", "water", 40), cm("Psybeam", "psychic", 60), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("mr._mime", "Mr. Mime", fm("Confusion", "psychic", 12, 4), listOf(cm("Psybeam", "psychic", 60), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("mr._rime", "Mr. Rime", fm("Powder Snow", "ice", 8, 2), listOf(cm("Icy Wind", "ice", 45), cm("Triple Axel", "ice", 45), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("xatu", "Xatu", fm("Feint Attack", "dark", 6, 2), listOf(cm("Aerial Ace", "flying", 40), cm("Ominous Wind", "ghost", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("wobbuffet", "Wobbuffet", fm("Counter", "fighting", 6, 2), listOf(cm("Mirror Coat", "psychic", 55), cm("Return", "normal", 70))),
        PvPokeEntry("grumpig", "Grumpig", fm("Psywave", "psychic", 4, 1), listOf(cm("Dynamic Punch", "fighting", 45), cm("Shadow Ball", "ghost", 55), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("spoink", "Spoink", fm("Splash", "water", 12, 4), listOf(cm("Mirror Coat", "psychic", 55), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("claydol", "Claydol", fm("Mud Slap", "ground", 10, 3), listOf(cm("Scorching Sands", "ground", 50), cm("Ice Beam", "ice", 55), cm("Rock Tomb", "rock", 60), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("bronzong", "Bronzong", fm("Confusion", "psychic", 12, 4), listOf(cm("Psyshock", "psychic", 45), cm("Payback", "dark", 60), cm("Bulldoze", "ground", 60))),
        PvPokeEntry("bronzor", "Bronzor", fm("Tackle", "normal", 3, 1), listOf(cm("Psyshock", "psychic", 45), cm("Payback", "dark", 60), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("chimecho", "Chimecho", fm("Astonish", "ghost", 10, 3), listOf(cm("Psyshock", "psychic", 45), cm("Shadow Ball", "ghost", 55), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("jirachi", "Jirachi", fm("Confusion", "psychic", 12, 4), listOf(cm("Doom Desire", "steel", 40), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("victini", "Victini", fm("Quick Attack", "normal", 8, 2), listOf(cm("V-create", "fire", 40), cm("Psyshock", "psychic", 45), cm("Overheat", "fire", 55))),
        PvPokeEntry("mew", "Mew", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Surf", "water", 40), cm("Wild Charge", "electric", 45), cm("Psyshock", "psychic", 45), cm("Flame Charge", "fire", 50))),
        PvPokeEntry("celebi", "Celebi", fm("Confusion", "psychic", 12, 4), listOf(cm("Seed Bomb", "grass", 45), cm("Leaf Storm", "grass", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("gothorita", "Gothorita", fm("Confusion", "psychic", 12, 4), listOf(cm("Psyshock", "psychic", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("gothitelle", "Gothitelle", fm("Confusion", "psychic", 12, 4), listOf(cm("Rock Slide", "rock", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("reuniclus", "Reuniclus", fm("Hidden Power", "normal", 8, 3), listOf(cm("Shadow Ball", "ghost", 55), cm("Thunder", "electric", 60))),
        PvPokeEntry("beheeyem", "Beheeyem", fm("Astonish", "ghost", 10, 3), listOf(cm("Psychic", "psychic", 55), cm("Rock Slide", "rock", 45), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("meowstic", "Meowstic", fm("Sucker Punch", "dark", 7, 2), listOf(cm("Psyshock", "psychic", 45), cm("Energy Ball", "grass", 55), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("hatterene", "Hatterene", fm("Charm", "fairy", 6, 3), listOf(cm("Psyshock", "psychic", 45), cm("Power Whip", "grass", 50))),
        PvPokeEntry("rapidash_galarian", "Rapidash (Galarian)", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Body Slam", "normal", 35), cm("Play Rough", "fairy", 60), cm("Megahorn", "bug", 55))),
        PvPokeEntry("rapidash", "Rapidash", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Drill Run", "ground", 45), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("granbull", "Granbull", fm("Charm", "fairy", 6, 3), listOf(cm("Crunch", "dark", 45), cm("Close Combat", "fighting", 45), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("snubbull", "Snubbull", fm("Bite", "dark", 4, 1), listOf(cm("Crunch", "dark", 45), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("togetic", "Togetic", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Aerial Ace", "flying", 40), cm("Ancient Power", "rock", 45), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("togekiss", "Togekiss", fm("Charm", "fairy", 6, 3), listOf(cm("Ancient Power", "rock", 45), cm("Aura Sphere", "fighting", 55), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("mawile", "Mawile", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Fire Fang", "normal", 45), cm("Power-Up Punch", "fighting", 35), cm("Play Rough", "fairy", 60), cm("Iron Head", "steel", 50))),
        PvPokeEntry("slurpuff", "Slurpuff", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Flamethrower", "fire", 55), cm("Play Rough", "fairy", 60), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("aromatisse", "Aromatisse", fm("Charm", "fairy", 6, 3), listOf(cm("Psychic", "psychic", 55), cm("Thunderbolt", "electric", 55), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("florges", "Florges", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Disarming Voice", "fairy", 45), cm("Trailblaze", "grass", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("floette", "Floette", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Brick Break", "fighting", 40), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("dedenne", "Dedenne", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Discharge", "electric", 45), cm("Play Rough", "fairy", 60), cm("Parabolic Charge", "electric", 55))),
        PvPokeEntry("klefki", "Klefki", fm("Astonish", "ghost", 10, 3), listOf(cm("Foul Play", "dark", 45), cm("Play Rough", "fairy", 60), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("shiinotic", "Shiinotic", fm("Astonish", "ghost", 10, 3), listOf(cm("Seed Bomb", "grass", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("tapu_fini", "Tapu Fini", fm("Water Gun", "water", 3, 1), listOf(cm("Surf", "water", 40), cm("Nature's Madness", "fairy", 50), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("tinkaton", "Tinkaton", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Play Rough", "fairy", 60), cm("Heavy Slam", "steel", 50), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("grimmsnarl", "Grimmsnarl", fm("Sucker Punch", "dark", 7, 2), listOf(cm("Foul Play", "dark", 45), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("ampharos", "Ampharos", fm("Volt Switch", "electric", 16, 4), listOf(cm("Brutal Swing", "dark", 40), cm("Trailblaze", "grass", 45), cm("Thunder Punch", "electric", 40), cm("Zap Cannon", "electric", 80))),
        PvPokeEntry("raichu", "Raichu", fm("Volt Switch", "electric", 16, 4), listOf(cm("Brick Break", "fighting", 40), cm("Trailblaze", "grass", 45), cm("Wild Charge", "electric", 45), cm("Thunder Punch", "electric", 40))),
        PvPokeEntry("raichu_alolan", "Raichu (Alolan)", fm("Volt Switch", "electric", 16, 4), listOf(cm("Thunder Punch", "electric", 40), cm("Trailblaze", "grass", 45), cm("Wild Charge", "electric", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("pikachu", "Pikachu", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Fly", "flying", 45), cm("Wild Charge", "electric", 45), cm("Surf", "water", 40))),
        PvPokeEntry("magneton", "Magneton", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Magnet Bomb", "steel", 45), cm("Discharge", "electric", 45), cm("Zap Cannon", "electric", 80))),
        PvPokeEntry("magnezone", "Magnezone", fm("Volt Switch", "electric", 16, 4), listOf(cm("Mirror Shot", "steel", 35), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("electrode", "Electrode", fm("Volt Switch", "electric", 16, 4), listOf(cm("Discharge", "electric", 45), cm("Foul Play", "dark", 45), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("electrode_hisuian", "Electrode (Hisuian)", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Energy Ball", "grass", 55), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("electabuzz", "Electabuzz", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Thunder Punch", "electric", 40), cm("Flamethrower", "fire", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("electivire", "Electivire", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Ice Punch", "ice", 40), cm("Wild Charge", "electric", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("luxray", "Luxray", fm("Spark", "electric", 7, 2), listOf(cm("Psychic Fangs", "psychic", 35), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("pachirisu", "Pachirisu", fm("Volt Switch", "electric", 16, 4), listOf(cm("Thunder Punch", "electric", 40), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("emolga", "Emolga", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Acrobatics", "flying", 60), cm("Discharge", "electric", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("eelektross", "Eelektross", fm("Volt Switch", "electric", 16, 4), listOf(cm("Dragon Claw", "dragon", 35), cm("Liquidation", "water", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("heliolisk", "Heliolisk", fm("Mud Slap", "ground", 10, 3), listOf(cm("Breaking Swipe", "dragon", 35), cm("Grass Knot", "grass", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("togedemaru", "Togedemaru", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Fell Stinger", "bug", 35), cm("Wild Charge", "electric", 45), cm("Gyro Ball", "steel", 60))),
        PvPokeEntry("bellibolt", "Bellibolt", fm("Thunder Shock", "electric", 9, 2), listOf(cm("Discharge", "electric", 45), cm("Zap Cannon", "electric", 80), cm("Water Pulse", "water", 55))),
        PvPokeEntry("lapras", "Lapras", fm("Ice Shard", "ice", 10, 3), listOf(cm("Surf", "water", 40), cm("Ice Beam", "ice", 55), cm("Skull Bash", "normal", 75))),
        PvPokeEntry("sealeo", "Sealeo", fm("Powder Snow", "ice", 8, 2), listOf(cm("Body Slam", "normal", 35), cm("Aurora Beam", "ice", 60))),
        PvPokeEntry("walrein", "Walrein", fm("Powder Snow", "ice", 8, 2), listOf(cm("Icicle Spear", "ice", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("cloyster", "Cloyster", fm("Ice Shard", "ice", 10, 3), listOf(cm("Icy Wind", "ice", 45), cm("Liquidation", "water", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("seaking", "Seaking", fm("Poison Jab", "poison", 7, 2), listOf(cm("Icy Wind", "ice", 45), cm("Drill Run", "ground", 45))),
        PvPokeEntry("gyarados", "Gyarados", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45))),
        PvPokeEntry("kingler", "Kingler", fm("Mud Shot", "ground", 9, 2), listOf(cm("X-Scissor", "bug", 40), cm("Crabhammer", "water", 50), cm("Razor Shell", "water", 35))),
        PvPokeEntry("crawdaunt", "Crawdaunt", fm("Snarl", "dark", 13, 3), listOf(cm("Night Slash", "dark", 35), cm("Crabhammer", "water", 50))),
        PvPokeEntry("sharpedo", "Sharpedo", fm("Waterfall", "water", 8, 3), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("tentacruel", "Tentacruel", fm("Poison Jab", "poison", 7, 2), listOf(cm("Scald", "water", 55), cm("Acid Spray", "poison", 45), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("golduck", "golduck", fm("Confusion", "psychic", 12, 4), listOf(cm("Cross Chop", "fighting", 35), cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("ludicolo", "Ludicolo", fm("Bubble", "water", 11, 3), listOf(cm("Ice Beam", "ice", 55), cm("Leaf Storm", "grass", 55), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("lombre", "Lombre", fm("Bubble", "water", 11, 3), listOf(cm("Ice Beam", "ice", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("seismitoad", "Seismitoad", fm("Mud Shot", "ground", 9, 2), listOf(cm("Muddy Water", "water", 35), cm("Earth Power", "ground", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("palpitoad", "Palpitoad", fm("Mud Shot", "ground", 9, 2), listOf(cm("Mud Bomb", "ground", 40), cm("Earth Power", "ground", 55))),
        PvPokeEntry("carracosta", "Carracosta", fm("Rock Throw", "rock", 5, 2), listOf(cm("Body Slam", "normal", 35), cm("Surf", "water", 40), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("swanna", "Swanna", fm("Wing Attack", "flying", 8, 2), listOf(cm("Bubble Beam", "water", 40), cm("Fly", "flying", 45), cm("Hurricane", "flying", 65))),
        PvPokeEntry("alomomola", "Alomomola", fm("Waterfall", "water", 8, 3), listOf(cm("Psychic", "psychic", 55), cm("Blizzard", "ice", 75))),
        PvPokeEntry("barbaracle", "Barbaracle", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Cross Chop", "fighting", 35), cm("Stone Edge", "rock", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("bruxish", "Bruxish", fm("Confusion", "psychic", 12, 4), listOf(cm("Psychic Fangs", "psychic", 35), cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45))),
        PvPokeEntry("dondozo", "Dondozo", fm("Waterfall", "water", 8, 3), listOf(cm("Body Slam", "normal", 35), cm("Liquidation", "water", 45), cm("Outrage", "dragon", 60))),
        PvPokeEntry("basculegion", "Basculegion", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Aqua Jet", "water", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("gligar", "Gligar", fm("Wing Attack", "flying", 8, 2), listOf(cm("Aerial Ace", "flying", 40), cm("Dig", "ground", 50), cm("Night Slash", "dark", 35))),
        PvPokeEntry("gliscor", "Gliscor", fm("Wing Attack", "flying", 8, 2), listOf(cm("Night Slash", "dark", 35), cm("Earthquake", "ground", 65), cm("Sand Tomb", "ground", 40))),
        PvPokeEntry("steelix", "Steelix", fm("Thunder Fang", "electric", 5, 2), listOf(cm("Psychic Fangs", "psychic", 35), cm("Breaking Swipe", "dragon", 35), cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("onix", "Onix", fm("Rock Throw", "rock", 5, 2), listOf(cm("Sand Tomb", "ground", 40), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("donphan", "Donphan", fm("Mud Slap", "ground", 10, 3), listOf(cm("Body Slam", "normal", 35), cm("Trailblaze", "grass", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("hippowdon", "Hippowdon", fm("Sand Attack", "ground", 4, 1), listOf(cm("Weather Ball (Rock)", "rock", 35), cm("Scorching Sands", "ground", 50), cm("Body Slam", "normal", 35))),
        PvPokeEntry("rhydon", "Rhydon", fm("Mud Slap", "ground", 10, 3), listOf(cm("Breaking Swipe", "dragon", 35), cm("Surf", "water", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("rhyperior", "Rhyperior", fm("Mud Slap", "ground", 10, 3), listOf(cm("Breaking Swipe", "dragon", 35), cm("Surf", "water", 40), cm("Rock Wrecker*", "rock", 50))),
        PvPokeEntry("excadrill", "Excadrill", fm("Mud Shot", "ground", 9, 2), listOf(cm("Drill Run", "ground", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("krookodile", "Krookodile", fm("Mud Slap", "ground", 10, 3), listOf(cm("Brick Break", "fighting", 40), cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("mamoswine", "Mamoswine", fm("Powder Snow", "ice", 8, 2), listOf(cm("Avalanche", "ice", 45), cm("High Horsepower", "ground", 60))),
        PvPokeEntry("piloswine", "Piloswine", fm("Powder Snow", "ice", 8, 2), listOf(cm("Avalanche", "ice", 45), cm("High Horsepower", "ground", 60), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("swinub", "Swinub", fm("Powder Snow", "ice", 8, 2), listOf(cm("Icy Wind", "ice", 45), cm("Body Slam", "normal", 35))),
        PvPokeEntry("avalugg", "Avalugg", fm("Ice Fang", "ice", 6, 2), listOf(cm("Body Slam", "normal", 35), cm("Icy Wind", "ice", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("avalugg_hisuian", "Avalugg (Hisuian)", fm("Powder Snow", "ice", 8, 2), listOf(cm("Icy Wind", "ice", 45), cm("Rock Slide", "rock", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("aurorus", "Aurorus", fm("Powder Snow", "ice", 8, 2), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Meteor Beam", "rock", 60), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("amaura", "Amaura", fm("Powder Snow", "ice", 8, 2), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("beartic", "Beartic", fm("Powder Snow", "ice", 8, 2), listOf(cm("Ice Punch", "ice", 40), cm("Surf", "water", 40))),
        PvPokeEntry("cryogonal", "Cryogonal", fm("Ice Shard", "ice", 10, 3), listOf(cm("Triple Axel", "ice", 45), cm("Night Slash", "dark", 35), cm("Water Pulse", "water", 55))),
        PvPokeEntry("cetitan", "Cetitan", fm("Powder Snow", "ice", 8, 2), listOf(cm("Body Slam", "normal", 35), cm("Avalanche", "ice", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("golem", "Golem", fm("Mud Slap", "ground", 10, 3), listOf(cm("Rock Blast", "rock", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("golem_alolan", "Golem (Alolan)", fm("Volt Switch", "electric", 16, 4), listOf(cm("Rock Blast", "rock", 40), cm("Wild Charge", "electric", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("graveler_alolan", "Graveler (Alolan)", fm("Volt Switch", "electric", 16, 4), listOf(cm("Rock Blast", "rock", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("sudowoodo", "Sudowoodo", fm("Counter", "fighting", 6, 2), listOf(cm("Rock Slide", "rock", 45), cm("Trailblaze", "grass", 45), cm("Meteor Beam", "rock", 60))),
        PvPokeEntry("magcargo", "Magcargo", fm("Incinerate", "fire", 20, 5), listOf(cm("Rock Tomb", "rock", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("lairon", "laIron", fm("Metal Claw", "steel", 7, 2), listOf(cm("Body Slam", "normal", 35), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("aggron", "Aggron", fm("Smack Down", "rock", 8, 3), listOf(cm("Heavy Slam", "steel", 50), cm("Meteor Beam", "rock", 60), cm("Thunder", "electric", 60))),
        PvPokeEntry("rampardos", "Rampardos", fm("Smack Down", "rock", 8, 3), listOf(cm("Rock Slide", "rock", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("archeops", "Archeops", fm("Wing Attack", "flying", 8, 2), listOf(cm("Dragon Claw", "dragon", 35), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("gigalith", "Gigalith", fm("Smack Down", "rock", 8, 3), listOf(cm("Superpower", "fighting", 40), cm("Meteor Beam", "rock", 60), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("tyrantrum", "Tyrantrum", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Crunch", "dark", 45), cm("Meteor Beam", "rock", 60))),
        PvPokeEntry("lycanroc_midnight", "Lycanroc (Midnight)", fm("Counter", "fighting", 6, 2), listOf(cm("Psychic Fangs", "psychic", 35), cm("Crunch", "dark", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("garganacl", "Garganacl", fm("Smack Down", "rock", 8, 3), listOf(cm("Rock Slide", "rock", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("nidoqueen", "Nidoqueen", fm("Poison Jab", "poison", 7, 2), listOf(cm("Poison Fang", "poison", 40), cm("Earth Power", "ground", 55), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("nidoking", "Nidoking", fm("Double Kick", "fighting", 12, 3), listOf(cm("Sand Tomb", "ground", 40), cm("Earth Power", "ground", 55), cm("Megahorn", "bug", 55))),
        PvPokeEntry("nidorina", "Nidorina", fm("Poison Sting", "poison", 10, 2), listOf(cm("Poison Fang", "poison", 40), cm("Dig", "ground", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("golbat", "Golbat", fm("Wing Attack", "flying", 8, 2), listOf(cm("Poison Fang", "poison", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("crobat", "Crobat", fm("Air Slash", "flying", 9, 3), listOf(cm("Poison Fang", "poison", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("muk", "Muk", fm("Poison Jab", "poison", 7, 2), listOf(cm("Thunder Punch", "electric", 40), cm("Dark Pulse", "dark", 50), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("muk_alolan", "Muk (Alolan)", fm("Poison Jab", "poison", 7, 2), listOf(cm("Acid Spray", "poison", 45), cm("Dark Pulse", "dark", 50), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("grimer_alolan", "Grimer (Alolan)", fm("Poison Jab", "poison", 7, 2), listOf(cm("Crunch", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("weezing", "Weezing", fm("Tackle", "normal", 3, 1), listOf(cm("Sludge Bomb", "poison", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("weezing_galarian", "Weezing (Galarian)", fm("Fairy Wind", "fairy", 9, 2), listOf(cm("Brutal Swing", "dark", 40), cm("Sludge", "poison", 40), cm("Overheat", "fire", 55), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("swalot", "Swalot", fm("Mud Shot", "ground", 9, 2), listOf(cm("Ice Beam", "ice", 55), cm("Sludge Bomb", "poison", 50), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("seviper", "Seviper", fm("Poison Jab", "poison", 7, 2), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("arbok", "Arbok", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Acid Spray", "poison", 45), cm("Dark Pulse", "dark", 50), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("garbodor", "Garbodor", fm("Infestation", "bug", 12, 3), listOf(cm("Body Slam", "normal", 35), cm("Seed Bomb", "grass", 45), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("salazzle", "Salazzle", fm("Incinerate", "fire", 20, 5), listOf(cm("Poison Fang", "poison", 40), cm("Dragon Pulse", "dragon", 60), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("grafaiai", "Grafaiai", fm("Poison Jab", "poison", 7, 2), listOf(cm("Acrobatics", "flying", 60), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("revavroom", "Revavroom", fm("Poison Jab", "poison", 7, 2), listOf(cm("Acid Spray", "poison", 45), cm("Gyro Ball", "steel", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("bisharp", "Bisharp", fm("Snarl", "dark", 13, 3), listOf(cm("Dark Pulse", "dark", 50), cm("Iron Head", "steel", 50), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("kingambit", "Kingambit", fm("Snarl", "dark", 13, 3), listOf(cm("Dark Pulse", "dark", 50), cm("Iron Head", "steel", 50), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("pawniard", "Pawniard", fm("Fury Cutter", "bug", 4, 1), listOf(cm("Night Slash", "dark", 35), cm("Iron Head", "steel", 50))),
        PvPokeEntry("perrserker", "Perrserker", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Close Combat", "fighting", 45), cm("Foul Play", "dark", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("torkoal", "Torkoal", fm("Fire Spin", "fire", 10, 3), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Earthquake", "ground", 65), cm("Overheat", "fire", 55))),
        PvPokeEntry("magmortar", "Magmortar", fm("Karate Chop", "fighting", 9, 2), listOf(cm("Fire Punch", "fire", 40), cm("Thunderbolt", "electric", 55), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("magmar", "Magmar", fm("Karate Chop", "fighting", 9, 2), listOf(cm("Fire Punch", "fire", 40), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("arcanine", "Arcanine", fm("Thunder Fang", "electric", 5, 2), listOf(cm("Psychic Fangs", "psychic", 35), cm("Scorching Sands", "ground", 50), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("arcanine_hisuian", "Arcanine (Hisuian)", fm("Snarl", "dark", 13, 3), listOf(cm("Rock Slide", "rock", 45), cm("Wild Charge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("houndoom", "Houndoom", fm("Snarl", "dark", 13, 3), listOf(cm("Foul Play", "dark", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("pyroar", "Pyroar", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Dark Pulse", "dark", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("camerupt", "Camerupt", fm("Incinerate", "fire", 20, 5), listOf(cm("Earth Power", "ground", 55), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("centiskorch", "Centiskorch", fm("Bug Bite", "bug", 3, 1), listOf(cm("Lunge", "bug", 45), cm("Crunch", "dark", 45), cm("Heat Wave", "fire", 75))),
        PvPokeEntry("volcarona", "Volcarona", fm("Incinerate", "fire", 20, 5), listOf(cm("Flame Charge", "fire", 50), cm("Bug Buzz", "bug", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("entei", "Entei", fm("Fire Spin", "fire", 10, 3), listOf(cm("Flame Charge", "fire", 50), cm("Scorching Sands", "ground", 50), cm("Iron Head", "steel", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("raikou", "Raikou", fm("Volt Switch", "electric", 16, 4), listOf(cm("Wild Charge", "electric", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("suicune", "Suicune", fm("Snarl", "dark", 13, 3), listOf(cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55), cm("Scald", "water", 55))),
        PvPokeEntry("lugia", "Lugia", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Sky Attack", "flying", 55), cm("Aeroblast", "flying", 75))),
        PvPokeEntry("ho-oh", "Ho-Oh", fm("Incinerate", "fire", 20, 5), listOf(cm("Sacred Fire", "fire", 65), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("mewtwo", "Mewtwo", fm("Psycho Cut", "psychic", 9, 2), listOf(cm("Psystrike*", "psychic", 45), cm("Shadow Ball", "ghost", 55), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("kyogre", "Kyogre", fm("Waterfall", "water", 8, 3), listOf(cm("Surf", "water", 40), cm("Origin Pulse", "water", 60))),
        PvPokeEntry("groudon", "Groudon", fm("Mud Shot", "ground", 9, 2), listOf(cm("Fire Punch", "fire", 40), cm("Precipice Blades", "ground", 60))),
        PvPokeEntry("rayquaza", "Rayquaza", fm("Dragon Tail", "dragon", 9, 3), listOf(cm("Breaking Swipe", "dragon", 35), cm("Dragon Ascent", "flying", 70))),
        PvPokeEntry("dialga", "Dialga", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Iron Head", "steel", 50), cm("Draco Meteor", "dragon", 65))),
        PvPokeEntry("palkia", "Palkia", fm("Dragon Breath", "dragon", 3, 1), listOf(cm("Aqua Tail", "water", 35), cm("Spacial Rend", "dragon", 50))),
        PvPokeEntry("giratina", "Giratina", fm("Shadow Claw", "ghost", 8, 2), listOf(cm("Dragon Claw", "dragon", 35), cm("Shadow Sneak", "ghost", 45))),
        PvPokeEntry("tapu_koko", "Tapu Koko", fm("Volt Switch", "electric", 16, 4), listOf(cm("Nature's Madness", "fairy", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("tapu_lele", "Tapu Lele", fm("Astonish", "ghost", 10, 3), listOf(cm("Nature's Madness", "fairy", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("tapu_bulu", "Tapu Bulu", fm("Bullet Seed", "grass", 13, 3), listOf(cm("Nature's Madness", "fairy", 50), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("kartana", "Kartana", fm("Razor Leaf", "grass", 4, 2), listOf(cm("Leaf Blade", "grass", 35), cm("Night Slash", "dark", 35))),
        PvPokeEntry("celesteela", "Celesteela", fm("Air Slash", "flying", 9, 3), listOf(cm("Body Slam", "normal", 35), cm("Heavy Slam", "steel", 50), cm("Bulldoze", "ground", 60))),
        PvPokeEntry("nihilego", "Nihilego", fm("Poison Jab", "poison", 7, 2), listOf(cm("Rock Slide", "rock", 45), cm("Sludge Bomb", "poison", 50)))
    )

    // Dynamic map populated with BUILT_IN_POKEMON + all 1,000+ Great League entries synced from PvPoke gamemaster.json
    @Volatile
    var allPokemonList: List<PvPokeEntry> = BUILT_IN_POKEMON
        private set

    fun syncFullPvPokeGreatLeagueData(context: Context, onSynced: ((Int) -> Unit)? = null) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cacheFile = File(context.filesDir, "pvpoke_gl_cache.json")
                val gmUrl = "https://raw.githubusercontent.com/pvpoke/pvpoke/master/src/data/gamemaster.json"
                val rkUrl = "https://raw.githubusercontent.com/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-1500.json"

                val gmText = fetchUrl(gmUrl)
                val rkText = fetchUrl(rkUrl)
                if (gmText != null) {
                    val parsed = parseGamemasterAndRankings(gmText, rkText)
                    if (parsed.isNotEmpty()) {
                        val mergedMap = linkedMapOf<String, PvPokeEntry>()
                        // Keep built-in first, then add all remaining Great League & Gamemaster species
                        for (p in BUILT_IN_POKEMON) mergedMap[p.name.lowercase()] = p
                        for (p in parsed) {
                            val key = p.name.lowercase()
                            if (!mergedMap.containsKey(key)) {
                                mergedMap[key] = p
                            }
                        }
                        allPokemonList = mergedMap.values.toList()
                        cacheFile.writeText(gmText)
                        onSynced?.invoke(allPokemonList.size)
                        return@launch
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun fetchUrl(urlStr: String): String? {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            requestMethod = "GET"
        }
        return if (conn.responseCode == 200) {
            conn.inputStream.bufferedReader().use { it.readText() }
        } else null
    }

    private fun parseGamemasterAndRankings(gmJsonStr: String, rkJsonStr: String?): List<PvPokeEntry> {
        val root = JSONObject(gmJsonStr)
        val movesArr = root.optJSONArray("moves") ?: return emptyList()
        val fastMap = mutableMapOf<String, FastMove>()
        val chargedMap = mutableMapOf<String, ChargedMove>()

        for (i in 0 until movesArr.length()) {
            val m = movesArr.getJSONObject(i)
            val moveId = m.optString("moveId")
            val name = m.optString("name", moveId)
            val type = m.optString("type", "normal")
            val energyGain = m.optInt("energyGain", 0)
            val energyCost = m.optInt("energy", 0)
            val turns = max(1, m.optInt("turns", 500) / 500)
            if (energyGain > 0) {
                fastMap[moveId] = FastMove(name, type, energyGain, turns)
            } else if (energyCost > 0) {
                chargedMap[moveId] = ChargedMove(name, type, energyCost)
            }
        }

        // Map recommended movesets from PvPoke Great League rankings-1500.json if available
        val recMovesMap = mutableMapOf<String, List<String>>()
        if (!rkJsonStr.isNullOrBlank()) {
            try {
                val rkArr = JSONArray(rkJsonStr)
                for (i in 0 until rkArr.length()) {
                    val obj = rkArr.getJSONObject(i)
                    val sid = obj.optString("speciesId")
                    val mArr = obj.optJSONObject("moveset") ?: obj.optJSONArray("moveset")
                    if (mArr is JSONArray && mArr.length() >= 2) {
                        val list = mutableListOf<String>()
                        for (j in 0 until mArr.length()) list.add(mArr.getString(j))
                        recMovesMap[sid] = list
                    }
                }
            } catch (_: Exception) {}
        }

        val pokeArr = root.optJSONArray("pokemon") ?: return emptyList()
        val result = mutableListOf<PvPokeEntry>()
        for (i in 0 until pokeArr.length()) {
            val p = pokeArr.getJSONObject(i)
            val sid = p.optString("speciesId")
            val sName = p.optString("speciesName", sid).replace(" (Shadow)", "")
            val rec = recMovesMap[sid]
            val fMoves = p.optJSONArray("fastMoves")
            val cMoves = p.optJSONArray("chargedMoves")

            val chosenFastId = if (rec != null && rec.isNotEmpty()) rec[0]
            else if (fMoves != null && fMoves.length() > 0) fMoves.getString(0)
            else continue

            val fastMove = fastMap[chosenFastId] ?: continue
            val chosenCharged = mutableListOf<ChargedMove>()
            if (rec != null && rec.size > 1) {
                for (k in 1 until rec.size) {
                    chargedMap[rec[k]]?.let { chosenCharged.add(it) }
                }
            }
            if (cMoves != null && chosenCharged.size < 3) {
                for (k in 0 until cMoves.length()) {
                    val cmObj = chargedMap[cMoves.getString(k)]
                    if (cmObj != null && !chosenCharged.any { it.name == cmObj.name }) {
                        chosenCharged.add(cmObj)
                        if (chosenCharged.size >= 3) break
                    }
                }
            }
            if (chosenCharged.isNotEmpty()) {
                result.add(PvPokeEntry(sid, sName, fastMove, chosenCharged))
            }
        }
        return result
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = i - 1
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev else 1 + min(prev, min(dp[j], dp[j - 1]))
                prev = temp
            }
        }
        return dp[b.length]
    }

    fun matchTopRightOpponent(topRightOcrText: String): PvPokeEntry? {
        if (topRightOcrText.isBlank()) return null

        val words = topRightOcrText
            .replace(Regex("(?i)\\bcp\\b"), " ")
            .replace(Regex("[^a-zA-Z\\-']"), " ")
            .split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.length >= 3 }

        if (words.isEmpty()) return null

        val joinedLower = words.joinToString(" ").lowercase()
        val list = allPokemonList

        // 1. Exact match (longest name first so e.g. 'Sandslash (Alolan)' or 'Marowak' matches cleanly)
        for (entry in list) {
            val cleanEntryName = entry.name.replace(Regex("\\s*\\([^)]*\\)"), "").lowercase()
            if (joinedLower.contains(cleanEntryName)) {
                return entry
            }
        }

        // 2. Fuzzy Levenshtein match (tolerates 1 OCR character error)
        for (word in words) {
            val wLow = word.lowercase()
            if (wLow.length < 4) continue
            for (entry in list) {
                val cleanEntryName = entry.name.replace(Regex("\\s*\\([^)]*\\)"), "").lowercase()
                if (kotlin.math.abs(wLow.length - cleanEntryName.length) <= 1) {
                    if (levenshtein(wLow, cleanEntryName) <= 1) {
                        return entry
                    }
                }
            }
        }

        // 3. Dynamic fallback if 'CP' is visible in the top-right box
        if (topRightOcrText.contains("CP", ignoreCase = true)) {
            val detectedName = words.last()
            if (detectedName.length >= 4) {
                return PvPokeEntry(
                    id = "dyn_${detectedName.lowercase()}",
                    name = detectedName,
                    fastMove = fm("Fast Move", "normal", 8, 2),
                    chargedMoves = listOf(
                        cm("Charged 1", "normal", 40),
                        cm("Charged 2", "normal", 55)
                    )
                )
            }
        }
        return null
    }

    fun matchChargedMoveUsed(bannerOcrText: String, entry: PvPokeEntry): ChargedMove? {
        val normalized = bannerOcrText.lowercase()
        for (cm in entry.chargedMoves) {
            val cleanMove = cm.name.replace("*", "").replace(Regex("\\s*\\([^)]*\\)"), "").lowercase()
            if (normalized.contains(cleanMove)) {
                return cm
            }
        }
        if (normalized.contains("used") || normalized.contains("incoming")) {
            return entry.chargedMoves.firstOrNull()
        }
        return null
    }
}
