package com.pokecount.overlay

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

data class FastMove(val name: String, val type: String, val energyGain: Int, val turns: Int)
data class ChargedMove(val name: String, val type: String, val energyCost: Int)
data class PvPokeEntry(
    val id: String,
    val name: String,
    val primaryType: String,
    val fastMoves: List<FastMove>,
    val chargedMoves: List<ChargedMove>
) {
    fun getPvPokeMoveCounts(fastMove: FastMove, chargedMove: ChargedMove, cycles: Int = 4): List<Int> {
        val counts = mutableListOf<Int>()
        var residual = 0
        val eFast = max(1, fastMove.energyGain)
        for (i in 0 until cycles) {
            val needed = max(0, chargedMove.energyCost - residual)
            val moves = ceil(needed.toDouble() / eFast).toInt()
            counts.add(moves)
            residual = (residual + moves * eFast) - chargedMove.energyCost
        }
        return counts
    }
}

object PvPokeRepository {
    private val DYNAMIC_DUAL_TYPES_MAP: MutableMap<String, List<String>> = mutableMapOf()

    private val PREFERRED_GL_REGIONAL_IDS: Set<String> by lazy { buildPreferredGlRegionalIds() }

    private fun buildPreferredGlRegionalIds(): Set<String> = setOf(
        "weezing_galarian", "corsola_galarian", "stunfisk_galarian",
        "sandslash_alola", "sandslash_alolan", "ninetales_alolan", "ninetales_alola",
        "marowak_alolan", "marowak_alola", "qwilfish_hisuian",
        "muk_alolan", "muk_alola", "raichu_alolan", "raichu_alola",
        "raticate_alolan", "raticate_alola", "rapidash_galarian",
        "moltres_galarian", "zapdos_galarian", "articuno_galarian",
        "linoone_galarian", "zigzagoon_galarian", "slowbro_galarian", "slowking_galarian",
        "yamask_galarian", "darmanitan_galarian", "farfetchd_galarian",
        "golem_alolan", "graveler_alolan", "geodude_alolan",
        "dugtrio_alolan", "diglett_alolan", "persian_alolan", "meowth_alolan",
        "vulpix_alolan", "sandshrew_alolan", "exeggutor_alolan",
        "typhlosion_hisuian", "decidueye_hisuian", "samurott_hisuian",
        "sneasel_hisuian", "electrode_hisuian", "voltorb_hisuian", "avalugg_hisuian",
        "wooper_paldean"
    )

    private val DUAL_TYPES_MAP: Map<String, List<String>> by lazy {
        buildDualTypesChunk1() + buildDualTypesChunk2()
    }

    private fun buildDualTypesChunk1(): Map<String, List<String>> = mapOf(
        "weezing_galarian" to listOf("poison", "fairy"),
        "weezing" to listOf("poison"),
        "corsola_galarian" to listOf("ghost"),
        "corsola" to listOf("water", "rock"),
        "ninetales" to listOf("fire"),
        "sandslash" to listOf("ground"),
        "marowak" to listOf("ground"),
        "raticate_alolan" to listOf("dark", "normal"),
        "muk" to listOf("poison"),
        "muk_alolan" to listOf("poison", "dark"),
        "grimer" to listOf("poison"),
        "grimer_alolan" to listOf("poison", "dark"),
        "golem" to listOf("rock", "ground"),
        "golem_alolan" to listOf("rock", "electric"),
        "graveler" to listOf("rock", "ground"),
        "graveler_alolan" to listOf("rock", "electric"),
        "raticate" to listOf("normal"),
        "raichu" to listOf("electric"),
        "linoone" to listOf("normal"),
        "rapidash" to listOf("fire"),
        "typhlosion" to listOf("fire"),
        "samurott" to listOf("water"),
        "avalugg" to listOf("ice"),
        "avalugg_hisuian" to listOf("ice", "rock"),
        "electrode" to listOf("electric"),
        "electrode_hisuian" to listOf("electric", "grass"),
        "raichu_alolan" to listOf("electric", "psychic"),
        "rapidash_galarian" to listOf("psychic", "fairy"),
        "moltres_galarian" to listOf("dark", "flying"),
        "zapdos_galarian" to listOf("fighting", "flying"),
        "articuno_galarian" to listOf("psychic", "flying"),
        "linoone_galarian" to listOf("dark", "normal"),
        "typhlosion_hisuian" to listOf("fire", "ghost"),
        "decidueye_hisuian" to listOf("grass", "fighting"),
        "samurott_hisuian" to listOf("water", "dark"),
        "sneasel_hisuian" to listOf("fighting", "poison"),
        "altaria" to listOf("dragon", "flying"),
        "combusken" to listOf("fire", "fighting"),
        "azumarill" to listOf("water", "fairy"),
        "mandibuzz" to listOf("dark", "flying"),
        "clodsire" to listOf("poison", "ground"),
        "gastrodon" to listOf("water", "ground"),
        "swampert" to listOf("water", "ground"),
        "marshtomp" to listOf("water", "ground"),
        "whiscash" to listOf("water", "ground"),
        "quagsire" to listOf("water", "ground"),
        "jumpluff" to listOf("grass", "flying"),
        "tropius" to listOf("grass", "flying"),
        "annihilape" to listOf("fighting", "ghost"),
        "corviknight" to listOf("flying", "steel"),
        "skarmory" to listOf("steel", "flying"),
        "morpeko" to listOf("electric", "dark"),
        "wigglytuff" to listOf("normal", "fairy"),
        "drapion" to listOf("poison", "dark"),
        "skuntank" to listOf("poison", "dark"),
        "overqwil" to listOf("dark", "poison"),
        "qwilfish" to listOf("water", "poison"),
        "qwilfish_hisuian" to listOf("dark", "poison"),
        "toxapex" to listOf("poison", "water"),
        "tentacruel" to listOf("water", "poison"),
        "dewgong" to listOf("water", "ice"),
        "lapras" to listOf("water", "ice"),
        "walrein" to listOf("ice", "water"),
        "sandslash_alola" to listOf("ice", "steel"),
        "ninetales_alolan" to listOf("ice", "fairy"),
        "carbink" to listOf("rock", "fairy"),
        "talonflame" to listOf("fire", "flying"),
        "charizard" to listOf("fire", "flying"),
        "malamar" to listOf("dark", "psychic"),
        "diggersby" to listOf("normal", "ground"),
        "marowak_alolan" to listOf("fire", "ghost"),
        "skeledirge" to listOf("fire", "ghost"),
        "stunfisk" to listOf("ground", "electric"),
        "stunfisk_galarian" to listOf("ground", "steel"),
        "steelix" to listOf("steel", "ground"),
        "chesnaught" to listOf("grass", "fighting"),
        "abomasnow" to listOf("grass", "ice"),
        "bastiodon" to listOf("rock", "steel"),
        "probopass" to listOf("rock", "steel"),
        "medicham" to listOf("fighting", "psychic"),
        "sableye" to listOf("dark", "ghost"),
        "spiritomb" to listOf("ghost", "dark"),
        "lanturn" to listOf("water", "electric"),
        "pelipper" to listOf("water", "flying"),
        "mantine" to listOf("water", "flying"),
        "gyarados" to listOf("water", "flying"),
        "pidgeot" to listOf("normal", "flying"),
        "noctowl" to listOf("normal", "flying"),
        "staraptor" to listOf("normal", "flying"),
        "swellow" to listOf("normal", "flying"),
        "fearow" to listOf("normal", "flying"),
        "dodrio" to listOf("normal", "flying"),
        "toucannon" to listOf("normal", "flying"),
        "gligar" to listOf("ground", "flying"),
        "gliscor" to listOf("ground", "flying"),
        "mimikyu" to listOf("ghost", "fairy"),
        "trevenant" to listOf("ghost", "grass"),
        "decidueye" to listOf("grass", "ghost"),
        "froslass" to listOf("ice", "ghost"),
        "jellicent" to listOf("water", "ghost"),
        "drifblim" to listOf("ghost", "flying"),
        "golbat" to listOf("poison", "flying"),
        "crobat" to listOf("poison", "flying"),
        "venusaur" to listOf("grass", "poison"),
        "ivysaur" to listOf("grass", "poison"),
        "victreebel" to listOf("grass", "poison"),
        "roserade" to listOf("grass", "poison"),
        "amoonguss" to listOf("grass", "poison"),
        "ferrothorn" to listOf("grass", "steel"),
        "cradily" to listOf("rock", "grass"),
        "empoleon" to listOf("water", "steel"),
        "lucario" to listOf("fighting", "steel"),
        "cobalion" to listOf("steel", "fighting"),
        "scrafty" to listOf("dark", "fighting"),
        "obstagoon" to listOf("dark", "normal"),
        "guzzlord" to listOf("dark", "dragon")
    )

    private fun buildDualTypesChunk2(): Map<String, List<String>> = mapOf(
        "zweilous" to listOf("dark", "dragon"),
        "hydreigon" to listOf("dark", "dragon"),
        "dragonite" to listOf("dragon", "flying"),
        "dragonair" to listOf("dragon"),
        "flygon" to listOf("ground", "dragon"),
        "garchomp" to listOf("dragon", "ground"),
        "hakamo_o" to listOf("dragon", "fighting"),
        "kommo_o" to listOf("dragon", "fighting"),
        "dragalge" to listOf("poison", "dragon"),
        "kingdra" to listOf("water", "dragon"),
        "palkia" to listOf("water", "dragon"),
        "dialga" to listOf("steel", "dragon"),
        "giratina_altered" to listOf("ghost", "dragon"),
        "mawile" to listOf("steel", "fairy"),
        "tinkaton" to listOf("fairy", "steel"),
        "klefki" to listOf("steel", "fairy"),
        "dedenne" to listOf("electric", "fairy"),
        "togetic" to listOf("fairy", "flying"),
        "togekiss" to listOf("fairy", "flying"),
        "emolga" to listOf("electric", "flying"),
        "zapdos" to listOf("electric", "flying"),
        "charjabug" to listOf("bug", "electric"),
        "gourgeist" to listOf("ghost", "grass"),
        "gourgeist_super" to listOf("ghost", "grass"),
        "gourgeist_large" to listOf("ghost", "grass"),
        "gourgeist_average" to listOf("ghost", "grass"),
        "gourgeist_small" to listOf("ghost", "grass"),
        "thievul" to listOf("dark"),
        "vikavolt" to listOf("bug", "electric"),
        "galvantula" to listOf("bug", "electric"),
        "ariados" to listOf("bug", "poison"),
        "beedrill" to listOf("bug", "poison"),
        "venomoth" to listOf("bug", "poison"),
        "scolipede" to listOf("bug", "poison"),
        "forretress" to listOf("bug", "steel"),
        "scizor" to listOf("bug", "steel"),
        "escavalier" to listOf("bug", "steel"),
        "genesect" to listOf("bug", "steel"),
        "golisopod" to listOf("bug", "water"),
        "araquanid" to listOf("water", "bug"),
        "crustle" to listOf("bug", "rock"),
        "heracross" to listOf("bug", "fighting"),
        "buzzwole" to listOf("bug", "fighting"),
        "lokix" to listOf("bug", "dark"),
        "greninja" to listOf("water", "dark"),
        "crawdaunt" to listOf("water", "dark"),
        "sharpedo" to listOf("water", "dark"),
        "sneasel" to listOf("dark", "ice"),
        "weavile" to listOf("dark", "ice"),
        "sneasler" to listOf("fighting", "poison"),
        "toxicroak" to listOf("poison", "fighting"),
        "poliwrath" to listOf("water", "fighting"),
        "quaquaval" to listOf("water", "fighting"),
        "urshifu_rapid_strike" to listOf("fighting", "water"),
        "urshifu_single_strike" to listOf("fighting", "dark"),
        "pangoro" to listOf("fighting", "dark"),
        "hawlucha" to listOf("fighting", "flying"),
        "gallade" to listOf("psychic", "fighting"),
        "gardevoir" to listOf("psychic", "fairy"),
        "hatterene" to listOf("psychic", "fairy"),
        "tapu_fini" to listOf("water", "fairy"),
        "primarina" to listOf("water", "fairy"),
        "slowbro" to listOf("water", "psychic"),
        "slowking" to listOf("water", "psychic"),
        "slowbro_galarian" to listOf("poison", "psychic"),
        "slowking_galarian" to listOf("poison", "psychic"),
        "starmie" to listOf("water", "psychic"),
        "bruxish" to listOf("water", "psychic"),
        "oranguru" to listOf("normal", "psychic"),
        "girafarig" to listOf("normal", "psychic"),
        "farigiraf" to listOf("normal", "psychic"),
        "bibarel" to listOf("normal", "water"),
        "pyroar" to listOf("fire", "normal"),
        "heliolisk" to listOf("electric", "normal"),
        "obstagoon" to listOf("dark", "normal"),
        "magnezone" to listOf("electric", "steel"),
        "magneton" to listOf("electric", "steel"),
        "togedemaru" to listOf("electric", "steel"),
        "Aegislash" to listOf("steel", "ghost"),
        "gholdengo" to listOf("steel", "ghost"),
        "metagross" to listOf("steel", "psychic"),
        "jirachi" to listOf("steel", "psychic"),
        "bronzong" to listOf("steel", "psychic"),
        "lugia" to listOf("psychic", "flying"),
        "xatu" to listOf("psychic", "flying"),
        "sigilyph" to listOf("psychic", "flying"),
        "woobat" to listOf("psychic", "flying"),
        "swoobat" to listOf("psychic", "flying"),
        "claydol" to listOf("ground", "psychic"),
        "camerupt" to listOf("fire", "ground"),
        "magcargo" to listOf("fire", "rock"),
        "coalossal" to listOf("rock", "fire"),
        "hisuian_growlithe" to listOf("fire", "rock"),
        "arcanine_hisuian" to listOf("fire", "rock"),
        "salazzle" to listOf("poison", "fire"),
        "incineroar" to listOf("fire", "dark"),
        "houndoom" to listOf("dark", "fire"),
        "blaziken" to listOf("fire", "fighting"),
        "infernape" to listOf("fire", "fighting"),
        "monferno" to listOf("fire", "fighting"),
        "emboar" to listOf("fire", "fighting"),
        "pignite" to listOf("fire", "fighting"),
        "turtonator" to listOf("fire", "dragon"),
        "victini" to listOf("psychic", "fire"),
        "delphox" to listOf("fire", "psychic"),
        "chandelure" to listOf("ghost", "fire"),
        "frosmoth" to listOf("ice", "bug"),
        "abomasnow" to listOf("grass", "ice"),
        "aurorus" to listOf("rock", "ice"),
        "amaura" to listOf("rock", "ice"),
        "arctibax" to listOf("dragon", "ice"),
        "baxcalibur" to listOf("dragon", "ice"),
        "kyurem" to listOf("dragon", "ice"),
        "mamoswine" to listOf("ice", "ground"),
        "piloswine" to listOf("ice", "ground"),
        "swinub" to listOf("ice", "ground")
    )


    fun getDefenderTypes(entry: PvPokeEntry): List<String> {
        val baseId = entry.id.lowercase().removePrefix("dyn_")
        return DYNAMIC_DUAL_TYPES_MAP[baseId] ?: DUAL_TYPES_MAP[baseId] ?: listOf(entry.primaryType.lowercase())
    }

    fun getSiblingForms(entry: PvPokeEntry): List<PvPokeEntry> {
        val targetBase = cleanBaseSpeciesName(entry.name)
        return allPokemonList.filter { cleanBaseSpeciesName(it.name) == targetBase }
    }

    private val PVPOKE_2026_FAST_STATS: Map<String, Pair<Int, Int>> by lazy { buildFastStatsMap() }

    private val DYNAMIC_FAST_STATS: MutableMap<String, Pair<Int, Int>> = java.util.concurrent.ConcurrentHashMap()
    private val DYNAMIC_CHARGED_COSTS: MutableMap<String, Int> = java.util.concurrent.ConcurrentHashMap()
    private val DYNAMIC_POKEMON_OVERRIDES: MutableMap<String, PvPokeEntry> = java.util.concurrent.ConcurrentHashMap()

    private fun buildFastStatsMap(): Map<String, Pair<Int, Int>> = mapOf(
        "Acid" to Pair(8, 2), "Air Slash" to Pair(9, 3), "Astonish" to Pair(10, 3), "Bite" to Pair(2, 1),
        "Bubble" to Pair(11, 3), "Bug Bite" to Pair(3, 1), "Bullet Punch" to Pair(8, 2), "Bullet Seed" to Pair(13, 3),
        "Charge Beam" to Pair(11, 3), "Charm" to Pair(8, 3), "Confusion" to Pair(14, 4), "Counter" to Pair(6, 2),
        "Cut" to Pair(2, 1), "Double Kick" to Pair(12, 3), "Dragon Breath" to Pair(3, 1), "Dragon Tail" to Pair(12, 3),
        "Ember" to Pair(9, 2), "Extrasensory" to Pair(10, 3), "Fairy Wind" to Pair(9, 2), "Fast Attack" to Pair(8, 2), "Feint Attack" to Pair(6, 2),
        "Fire Fang" to Pair(7, 2), "Fire Spin" to Pair(10, 3), "Force Palm" to Pair(10, 3), "Frost Breath" to Pair(5, 2),
        "Fury Cutter" to Pair(4, 1), "Geomancy" to Pair(13, 3), "Gust" to Pair(14, 4), "Hex" to Pair(13, 3),
        "Hidden Power" to Pair(8, 3), "Ice Fang" to Pair(7, 2), "Ice Shard" to Pair(10, 3), "Incinerate" to Pair(20, 5),
        "Infestation" to Pair(12, 3), "Iron Tail" to Pair(7, 3), "Karate Chop" to Pair(9, 2), "Leafage" to Pair(8, 2),
        "Lick" to Pair(3, 1), "Lock On" to Pair(5, 1), "Lock-On" to Pair(5, 1), "Low Kick" to Pair(8, 2),
        "Magical Leaf" to Pair(10, 3), "Metal Claw" to Pair(8, 2), "Metal Sound" to Pair(8, 2), "Mud Shot" to Pair(9, 2),
        "Mud Slap" to Pair(10, 3), "Mud-Slap" to Pair(10, 3), "Peck" to Pair(8, 2), "Poison Jab" to Pair(8, 2),
        "Poison Sting" to Pair(9, 2), "Pound" to Pair(4, 2), "Powder Snow" to Pair(8, 2), "Present" to Pair(12, 3),
        "Psycho Cut" to Pair(9, 2), "Psywave" to Pair(4, 1), "Quick Attack" to Pair(8, 2), "Razor Leaf" to Pair(4, 2),
        "Rock Smash" to Pair(7, 3), "Rock Throw" to Pair(5, 2), "Rollout" to Pair(13, 3), "Sand Attack" to Pair(4, 1),
        "Scratch" to Pair(2, 1), "Shadow Claw" to Pair(8, 2), "Smack Down" to Pair(8, 3), "Snarl" to Pair(13, 3),
        "Spark" to Pair(7, 2), "Splash" to Pair(12, 4), "Steel Wing" to Pair(5, 2), "Struggle Bug" to Pair(8, 3),
        "Sucker Punch" to Pair(8, 2), "Tackle" to Pair(3, 1), "Take Down" to Pair(9, 3), "Thunder Fang" to Pair(7, 2),
        "Thunder Shock" to Pair(9, 2), "Transform" to Pair(8, 3), "Vine Whip" to Pair(8, 2), "Volt Switch" to Pair(16, 4),
        "Water Gun" to Pair(3, 1), "Water Shuriken" to Pair(14, 3), "Waterfall" to Pair(10, 3), "Wing Attack" to Pair(8, 2),
        "Yawn" to Pair(12, 4), "Zen Headbutt" to Pair(6, 3)
    )

    private val PVPOKE_2026_CHARGED_COSTS: Map<String, Int> by lazy {
        buildChargedCostsChunk1() + buildChargedCostsChunk2()
    }

    private fun buildChargedCostsChunk1(): Map<String, Int> = mapOf(
        "Acid Spray" to 45, "Acrobatics" to 55, "Aerial Ace" to 45, "Aeroblast" to 75,
        "Air Cutter" to 40, "Ancient Power" to 45, "Aqua Jet" to 40, "Aqua Step" to 40,
        "Aqua Tail" to 35, "Aura Sphere" to 40, "Aura Wheel" to 45, "Aurora Beam" to 60,
        "Avalanche" to 45, "Beak Blast" to 55, "Blast Burn" to 50, "Blaze Kick" to 35, "Bleakwind Storm" to 45,
        "Blizzard" to 75, "Body Slam" to 40, "Bone Club" to 35, "Boomburst" to 70,
        "Brave Bird" to 55, "Breaking Swipe" to 50, "Brick Break" to 40, "Brine" to 60,
        "Brutal Swing" to 35, "Bubble Beam" to 50, "Bug Buzz" to 60, "Bulldoze" to 55,
        "Chilling Water" to 45, "Clanging Scales" to 45, "Close Combat" to 45, "Crabhammer" to 50,
        "Cross Chop" to 35, "Cross Poison" to 35, "Crunch" to 45, "Crush Grip" to 50,
        "Dark Pulse" to 45, "Darkest Lariat" to 60, "Dazzling Gleam" to 55, "Dig" to 50,
        "Disarming Voice" to 45, "Discharge" to 40, "Dive" to 40, "Doom Desire" to 40,
        "Double Iron Bash" to 35, "Draco Meteor" to 65, "Dragon Ascent" to 45, "Dragon Claw" to 50,
        "Dragon Energy" to 45, "Dragon Pulse" to 55, "Drain Punch" to 40, "Draining Kiss" to 55,
        "Drill Peck" to 40, "Drill Run" to 40, "Drum Beating" to 35, "Dynamax Cannon" to 45,
        "Dynamic Punch" to 45, "Earth Power" to 50, "Earthquake" to 65, "Energy Ball" to 45,
        "Feather Dance" to 50, "Fell Stinger" to 35, "Fire Blast" to 80, "Fire Punch" to 40,
        "Flame Burst" to 55, "Flame Charge" to 50, "Flame Wheel" to 45, "Flamethrower" to 55,
        "Flash Cannon" to 65, "Flower Trick" to 35, "Fly" to 45, "Flying Press" to 40,
        "Focus Blast" to 75, "Foul Play" to 40, "Freeze Shock" to 60, "Frenzy Plant" to 45,
        "Frustration" to 70, "Fusion Bolt" to 45, "Fusion Flare" to 45, "Future Sight" to 65,
        "Giga Drain" to 80, "Giga Impact" to 80, "Gigaton Hammer" to 60, "Glaciate" to 40,
        "Glaive Rush" to 40, "Grass Knot" to 50, "Gunk Shot" to 75, "Gyro Ball" to 50,
        "Heart Stamp" to 40, "Heat Wave" to 45, "Heavy Slam" to 50, "High Horsepower" to 55,
        "High Jump Kick" to 55, "Horn Attack" to 35, "Hurricane" to 60, "Hydro Cannon" to 40,
        "Hydro Pump" to 75, "Hyper Beam" to 80, "Hyper Fang" to 50, "Ice Beam" to 55,
        "Ice Burn" to 60, "Ice Punch" to 40, "Icicle Spear" to 40, "Icy Wind" to 45,
        "Iron Head" to 50, "Last Resort" to 55, "Leaf Blade" to 35, "Leaf Storm" to 55,
        "Leaf Tornado" to 40, "Liquidation" to 45, "Low Sweep" to 40, "Lunge" to 45
    )

    private fun buildChargedCostsChunk2(): Map<String, Int> = mapOf(
        "Luster Purge" to 60, "Magma Storm" to 40, "Magnet Bomb" to 40, "Mega Drain" to 55,
        "Megahorn" to 55, "Meteor Beam" to 60, "Meteor Mash" to 45, "Mind Blown" to 35,
        "Mirror Coat" to 45, "Mirror Shot" to 35, "Mist Ball" to 60, "Moonblast" to 50,
        "Moongeist Beam" to 65, "Mud Bomb" to 45, "Muddy Water" to 35, "Mystical Fire" to 45,
        "Nature's Madness" to 50, "Night Shade" to 45, "Night Slash" to 35, "Oblivion Wing" to 50,
        "Obstruct" to 40, "Octazooka" to 50, "Ominous Wind" to 45, "Origin Pulse" to 60,
        "Outrage" to 60, "Overheat" to 55, "Parabolic Charge" to 50, "Payback" to 60,
        "Petal Blizzard" to 65, "Plasma Fists" to 35, "Play Rough" to 60, "Poison Fang" to 40,
        "Poltergeist" to 75, "Power Gem" to 50, "Power Whip" to 50, "Power-Up Punch" to 35,
        "Precipice Blades" to 60, "Psybeam" to 60, "Psychic" to 55, "Psychic Fangs" to 35,
        "Psycho Boost" to 35, "Psyshock" to 40, "Psystrike" to 45, "Pyro Ball" to 40,
        "Rage Fist" to 40, "Razor Shell" to 35, "Rest" to 35, "Return" to 70,
        "Roar of Time" to 65, "Rock Blast" to 40, "Rock Slide" to 45, "Rock Tomb" to 50,
        "Rock Wrecker" to 50, "Sacred Fire" to 65, "Sacred Sword" to 35, "Sand Tomb" to 45,
        "Sandsear Storm" to 45, "Scald" to 50, "Scorching Sands" to 50, "Secret Sword" to 35,
        "Seed Bomb" to 40, "Seed Flare" to 75, "Shadow Ball" to 50, "Shadow Bone" to 45,
        "Shadow Force" to 65, "Shadow Punch" to 35, "Shadow Sneak" to 50, "Signal Beam" to 55,
        "Silver Wind" to 45, "Skull Bash" to 75, "Sky Attack" to 50, "Sludge" to 40,
        "Sludge Bomb" to 50, "Sludge Wave" to 65, "Snipe Shot" to 35, "Solar Beam" to 80,
        "Spacial Rend" to 55, "Sparkling Aria" to 45, "Spirit Shackle" to 40, "Stomp" to 40,
        "Stone Edge" to 55, "Struggle" to 100, "Submission" to 50, "Sunsteel Strike" to 65,
        "Superpower" to 40, "Surf" to 45, "Swift" to 35, "Synchronoise" to 50,
        "Techno Blast" to 55, "Thunder" to 60, "Thunder Cage" to 40, "Thunder Punch" to 40,
        "Thunderbolt" to 55, "Torch Song" to 45, "Trailblaze" to 45, "Tri Attack" to 50,
        "Triple Axel" to 45, "Twister" to 40, "Upper Hand" to 40, "V-create" to 40,
        "Behemoth Bash" to 45, "Behemoth Blade" to 55, "Jet Punch" to 40, "Kowtow Cleave" to 45,
        "Vice Grip" to 40, "Vise Grip" to 40, "Volt Tackle" to 40, "Water Pulse" to 50,
        "Weather Ball (Fire)" to 35, "Weather Ball (Ice)" to 35, "Weather Ball (Normal)" to 35,
        "Weather Ball (Rock)" to 35, "Weather Ball (Water)" to 35, "Wild Charge" to 45,
        "Wildbolt Storm" to 45, "Wrap" to 45, "X-Scissor" to 40, "Zap Cannon" to 80
    )


    private fun fm(name: String, type: String, e: Int, t: Int): FastMove {
        val clean = name.replace("*", "").trim()
        val canonical = DYNAMIC_FAST_STATS[clean] ?: PVPOKE_2026_FAST_STATS[clean]
        return if (canonical != null) {
            FastMove(name, type, canonical.first, canonical.second)
        } else {
            FastMove(name, type, e, t)
        }
    }

    private fun cm(name: String, type: String, cost: Int): ChargedMove {
        val clean = name.replace("*", "").trim()
        val canonicalCost = DYNAMIC_CHARGED_COSTS[clean] ?: PVPOKE_2026_CHARGED_COSTS[clean] ?: cost
        return ChargedMove(name, type, canonicalCost)
    }


    val BUILT_IN_POKEMON: List<PvPokeEntry> by lazy {
        buildList(559) {
            addAll(loadPokemonChunk1())
            addAll(loadPokemonChunk2())
            addAll(loadPokemonChunk3())
            addAll(loadPokemonChunk4())
            addAll(loadPokemonChunk5())
            addAll(loadPokemonChunk6())
            addAll(loadPokemonChunk7())
            addAll(loadPokemonChunk8())
            addAll(loadPokemonChunk9())
        }
    }

    private fun loadPokemonChunk1(): List<PvPokeEntry> = listOf(
        PvPokeEntry("melmetal", "Melmetal", "steel", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Double Iron Bash*", "steel", 35), cm("Dynamic Punch", "fighting", 45), cm("Superpower", "fighting", 40), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("clodsire", "Clodsire", "poison", listOf(fm("Poison Sting", "poison", 9, 2), fm("Mud Shot", "ground", 9, 2)), listOf(cm("Earthquake", "ground", 65), cm("Stone Edge", "rock", 55), cm("Sludge Bomb", "poison", 50), cm("Megahorn*", "bug", 55), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("feraligatr", "Feraligatr", "water", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Water Gun", "water", 3, 1), fm("Ice Fang", "ice", 6, 2), fm("Waterfall", "water", 8, 3)), listOf(cm("Hydro Cannon*", "water", 40), cm("Ice Beam", "ice", 55), cm("Crunch", "dark", 45))),
        PvPokeEntry("mandibuzz", "Mandibuzz", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Air Slash", "flying", 9, 3)), listOf(cm("Dark Pulse", "dark", 50), cm("Aerial Ace", "flying", 40), cm("Foul Play", "dark", 45))),
        PvPokeEntry("azumarill", "Azumarill", "water", listOf(fm("Bubble", "water", 11, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Ice Beam", "ice", 55), cm("Play Rough", "fairy", 60), cm("Hydro Pump", "water", 75))),
        PvPokeEntry("gastrodon", "Gastrodon", "water", listOf(fm("Mud Slap", "ground", 10, 3), fm("Hidden Power", "normal", 8, 3)), listOf(cm("Body Slam", "normal", 35), cm("Earth Power", "ground", 55), cm("Water Pulse", "water", 55))),
        PvPokeEntry("jumpluff", "Jumpluff", "grass", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Aerial Ace", "flying", 40), cm("Energy Ball", "grass", 55), cm("Acrobatics", "flying", 60))),
        PvPokeEntry("dunsparce", "Dunsparce", "normal", listOf(fm("Rollout", "rock", 13, 3), fm("Bite", "dark", 2, 1), fm("Astonish", "ghost", 10, 3)), listOf(cm("Drill Run", "ground", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("annihilape", "Annihilape", "fighting", listOf(fm("Karate Chop", "fighting", 9, 2), fm("Counter", "fighting", 6, 2), fm("Low Kick", "fighting", 8, 2)), listOf(cm("Rage Fist*", "ghost", 40), cm("Ice Punch", "ice", 40), cm("Close Combat", "fighting", 45), cm("Shadow Ball", "ghost", 50), cm("Night Slash", "dark", 35))),
        PvPokeEntry("primeape", "Primeape", "fighting", listOf(fm("Karate Chop*", "fighting", 9, 2), fm("Counter", "fighting", 6, 2), fm("Low Kick", "fighting", 8, 2)), listOf(cm("Rage Fist*", "ghost", 40), cm("Cross Chop*", "fighting", 35), cm("Ice Punch", "ice", 40), cm("Close Combat", "fighting", 45), cm("Night Slash", "dark", 35))),
        PvPokeEntry("corsola", "Corsola", "water", listOf(fm("Bubble", "water", 11, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Rock Blast", "rock", 40), cm("Power Gem", "rock", 50), cm("Bubble Beam", "water", 50))),
        PvPokeEntry("corsola_galarian", "Corsola (Galarian)", "ghost", listOf(fm("Astonish", "ghost", 10, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Night Shade", "ghost", 45), cm("Power Gem", "rock", 50), cm("Brine", "water", 60))),
        PvPokeEntry("cursola", "Cursola", "ghost", listOf(fm("Astonish", "ghost", 10, 3), fm("Hex", "ghost", 13, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Night Shade", "ghost", 45), cm("Rock Blast", "rock", 40), cm("Power Gem", "rock", 50), cm("Brine", "water", 60))),
        PvPokeEntry("corviknight", "Corviknight", "steel", listOf(fm("Sand Attack", "ground", 4, 1), fm("Steel Wing", "steel", 5, 2), fm("Air Slash", "flying", 9, 3)), listOf(cm("Air Cutter*", "flying", 40), cm("Sky Attack", "flying", 50), cm("Iron Head", "steel", 50), cm("Payback", "dark", 60))),
        PvPokeEntry("morpeko", "Morpeko", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Aura Wheel", "electric", 45), cm("Psychic Fangs", "psychic", 35), cm("Seed Bomb", "grass", 45))),
        PvPokeEntry("serperior", "Serperior", "grass", listOf(fm("Vine Whip", "grass", 8, 2), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("lickilicky", "Lickilicky", "normal", listOf(fm("Rollout", "rock", 13, 3), fm("Lick", "ghost", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Shadow Ball", "ghost", 55), cm("Earthquake", "ground", 65))),
        PvPokeEntry("lickitung", "Lickitung", "normal", listOf(fm("Lick", "ghost", 3, 1), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Body Slam*", "normal", 40), cm("Wrap", "normal", 45), cm("Power Whip", "grass", 50), cm("Stomp", "normal", 40))),
        PvPokeEntry("wigglytuff", "Wigglytuff", "normal", listOf(fm("Charm", "fairy", 6, 3), fm("Feint Attack", "dark", 6, 2), fm("Pound", "normal", 4, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Swift", "normal", 35), cm("Disarming Voice", "fairy", 45))),
        PvPokeEntry("clefable", "Clefable", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Charm", "fairy", 8, 3), fm("Pound", "normal", 4, 2)), listOf(cm("Swift", "normal", 35), cm("Meteor Mash", "steel", 45), cm("Moonblast", "fairy", 50), cm("Draining Kiss", "fairy", 55), cm("Dazzling Gleam", "fairy", 55))),
        PvPokeEntry("drapion", "Drapion", "poison", listOf(fm("Poison Sting", "poison", 10, 2), fm("Bite", "dark", 2, 1), fm("Ice Fang", "ice", 6, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("skuntank", "Skuntank", "poison", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Crunch", "dark", 45), cm("Trailblaze", "grass", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("overqwil", "Overqwil", "dark", listOf(fm("Poison Jab", "poison", 7, 2), fm("Poison Sting", "poison", 10, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("qwilfish", "Qwilfish", "water", listOf(fm("Poison Sting", "poison", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Shadow Ball", "ghost", 50), cm("Scald", "water", 50), cm("Ice Beam", "ice", 55), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("qwilfish_hisuian", "Qwilfish (Hisuian)", "dark", listOf(fm("Poison Jab", "poison", 7, 2), fm("Poison Sting", "poison", 10, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("dewgong", "Dewgong", "water", listOf(fm("Ice Shard", "ice", 10, 3), fm("Frost Breath", "ice", 5, 2), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Drill Run", "ground", 45))),
        PvPokeEntry("toxapex", "Toxapex", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Brine", "water", 40), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("sandslash_alola", "Sandslash (Alolan)", "ice", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Powder Snow", "ice", 8, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Drill Run", "ground", 45))),
        PvPokeEntry("sandslash", "Sandslash", "ground", listOf(fm("Mud Shot", "ground", 9, 2), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Night Slash", "dark", 35), cm("Scorching Sands", "ground", 50), cm("Earthquake", "ground", 65))),
        PvPokeEntry("ninetales_alolan", "Ninetales (Alolan)", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Charm", "fairy", 6, 3)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Dazzling Gleam", "fairy", 70), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("ninetales", "Ninetales", "fire", listOf(fm("Fire Spin", "fire", 10, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Scorching Sands", "ground", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("carbink", "Carbink", "rock", listOf(fm("Rock Throw", "rock", 5, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("talonflame", "Talonflame", "fire", listOf(fm("Incinerate", "fire", 20, 5), fm("Peck", "flying", 5, 2), fm("Fire Spin", "fire", 10, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Fly", "flying", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("malamar", "Malamar", "dark", listOf(fm("Psywave", "psychic", 4, 1), fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Superpower", "fighting", 40), cm("Foul Play", "dark", 40), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("diggersby", "Diggersby", "normal", listOf(fm("Quick Attack", "normal", 8, 2), fm("Mud Shot", "ground", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Scorching Sands", "ground", 50), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("marowak", "Marowak", "ground", listOf(fm("Mud Slap", "ground", 10, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Bone Club", "ground", 35), cm("Rock Slide", "rock", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("marowak_alolan", "Marowak (Alolan)", "fire", listOf(fm("Fire Spin", "fire", 10, 3), fm("Hex", "ghost", 11, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Bone Club", "ground", 35), cm("Shadow Bone", "ghost", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("stunfisk", "Stunfisk", "ground", listOf(fm("Thunder Shock", "electric", 9, 2), fm("Mud Shot", "ground", 9, 2)), listOf(cm("Mud Bomb", "ground", 40), cm("Discharge", "electric", 45))),
        PvPokeEntry("stunfisk_galarian", "Stunfisk (Galarian)", "ground", listOf(fm("Mud Shot", "ground", 9, 2), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("chesnaught", "Chesnaught", "grass", listOf(fm("Vine Whip", "grass", 8, 2), fm("Low Kick", "fighting", 8, 2), fm("Smack Down", "rock", 8, 3)), listOf(cm("Superpower", "fighting", 40), cm("Thunder Punch", "electric", 40), cm("Frenzy Plant*", "grass", 45), cm("Energy Ball", "grass", 45))),
        PvPokeEntry("abomasnow", "Abomasnow", "grass", listOf(fm("Powder Snow", "ice", 8, 2), fm("Razor Leaf", "grass", 4, 2), fm("Leafage", "grass", 7, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Energy Ball", "grass", 55), cm("Icy Wind", "ice", 45))),
        PvPokeEntry("bastiodon", "Bastiodon", "rock", listOf(fm("Smack Down", "rock", 8, 3), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Stone Edge", "rock", 55), cm("Flamethrower", "fire", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("probopass", "Probopass", "rock", listOf(fm("Spark", "electric", 7, 2), fm("Rock Throw", "rock", 5, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Magnet Bomb", "steel", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("cresselia", "Cresselia", "psychic", listOf(fm("Psycho Cut", "psychic", 9, 2), fm("Confusion", "psychic", 12, 4)), listOf(cm("Grass Knot", "grass", 50), cm("Moonblast", "fairy", 60), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("registeel", "Registeel", "steel", listOf(fm("Lock On", "normal", 5, 1)), listOf(cm("Focus Blast", "fighting", 75), cm("Zap Cannon", "electric", 80), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("regirock", "Regirock", "rock", listOf(fm("Lock On", "normal", 5, 1)), listOf(cm("Stone Edge", "rock", 55), cm("Focus Blast", "fighting", 75), cm("Earthquake", "ground", 65))),
        PvPokeEntry("regice", "Regice", "ice", listOf(fm("Lock On", "normal", 5, 1)), listOf(cm("Blizzard", "ice", 75), cm("Earthquake", "ground", 65), cm("Thunder", "electric", 60))),
        PvPokeEntry("skarmory", "Skarmory", "steel", listOf(fm("Steel Wing", "steel", 5, 2), fm("Air Slash", "flying", 9, 3)), listOf(cm("Drill Run", "ground", 40), cm("Sky Attack", "flying", 50), cm("Brave Bird", "flying", 55), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("medicham", "Medicham", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Dynamic Punch", "fighting", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("sableye", "Sableye", "dark", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Foul Play", "dark", 40), cm("Drain Punch", "fighting", 40), cm("Power Gem", "rock", 50), cm("Dazzling Gleam", "fairy", 55), cm("Return", "normal", 70), cm("Shadow Sneak", "ghost", 50))),
        PvPokeEntry("umbreon", "Umbreon", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Foul Play", "dark", 45), cm("Last Resort*", "normal", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("sylveon", "Sylveon", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Charm", "fairy", 8, 3), fm("Quick Attack", "normal", 8, 2)), listOf(cm("Psyshock*", "psychic", 40), cm("Shadow Ball", "ghost", 50), cm("Moonblast", "fairy", 50), cm("Last Resort*", "normal", 55), cm("Draining Kiss", "fairy", 55))),
        PvPokeEntry("vaporeon", "Vaporeon", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Last Resort*", "normal", 55), cm("Scald", "water", 55))),
        PvPokeEntry("jolteon", "Jolteon", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Discharge", "electric", 45), cm("Last Resort*", "normal", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("flareon", "Flareon", "fire", listOf(fm("Fire Spin", "fire", 10, 3)), listOf(cm("Flamethrower", "fire", 55), cm("Superpower", "fighting", 40), cm("Last Resort*", "normal", 55))),
        PvPokeEntry("espeon", "Espeon", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("leafeon", "Leafeon", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Last Resort*", "normal", 55))),
        PvPokeEntry("glaceon", "Glaceon", "ice", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("deoxys_defense", "Deoxys (Defense)", "psychic", listOf(fm("Low Kick", "fighting", 8, 2), fm("Counter", "fighting", 6, 2), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Psycho Boost", "psychic", 35), cm("Rock Slide", "rock", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("lanturn", "Lanturn", "water", listOf(fm("Spark", "electric", 7, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("swampert", "Swampert", "water", listOf(fm("Mud Shot", "ground", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Hydro Cannon*", "water", 40), cm("Sludge", "poison", 40), cm("Earthquake", "ground", 65), cm("Sludge Wave", "poison", 65), cm("Surf", "water", 45))),
        PvPokeEntry("marshtomp", "Marshtomp", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Surf", "water", 40), cm("Mud Bomb", "ground", 40), cm("Sludge", "poison", 40))),
        PvPokeEntry("whiscash", "Whiscash", "water", listOf(fm("Mud Shot", "ground", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Mud Bomb", "ground", 40), cm("Scald", "water", 55), cm("Blizzard", "ice", 75))),
        PvPokeEntry("quagsire", "Quagsire", "water", listOf(fm("Mud Shot", "ground", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail*", "water", 35), cm("Drain Punch", "fighting", 40), cm("Mud Bomb", "ground", 45), cm("Stone Edge", "rock", 55), cm("Earthquake", "ground", 65))),
        PvPokeEntry("pelipper", "Pelipper", "water", listOf(fm("Wing Attack", "flying", 8, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Hurricane", "flying", 65)))
    )

    private fun loadPokemonChunk2(): List<PvPokeEntry> = listOf(
        PvPokeEntry("mantine", "Mantine", "water", listOf(fm("Wing Attack", "flying", 8, 2), fm("Bubble", "water", 11, 3), fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Twister", "dragon", 40), cm("Aerial Ace", "flying", 45), cm("Water Pulse", "water", 50), cm("Bubble Beam", "water", 50), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("altaria", "Altaria", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Peck", "flying", 8, 2)), listOf(cm("Sky Attack", "flying", 50), cm("Moonblast*", "fairy", 50), cm("Flamethrower", "fire", 55), cm("Dragon Pulse", "dragon", 55), cm("Dazzling Gleam", "fairy", 55))),
        PvPokeEntry("pidgeot", "Pidgeot", "normal", listOf(fm("Wing Attack*", "flying", 8, 2), fm("Gust*", "flying", 14, 4), fm("Air Slash", "flying", 9, 3), fm("Steel Wing", "steel", 5, 2)), listOf(cm("Twister", "dragon", 40), cm("Heat Wave", "fire", 45), cm("Feather Dance", "flying", 50), cm("Brave Bird", "flying", 55), cm("Air Cutter*", "flying", 40))),
        PvPokeEntry("noctowl", "Noctowl", "normal", listOf(fm("Wing Attack", "flying", 8, 2), fm("Extrasensory", "psychic", 10, 3)), listOf(cm("Sky Attack", "flying", 55), cm("Shadow Ball", "ghost", 55), cm("Night Shade", "ghost", 55))),
        PvPokeEntry("staraptor", "Staraptor", "normal", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Fly", "flying", 45), cm("Close Combat", "fighting", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("swellow", "Swellow", "normal", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Aerial Ace", "flying", 40), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("fearow", "Fearow", "normal", listOf(fm("Peck", "flying", 8, 2), fm("Steel Wing", "steel", 5, 2)), listOf(cm("Drill Peck", "flying", 40), cm("Drill Run", "ground", 40), cm("Sky Attack", "flying", 50), cm("Aerial Ace", "flying", 45))),
        PvPokeEntry("dodrio", "Dodrio", "normal", listOf(fm("Peck", "flying", 8, 2), fm("Feint Attack", "dark", 6, 2), fm("Steel Wing", "steel", 5, 2)), listOf(cm("Drill Peck", "flying", 40), cm("Trailblaze", "grass", 45), cm("Aerial Ace", "flying", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("toucannon", "Toucannon", "normal", listOf(fm("Peck", "flying", 8, 2), fm("Bullet Seed", "grass", 13, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Beak Blast*", "flying", 55), cm("Drill Peck", "flying", 40), cm("Rock Blast", "rock", 40), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("vigoroth", "Vigoroth", "normal", listOf(fm("Scratch", "normal", 2, 1), fm("Counter", "fighting", 6, 2)), listOf(cm("Body Slam", "normal", 40), cm("Rock Slide", "rock", 45), cm("Brick Break", "fighting", 40), cm("Bulldoze", "ground", 55))),
        PvPokeEntry("slaking", "Slaking", "normal", listOf(fm("Yawn", "normal", 12, 4)), listOf(cm("Body Slam", "normal", 35), cm("Play Rough", "fairy", 60), cm("Earthquake", "ground", 65))),
        PvPokeEntry("obstagoon", "Obstagoon", "dark", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Night Slash", "dark", 35), cm("Cross Chop", "fighting", 35), cm("Obstruct", "dark", 40))),
        PvPokeEntry("linoone_galarian", "Linoone (Galarian)", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Body Slam", "normal", 35), cm("Dig", "ground", 50))),
        PvPokeEntry("linoone", "Linoone", "normal", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Tackle", "normal", 3, 1)), listOf(cm("Swift", "normal", 35), cm("Grass Knot", "grass", 50), cm("Dig", "ground", 50), cm("Thunder", "electric", 60))),
        PvPokeEntry("dubwool", "Dubwool", "normal", listOf(fm("Double Kick", "fighting", 12, 3), fm("Take Down", "normal", 9, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 40), cm("Wild Charge", "electric", 45), cm("Payback", "dark", 60))),
        PvPokeEntry("greedent", "Greedent", "normal", listOf(fm("Mud Shot", "ground", 9, 2), fm("Bullet Seed", "grass", 13, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Crunch", "dark", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("oinkologne", "Oinkologne", "normal", listOf(fm("Take Down", "normal", 9, 3), fm("Mud Slap*", "ground", 10, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 40), cm("Trailblaze", "grass", 45), cm("Dig", "ground", 50))),
        PvPokeEntry("miltank", "Miltank", "normal", listOf(fm("Rollout", "rock", 13, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 40), cm("High Horsepower", "ground", 55), cm("Ice Beam", "ice", 55), cm("Thunderbolt", "electric", 55), cm("Stomp", "normal", 40))),
        PvPokeEntry("tauros", "Tauros", "normal", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Horn Attack", "normal", 35), cm("Earthquake", "ground", 65), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("tauros_combat", "Tauros (Combat)", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("tauros_blaze", "Tauros (Blaze)", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("tauros_aqua", "Tauros (Aqua)", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Liquidation", "water", 45), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("bouffalant", "Bouffalant", "normal", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Stomp", "normal", 40), cm("Superpower", "fighting", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("kangaskhan", "Kangaskhan", "normal", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Power-Up Punch", "fighting", 35), cm("Outrage", "dragon", 60), cm("Crunch", "dark", 45))),
        PvPokeEntry("snorlax", "Snorlax", "normal", listOf(fm("Psywave", "psychic", 4, 1), fm("Lick", "ghost", 3, 1), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Body Slam", "normal", 40), cm("Superpower", "fighting", 40), cm("Earthquake", "ground", 65), cm("Outrage", "dragon", 60), cm("Skull Bash", "normal", 75))),
        PvPokeEntry("munchlax", "Munchlax", "normal", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Bulldoze", "ground", 60), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("zangoose", "Zangoose", "normal", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Night Slash", "dark", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("oranguru", "Oranguru", "normal", listOf(fm("Confusion", "psychic", 12, 4), fm("Yawn", "normal", 12, 4)), listOf(cm("Brutal Swing", "dark", 40), cm("Trailblaze", "grass", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("girafarig", "Girafarig", "normal", listOf(fm("Double Kick", "fighting", 12, 3), fm("Confusion", "psychic", 12, 4), fm("Tackle", "normal", 3, 1)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Thunderbolt", "electric", 55), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("farigiraf", "Farigiraf", "normal", listOf(fm("Double Kick", "fighting", 12, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Foul Play", "dark", 45), cm("Trailblaze", "grass", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("bibarel", "Bibarel", "normal", listOf(fm("Rollout", "rock", 13, 3)), listOf(cm("Surf", "water", 40), cm("Hyper Fang", "normal", 50))),
        PvPokeEntry("raticate", "Raticate", "normal", listOf(fm("Quick Attack", "normal", 8, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Body Slam", "normal", 40), cm("Hyper Fang", "normal", 50), cm("Return", "normal", 70))),
        PvPokeEntry("raticate_alolan", "Raticate (Alolan)", "dark", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("Crunch", "dark", 45), cm("Return", "normal", 70), cm("Hyper Fang", "normal", 50))),
        PvPokeEntry("furret", "Furret", "normal", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Quick Attack", "normal", 8, 2)), listOf(cm("Swift", "normal", 35), cm("Trailblaze", "grass", 45), cm("Brick Break", "fighting", 40), cm("Dig", "ground", 50), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("castform", "Castform", "normal", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Weather Ball (Rock)", "rock", 35), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("castform_sunny", "Castform (Sunny)", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("castform_rainy", "Castform (Rainy)", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Thunder", "electric", 60))),
        PvPokeEntry("castform_snowy", "Castform (Snowy)", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Blizzard", "ice", 75))),
        PvPokeEntry("cherrim_sunny", "Cherrim (Sunny)", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("scrafty", "Scrafty", "dark", listOf(fm("Counter", "fighting", 6, 2), fm("Snarl", "dark", 13, 3)), listOf(cm("Thunder Punch", "electric", 40), cm("Power-Up Punch", "fighting", 35), cm("Foul Play", "dark", 45))),
        PvPokeEntry("pangoro", "Pangoro", "fighting", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Night Slash", "dark", 35), cm("Close Combat", "fighting", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("guzzlord", "Guzzlord", "dark", listOf(fm("Dragon Tail", "dragon", 9, 3), fm("Snarl", "dark", 13, 3)), listOf(cm("Dragon Claw", "dragon", 35), cm("Brutal Swing", "dark", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("zweilous", "Zweilous", "dark", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("hydreigon", "Hydreigon", "dark", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Bite", "dark", 2, 1)), listOf(cm("Brutal Swing*", "dark", 35), cm("Fly", "flying", 45), cm("Dark Pulse", "dark", 45), cm("Dragon Pulse", "dragon", 55), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("goodra", "Goodra", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Thunder Punch", "electric", 40), cm("Power Whip", "grass", 50))),
        PvPokeEntry("sliggoo", "Sliggoo", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Body Slam", "normal", 40), cm("Dragon Pulse", "dragon", 55), cm("Muddy Water", "water", 35))),
        PvPokeEntry("dragonair", "Dragonair", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Aqua Tail", "water", 35), cm("Body Slam", "normal", 35), cm("Dragon Pulse", "dragon", 60))),
        PvPokeEntry("dragonite", "Dragonite", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Dragon Tail", "dragon", 12, 3), fm("Steel Wing", "steel", 5, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Superpower", "fighting", 40), cm("Dragon Claw", "dragon", 50), cm("Hurricane", "flying", 60), cm("Draco Meteor*", "dragon", 65))),
        PvPokeEntry("hakamo_o", "Hakamo-o", "dragon", listOf(fm("Dragon Tail", "dragon", 12, 3), fm("Poison Jab", "poison", 7, 2)), listOf(cm("Brick Break", "fighting", 40), cm("Rock Tomb", "rock", 50), cm("Dragon Claw", "dragon", 50), cm("Dragon Pulse", "dragon", 55))),
        PvPokeEntry("kommo_o", "Kommo-o", "dragon", listOf(fm("Dragon Tail", "dragon", 12, 3), fm("Metal Sound", "steel", 8, 2), fm("Poison Jab", "poison", 7, 2)), listOf(cm("Upper Hand", "fighting", 40), cm("Clanging Scales*", "dragon", 45), cm("Close Combat", "fighting", 45), cm("Brick Break", "fighting", 40), cm("Dragon Claw", "dragon", 50), cm("Boomburst", "normal", 70))),
        PvPokeEntry("haxorus", "Haxorus", "dragon", listOf(fm("Counter", "fighting", 6, 2), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Night Slash", "dark", 35), cm("Earthquake", "ground", 65))),
        PvPokeEntry("fraxure", "Fraxure", "dragon", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("flygon", "Flygon", "ground", listOf(fm("Mud Shot", "ground", 9, 2), fm("Dragon Tail", "dragon", 12, 3), fm("Sand Attack", "ground", 4, 1)), listOf(cm("Sand Tomb", "ground", 45), cm("Twister", "dragon", 40), cm("Dragon Claw", "dragon", 50), cm("Scorching Sands", "ground", 50), cm("Earth Power*", "ground", 50), cm("Boomburst", "normal", 70))),
        PvPokeEntry("vibrava", "Vibrava", "ground", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Sand Tomb", "ground", 40), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("garchomp", "Garchomp", "dragon", listOf(fm("Mud Shot", "ground", 9, 2), fm("Dragon Tail", "dragon", 12, 3)), listOf(cm("Twister", "dragon", 40), cm("Sand Tomb", "ground", 45), cm("Breaking Swipe", "dragon", 50), cm("Earth Power*", "ground", 50), cm("Outrage", "dragon", 60), cm("Earthquake", "ground", 65))),
        PvPokeEntry("gabite", "Gabite", "dragon", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Sand Tomb", "ground", 40), cm("Twister", "dragon", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("kingdra", "Kingdra", "water", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Waterfall", "water", 10, 3)), listOf(cm("Swift", "normal", 35), cm("Surf", "water", 45), cm("Octazooka", "water", 50), cm("Outrage", "dragon", 60), cm("Blizzard", "ice", 75))),
        PvPokeEntry("dragalge", "Dragalge", "poison", listOf(fm("Dragon Tail", "dragon", 12, 3), fm("Acid", "poison", 8, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Sludge Bomb", "poison", 50), cm("Outrage", "dragon", 60), cm("Focus Blast", "fighting", 75), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("turtonator", "Turtonator", "fire", listOf(fm("Incinerate", "fire", 20, 5), fm("Ember", "fire", 9, 2)), listOf(cm("Brutal Swing", "dark", 35), cm("Dragon Claw", "dragon", 50), cm("Dragon Pulse", "dragon", 55), cm("Overheat", "fire", 55), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("drampa", "Drampa", "normal", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Extrasensory", "psychic", 10, 3)), listOf(cm("Swift", "normal", 35), cm("Fly", "flying", 45), cm("Dragon Pulse", "dragon", 55), cm("Outrage", "dragon", 60))),
        PvPokeEntry("baxcalibur", "Baxcalibur", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("arctibax", "Arctibax", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("frigibax", "Frigibax", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("dragapult", "Dragapult", "dragon", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("venusaur", "Venusaur", "grass", listOf(fm("Vine Whip", "grass", 8, 2), fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Sludge Bomb", "poison", 50)))
    )

    private fun loadPokemonChunk3(): List<PvPokeEntry> = listOf(
        PvPokeEntry("ivysaur", "Ivysaur", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Power Whip", "grass", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("charizard", "Charizard", "fire", listOf(fm("Dragon Breath*", "dragon", 3, 1), fm("Ember*", "fire", 9, 2), fm("Wing Attack*", "flying", 8, 2), fm("Fire Spin", "fire", 10, 3), fm("Air Slash", "flying", 9, 3)), listOf(cm("Air Cutter", "flying", 40), cm("Blast Burn*", "fire", 50), cm("Dragon Claw", "dragon", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("charmeleon", "Charmeleon", "fire", listOf(fm("Fire Fang", "fire", 8, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("blastoise", "Blastoise", "water", listOf(fm("Rollout", "rock", 13, 3), fm("Water Gun", "water", 3, 1), fm("Bite", "dark", 2, 1)), listOf(cm("Hydro Cannon*", "water", 40), cm("Ice Beam", "ice", 55), cm("Skull Bash", "normal", 75), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("wartortle", "Wartortle", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Jet", "water", 45), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("meganium", "Meganium", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("bayleef", "Bayleef", "grass", listOf(fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Grass Knot", "grass", 50), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("typhlosion", "Typhlosion", "fire", listOf(fm("Incinerate", "fire", 20, 5), fm("Shadow Claw", "ghost", 8, 2), fm("Ember", "fire", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("typhlosion_hisuian", "Typhlosion (Hisuian)", "fire", listOf(fm("Hex", "ghost", 11, 3), fm("Ember", "fire", 7, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("quilava", "Quilava", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Dig", "ground", 50))),
        PvPokeEntry("croconaw", "Croconaw", "water", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Crunch", "dark", 45), cm("Ice Punch", "ice", 40))),
        PvPokeEntry("sceptile", "Sceptile", "grass", listOf(fm("Bullet Seed", "grass", 13, 3), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Leaf Blade", "grass", 35), cm("Breaking Swipe", "dragon", 35), cm("Earthquake", "ground", 65))),
        PvPokeEntry("grovyle", "Grovyle", "grass", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("blaziken", "Blaziken", "fire", listOf(fm("Ember", "fire", 9, 2), fm("Counter", "fighting", 6, 2), fm("Fire Spin", "fire", 10, 3)), listOf(cm("Blaze Kick", "fire", 35), cm("Aura Sphere", "fighting", 40), cm("Blast Burn*", "fire", 50), cm("Stone Edge*", "rock", 55), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("combusken", "Combusken", "fire", listOf(fm("Ember", "fire", 9, 2), fm("Peck", "flying", 8, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Flame Charge", "fire", 50), cm("Flamethrower", "fire", 55), cm("Return", "normal", 70))),
        PvPokeEntry("torterra", "Torterra", "grass", listOf(fm("Mud Slap", "ground", 10, 3), fm("Razor Leaf", "grass", 4, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Sand Tomb", "ground", 45), cm("Frenzy Plant*", "grass", 45), cm("Stone Edge", "rock", 55), cm("Earthquake", "ground", 65))),
        PvPokeEntry("grotle", "Grotle", "grass", listOf(fm("Bite", "dark", 2, 1)), listOf(cm("Body Slam", "normal", 35), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("infernape", "Infernape", "fire", listOf(fm("Fire Spin", "fire", 10, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("monferno", "Monferno", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Flame Wheel", "fire", 55), cm("Low Sweep", "fighting", 40))),
        PvPokeEntry("empoleon", "Empoleon", "water", listOf(fm("Metal Sound", "steel", 8, 2), fm("Waterfall", "water", 10, 3), fm("Metal Claw", "steel", 7, 2), fm("Steel Wing", "steel", 5, 2)), listOf(cm("Hydro Cannon*", "water", 40), cm("Drill Peck", "flying", 40), cm("Flash Cannon", "steel", 65), cm("Blizzard", "ice", 75))),
        PvPokeEntry("prinplup", "Prinplup", "water", listOf(fm("Metal Claw", "steel", 7, 2)), listOf(cm("Bubble Beam", "water", 40), cm("Icy Wind", "ice", 45))),
        PvPokeEntry("servine", "Servine", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Grass Knot", "grass", 50), cm("Wrap", "normal", 45))),
        PvPokeEntry("emboar", "Emboar", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Blast Burn*", "fire", 50), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("pignite", "Pignite", "fire", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Flame Charge", "fire", 50), cm("Rock Tomb", "rock", 60))),
        PvPokeEntry("samurott", "Samurott", "water", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Hydro Cannon*", "water", 40), cm("Megahorn", "bug", 55), cm("Razor Shell", "water", 35))),
        PvPokeEntry("samurott_hisuian", "Samurott (Hisuian)", "water", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Snarl", "dark", 13, 3), fm("Waterfall", "water", 10, 3)), listOf(cm("Sacred Sword", "fighting", 35), cm("Razor Shell", "water", 35), cm("Icy Wind", "ice", 45), cm("Dark Pulse", "dark", 45), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("dewott", "Dewott", "water", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Aqua Tail", "water", 35), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("quilladin", "Quilladin", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Body Slam", "normal", 35), cm("Gyro Ball", "steel", 60))),
        PvPokeEntry("delphox", "Delphox", "fire", listOf(fm("Scratch", "normal", 2, 1), fm("Fire Spin", "fire", 10, 3), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Psyshock", "psychic", 40), cm("Mystical Fire", "fire", 45), cm("Blast Burn*", "fire", 50), cm("Flame Charge", "fire", 50), cm("Psychic", "psychic", 55))),
        PvPokeEntry("braixen", "Braixen", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("greninja", "Greninja", "water", listOf(fm("Water Shuriken", "water", 14, 3), fm("Bubble", "water", 11, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Hydro Cannon*", "water", 40), cm("Night Slash", "dark", 35), cm("Brutal Swing", "dark", 35), cm("Aerial Ace", "flying", 45))),
        PvPokeEntry("frogadier", "Frogadier", "water", listOf(fm("Bubble", "water", 11, 3)), listOf(cm("Surf", "water", 40), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("decidueye", "Decidueye", "grass", listOf(fm("Astonish", "ghost", 10, 3), fm("Magical Leaf", "grass", 10, 3), fm("Leafage", "grass", 7, 2)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Spirit Shackle", "ghost", 40), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("decidueye_hisuian", "Decidueye (Hisuian)", "grass", listOf(fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Aura Sphere", "fighting", 55), cm("Trailblaze", "grass", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("dartrix", "Dartrix", "grass", listOf(fm("Peck", "flying", 5, 2)), listOf(cm("Seed Bomb", "grass", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("incineroar", "Incineroar", "fire", listOf(fm("Snarl", "dark", 13, 3), fm("Double Kick", "fighting", 12, 3), fm("Fire Fang", "fire", 6, 2)), listOf(cm("Brutal Swing", "dark", 35), cm("Blaze Kick", "fire", 35), cm("Drain Punch", "fighting", 40), cm("Blast Burn*", "fire", 50), cm("Dark Pulse", "dark", 45), cm("Darkest Lariat", "dark", 60))),
        PvPokeEntry("torracat", "Torracat", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Crunch", "dark", 45))),
        PvPokeEntry("primarina", "Primarina", "water", listOf(fm("Charm", "fairy", 6, 3), fm("Waterfall", "water", 8, 3)), listOf(cm("Hydro Cannon*", "water", 40), cm("Disarming Voice", "fairy", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("brionne", "Brionne", "water", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Aqua Jet", "water", 45), cm("Disarming Voice", "fairy", 45))),
        PvPokeEntry("rillaboom", "Rillaboom", "grass", listOf(fm("Scratch", "normal", 2, 1), fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Drum Beating", "grass", 35), cm("Frenzy Plant*", "grass", 45), cm("Grass Knot", "grass", 50), cm("Earth Power", "ground", 50))),
        PvPokeEntry("cinderace", "Cinderace", "fire", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Flame Charge", "fire", 50), cm("Flamethrower", "fire", 55), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("inteleon", "Inteleon", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("meowscarada", "Meowscarada", "grass", listOf(fm("Leafage", "grass", 7, 2)), listOf(cm("Night Slash", "dark", 35), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("skeledirge", "Skeledirge", "fire", listOf(fm("Incinerate", "fire", 20, 5), fm("Hex", "ghost", 13, 3), fm("Bite", "dark", 2, 1)), listOf(cm("Disarming Voice", "fairy", 45), cm("Torch Song", "fire", 45), cm("Blast Burn*", "fire", 50), cm("Shadow Ball", "ghost", 50), cm("Crunch", "dark", 45))),
        PvPokeEntry("crocalor", "Crocalor", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Disarming Voice", "fairy", 45), cm("Crunch", "dark", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("quaquaval", "Quaquaval", "water", listOf(fm("Wing Attack", "flying", 8, 2), fm("Low Kick", "fighting", 8, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Hydro Cannon*", "water", 40), cm("Aqua Step", "water", 40), cm("Aqua Jet", "water", 40), cm("Aerial Ace", "flying", 45), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("victreebel", "Victreebel", "grass", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Magical Leaf", "grass", 10, 3), fm("Razor Leaf", "grass", 4, 2), fm("Acid", "poison", 8, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Sludge Bomb", "poison", 50), cm("Acid Spray", "poison", 45), cm("Leaf Tornado", "grass", 40))),
        PvPokeEntry("weepinbell", "Weepinbell", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Power Whip", "grass", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("vileplume", "Vileplume", "grass", listOf(fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Sludge Bomb", "poison", 50), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("bellossom", "Bellossom", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("tropius", "Tropius", "grass", listOf(fm("Air Slash", "flying", 9, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("cradily", "Cradily", "rock", listOf(fm("Bullet Seed", "grass", 13, 3), fm("Acid", "poison", 8, 2), fm("Infestation", "bug", 12, 3)), listOf(cm("Rock Tomb", "rock", 50), cm("Rock Slide", "rock", 45), cm("Grass Knot", "grass", 50), cm("Bulldoze", "ground", 55))),
        PvPokeEntry("lileep", "Lileep", "rock", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Ancient Power", "rock", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("ferrothorn", "Ferrothorn", "grass", listOf(fm("Bullet Seed", "grass", 13, 3), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Power Whip", "grass", 50), cm("Thunder", "electric", 60), cm("Mirror Shot", "steel", 35))),
        PvPokeEntry("trevenant", "Trevenant", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Seed Bomb", "grass", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("phantump", "Phantump", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("gourgeist", "Gourgeist", "ghost", listOf(fm("Incinerate", "fire", 20, 5), fm("Hex", "ghost", 13, 3), fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Seed Bomb", "grass", 40), cm("Foul Play", "dark", 40), cm("Shadow Ball", "ghost", 50), cm("Fire Blast", "fire", 80))),
        PvPokeEntry("pumpkaboo", "Pumpkaboo", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("lurantis", "Lurantis", "grass", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Leaf Blade", "grass", 35), cm("Superpower", "fighting", 40))),
        PvPokeEntry("tsareena", "Tsareena", "grass", listOf(fm("Magical Leaf", "grass", 10, 3)), listOf(cm("Triple Axel", "ice", 45), cm("High Jump Kick", "fighting", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("roserade", "Roserade", "grass", listOf(fm("Poison Sting", "poison", 9, 2), fm("Poison Jab", "poison", 7, 2), fm("Bullet Seed*", "grass", 13, 3), fm("Magical Leaf", "grass", 10, 3)), listOf(cm("Weather Ball (Fire)*", "fire", 35), cm("Grass Knot", "grass", 50), cm("Sludge Bomb", "poison", 50), cm("Leaf Storm", "grass", 55), cm("Dazzling Gleam", "fairy", 55))),
        PvPokeEntry("shiftry", "Shiftry", "grass", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Foul Play", "dark", 45), cm("Hurricane", "flying", 65))),
        PvPokeEntry("cacturne", "Cacturne", "grass", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Grass Knot", "grass", 50), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("whimsicott", "Whimsicott", "grass", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Seed Bomb", "grass", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("cottonee", "Cottonee", "grass", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Grass Knot", "grass", 50)))
    )

    private fun loadPokemonChunk4(): List<PvPokeEntry> = listOf(
        PvPokeEntry("amoonguss", "Amoonguss", "grass", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Grass Knot", "grass", 50), cm("Foul Play", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("tangrowth", "Tangrowth", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Power Whip", "grass", 50))),
        PvPokeEntry("sunflora", "Sunflora", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Leaf Storm", "grass", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("cherrim", "Cherrim", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("wormadam_trash", "Wormadam (Trash)", "bug", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Confusion", "psychic", 14, 4), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Psybeam", "psychic", 60), cm("Iron Head", "steel", 50), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("wormadam_plant", "Wormadam (Plant)", "bug", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Confusion", "psychic", 14, 4), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Energy Ball", "grass", 45), cm("Psybeam", "psychic", 60), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("forretress", "Forretress", "bug", listOf(fm("Volt Switch", "electric", 16, 4), fm("Bug Bite", "bug", 3, 1), fm("Struggle Bug", "bug", 8, 3)), listOf(cm("Sand Tomb", "ground", 45), cm("Rock Tomb", "rock", 50), cm("Mirror Shot", "steel", 35), cm("Earthquake", "ground", 65), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("scizor", "Scizor", "bug", listOf(fm("Bullet Punch", "steel", 7, 2), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Night Slash", "dark", 35), cm("Iron Head", "steel", 50), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("scyther", "Scyther", "bug", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Night Slash", "dark", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("kleavor", "Kleavor", "bug", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Quick Attack", "normal", 8, 2), fm("Smack Down", "rock", 8, 3), fm("Air Slash", "flying", 9, 3)), listOf(cm("X-Scissor", "bug", 40), cm("Rock Slide", "rock", 45), cm("Trailblaze", "grass", 45), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("pinsir", "Pinsir", "bug", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("X-Scissor", "bug", 40), cm("Close Combat", "fighting", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("heracross", "Heracross", "bug", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Counter", "fighting", 6, 2), fm("Struggle Bug", "bug", 8, 3)), listOf(cm("Rock Blast", "rock", 40), cm("Upper Hand", "fighting", 40), cm("Close Combat", "fighting", 45), cm("Rock Tomb", "rock", 50), cm("Megahorn", "bug", 55))),
        PvPokeEntry("escavalier", "Escavalier", "bug", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Drill Run", "ground", 45), cm("Megahorn", "bug", 55), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("shelmet", "Shelmet", "bug", listOf(fm("Infestation", "bug", 12, 3)), listOf(cm("Body Slam", "normal", 35), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("accelgor", "Accelgor", "bug", listOf(fm("Water Shuriken", "water", 14, 3)), listOf(cm("Body Slam", "normal", 35), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("galvantula", "Galvantula", "bug", listOf(fm("Volt Switch", "electric", 16, 4), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Lunge", "bug", 45), cm("Discharge", "electric", 45), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("ariados", "Ariados", "bug", listOf(fm("Poison Sting", "poison", 9, 2), fm("Infestation", "bug", 12, 3)), listOf(cm("Foul Play", "dark", 40), cm("Lunge", "bug", 45), cm("Trailblaze", "grass", 45), cm("Cross Poison", "poison", 35), cm("Megahorn", "bug", 55))),
        PvPokeEntry("beedrill", "Beedrill", "bug", listOf(fm("Poison Sting", "poison", 9, 2), fm("Poison Jab", "poison", 7, 2), fm("Bug Bite*", "bug", 3, 1), fm("Infestation", "bug", 12, 3)), listOf(cm("Drill Run*", "ground", 40), cm("X-Scissor", "bug", 40), cm("Fell Stinger", "bug", 35), cm("Sludge Bomb", "poison", 50), cm("Aerial Ace", "flying", 45))),
        PvPokeEntry("venomoth", "Venomoth", "bug", listOf(fm("Psywave", "psychic", 4, 1), fm("Confusion", "psychic", 14, 4), fm("Infestation", "bug", 12, 3), fm("Bug Bite*", "bug", 3, 1)), listOf(cm("Poison Fang", "poison", 40), cm("Silver Wind", "bug", 45), cm("Psychic", "psychic", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("ledian", "Ledian", "bug", listOf(fm("Counter", "fighting", 6, 2), fm("Rollout", "rock", 13, 3), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Aerial Ace", "flying", 45), cm("Acrobatics", "flying", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("yanmega", "Yanmega", "bug", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Ancient Power", "rock", 45), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("leavanny", "Leavanny", "bug", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("scolipede", "Scolipede", "bug", listOf(fm("Poison Sting", "poison", 9, 2), fm("Poison Jab", "poison", 7, 2)), listOf(cm("Aqua Tail", "water", 35), cm("X-Scissor", "bug", 40), cm("Sludge Bomb", "poison", 50), cm("Megahorn", "bug", 55))),
        PvPokeEntry("crustle", "Crustle", "bug", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Smack Down", "rock", 8, 3)), listOf(cm("X-Scissor", "bug", 40), cm("Rock Slide", "rock", 45), cm("Rock Wrecker", "rock", 50), cm("Rock Blast", "rock", 40))),
        PvPokeEntry("durant", "Durant", "bug", listOf(fm("Metal Claw", "steel", 7, 2)), listOf(cm("X-Scissor", "bug", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("genesect", "Genesect", "bug", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Techno Blast", "normal", 55), cm("X-Scissor", "bug", 40), cm("Magnet Bomb", "steel", 45))),
        PvPokeEntry("araquanid", "Araquanid", "water", listOf(fm("Infestation", "bug", 12, 3), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Water Pulse", "water", 50), cm("Mirror Coat", "psychic", 45), cm("Bug Buzz", "bug", 60), cm("Bubble Beam", "water", 50))),
        PvPokeEntry("dewpider", "Dewpider", "water", listOf(fm("Bug Bite", "bug", 3, 1), fm("Infestation", "bug", 12, 3)), listOf(cm("Water Pulse", "water", 50), cm("Mirror Coat", "psychic", 45), cm("Bubble Beam", "water", 50))),
        PvPokeEntry("golisopod", "Golisopod", "bug", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Fury Cutter", "bug", 4, 1), fm("Waterfall", "water", 8, 3)), listOf(cm("Liquidation", "water", 45), cm("X-Scissor", "bug", 40), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("charjabug", "Charjabug", "bug", listOf(fm("Volt Switch", "electric", 16, 4), fm("Bug Bite", "bug", 3, 1)), listOf(cm("X-Scissor", "bug", 40), cm("Discharge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("vikavolt", "Vikavolt", "bug", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Fly", "flying", 45), cm("Discharge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("ribombee", "Ribombee", "bug", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Charm", "fairy", 8, 3), fm("Struggle Bug", "bug", 8, 3)), listOf(cm("Moonblast", "fairy", 50), cm("Dazzling Gleam", "fairy", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("lokix", "Lokix", "bug", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Trailblaze", "grass", 45), cm("X-Scissor", "bug", 40), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("buzzwole", "Buzzwole", "bug", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Lunge", "bug", 45), cm("Superpower", "fighting", 40), cm("Power-Up Punch", "fighting", 35))),
        PvPokeEntry("machamp", "Machamp", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Karate Chop", "fighting", 9, 2), fm("Bullet Punch", "steel", 7, 2)), listOf(cm("Cross Chop", "fighting", 35), cm("Rock Slide", "rock", 45), cm("Payback", "dark", 60))),
        PvPokeEntry("machoke", "Machoke", "fighting", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Cross Chop", "fighting", 35), cm("Brick Break", "fighting", 40), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("hariyama", "Hariyama", "fighting", listOf(fm("Force Palm", "fighting", 13, 3)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Upper Hand", "fighting", 40), cm("Superpower", "fighting", 40))),
        PvPokeEntry("hitmonchan", "Hitmonchan", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Thunder Punch", "electric", 40), cm("Fire Punch", "fire", 40), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("hitmontop", "Hitmontop", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Triple Axel", "ice", 45), cm("Close Combat", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("hitmonlee", "Hitmonlee", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("poliwrath", "Poliwrath", "water", listOf(fm("Counter", "fighting", 6, 2), fm("Mud Shot", "ground", 9, 2), fm("Bubble", "water", 11, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Scald", "water", 55), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("politoed", "Politoed", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Earthquake", "ground", 65), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("toxicroak", "Toxicroak", "poison", listOf(fm("Poison Sting", "poison", 9, 2), fm("Mud Shot", "ground", 9, 2), fm("Counter", "fighting", 6, 2), fm("Poison Jab", "poison", 7, 2)), listOf(cm("Mud Bomb", "ground", 45), cm("Drain Punch", "fighting", 40), cm("Dynamic Punch", "fighting", 45), cm("Shadow Ball", "ghost", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("sneasler", "Sneasler", "fighting", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Poison Jab", "poison", 7, 2), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("sneasel_hisuian", "Sneasel (Hisuian)", "fighting", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("sneasel", "Sneasel", "dark", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Avalanche", "ice", 45), cm("Triple Axel", "ice", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("weavile", "Weavile", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Triple Axel", "ice", 45), cm("Avalanche", "ice", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("sirfetchd", "Sirfetch'd", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Night Slash", "dark", 35), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("lucario", "Lucario", "fighting", listOf(fm("Force Palm", "fighting", 13, 3), fm("Counter", "fighting", 6, 2), fm("Bullet Punch", "steel", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Shadow Ball", "ghost", 55), cm("Power-Up Punch", "fighting", 35))),
        PvPokeEntry("gallade", "Gallade", "psychic", listOf(fm("Low Kick", "fighting", 8, 2), fm("Psycho Cut", "psychic", 9, 2), fm("Confusion", "psychic", 14, 4), fm("Charm", "fairy", 8, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Sacred Sword", "fighting", 35), cm("Close Combat", "fighting", 45), cm("Synchronoise*", "psychic", 50), cm("Psychic", "psychic", 55))),
        PvPokeEntry("gardevoir", "Gardevoir", "psychic", listOf(fm("Charm", "fairy", 6, 3), fm("Confusion", "psychic", 12, 4)), listOf(cm("Shadow Ball", "ghost", 55), cm("Triple Axel", "ice", 45), cm("Synchronoise", "psychic", 50))),
        PvPokeEntry("conkeldurr", "Conkeldurr", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Brutal Swing", "dark", 40), cm("Dynamic Punch", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("gurdurr", "Gurdurr", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("throh", "Throh", "fighting", listOf(fm("Low Kick", "fighting", 5, 2)), listOf(cm("Body Slam", "normal", 35), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("sawk", "Sawk", "fighting", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Body Slam", "normal", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("mienfoo", "Mienfoo", "fighting", listOf(fm("Force Palm", "fighting", 13, 3)), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("mienshao", "Mienshao", "fighting", listOf(fm("Force Palm", "fighting", 13, 3)), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55), cm("Blaze Kick", "fire", 40))),
        PvPokeEntry("hawlucha", "Hawlucha", "fighting", listOf(fm("Wing Attack", "flying", 8, 2), fm("Poison Jab", "poison", 7, 2), fm("Low Kick", "fighting", 5, 2)), listOf(cm("Flying Press", "fighting", 40), cm("Sky Attack", "flying", 55), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("bewear", "Bewear", "normal", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Low Kick", "fighting", 8, 2), fm("Tackle", "normal", 3, 1)), listOf(cm("Superpower", "fighting", 40), cm("Drain Punch*", "fighting", 40), cm("Stomp", "normal", 40), cm("Payback", "dark", 60))),
        PvPokeEntry("stufful", "Stufful", "normal", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Superpower", "fighting", 40))),
        PvPokeEntry("passimian", "Passimian", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Brutal Swing", "dark", 35), cm("Drain Punch", "fighting", 40), cm("Superpower", "fighting", 40), cm("Brick Break", "fighting", 40), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("falinks", "Falinks", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Superpower", "fighting", 40), cm("Brick Break", "fighting", 40), cm("Megahorn", "bug", 55))),
        PvPokeEntry("pawmot", "Pawmot", "electric", listOf(fm("Spark", "electric", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Close Combat", "fighting", 45), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("pawmo", "Pawmo", "electric", listOf(fm("Spark", "electric", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Discharge", "electric", 45))),
        PvPokeEntry("jellicent", "Jellicent", "water", listOf(fm("Hex", "ghost", 11, 3), fm("Bubble", "water", 11, 3)), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55), cm("Bubble Beam", "water", 40)))
    )

    private fun loadPokemonChunk5(): List<PvPokeEntry> = listOf(
        PvPokeEntry("frillish", "Frillish", "water", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Ominous Wind", "ghost", 45), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("gengar", "Gengar", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Hex", "ghost", 13, 3), fm("Sucker Punch", "dark", 7, 2), fm("Lick*", "ghost", 3, 1)), listOf(cm("Shadow Punch*", "ghost", 35), cm("Drain Punch", "fighting", 40), cm("Shadow Ball", "ghost", 50), cm("Sludge Bomb", "poison", 50), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("haunter", "Haunter", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Astonish", "ghost", 10, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Sludge Bomb", "poison", 50), cm("Ice Punch", "ice", 40))),
        PvPokeEntry("drifblim", "Drifblim", "ghost", listOf(fm("Astonish", "ghost", 10, 3), fm("Hex", "ghost", 11, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Mystical Fire", "fire", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("froslass", "Froslass", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Hex", "ghost", 11, 3)), listOf(cm("Avalanche", "ice", 45), cm("Triple Axel", "ice", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("spiritomb", "Spiritomb", "ghost", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Rock Tomb", "rock", 50), cm("Ominous Wind", "ghost", 45), cm("Shadow Ball", "ghost", 50), cm("Shadow Sneak", "ghost", 50))),
        PvPokeEntry("dusknoir", "Dusknoir", "ghost", listOf(fm("Astonish", "ghost", 10, 3), fm("Hex", "ghost", 13, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Dynamic Punch", "fighting", 45), cm("Shadow Ball*", "ghost", 50), cm("Dark Pulse", "dark", 45), cm("Poltergeist", "ghost", 75))),
        PvPokeEntry("dusclops", "Dusclops", "ghost", listOf(fm("Hex", "ghost", 13, 3), fm("Astonish", "ghost", 10, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Shadow Punch", "ghost", 35), cm("Poltergeist", "ghost", 75))),
        PvPokeEntry("banette", "Banette", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Shadow Ball", "ghost", 55), cm("Thunder", "electric", 60), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("mismagius", "Mismagius", "ghost", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Hex", "ghost", 13, 3), fm("Astonish", "ghost", 10, 3)), listOf(cm("Mystical Fire", "fire", 45), cm("Shadow Ball", "ghost", 50), cm("Dazzling Gleam", "fairy", 55), cm("Dark Pulse", "dark", 45))),
        PvPokeEntry("misdreavus", "Misdreavus", "ghost", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Ominous Wind", "ghost", 45), cm("Shadow Sneak", "ghost", 45))),
        PvPokeEntry("cofagrigus", "Cofagrigus", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Astonish", "ghost", 10, 3)), listOf(cm("Shadow Ball", "ghost", 50), cm("Energy Ball", "grass", 45), cm("Dark Pulse", "dark", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("runerigus", "Runerigus", "ground", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Brutal Swing", "dark", 40), cm("Sand Tomb", "ground", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("chandelure", "Chandelure", "ghost", listOf(fm("Astonish", "ghost", 10, 3), fm("Incinerate", "fire", 20, 5), fm("Hex", "ghost", 13, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 50), cm("Poltergeist*", "ghost", 75), cm("Overheat", "fire", 55), cm("Energy Ball", "grass", 45))),
        PvPokeEntry("lampent", "Lampent", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("golurk", "Golurk", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Earth Power", "ground", 55), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("golett", "Golett", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("aegislash", "Aegislash", "steel", listOf(fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Shadow Ball", "ghost", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("palossand", "Palossand", "ghost", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Scorching Sands", "ground", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("mimikyu", "Mimikyu", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Play Rough", "fairy", 60), cm("Shadow Sneak", "ghost", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("gholdengo", "Gholdengo", "steel", listOf(fm("Hex", "ghost", 13, 3), fm("Astonish", "ghost", 10, 3)), listOf(cm("Shadow Ball", "ghost", 50), cm("Power Gem", "rock", 50), cm("Dazzling Gleam", "fairy", 55), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("houndstone", "Houndstone", "ghost", listOf(fm("Lick", "ghost", 3, 1), fm("Bite", "dark", 2, 1)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Shadow Ball", "ghost", 50), cm("Dig", "ground", 50), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("ceruledge", "Ceruledge", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("armarouge", "Armarouge", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("hypno", "Hypno", "psychic", listOf(fm("Confusion", "psychic", 12, 4), fm("Psywave", "psychic", 4, 1)), listOf(cm("Thunder Punch", "electric", 40), cm("Ice Punch", "ice", 40), cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("alakazam", "Alakazam", "psychic", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowbro", "Slowbro", "water", listOf(fm("Confusion", "psychic", 14, 4), fm("Water Gun", "water", 3, 1)), listOf(cm("Surf*", "water", 45), cm("Drain Punch", "fighting", 40), cm("Scald", "water", 50), cm("Ice Beam", "ice", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowbro_galarian", "Slowbro (Galarian)", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Confusion", "psychic", 12, 4)), listOf(cm("Brutal Swing", "dark", 40), cm("Surf", "water", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("slowking", "Slowking", "water", listOf(fm("Confusion", "psychic", 12, 4), fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Blizzard", "ice", 75), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowking_galarian", "Slowking (Galarian)", "poison", listOf(fm("Hex", "ghost", 13, 3), fm("Confusion", "psychic", 14, 4), fm("Acid", "poison", 8, 2)), listOf(cm("Psyshock", "psychic", 40), cm("Surf", "water", 45), cm("Shadow Ball", "ghost", 50), cm("Sludge Wave", "poison", 65), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("starmie", "Starmie", "water", listOf(fm("Psywave", "psychic", 4, 1), fm("Quick Attack", "normal", 8, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 45), cm("Aqua Jet", "water", 40), cm("Power Gem", "rock", 50), cm("Ice Beam", "ice", 55), cm("Psychic", "psychic", 55), cm("Thunder", "electric", 60))),
        PvPokeEntry("mr._mime", "Mr. Mime", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psybeam", "psychic", 60), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("mr._rime", "Mr. Rime", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Triple Axel", "ice", 45), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("xatu", "Xatu", "psychic", listOf(fm("Peck", "flying", 8, 2), fm("Air Slash", "flying", 9, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Psyshock", "psychic", 40), cm("Aerial Ace", "flying", 45), cm("Shadow Ball", "ghost", 50), cm("Ominous Wind", "ghost", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("wobbuffet", "Wobbuffet", "psychic", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Mirror Coat", "psychic", 55), cm("Return", "normal", 70))),
        PvPokeEntry("grumpig", "Grumpig", "psychic", listOf(fm("Psywave", "psychic", 4, 1)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Shadow Ball", "ghost", 55), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("spoink", "Spoink", "psychic", listOf(fm("Splash", "water", 12, 4)), listOf(cm("Mirror Coat", "psychic", 55), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("claydol", "Claydol", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Scorching Sands", "ground", 50), cm("Ice Beam", "ice", 55), cm("Rock Tomb", "rock", 60), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("bronzong", "Bronzong", "steel", listOf(fm("Confusion", "psychic", 14, 4), fm("Metal Sound", "steel", 8, 2), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Psyshock", "psychic", 40), cm("Bulldoze", "ground", 55), cm("Payback", "dark", 60), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("bronzor", "Bronzor", "steel", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Psyshock", "psychic", 45), cm("Payback", "dark", 60), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("chimecho", "Chimecho", "psychic", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Psyshock", "psychic", 45), cm("Shadow Ball", "ghost", 55), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("jirachi", "Jirachi", "steel", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Doom Desire", "steel", 40), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("victini", "Victini", "psychic", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("V-create", "fire", 40), cm("Psyshock", "psychic", 45), cm("Overheat", "fire", 55))),
        PvPokeEntry("mew", "Mew", "psychic", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Volt Switch", "electric", 16, 4), fm("Snarl", "dark", 13, 3), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Surf", "water", 40), cm("Wild Charge", "electric", 45), cm("Psyshock", "psychic", 45), cm("Flame Charge", "fire", 50))),
        PvPokeEntry("celebi", "Celebi", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Seed Bomb", "grass", 45), cm("Leaf Storm", "grass", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("gothorita", "Gothorita", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psyshock", "psychic", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("gothitelle", "Gothitelle", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Rock Slide", "rock", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("reuniclus", "Reuniclus", "psychic", listOf(fm("Charm*", "fairy", 8, 3), fm("Hidden Power", "normal", 8, 3), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Psyshock", "psychic", 40), cm("Shadow Ball", "ghost", 50), cm("Thunder", "electric", 60), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("beheeyem", "Beheeyem", "psychic", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Psychic", "psychic", 55), cm("Rock Slide", "rock", 45), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("meowstic", "Meowstic", "psychic", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Psyshock", "psychic", 45), cm("Energy Ball", "grass", 55), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("hatterene", "Hatterene", "psychic", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Psyshock", "psychic", 45), cm("Power Whip", "grass", 50))),
        PvPokeEntry("rapidash_galarian", "Rapidash (Galarian)", "psychic", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Body Slam", "normal", 35), cm("Play Rough", "fairy", 60), cm("Megahorn", "bug", 55))),
        PvPokeEntry("rapidash", "Rapidash", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Drill Run", "ground", 45), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("granbull", "Granbull", "fairy", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Crunch", "dark", 45), cm("Close Combat", "fighting", 45), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("snubbull", "Snubbull", "fairy", listOf(fm("Bite", "dark", 2, 1)), listOf(cm("Crunch", "dark", 45), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("togetic", "Togetic", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Steel Wing", "steel", 5, 2)), listOf(cm("Psyshock", "psychic", 40), cm("Aerial Ace", "flying", 45), cm("Heat Wave", "fire", 45), cm("Ancient Power", "rock", 45), cm("Draining Kiss", "fairy", 55), cm("Dazzling Gleam", "fairy", 55))),
        PvPokeEntry("togekiss", "Togekiss", "fairy", listOf(fm("Peck", "flying", 8, 2), fm("Charm", "fairy", 8, 3), fm("Air Slash", "flying", 9, 3)), listOf(cm("Psyshock", "psychic", 40), cm("Aura Sphere*", "fighting", 40), cm("Ancient Power", "rock", 45), cm("Aerial Ace", "flying", 45), cm("Flamethrower", "fire", 55), cm("Dazzling Gleam", "fairy", 55))),
        PvPokeEntry("mawile", "Mawile", "steel", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Fire Fang", "fire", 6, 2), fm("Ice Fang", "ice", 6, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Power-Up Punch", "fighting", 35), cm("Vise Grip", "normal", 40), cm("Iron Head", "steel", 50), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("slurpuff", "Slurpuff", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Flamethrower", "fire", 55), cm("Play Rough", "fairy", 60), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("aromatisse", "Aromatisse", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Charm", "fairy", 8, 3), fm("Charge Beam", "electric", 11, 3)), listOf(cm("Psyshock", "psychic", 40), cm("Draining Kiss", "fairy", 55), cm("Moonblast", "fairy", 50), cm("Thunderbolt", "electric", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("florges", "Florges", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Vine Whip", "grass", 8, 2)), listOf(cm("Chilling Water*", "water", 45), cm("Trailblaze", "grass", 45), cm("Disarming Voice", "fairy", 45), cm("Moonblast", "fairy", 50), cm("Petal Blizzard", "grass", 65))),
        PvPokeEntry("floette", "Floette", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Brick Break", "fighting", 40), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("dedenne", "Dedenne", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Discharge", "electric", 45), cm("Play Rough", "fairy", 60), cm("Parabolic Charge", "electric", 55))),
        PvPokeEntry("klefki", "Klefki", "steel", listOf(fm("Astonish", "ghost", 10, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Foul Play", "dark", 40), cm("Draining Kiss", "fairy", 55), cm("Play Rough", "fairy", 60), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("shiinotic", "Shiinotic", "grass", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Moonblast", "fairy", 60)))
    )

    private fun loadPokemonChunk6(): List<PvPokeEntry> = listOf(
        PvPokeEntry("tapu_fini", "Tapu Fini", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Nature's Madness", "fairy", 50), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("tinkaton", "Tinkaton", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Play Rough", "fairy", 60), cm("Heavy Slam", "steel", 50), cm("Bulldoze", "ground", 55), cm("Gigaton Hammer", "steel", 60), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("grimmsnarl", "Grimmsnarl", "dark", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Low Kick", "fighting", 8, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Foul Play", "dark", 40), cm("Draining Kiss", "fairy", 55), cm("Play Rough", "fairy", 60), cm("Power-Up Punch", "fighting", 35), cm("Dark Pulse", "dark", 45))),
        PvPokeEntry("ampharos", "Ampharos", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Brutal Swing", "dark", 40), cm("Trailblaze", "grass", 45), cm("Thunder Punch", "electric", 40), cm("Zap Cannon", "electric", 80))),
        PvPokeEntry("raichu", "Raichu", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Thunder Shock", "electric", 9, 2), fm("Charm", "fairy", 8, 3), fm("Spark", "electric", 7, 2)), listOf(cm("Volt Tackle", "electric", 40), cm("Surf", "water", 45), cm("Trailblaze", "grass", 45), cm("Brick Break", "fighting", 40), cm("Wild Charge", "electric", 45), cm("Thunder Punch", "electric", 40))),
        PvPokeEntry("raichu_alolan", "Raichu (Alolan)", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Thunder Shock", "electric", 9, 2), fm("Spark", "electric", 7, 2)), listOf(cm("Volt Tackle", "electric", 40), cm("Surf", "water", 45), cm("Psyshock", "psychic", 40), cm("Trailblaze", "grass", 45), cm("Thunder Punch", "electric", 40), cm("Wild Charge", "electric", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("pikachu", "Pikachu", "electric", listOf(fm("Thunder Shock", "electric", 9, 2), fm("Quick Attack", "normal", 8, 2), fm("Charm", "fairy", 8, 3)), listOf(cm("Volt Tackle", "electric", 40), cm("Surf*", "water", 45), cm("Fly*", "flying", 45), cm("Wild Charge", "electric", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("magneton", "Magneton", "electric", listOf(fm("Thunder Shock", "electric", 9, 2), fm("Spark", "electric", 7, 2)), listOf(cm("Magnet Bomb", "steel", 45), cm("Discharge", "electric", 45), cm("Zap Cannon", "electric", 80))),
        PvPokeEntry("magnezone", "Magnezone", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Spark", "electric", 7, 2)), listOf(cm("Mirror Shot", "steel", 35), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("electrode", "Electrode", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Discharge", "electric", 45), cm("Foul Play", "dark", 45), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("electrode_hisuian", "Electrode (Hisuian)", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Energy Ball", "grass", 55), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("electabuzz", "Electabuzz", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Flamethrower", "fire", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("electivire", "Electivire", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Wild Charge", "electric", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("luxray", "Luxray", "electric", listOf(fm("Spark", "electric", 7, 2)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("pachirisu", "Pachirisu", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Spark", "electric", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Hyper Fang", "normal", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("emolga", "Emolga", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Acrobatics", "flying", 60), cm("Discharge", "electric", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("eelektross", "Eelektross", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Dragon Claw", "dragon", 35), cm("Liquidation", "water", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("heliolisk", "Heliolisk", "electric", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Grass Knot", "grass", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("togedemaru", "Togedemaru", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Fell Stinger", "bug", 35), cm("Wild Charge", "electric", 45), cm("Gyro Ball", "steel", 60))),
        PvPokeEntry("bellibolt", "Bellibolt", "electric", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Thunder Shock", "electric", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Discharge", "electric", 40), cm("Parabolic Charge", "electric", 50), cm("Water Pulse", "water", 50), cm("Zap Cannon", "electric", 80))),
        PvPokeEntry("lapras", "Lapras", "water", listOf(fm("Psywave", "psychic", 4, 1), fm("Ice Shard*", "ice", 10, 3), fm("Water Gun", "water", 3, 1), fm("Frost Breath", "ice", 5, 2)), listOf(cm("Sparkling Aria", "water", 45), cm("Surf", "water", 45), cm("Ice Beam*", "ice", 55), cm("Skull Bash", "normal", 75), cm("Dragon Pulse*", "dragon", 55))),
        PvPokeEntry("sealeo", "Sealeo", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Body Slam", "normal", 40), cm("Surf", "water", 45), cm("Water Pulse", "water", 50), cm("Aurora Beam", "ice", 60))),
        PvPokeEntry("walrein", "Walrein", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Waterfall", "water", 8, 3)), listOf(cm("Icicle Spear", "ice", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("cloyster", "Cloyster", "water", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Liquidation", "water", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("seaking", "Seaking", "water", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Drill Run", "ground", 45))),
        PvPokeEntry("gyarados", "Gyarados", "water", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45))),
        PvPokeEntry("kingler", "Kingler", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("X-Scissor", "bug", 40), cm("Crabhammer", "water", 50), cm("Razor Shell", "water", 35))),
        PvPokeEntry("crawdaunt", "Crawdaunt", "water", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Night Slash", "dark", 35), cm("Crabhammer", "water", 50))),
        PvPokeEntry("sharpedo", "Sharpedo", "water", listOf(fm("Waterfall", "water", 8, 3)), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("tentacruel", "Tentacruel", "water", listOf(fm("Poison Sting", "poison", 9, 2), fm("Poison Jab", "poison", 7, 2), fm("Acid", "poison", 8, 2)), listOf(cm("Scald", "water", 50), cm("Acid Spray", "poison", 45), cm("Payback", "dark", 60), cm("Sludge Wave", "poison", 65), cm("Blizzard", "ice", 75))),
        PvPokeEntry("golduck", "Golduck", "water", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Cross Chop", "fighting", 35), cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("ludicolo", "Ludicolo", "water", listOf(fm("Astonish", "ghost", 10, 3), fm("Bubble", "water", 11, 3), fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Energy Ball", "grass", 45), cm("Leaf Storm", "grass", 55), cm("Ice Beam", "ice", 55), cm("Scald", "water", 50))),
        PvPokeEntry("lombre", "Lombre", "water", listOf(fm("Bubble", "water", 11, 3)), listOf(cm("Ice Beam", "ice", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("seismitoad", "Seismitoad", "water", listOf(fm("Mud Shot", "ground", 9, 2), fm("Bubble", "water", 11, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Earth Power", "ground", 50), cm("Muddy Water", "water", 35), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("palpitoad", "Palpitoad", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Mud Bomb", "ground", 40), cm("Earth Power", "ground", 55))),
        PvPokeEntry("carracosta", "Carracosta", "water", listOf(fm("Rock Throw", "rock", 5, 2)), listOf(cm("Body Slam", "normal", 35), cm("Surf", "water", 40), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("swanna", "Swanna", "water", listOf(fm("Gust", "flying", 14, 4), fm("Wing Attack", "flying", 8, 2), fm("Air Slash", "flying", 9, 3), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Jet", "water", 40), cm("Fly", "flying", 45), cm("Bubble Beam", "water", 50), cm("Ice Beam", "ice", 55), cm("Hurricane", "flying", 60))),
        PvPokeEntry("alomomola", "Alomomola", "water", listOf(fm("Waterfall", "water", 8, 3)), listOf(cm("Psychic", "psychic", 55), cm("Blizzard", "ice", 75))),
        PvPokeEntry("barbaracle", "Barbaracle", "rock", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Cross Chop", "fighting", 35), cm("Stone Edge", "rock", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("bruxish", "Bruxish", "water", listOf(fm("Confusion", "psychic", 14, 4), fm("Water Gun", "water", 3, 1), fm("Bite", "dark", 2, 1)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Aqua Tail", "water", 35), cm("Psyshock", "psychic", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("dondozo", "Dondozo", "water", listOf(fm("Waterfall", "water", 10, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 40), cm("Surf", "water", 45), cm("Liquidation", "water", 45), cm("Outrage", "dragon", 60), cm("Hydro Pump", "water", 75))),
        PvPokeEntry("basculegion", "Basculegion", "water", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Aqua Jet", "water", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("gligar", "Gligar", "ground", listOf(fm("Wing Attack", "flying", 8, 2), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Aerial Ace", "flying", 40), cm("Dig", "ground", 50), cm("Night Slash", "dark", 35))),
        PvPokeEntry("gliscor", "Gliscor", "ground", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Sand Attack", "ground", 4, 1), fm("Wing Attack", "flying", 8, 2)), listOf(cm("Night Slash", "dark", 35), cm("Sand Tomb", "ground", 45), cm("Acrobatics", "flying", 55), cm("Earthquake", "ground", 65))),
        PvPokeEntry("steelix", "Steelix", "steel", listOf(fm("Thunder Fang", "electric", 5, 2), fm("Dragon Tail", "dragon", 9, 3), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Breaking Swipe", "dragon", 35), cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("onix", "Onix", "rock", listOf(fm("Rock Throw", "rock", 5, 2)), listOf(cm("Sand Tomb", "ground", 40), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("donphan", "Donphan", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Body Slam", "normal", 35), cm("Trailblaze", "grass", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("hippowdon", "Hippowdon", "ground", listOf(fm("Sand Attack", "ground", 4, 1)), listOf(cm("Weather Ball (Rock)", "rock", 35), cm("Scorching Sands", "ground", 50), cm("Body Slam", "normal", 35))),
        PvPokeEntry("rhydon", "Rhydon", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Surf", "water", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("rhyperior", "Rhyperior", "ground", listOf(fm("Mud Slap", "ground", 10, 3), fm("Smack Down", "rock", 8, 3)), listOf(cm("Drill Run", "ground", 40), cm("Breaking Swipe", "dragon", 50), cm("Surf", "water", 45), cm("Rock Wrecker*", "rock", 50), cm("Superpower", "fighting", 40))),
        PvPokeEntry("excadrill", "Excadrill", "ground", listOf(fm("Mud Shot", "ground", 9, 2), fm("Mud Slap", "ground", 10, 3), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Drill Run", "ground", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("krookodile", "Krookodile", "ground", listOf(fm("Mud Slap", "ground", 10, 3), fm("Snarl", "dark", 13, 3)), listOf(cm("Brick Break", "fighting", 40), cm("Sand Tomb", "ground", 45), cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65), cm("Outrage", "dragon", 60))),
        PvPokeEntry("mamoswine", "Mamoswine", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Mud Slap", "ground", 10, 3)), listOf(cm("Icicle Spear", "ice", 40), cm("Avalanche", "ice", 45), cm("High Horsepower", "ground", 55), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("piloswine", "Piloswine", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Ice Shard", "ice", 10, 3)), listOf(cm("Icicle Spear", "ice", 40), cm("Avalanche", "ice", 45), cm("High Horsepower", "ground", 55), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("swinub", "Swinub", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Body Slam", "normal", 35))),
        PvPokeEntry("avalugg", "Avalugg", "ice", listOf(fm("Ice Fang", "ice", 6, 2)), listOf(cm("Body Slam", "normal", 35), cm("Icy Wind", "ice", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("avalugg_hisuian", "Avalugg (Hisuian)", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Rock Slide", "rock", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("aurorus", "Aurorus", "rock", listOf(fm("Powder Snow", "ice", 8, 2), fm("Rock Throw", "rock", 5, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Meteor Beam", "rock", 60), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("amaura", "Amaura", "rock", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("beartic", "Beartic", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Surf", "water", 40))),
        PvPokeEntry("cryogonal", "Cryogonal", "ice", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Triple Axel", "ice", 45), cm("Night Slash", "dark", 35), cm("Water Pulse", "water", 55))),
        PvPokeEntry("cetitan", "Cetitan", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Ice Shard", "ice", 10, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Icicle Spear", "ice", 40), cm("Body Slam", "normal", 40), cm("Superpower", "fighting", 40), cm("Avalanche", "ice", 45), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("golem", "Golem", "rock", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Rock Blast", "rock", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("golem_alolan", "Golem (Alolan)", "rock", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Rock Blast", "rock", 40), cm("Wild Charge", "electric", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("graveler", "Graveler", "rock", listOf(fm("Mud Slap", "ground", 10, 3), fm("Rock Throw", "rock", 5, 2)), listOf(cm("Rock Blast", "rock", 40), cm("Dig", "ground", 50), cm("Stone Edge", "rock", 55)))
    )

    private fun loadPokemonChunk7(): List<PvPokeEntry> = listOf(
        PvPokeEntry("graveler_alolan", "Graveler (Alolan)", "rock", listOf(fm("Volt Switch", "electric", 16, 4), fm("Rock Throw", "rock", 5, 2)), listOf(cm("Rock Blast", "rock", 40), cm("Stone Edge", "rock", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("sudowoodo", "Sudowoodo", "rock", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Trailblaze", "grass", 45), cm("Meteor Beam", "rock", 60))),
        PvPokeEntry("magcargo", "Magcargo", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Rock Tomb", "rock", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("lairon", "Lairon", "steel", listOf(fm("Metal Sound", "steel", 8, 2), fm("Metal Claw", "steel", 7, 2), fm("Iron Tail", "steel", 7, 3)), listOf(cm("Body Slam", "normal", 40), cm("Rock Slide", "rock", 45), cm("Rock Tomb", "rock", 50), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("aggron", "Aggron", "steel", listOf(fm("Metal Sound", "steel", 8, 2), fm("Smack Down", "rock", 8, 3), fm("Dragon Tail", "dragon", 12, 3), fm("Iron Tail", "steel", 7, 3)), listOf(cm("Brick Break", "fighting", 40), cm("Rock Tomb", "rock", 50), cm("Heavy Slam", "steel", 50), cm("Meteor Beam", "rock", 60), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("rampardos", "Rampardos", "rock", listOf(fm("Smack Down", "rock", 8, 3)), listOf(cm("Rock Slide", "rock", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("archeops", "Archeops", "rock", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Dragon Claw", "dragon", 35), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("gigalith", "Gigalith", "rock", listOf(fm("Lock On", "normal", 5, 1), fm("Smack Down", "rock", 8, 3), fm("Mud Slap", "ground", 10, 3)), listOf(cm("Superpower", "fighting", 40), cm("Rock Slide", "rock", 45), cm("Meteor Beam*", "rock", 60), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("tyrantrum", "Tyrantrum", "rock", listOf(fm("Dragon Tail", "dragon", 12, 3), fm("Rock Throw", "rock", 5, 2), fm("Charm", "fairy", 8, 3)), listOf(cm("Crunch", "dark", 45), cm("Rock Tomb", "rock", 50), cm("Meteor Beam", "rock", 60), cm("Earthquake", "ground", 65))),
        PvPokeEntry("lycanroc_midnight", "Lycanroc (Midnight)", "rock", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Crunch", "dark", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("garganacl", "Garganacl", "rock", listOf(fm("Smack Down", "rock", 8, 3)), listOf(cm("Rock Slide", "rock", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("nidoqueen", "Nidoqueen", "poison", listOf(fm("Poison Sting", "poison", 9, 2), fm("Mud Slap", "ground", 10, 3), fm("Poison Jab", "poison", 7, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Poison Fang", "poison", 40), cm("Earth Power", "ground", 50), cm("Stone Edge", "rock", 55), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("nidoking", "Nidoking", "poison", listOf(fm("Poison Sting", "poison", 9, 2), fm("Double Kick", "fighting", 12, 3), fm("Poison Jab", "poison", 7, 2), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Sand Tomb", "ground", 45), cm("Avalanche", "ice", 45), cm("Earth Power", "ground", 50), cm("Sludge Wave", "poison", 65), cm("Megahorn", "bug", 55))),
        PvPokeEntry("nidorina", "Nidorina", "poison", listOf(fm("Poison Sting", "poison", 10, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Dig", "ground", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("golbat", "Golbat", "poison", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("crobat", "Crobat", "poison", listOf(fm("Gust", "flying", 14, 4), fm("Air Slash", "flying", 9, 3), fm("Bite", "dark", 2, 1)), listOf(cm("Poison Fang", "poison", 40), cm("Shadow Ball", "ghost", 50), cm("Air Cutter", "flying", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("muk", "Muk", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Infestation", "bug", 12, 3)), listOf(cm("Thunder Punch", "electric", 40), cm("Dark Pulse", "dark", 50), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("muk_alolan", "Muk (Alolan)", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Snarl", "dark", 13, 3), fm("Bite", "dark", 2, 1)), listOf(cm("Brutal Swing", "dark", 35), cm("Ice Punch", "ice", 40), cm("Acid Spray", "poison", 45), cm("Dark Pulse", "dark", 45), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("grimer", "Grimer", "poison", listOf(fm("Mud Slap", "ground", 10, 3), fm("Poison Jab", "poison", 7, 2), fm("Acid", "poison", 8, 2)), listOf(cm("Sludge", "poison", 40), cm("Mud Bomb", "ground", 45), cm("Sludge Bomb", "poison", 50), cm("Return", "normal", 70))),
        PvPokeEntry("grimer_alolan", "Grimer (Alolan)", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Bite", "dark", 2, 1), fm("Snarl", "dark", 13, 3)), listOf(cm("Crunch", "dark", 45), cm("Sludge Bomb", "poison", 50), cm("Gunk Shot", "poison", 75), cm("Return", "normal", 70))),
        PvPokeEntry("weezing", "Weezing", "poison", listOf(fm("Rollout", "rock", 13, 3), fm("Infestation", "bug", 12, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Sludge Bomb", "poison", 50), cm("Dark Pulse", "dark", 45), cm("Thunderbolt", "electric", 55), cm("Shadow Ball", "ghost", 50))),
        PvPokeEntry("weezing_galarian", "Weezing (Galarian)", "poison", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Tackle", "normal", 3, 1)), listOf(cm("Brutal Swing", "dark", 40), cm("Sludge", "poison", 40), cm("Overheat", "fire", 55), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("swalot", "Swalot", "poison", listOf(fm("Mud Shot", "ground", 9, 2), fm("Infestation", "bug", 12, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Sludge", "poison", 40), cm("Acid Spray", "poison", 45), cm("Sludge Bomb", "poison", 50), cm("Ice Beam", "ice", 55), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("seviper", "Seviper", "poison", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("arbok", "Arbok", "poison", listOf(fm("Poison Sting", "poison", 9, 2), fm("Dragon Tail", "dragon", 12, 3), fm("Acid", "poison", 8, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Brutal Swing", "dark", 35), cm("Acid Spray", "poison", 45), cm("Dark Pulse", "dark", 45), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("garbodor", "Garbodor", "poison", listOf(fm("Infestation", "bug", 12, 3)), listOf(cm("Body Slam", "normal", 35), cm("Seed Bomb", "grass", 45), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("salazzle", "Salazzle", "poison", listOf(fm("Incinerate", "fire", 20, 5), fm("Poison Jab", "poison", 7, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Fire Blast", "fire", 80), cm("Dragon Pulse", "dragon", 55), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("grafaiai", "Grafaiai", "poison", listOf(fm("Scratch", "normal", 2, 1), fm("Poison Jab", "poison", 7, 2), fm("Acid", "poison", 8, 2)), listOf(cm("Foul Play", "dark", 40), cm("Sludge Bomb", "poison", 50), cm("Acrobatics", "flying", 55), cm("Dig", "ground", 50))),
        PvPokeEntry("revavroom", "Revavroom", "steel", listOf(fm("Metal Sound", "steel", 8, 2), fm("Poison Jab", "poison", 7, 2), fm("Lick", "ghost", 3, 1)), listOf(cm("Acid Spray", "poison", 45), cm("Gyro Ball", "steel", 50), cm("Overheat", "fire", 55), cm("Sludge Wave", "poison", 65), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("bisharp", "Bisharp", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Dark Pulse", "dark", 50), cm("Iron Head", "steel", 50), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("kingambit", "Kingambit", "dark", listOf(fm("Low Kick", "fighting", 8, 2), fm("Snarl", "dark", 13, 3), fm("Metal Sound", "steel", 8, 2), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Foul Play", "dark", 40), cm("Dark Pulse", "dark", 45), cm("Iron Head", "steel", 50), cm("X-Scissor", "bug", 40), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("pawniard", "Pawniard", "dark", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Night Slash", "dark", 35), cm("Iron Head", "steel", 50))),
        PvPokeEntry("perrserker", "Perrserker", "steel", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Metal Sound", "steel", 8, 2), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Foul Play", "dark", 40), cm("Close Combat", "fighting", 45), cm("Trailblaze", "grass", 45), cm("Iron Head", "steel", 50), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("torkoal", "Torkoal", "fire", listOf(fm("Fire Spin", "fire", 10, 3)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Flame Wheel", "fire", 45), cm("Overheat", "fire", 55), cm("Earthquake", "ground", 65))),
        PvPokeEntry("magmortar", "Magmortar", "fire", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Thunderbolt", "electric", 55), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("magmar", "Magmar", "fire", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("arcanine", "Arcanine", "fire", listOf(fm("Thunder Fang", "electric", 5, 2)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Scorching Sands", "ground", 50), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("arcanine_hisuian", "Arcanine (Hisuian)", "fire", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Rock Slide", "rock", 45), cm("Wild Charge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("houndoom", "Houndoom", "dark", listOf(fm("Incinerate", "fire", 20, 5), fm("Snarl", "dark", 13, 3), fm("Fire Fang", "fire", 6, 2)), listOf(cm("Foul Play", "dark", 40), cm("Trailblaze", "grass", 45), cm("Crunch", "dark", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("pyroar", "Pyroar", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Dark Pulse", "dark", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("camerupt", "Camerupt", "fire", listOf(fm("Incinerate", "fire", 20, 5), fm("Ember", "fire", 9, 2)), listOf(cm("Rock Tomb", "rock", 50), cm("Scorching Sands", "ground", 50), cm("Earth Power", "ground", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("centiskorch", "Centiskorch", "fire", listOf(fm("Bug Bite", "bug", 3, 1)), listOf(cm("Lunge", "bug", 45), cm("Crunch", "dark", 45), cm("Heat Wave", "fire", 75))),
        PvPokeEntry("volcarona", "Volcarona", "bug", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Bug Buzz", "bug", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("entei", "Entei", "fire", listOf(fm("Fire Spin", "fire", 10, 3), fm("Fire Fang", "fire", 8, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Scorching Sands", "ground", 50), cm("Iron Head", "steel", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("raikou", "Raikou", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Wild Charge", "electric", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("suicune", "Suicune", "water", listOf(fm("Snarl", "dark", 13, 3), fm("Ice Fang", "ice", 6, 2), fm("Extrasensory", "psychic", 10, 3)), listOf(cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55), cm("Scald", "water", 55))),
        PvPokeEntry("lugia", "Lugia", "psychic", listOf(fm("Dragon Tail", "dragon", 12, 3), fm("Extrasensory", "psychic", 10, 3)), listOf(cm("Fly", "flying", 45), cm("Earth Power", "ground", 50), cm("Sky Attack", "flying", 50), cm("Aeroblast*", "flying", 75), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("ho_oh", "Ho-Oh", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Sacred Fire", "fire", 65), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("mewtwo", "Mewtwo", "psychic", listOf(fm("Psycho Cut", "psychic", 9, 2), fm("Confusion", "psychic", 12, 4)), listOf(cm("Psystrike*", "psychic", 45), cm("Shadow Ball", "ghost", 55), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("kyogre", "Kyogre", "water", listOf(fm("Waterfall", "water", 8, 3)), listOf(cm("Surf", "water", 40), cm("Origin Pulse", "water", 60))),
        PvPokeEntry("groudon", "Groudon", "ground", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Precipice Blades", "ground", 60))),
        PvPokeEntry("rayquaza", "Rayquaza", "dragon", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Dragon Ascent", "flying", 70))),
        PvPokeEntry("dialga_origin", "Dialga (Origin)", "steel", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Iron Head", "steel", 50), cm("Roar of Time", "dragon", 65))),
        PvPokeEntry("palkia_origin", "Palkia (Origin)", "water", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Aqua Tail", "water", 35), cm("Spacial Rend", "dragon", 50))),
        PvPokeEntry("giratina_altered", "Giratina (Altered)", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Dragon Claw", "dragon", 50), cm("Ancient Power", "rock", 45), cm("Shadow Sneak", "ghost", 50), cm("Shadow Force*", "ghost", 65))),
        PvPokeEntry("zygarde_complete", "Zygarde (Complete)", "dragon", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("landorus_therian", "Landorus (Therian)", "ground", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Sandsear Storm", "ground", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("necrozma_dusk", "Necrozma (Dusk Mane)", "psychic", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Dark Pulse", "dark", 50), cm("Sunsteel Strike", "steel", 65))),
        PvPokeEntry("tapu_koko", "Tapu Koko", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Nature's Madness", "fairy", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("tapu_lele", "Tapu Lele", "psychic", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Nature's Madness", "fairy", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("tapu_bulu", "Tapu Bulu", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Nature's Madness", "fairy", 50), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("kartana", "Kartana", "grass", listOf(fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Night Slash", "dark", 35))),
        PvPokeEntry("celesteela", "Celesteela", "steel", listOf(fm("Air Slash", "flying", 9, 3)), listOf(cm("Body Slam", "normal", 35), cm("Heavy Slam", "steel", 50), cm("Bulldoze", "ground", 60))),
        PvPokeEntry("nihilego", "Nihilego", "rock", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("thievul", "Thievul", "dark", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Snarl", "dark", 13, 3), fm("Quick Attack", "normal", 8, 2)), listOf(cm("Night Slash", "dark", 35), cm("Icy Wind*", "ice", 45), cm("Play Rough", "fairy", 60)))
    )

    private fun loadPokemonChunk8(): List<PvPokeEntry> = listOf(
        PvPokeEntry("nickit", "Nickit", "dark", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Snarl", "dark", 13, 3), fm("Quick Attack", "normal", 8, 2)), listOf(cm("Night Slash", "dark", 35), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("liepard", "Liepard", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Charm", "fairy", 6, 3)), listOf(cm("Dark Pulse", "dark", 50), cm("Play Rough", "fairy", 60), cm("Gunk Shot", "poison", 65))),
        PvPokeEntry("purrloin", "Purrloin", "dark", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Scratch", "normal", 2, 1)), listOf(cm("Night Slash", "dark", 35), cm("Dark Pulse", "dark", 50), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("mightyena", "Mightyena", "dark", listOf(fm("Sucker Punch", "dark", 8, 2), fm("Fire Fang", "fire", 7, 2), fm("Ice Fang", "ice", 7, 2), fm("Thunder Fang", "electric", 7, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("poochyena", "Poochyena", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("zoroark", "Zoroark", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Foul Play", "dark", 40), cm("Flamethrower", "fire", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("zorua", "Zorua", "dark", listOf(fm("Feint Attack", "dark", 6, 2), fm("Scratch", "normal", 2, 1)), listOf(cm("Foul Play", "dark", 40), cm("Dark Pulse", "dark", 50), cm("Aerial Ace", "flying", 45))),
        PvPokeEntry("mabosstiff", "Mabosstiff", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Bite", "dark", 2, 1)), listOf(cm("Crunch", "dark", 45), cm("Payback", "dark", 60), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("maschiff", "Maschiff", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Bite", "dark", 2, 1)), listOf(cm("Crunch", "dark", 45), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("honchkrow", "Honchkrow", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Peck", "flying", 6, 2)), listOf(cm("Sky Attack", "flying", 55), cm("Dark Pulse", "dark", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("murkrow", "Murkrow", "dark", listOf(fm("Peck", "flying", 6, 2), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Drill Peck", "flying", 40), cm("Foul Play", "dark", 40), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("absol", "Absol", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Brutal Swing*", "dark", 40), cm("Dark Pulse", "dark", 50), cm("Megahorn", "bug", 55))),
        PvPokeEntry("darkrai", "Darkrai", "dark", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Snarl", "dark", 13, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Foul Play", "dark", 40), cm("Dark Pulse", "dark", 45), cm("Shadow Ball", "ghost", 50), cm("Sludge Bomb*", "poison", 50), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("cramorant", "Cramorant", "flying", listOf(fm("Peck", "flying", 6, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Dive", "water", 45), cm("Fly", "flying", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("doublade", "Doublade", "steel", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Sacred Sword", "fighting", 35), cm("Iron Head", "steel", 50), cm("Gyro Ball", "steel", 50))),
        PvPokeEntry("honedge", "Honedge", "steel", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Tackle", "normal", 3, 1)), listOf(cm("Iron Head", "steel", 50), cm("Shadow Sneak", "ghost", 45))),
        PvPokeEntry("polteageist", "Polteageist", "ghost", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Hex", "ghost", 13, 3)), listOf(cm("Shadow Ball", "ghost", 55), cm("Poltergeist", "ghost", 75), cm("Psychic", "psychic", 55))),
        PvPokeEntry("sinistea", "Sinistea", "ghost", listOf(fm("Astonish", "ghost", 10, 2), fm("Hex", "ghost", 13, 3)), listOf(cm("Shadow Ball", "ghost", 55), cm("Psyshock", "psychic", 40))),
        PvPokeEntry("greavard", "Greavard", "ghost", listOf(fm("Lick", "ghost", 3, 1), fm("Bite", "dark", 2, 1)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Shadow Ball", "ghost", 55), cm("Dig", "ground", 50))),
        PvPokeEntry("brambleghast", "Brambleghast", "grass", listOf(fm("Hex", "ghost", 13, 3), fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Night Shade", "ghost", 45), cm("Shadow Ball", "ghost", 55), cm("Power Whip", "grass", 50))),
        PvPokeEntry("bramblin", "Bramblin", "grass", listOf(fm("Astonish", "ghost", 10, 2), fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Night Shade", "ghost", 45), cm("Seed Bomb", "grass", 45))),
        PvPokeEntry("rotom", "Rotom", "electric", listOf(fm("Thunder Shock", "electric", 9, 2), fm("Astonish", "ghost", 10, 2)), listOf(cm("Hydro Pump", "water", 75), cm("Overheat", "fire", 55), cm("Leaf Storm", "grass", 55), cm("Blizzard", "ice", 75), cm("Thunderbolt", "electric", 55), cm("Ominous Wind", "ghost", 45))),
        PvPokeEntry("frosmoth", "Frosmoth", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Ice Beam", "ice", 55), cm("Bug Buzz", "bug", 60), cm("Hurricane", "flying", 65))),
        PvPokeEntry("snom", "Snom", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Struggle Bug", "bug", 8, 3)), listOf(cm("Icy Wind", "ice", 45))),
        PvPokeEntry("orbeetle", "Orbeetle", "bug", listOf(fm("Confusion", "psychic", 12, 4), fm("Struggle Bug", "bug", 8, 3)), listOf(cm("Bug Buzz", "bug", 60), cm("Psychic", "psychic", 55))),
        PvPokeEntry("rabsca", "Rabsca", "bug", listOf(fm("Struggle Bug", "bug", 8, 3), fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Psyshock", "psychic", 40), cm("Lunge", "bug", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("spidops", "Spidops", "bug", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Counter", "fighting", 6, 2), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Lunge", "bug", 45), cm("Rock Tomb", "rock", 50), cm("Grass Knot", "grass", 50), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("vespiquen", "Vespiquen", "bug", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Bug Bite", "bug", 3, 1), fm("Air Slash", "flying", 9, 3)), listOf(cm("X-Scissor", "bug", 40), cm("Fell Stinger", "bug", 35), cm("Power Gem", "rock", 60), cm("Signal Beam*", "bug", 55))),
        PvPokeEntry("masquerain", "Masquerain", "bug", listOf(fm("Air Slash", "flying", 9, 3), fm("Infestation", "bug", 12, 3)), listOf(cm("Lunge", "bug", 45), cm("Bubble Beam", "water", 40), cm("Ominous Wind", "ghost", 45), cm("Silver Wind", "bug", 45))),
        PvPokeEntry("ninjask", "Ninjask", "bug", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Metal Claw", "steel", 6, 2)), listOf(cm("Aerial Ace", "flying", 45), cm("Shadow Ball", "ghost", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("shedinja", "Shedinja", "bug", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Shadow Sneak", "ghost", 45), cm("Aerial Ace", "flying", 45), cm("Dig", "ground", 50))),
        PvPokeEntry("volbeat", "Volbeat", "bug", listOf(fm("Fury Cutter", "bug", 4, 1), fm("Struggle Bug", "bug", 8, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Lunge", "bug", 45), cm("Signal Beam", "bug", 55), cm("Thunderbolt", "electric", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("illumise", "Illumise", "bug", listOf(fm("Counter", "fighting", 6, 2), fm("Struggle Bug", "bug", 8, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Lunge", "bug", 45), cm("Silver Wind", "bug", 45), cm("Dazzling Gleam", "fairy", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("swoobat", "Swoobat", "psychic", listOf(fm("Confusion", "psychic", 12, 4), fm("Air Slash", "flying", 9, 3)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Fly", "flying", 45), cm("Aerial Ace", "flying", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("woobat", "Woobat", "psychic", listOf(fm("Confusion", "psychic", 12, 4), fm("Air Slash", "flying", 9, 3)), listOf(cm("Psyshock", "psychic", 40), cm("Air Cutter", "flying", 45))),
        PvPokeEntry("sigilyph", "Sigilyph", "psychic", listOf(fm("Air Slash", "flying", 9, 3), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Sky Attack", "flying", 55), cm("Psybeam", "psychic", 60), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("espathra", "Espathra", "psychic", listOf(fm("Confusion", "psychic", 12, 4), fm("Peck", "flying", 6, 2)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Dazzling Gleam", "fairy", 70), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("wyrdeer", "Wyrdeer", "normal", listOf(fm("Confusion", "psychic", 12, 4), fm("Tackle", "normal", 3, 1)), listOf(cm("Stomp", "normal", 40), cm("Wild Charge", "electric", 45), cm("Megahorn", "bug", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("dachsbun", "Dachsbun", "fairy", listOf(fm("Charm", "fairy", 8, 3), fm("Fire Fang", "fire", 6, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Body Slam", "normal", 40), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("fidough", "Fidough", "fairy", listOf(fm("Charm", "fairy", 6, 3), fm("Quick Attack", "normal", 8, 2)), listOf(cm("Body Slam", "normal", 35), cm("Play Rough", "fairy", 60), cm("Crunch", "dark", 45))),
        PvPokeEntry("comfey", "Comfey", "fairy", listOf(fm("Vine Whip", "grass", 8, 2), fm("Hidden Power", "normal", 8, 3)), listOf(cm("Disarming Voice", "fairy", 45), cm("Grass Knot", "grass", 50), cm("Draining Kiss", "fairy", 55))),
        PvPokeEntry("alcremie", "Alcremie", "fairy", listOf(fm("Charm", "fairy", 6, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Psyshock", "psychic", 40), cm("Dazzling Gleam", "fairy", 70), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("hattrem", "Hattrem", "psychic", listOf(fm("Charm", "fairy", 6, 3), fm("Confusion", "psychic", 12, 4)), listOf(cm("Psyshock", "psychic", 40), cm("Power Whip", "grass", 50), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("morgrem", "Morgrem", "dark", listOf(fm("Bite", "dark", 2, 1), fm("Low Kick", "fighting", 5, 2)), listOf(cm("Foul Play", "dark", 40), cm("Play Rough", "fairy", 60), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("spritzee", "Spritzee", "fairy", listOf(fm("Charm", "fairy", 6, 3), fm("Charge Beam", "electric", 11, 3)), listOf(cm("Thunderbolt", "electric", 55), cm("Draining Kiss", "fairy", 55))),
        PvPokeEntry("swirlix", "Swirlix", "fairy", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Draining Kiss", "fairy", 55), cm("Energy Ball", "grass", 55), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("glimmora", "Glimmora", "rock", listOf(fm("Rock Throw", "rock", 5, 2), fm("Smack Down", "rock", 8, 3)), listOf(cm("Rock Slide", "rock", 45), cm("Sludge Wave", "poison", 65), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("mareanie", "Mareanie", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Brine", "water", 50), cm("Sludge Wave", "poison", 65), cm("Gunk Shot", "poison", 65))),
        PvPokeEntry("skrelp", "Skrelp", "poison", listOf(fm("Water Gun", "water", 3, 1), fm("Acid", "poison", 5, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Twister", "dragon", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("skorupi", "Skorupi", "poison", listOf(fm("Poison Sting", "poison", 9, 2), fm("Infestation", "bug", 12, 3)), listOf(cm("Aqua Tail", "water", 35), cm("Cross Poison", "poison", 35), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("stunky", "Stunky", "poison", listOf(fm("Bite", "dark", 2, 1), fm("Scratch", "normal", 2, 1)), listOf(cm("Crunch", "dark", 45), cm("Sludge Bomb", "poison", 50), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("croagunk", "Croagunk", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Mud Shot", "ground", 8, 2)), listOf(cm("Mud Bomb", "ground", 40), cm("Brick Break", "fighting", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("gulpin", "Gulpin", "poison", listOf(fm("Pound", "normal", 4, 2), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Ice Beam", "ice", 55), cm("Sludge", "poison", 40), cm("Gunk Shot", "poison", 65))),
        PvPokeEntry("roselia", "Roselia", "grass", listOf(fm("Poison Jab", "poison", 7, 2), fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Sludge Bomb", "poison", 50), cm("Dazzling Gleam", "fairy", 70), cm("Petal Blizzard", "grass", 65))),
        PvPokeEntry("grubbin", "Grubbin", "bug", listOf(fm("Bug Bite", "bug", 3, 1), fm("Spark", "electric", 7, 2)), listOf(cm("X-Scissor", "bug", 40), cm("Crunch", "dark", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("joltik", "Joltik", "bug", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Charge Beam", "electric", 11, 3)), listOf(cm("Cross Poison", "poison", 35), cm("Discharge", "electric", 45), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("inkay", "Inkay", "dark", listOf(fm("Psywave", "psychic", 4, 1), fm("Tackle", "normal", 3, 1)), listOf(cm("Foul Play", "dark", 40), cm("Night Slash", "dark", 35), cm("Psybeam", "psychic", 60))),
        PvPokeEntry("vullaby", "Vullaby", "dark", listOf(fm("Air Slash", "flying", 9, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Foul Play", "dark", 40), cm("Brave Bird", "flying", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("scraggy", "Scraggy", "dark", listOf(fm("Counter", "fighting", 6, 2), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Power-Up Punch", "fighting", 35), cm("Foul Play", "dark", 40), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("deino", "Deino", "dark", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Crunch", "dark", 45), cm("Dark Pulse", "dark", 50)))
    )

    private fun loadPokemonChunk9(): List<PvPokeEntry> = listOf(
        PvPokeEntry("yamask", "Yamask", "ghost", listOf(fm("Astonish", "ghost", 10, 2)), listOf(cm("Night Shade", "ghost", 45), cm("Dark Pulse", "dark", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("drifloon", "Drifloon", "ghost", listOf(fm("Hex", "ghost", 13, 3), fm("Astonish", "ghost", 10, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Ominous Wind", "ghost", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("duskull", "Duskull", "ghost", listOf(fm("Hex", "ghost", 13, 3), fm("Astonish", "ghost", 10, 2)), listOf(cm("Shadow Sneak", "ghost", 45), cm("Night Shade", "ghost", 45), cm("Ominous Wind", "ghost", 45))),
        PvPokeEntry("shuppet", "Shuppet", "ghost", listOf(fm("Astonish", "ghost", 10, 2), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Shadow Sneak", "ghost", 45), cm("Ominous Wind", "ghost", 45), cm("Night Shade", "ghost", 45))),
        PvPokeEntry("litwick", "Litwick", "ghost", listOf(fm("Astonish", "ghost", 10, 2), fm("Ember", "fire", 7, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Mystical Fire", "fire", 45), cm("Heat Wave", "fire", 75))),
        PvPokeEntry("coalossal", "Coalossal", "rock", listOf(fm("Incinerate", "fire", 20, 5), fm("Smack Down", "rock", 8, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Rock Slide", "rock", 45), cm("Rock Blast", "rock", 40))),
        PvPokeEntry("cobalion", "Cobalion", "steel", listOf(fm("Double Kick", "fighting", 12, 3), fm("Metal Claw", "steel", 6, 2)), listOf(cm("Sacred Sword*", "fighting", 35), cm("Stone Edge", "rock", 55), cm("Iron Head", "steel", 50))),
        PvPokeEntry("virizion", "Virizion", "grass", listOf(fm("Double Kick", "fighting", 12, 3), fm("Quick Attack", "normal", 8, 2)), listOf(cm("Sacred Sword*", "fighting", 35), cm("Leaf Blade", "grass", 35), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("terrakion", "Terrakion", "rock", listOf(fm("Double Kick", "fighting", 12, 3), fm("Smack Down", "rock", 8, 3)), listOf(cm("Sacred Sword*", "fighting", 35), cm("Rock Slide", "rock", 45), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("keldeo", "Keldeo", "water", listOf(fm("Low Kick", "fighting", 5, 2), fm("Poison Jab", "poison", 7, 2)), listOf(cm("Sacred Sword", "fighting", 35), cm("Aqua Jet", "water", 45), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("urshifu_single_strike", "Urshifu (Single Strike)", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Dynamic Punch", "fighting", 50), cm("Payback", "dark", 60), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("urshifu_rapid_strike", "Urshifu (Rapid Strike)", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Waterfall", "water", 8, 3)), listOf(cm("Aqua Jet", "water", 45), cm("Dynamic Punch", "fighting", 50), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("metagross", "Metagross", "steel", listOf(fm("Shadow Claw*", "ghost", 8, 2), fm("Fury Cutter", "bug", 4, 1), fm("Bullet Punch", "steel", 7, 2), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Meteor Mash*", "steel", 45), cm("Psychic", "psychic", 55), cm("Earthquake", "ground", 65), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("milotic", "Milotic", "water", listOf(fm("Dragon Tail", "dragon", 12, 3), fm("Waterfall", "water", 10, 3)), listOf(cm("Aqua Tail", "water", 35), cm("Surf", "water", 45), cm("Wrap", "normal", 45), cm("Blizzard", "ice", 75), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("breloom", "Breloom", "grass", listOf(fm("Counter", "fighting", 6, 2), fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Dynamic Punch", "fighting", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("lopunny", "Lopunny", "normal", listOf(fm("Double Kick", "fighting", 12, 3), fm("Low Kick", "fighting", 8, 2), fm("Pound", "normal", 4, 2)), listOf(cm("Triple Axel", "ice", 45), cm("Thunder Punch", "electric", 40), cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 50), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("cinccino", "Cinccino", "normal", listOf(fm("Charm", "fairy", 6, 3), fm("Pound", "normal", 4, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Thunderbolt", "electric", 55), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("audino", "Audino", "normal", listOf(fm("Charge Beam", "electric", 11, 3), fm("Pound", "normal", 4, 2), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Body Slam", "normal", 40), cm("Disarming Voice", "fairy", 45), cm("Dazzling Gleam", "fairy", 55), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("dudunsparce", "Dudunsparce", "normal", listOf(fm("Rollout", "rock", 13, 3), fm("Dragon Tail", "dragon", 12, 3), fm("Bite", "dark", 2, 1)), listOf(cm("Body Slam", "normal", 40), cm("Drill Run", "ground", 40), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("kecleon", "Kecleon", "normal", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Lick", "ghost", 3, 1)), listOf(cm("Foul Play", "dark", 40), cm("Thunder Punch", "electric", 40), cm("Dynamic Punch", "fighting", 45), cm("Shadow Sneak", "ghost", 50), cm("Ice Beam", "ice", 55), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("ursaluna", "Ursaluna", "ground", listOf(fm("Scratch", "normal", 2, 1), fm("Tackle", "normal", 3, 1), fm("Smack Down", "rock", 8, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Swift", "normal", 35), cm("Ice Punch", "ice", 40), cm("Thunder Punch", "electric", 40), cm("Fire Punch", "fire", 40), cm("High Horsepower*", "ground", 55), cm("Play Rough", "fairy", 60), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("ursaring", "Ursaring", "normal", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Counter", "fighting", 6, 2)), listOf(cm("Swift", "normal", 35), cm("Close Combat", "fighting", 45), cm("Play Rough", "fairy", 60), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("kilowattrel", "Kilowattrel", "electric", listOf(fm("Thunder Shock", "electric", 9, 2), fm("Air Slash", "flying", 9, 3)), listOf(cm("Aerial Ace", "flying", 45), cm("Wild Charge", "electric", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("archaludon", "Archaludon", "steel", listOf(fm("Metal Claw", "steel", 6, 2), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Dragon Claw", "dragon", 35), cm("Flash Cannon", "steel", 70), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("duraludon", "Duraludon", "steel", listOf(fm("Metal Claw", "steel", 6, 2), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Dragon Claw", "dragon", 35), cm("Flash Cannon", "steel", 70), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("toedscruel", "Toedscruel", "ground", listOf(fm("Mud-Slap", "ground", 10, 3)), listOf(cm("Seed Bomb", "grass", 40), cm("Sludge Wave", "poison", 65), cm("Earth Power", "ground", 50))),
        PvPokeEntry("scovillain", "Scovillain", "grass", listOf(fm("Magical Leaf", "grass", 10, 3), fm("Fire Fang", "fire", 6, 2)), listOf(cm("Crunch", "dark", 45), cm("Grass Knot", "grass", 50), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("aerodactyl", "Aerodactyl", "rock", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Rock Throw", "rock", 5, 2), fm("Steel Wing", "steel", 5, 2), fm("Bite", "dark", 2, 1)), listOf(cm("Rock Slide", "rock", 45), cm("Ancient Power", "rock", 45), cm("Earth Power", "ground", 50), cm("Iron Head", "steel", 50), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("moltres_galarian", "Moltres (Galarian)", "dark", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Wing Attack", "flying", 8, 2)), listOf(cm("Fly", "flying", 45), cm("Ancient Power", "rock", 45), cm("Brave Bird", "flying", 55), cm("Payback", "dark", 60))),
        PvPokeEntry("zapdos_galarian", "Zapdos (Galarian)", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Low Kick", "fighting", 8, 2)), listOf(cm("Fly", "flying", 45), cm("Ancient Power", "rock", 45), cm("Close Combat", "fighting", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("articuno_galarian", "Articuno (Galarian)", "psychic", listOf(fm("Psycho Cut", "psychic", 9, 2), fm("Confusion", "psychic", 14, 4)), listOf(cm("Fly", "flying", 45), cm("Ancient Power", "rock", 45), cm("Brave Bird", "flying", 55), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("orthworm", "Orthworm", "steel", listOf(fm("Metal Sound", "steel", 8, 2), fm("Mud Slap", "ground", 10, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 40), cm("Rock Tomb", "rock", 50), cm("Iron Head", "steel", 50), cm("Earthquake", "ground", 65))),
        PvPokeEntry("bombirdier", "Bombirdier", "flying", listOf(fm("Sucker Punch", "dark", 7, 2), fm("Wing Attack", "flying", 8, 2), fm("Rock Throw", "rock", 5, 2)), listOf(cm("Fly", "flying", 45), cm("Rock Tomb", "rock", 50), cm("Payback", "dark", 60))),
        PvPokeEntry("flamigo", "Flamigo", "flying", listOf(fm("Double Kick", "fighting", 12, 3), fm("Wing Attack", "flying", 8, 2), fm("Low Kick", "fighting", 8, 2)), listOf(cm("Fly", "flying", 45), cm("Upper Hand", "fighting", 40), cm("Close Combat", "fighting", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("dhelmise", "Dhelmise", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Astonish", "ghost", 10, 3), fm("Metal Sound", "steel", 8, 2)), listOf(cm("Power Whip", "grass", 50), cm("Shadow Ball", "ghost", 50), cm("Heavy Slam", "steel", 50), cm("Earthquake", "ground", 65))),
        PvPokeEntry("toxtricity", "Toxtricity", "electric", listOf(fm("Poison Jab", "poison", 7, 2), fm("Spark", "electric", 7, 2), fm("Acid", "poison", 8, 2)), listOf(cm("Power-Up Punch", "fighting", 35), cm("Discharge", "electric", 40), cm("Wild Charge", "electric", 45), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("tinkatuff", "Tinkatuff", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Play Rough", "fairy", 60), cm("Rock Tomb", "rock", 50), cm("Flash Cannon", "steel", 65))),
        PvPokeEntry("palafin", "Palafin", "water", listOf(fm("Waterfall", "water", 10, 3), fm("Counter", "fighting", 6, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Jet Punch", "water", 40), cm("Ice Punch", "ice", 40), cm("Drain Punch", "fighting", 40), cm("Close Combat", "fighting", 45)))
    )

    @Volatile
    private var cachedMergedPokemonList: List<PvPokeEntry>? = null

    val allPokemonList: List<PvPokeEntry>
        get() = cachedMergedPokemonList ?: BUILT_IN_POKEMON

    fun syncFullPvPokeGreatLeagueData(context: Context, onSynced: ((Int) -> Unit)? = null) {
        val cacheFile = File(context.filesDir, "pvpoke_gamemaster_cache.json")
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (cacheFile.exists() && cacheFile.length() > 1000L) {
                    applyGamemasterJson(cacheFile.readText())
                }
                val url = java.net.URL("https://raw.githubusercontent.com/pvpoke/pvpoke/master/src/data/gamemaster.json")
                val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 12000
                    requestMethod = "GET"
                    setRequestProperty("Accept", "application/json")
                }
                if (conn.responseCode == 200) {
                    val rawJson = conn.inputStream.bufferedReader().use { it.readText() }
                    if (rawJson.length > 1000) {
                        cacheFile.writeText(rawJson)
                        applyGamemasterJson(rawJson)
                    }
                }
                conn.disconnect()
            } catch (_: Throwable) {
                // Offline or network restricted; built-in Season 28 PvPoke database remains active
            }
            kotlinx.coroutines.withContext(Dispatchers.Main) {
                onSynced?.invoke(allPokemonList.size)
            }
        }
    }

    private fun applyGamemasterJson(rawJson: String) {
        try {
            val root = JSONObject(rawJson)
            val moveIdToFast = mutableMapOf<String, FastMove>()
            val moveIdToCharged = mutableMapOf<String, ChargedMove>()

            val movesArr = root.optJSONArray("moves")
            if (movesArr != null) {
                for (i in 0 until movesArr.length()) {
                    val m = movesArr.optJSONObject(i) ?: continue
                    val moveId = m.optString("moveId", "").trim()
                    val name = m.optString("name", "").trim()
                    val type = m.optString("type", "normal").trim().lowercase()
                    if (moveId.isEmpty() || name.isEmpty()) continue
                    val energyGain = m.optInt("energyGain", 0)
                    val energyCost = m.optInt("energy", 0)
                    val cooldownMs = m.optInt("cooldown", 500)
                    if (energyGain > 0) {
                        val turns = max(1, cooldownMs / 500)
                        DYNAMIC_FAST_STATS[name] = Pair(energyGain, turns)
                        moveIdToFast[moveId] = FastMove(name, type, energyGain, turns)
                    } else if (energyCost > 0) {
                        DYNAMIC_CHARGED_COSTS[name] = energyCost
                        moveIdToCharged[moveId] = ChargedMove(name, type, energyCost)
                    }
                }
            }

            val pokemonArr = root.optJSONArray("pokemon")
            if (pokemonArr != null) {
                val builtInById = BUILT_IN_POKEMON.associateBy { it.id.lowercase() }.toMutableMap()
                for (i in 0 until pokemonArr.length()) {
                    val p = pokemonArr.optJSONObject(i) ?: continue
                    val speciesId = p.optString("speciesId", "").trim().lowercase()
                    if (speciesId.isEmpty() || speciesId.endsWith("_shadow") || speciesId.contains("_mega")) continue
                    val existing = builtInById[speciesId] ?: continue

                    val typesArr = p.optJSONArray("types")
                    if (typesArr != null && typesArr.length() > 0) {
                        val tList = mutableListOf<String>()
                        for (tIdx in 0 until typesArr.length()) {
                            val tStr = typesArr.optString(tIdx, "none").lowercase()
                            if (tStr != "none" && tStr.isNotBlank()) tList.add(tStr)
                        }
                        if (tList.isNotEmpty()) DYNAMIC_DUAL_TYPES_MAP[speciesId] = tList
                    }

                    val gmFast = mutableListOf<FastMove>()
                    val fArr = p.optJSONArray("fastMoves")
                    if (fArr != null) {
                        for (j in 0 until fArr.length()) {
                            moveIdToFast[fArr.optString(j)]?.let { gmFast.add(it) }
                        }
                    }

                    val gmCharged = mutableListOf<ChargedMove>()
                    val cArr = p.optJSONArray("chargedMoves")
                    if (cArr != null) {
                        for (j in 0 until cArr.length()) {
                            moveIdToCharged[cArr.optString(j)]?.let { gmCharged.add(it) }
                        }
                    }
                    val eliteArr = p.optJSONArray("eliteMoves")
                    if (eliteArr != null) {
                        for (j in 0 until eliteArr.length()) {
                            val mId = eliteArr.optString(j)
                            moveIdToFast[mId]?.let { fm ->
                                if (gmFast.none { it.name.replace("*", "") == fm.name }) {
                                    gmFast.add(fm.copy(name = "${fm.name}*"))
                                }
                            }
                            moveIdToCharged[mId]?.let { cm ->
                                if (gmCharged.none { it.name.replace("*", "") == cm.name }) {
                                    gmCharged.add(cm.copy(name = "${cm.name}*"))
                                }
                            }
                        }
                    }

                    if (gmFast.isNotEmpty() && gmCharged.isNotEmpty()) {
                        // Preserve built-in PvPoke meta ordering first, then append any newly added gamemaster moves
                        val mergedFast = existing.fastMoves.map { ef ->
                            val cleanName = ef.name.replace("*", "").trim()
                            val updatedStats = DYNAMIC_FAST_STATS[cleanName]
                            if (updatedStats != null) ef.copy(energyGain = updatedStats.first, turns = updatedStats.second) else ef
                        }.toMutableList()
                        for (gf in gmFast) {
                            val cleanGf = gf.name.replace("*", "").trim()
                            if (mergedFast.none { it.name.replace("*", "").trim().equals(cleanGf, ignoreCase = true) }) {
                                mergedFast.add(gf)
                            }
                        }

                        val mergedCharged = existing.chargedMoves.map { ec ->
                            val cleanName = ec.name.replace("*", "").trim()
                            val updatedCost = DYNAMIC_CHARGED_COSTS[cleanName]
                            if (updatedCost != null) ec.copy(energyCost = updatedCost) else ec
                        }.toMutableList()
                        for (gc in gmCharged) {
                            val cleanGc = gc.name.replace("*", "").trim()
                            if (mergedCharged.none { it.name.replace("*", "").trim().equals(cleanGc, ignoreCase = true) }) {
                                mergedCharged.add(gc)
                            }
                        }

                        val updatedEntry = existing.copy(
                            fastMoves = mergedFast,
                            chargedMoves = mergedCharged
                        )
                        DYNAMIC_POKEMON_OVERRIDES[speciesId] = updatedEntry
                        builtInById[speciesId] = updatedEntry
                    }
                }
                cachedMergedPokemonList = BUILT_IN_POKEMON.map { entry ->
                    DYNAMIC_POKEMON_OVERRIDES[entry.id.lowercase()] ?: entry
                }
            }
        } catch (_: Throwable) {
        }
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = i - 1
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev else 1 + min(prev, min(dp[j], dp[j - 1]))
                prev = temp
            }
        }
        return dp[b.length]
    }

    private val HUD_NOISE_WORDS: Set<String> by lazy { buildHudNoiseWords() }

    private fun buildHudNoiseWords(): Set<String> = setOf(
        "cp", "attack", "incoming", "use", "protect", "shield", "not", "now",
        "super", "effective", "very", "weak", "fast", "move", "count", "ready"
    )

    private fun cleanBaseSpeciesName(name: String): String {
        val idx = name.indexOf('(')
        return (if (idx > 0) name.substring(0, idx) else name).trim().lowercase()
    }

    private fun extractAlphaWords(raw: String): List<String> {
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            if (ch in 'a'..'z' || ch in 'A'..'Z' || ch == '-' || ch == '\'') {
                sb.append(ch)
            } else {
                sb.append(' ')
            }
        }
        return sb.toString()
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 3 && !HUD_NOISE_WORDS.contains(it.lowercase()) }
    }

    private fun pickBestRegionalOrBaseForm(candidates: List<PvPokeEntry>, badgeTypes: Set<String>): PvPokeEntry {
        if (candidates.size == 1) return candidates.first()
        var bestEntry = candidates.first()
        var bestScore = -999
        for (cand in candidates) {
            var score = 0
            val candTypes = getDefenderTypes(cand).toSet()
            if (badgeTypes.isNotEmpty()) {
                // Count how many detected top-right Type Badge colors match this form's types
                val matchedBadgeCount = candTypes.count { badgeTypes.contains(it) }
                val unmatchedCandTypes = candTypes.count { !badgeTypes.contains(it) }
                score += matchedBadgeCount * 40 - unmatchedCandTypes * 30
            }
            // Prefer Great League meta regional variants when badges match or are not yet visible
            if (PREFERRED_GL_REGIONAL_IDS.contains(cand.id.lowercase())) {
                score += 15
            }
            if (score > bestScore) {
                bestScore = score
                bestEntry = cand
            }
        }
        return bestEntry
    }

    fun matchPokemonFromHudText(hudOcrText: String, badgeTypes: Set<String> = emptySet()): PvPokeEntry? {
        if (hudOcrText.isBlank()) return null

        val nonOverlayText = hudOcrText.lines().filter { line ->
            val l = line.lowercase()
            !l.contains("[v") &&
                !l.contains("ready") &&
                !l.contains("(-") &&
                !l.contains("[⇄") &&
                !l.contains("locked:") &&
                !l.contains("watching ") &&
                !l.contains("restored ") &&
                !l.contains("subtracted ") &&
                !l.contains("bench:") &&
                !l.contains("scanner") &&
                !l.contains("engine") &&
                !Regex("\\d+e/\\d+t").containsMatchIn(l)
        }.joinToString(" ")
        if (nonOverlayText.isBlank()) return null

        val cleanedWords = extractAlphaWords(nonOverlayText)
        if (cleanedWords.isEmpty()) return null

        val joinedLower = cleanedWords.joinToString(" ").lowercase()
        val list = allPokemonList

        val sortedByLength = list.sortedByDescending {
            cleanBaseSpeciesName(it.name).length
        }

        for (entry in sortedByLength) {
            val baseName = cleanBaseSpeciesName(entry.name)
            if (baseName.length >= 3 && joinedLower.contains(baseName)) {
                val allSameBase = list.filter { cleanBaseSpeciesName(it.name) == baseName }
                return pickBestRegionalOrBaseForm(allSameBase, badgeTypes)
            }
        }

        var bestMatch: PvPokeEntry? = null
        var bestDist = 3
        for (word in cleanedWords) {
            val wLow = word.lowercase()
            if (wLow.length < 4) continue
            for (entry in sortedByLength) {
                val baseName = cleanBaseSpeciesName(entry.name)
                if (abs(wLow.length - baseName.length) <= 2) {
                    val d = levenshtein(wLow, baseName)
                    val maxAllowed = if (baseName.length >= 7) 2 else 1
                    if (d <= maxAllowed && d < bestDist) {
                        bestDist = d
                        bestMatch = entry
                    }
                }
            }
        }
        if (bestMatch != null) {
            val baseName = cleanBaseSpeciesName(bestMatch.name)
            val allSameBase = list.filter { cleanBaseSpeciesName(it.name) == baseName }
            return pickBestRegionalOrBaseForm(allSameBase, badgeTypes)
        }

        for (word in cleanedWords) {
            val wLow = word.lowercase()
            if (wLow.length >= 5) {
                val prefixMatches = list.filter { cleanBaseSpeciesName(it.name).startsWith(wLow) }
                if (prefixMatches.isNotEmpty()) {
                    return pickBestRegionalOrBaseForm(prefixMatches, badgeTypes)
                }
            }
        }

        if (nonOverlayText.contains("CP", ignoreCase = true)) {
            val detectedName = cleanedWords.last()
            if (detectedName.length >= 4) {
                return PvPokeEntry(
                    id = "dyn_${detectedName.lowercase()}",
                    name = detectedName,
                    primaryType = "normal",
                    fastMoves = listOf(fm("Fast Attack", "normal", 8, 2)),
                    chargedMoves = listOf(
                        cm("Charged 1 (40E)", "normal", 40),
                        cm("Charged 2 (55E)", "normal", 55)
                    )
                )
            }
        }
        return null
    }

    fun matchPlayerPokemonFromOwnBanner(screenOcrText: String, opponentPokemonName: String): PvPokeEntry? {
        if (screenOcrText.isBlank()) return null
        val oBase = cleanBaseSpeciesName(opponentPokemonName)
        val cleanLines = screenOcrText.lines().filter { line ->
            val l = line.lowercase()
            !l.contains("fast move count") &&
                !l.contains("ready") &&
                !l.contains("(-") &&
                !l.contains("[⇄") &&
                !l.contains("locked:") &&
                !l.contains("watching ") &&
                !l.contains("restored ") &&
                !l.contains("subtracted ") &&
                !l.contains("bench:") &&
                !l.contains("scanner") &&
                !l.contains("engine") &&
                !Regex("\\d+/\\d+").containsMatchIn(l)
        }
        val norm = cleanLines.joinToString(" ").lowercase()
        val match = Regex("([a-z][a-z0-9'\\-.]{2,14})\\s+used\\b").find(norm) ?: return null
        val actorWord = match.groupValues[1].replace(Regex("[^a-z]"), "")
        if (actorWord.length < 3) return null
        if (oBase.length >= 3 && (actorWord == oBase || levenshtein(actorWord, oBase) <= 1)) return null
        return BUILT_IN_POKEMON.firstOrNull { entry ->
            val eBase = cleanBaseSpeciesName(entry.name)
            eBase == actorWord || (actorWord.length >= 5 && levenshtein(actorWord, eBase) <= 1)
        }
    }

    fun isPlayerOwnChargedMoveBanner(screenOcrText: String, playerPokemonName: String?, opponentPokemonName: String): Boolean {
        if (screenOcrText.isBlank()) return false
        val cleanLines = screenOcrText.lines().filter { line ->
            val l = line.lowercase()
            !l.contains("fast move count") &&
                !l.contains("ready") &&
                !l.contains("(-") &&
                !l.contains("[⇄") &&
                !l.contains("locked:") &&
                !l.contains("watching ") &&
                !l.contains("restored ") &&
                !l.contains("subtracted ") &&
                !l.contains("bench:") &&
                !l.contains("scanner") &&
                !l.contains("engine") &&
                !Regex("\\d+/\\d+").containsMatchIn(l)
        }
        val norm = cleanLines.joinToString(" ").lowercase()
        if (!norm.contains("used ")) return false
        val oBase = cleanBaseSpeciesName(opponentPokemonName)
        if (!playerPokemonName.isNullOrBlank()) {
            val pBase = cleanBaseSpeciesName(playerPokemonName)
            if (pBase.length >= 3 && pBase != oBase && norm.contains("$pBase used")) {
                return true
            }
        }
        val match = Regex("([a-z][a-z0-9'\\-.]{2,14})\\s+used\\b").find(norm)
        if (match != null) {
            val actorWord = match.groupValues[1].replace(Regex("[^a-z]"), "")
            if (
                actorWord.length >= 4 &&
                oBase.length >= 3 &&
                actorWord != oBase &&
                !oBase.contains(actorWord) &&
                !actorWord.contains(oBase) &&
                levenshtein(actorWord, oBase) >= 3
            ) {
                return true
            }
        }
        return false
    }

    fun detectChargedAttackAndEffectiveness(screenOcrText: String, entry: PvPokeEntry): Triple<Boolean, ChargedMove?, String?> {
        if (screenOcrText.isBlank()) return Triple(false, null, null)

        // Strip out any OCR lines that could come from our own floating overlay HUD
        val cleanLines = screenOcrText.lines().filter { line ->
            val l = line.lowercase()
            !l.contains("fast move count") &&
                !l.contains("ready") &&
                !l.contains("(-") &&
                !l.contains("[⇄") &&
                !l.contains("locked:") &&
                !l.contains("watching ") &&
                !l.contains("restored ") &&
                !l.contains("subtracted ") &&
                !l.contains("bench:") &&
                !l.contains("scanner") &&
                !l.contains("engine") &&
                !Regex("\\d+/\\d+").containsMatchIn(l)
        }
        val norm = cleanLines.joinToString(" ").lowercase()
        if (norm.isBlank()) return Triple(false, null, null)

        val effHint = when {
            norm.contains("super effective") -> "super"
            norm.contains("not very effective") -> "not_very"
            else -> null
        }

        val hasUsedContext = norm.contains("used ") || norm.contains("!")

        if (hasUsedContext) {
            for (cm in entry.chargedMoves) {
                val cleanMove = cleanBaseSpeciesName(cm.name.replace("*", ""))
                if (cleanMove.length >= 4 && norm.contains(cleanMove) && !norm.contains("$cleanMove:")) {
                    return Triple(true, cm, effHint)
                }
            }
            // Check sibling regional forms (e.g. if "Weezing used Overheat!" or "Brutal Swing!" is read while on Kanto Weezing)
            for (sibling in getSiblingForms(entry)) {
                if (sibling.id == entry.id) continue
                for (cm in sibling.chargedMoves) {
                    val cleanMove = cleanBaseSpeciesName(cm.name.replace("*", ""))
                    if (cleanMove.length >= 4 && norm.contains(cleanMove) && !norm.contains("$cleanMove:")) {
                        return Triple(true, cm, effHint)
                    }
                }
            }
        }

        val isIncomingBanner = norm.contains("attack incoming") ||
            norm.contains("protect shield") ||
            norm.contains("shields remaining") ||
            norm.contains("no protect") ||
            (norm.contains("used ") && norm.contains(cleanBaseSpeciesName(entry.name)))

        return Triple(isIncomingBanner, null, effHint)
    }

    fun isMenuOrPreBattleText(screenOcrText: String): Boolean {
        if (screenOcrText.isBlank()) return false
        val norm = screenOcrText.lowercase()
        // IMPORTANT: Do NOT include "go, " or "great league" here!
        // "Go, [Pokemon]!" appears every time a player switches Pokémon mid-battle!
        return norm.contains("choose your league") ||
            norm.contains("good effort") ||
            norm.contains("you win") ||
            norm.contains("claim rank") ||
            norm.contains("next battle") ||
            norm.contains("use this party") ||
            norm.contains("finding opponent") ||
            norm.contains("battleRewards".lowercase())
    }
}
