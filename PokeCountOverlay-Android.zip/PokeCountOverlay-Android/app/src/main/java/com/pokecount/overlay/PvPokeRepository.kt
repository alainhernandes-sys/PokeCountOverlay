package com.pokecount.overlay

data class FastMove(val name: String, val type: String, val energyGain: Int, val turns: Int)
data class ChargedMove(val name: String, val type: String, val energyCost: Int, val colorHex: Int)
data class PvPokeEntry(
    val id: String,
    val name: String,
    val fastMove: FastMove,
    val chargedMoves: List<ChargedMove>
)

object PvPokeRepository {
    val META_POKEMON = listOf(
        PvPokeEntry("feraligatr", "Feraligatr", FastMove("Shadow Claw", "ghost", 8, 2), listOf(
            ChargedMove("Hydro Cannon", "water", 40, 0xFF0284C7.toInt()),
            ChargedMove("Ice Beam", "ice", 55, 0xFF0891B2.toInt()),
            ChargedMove("Crunch", "dark", 45, 0xFF475569.toInt())
        )),
        PvPokeEntry("clodsire", "Clodsire", FastMove("Poison Sting", "poison", 10, 2), listOf(
            ChargedMove("Earthquake", "ground", 65, 0xFFB45309.toInt()),
            ChargedMove("Stone Edge", "rock", 55, 0xFF78716C.toInt()),
            ChargedMove("Sludge Bomb", "poison", 50, 0xFF9333EA.toInt())
        )),
        PvPokeEntry("azumarill", "Azumarill", FastMove("Bubble", "water", 11, 3), listOf(
            ChargedMove("Ice Beam", "ice", 55, 0xFF0891B2.toInt()),
            ChargedMove("Play Rough", "fairy", 60, 0xFFBE185D.toInt()),
            ChargedMove("Hydro Pump", "water", 75, 0xFF0284C7.toInt())
        )),
        PvPokeEntry("mandibuzz", "Mandibuzz", FastMove("Snarl", "dark", 13, 3), listOf(
            ChargedMove("Dark Pulse", "dark", 50, 0xFF334155.toInt()),
            ChargedMove("Aerial Ace", "flying", 40, 0xFF4F46E5.toInt())
        )),
        PvPokeEntry("annihilape", "Annihilape", FastMove("Karate Chop", "fighting", 9, 2), listOf(
            ChargedMove("Rage Fist", "ghost", 35, 0xFF6D28D9.toInt()),
            ChargedMove("Shadow Ball", "ghost", 55, 0xFF6D28D9.toInt()),
            ChargedMove("Close Combat", "fighting", 45, 0xFFDC2626.toInt())
        )),
        PvPokeEntry("gastrodon", "Gastrodon", FastMove("Mud Slap", "ground", 10, 3), listOf(
            ChargedMove("Body Slam", "normal", 35, 0xFF52525B.toInt()),
            ChargedMove("Earth Power", "ground", 55, 0xFFB45309.toInt())
        )),
        PvPokeEntry("talonflame", "Talonflame", FastMove("Incinerate", "fire", 20, 5), listOf(
            ChargedMove("Flame Charge", "fire", 50, 0xFFEA580C.toInt()),
            ChargedMove("Fly", "flying", 45, 0xFF4F46E5.toInt()),
            ChargedMove("Brave Bird", "flying", 55, 0xFF4F46E5.toInt())
        )),
        PvPokeEntry("swampert", "Swampert", FastMove("Mud Shot", "ground", 9, 2), listOf(
            ChargedMove("Hydro Cannon", "water", 40, 0xFF0284C7.toInt()),
            ChargedMove("Earthquake", "ground", 65, 0xFFB45309.toInt())
        )),
        PvPokeEntry("whiscash", "Whiscash", FastMove("Mud Shot", "ground", 9, 2), listOf(
            ChargedMove("Mud Bomb", "ground", 40, 0xFFB45309.toInt()),
            ChargedMove("Scald", "water", 55, 0xFF0284C7.toInt()),
            ChargedMove("Blizzard", "ice", 75, 0xFF0891B2.toInt())
        )),
        PvPokeEntry("skarmory", "Skarmory", FastMove("Steel Wing", "steel", 6, 2), listOf(
            ChargedMove("Sky Attack", "flying", 55, 0xFF4F46E5.toInt()),
            ChargedMove("Brave Bird", "flying", 55, 0xFF4F46E5.toInt())
        )),
        PvPokeEntry("bastiodon", "Bastiodon", FastMove("Smack Down", "rock", 8, 3), listOf(
            ChargedMove("Stone Edge", "rock", 55, 0xFF78716C.toInt()),
            ChargedMove("Flamethrower", "fire", 55, 0xFFEA580C.toInt())
        )),
        PvPokeEntry("wigglytuff", "Wigglytuff", FastMove("Charm", "fairy", 6, 3), listOf(
            ChargedMove("Icy Wind", "ice", 45, 0xFF0891B2.toInt()),
            ChargedMove("Swift", "normal", 35, 0xFF52525B.toInt())
        )),
        PvPokeEntry("dunsparce", "Dunsparce", FastMove("Rollout", "rock", 13, 3), listOf(
            ChargedMove("Drill Run", "ground", 45, 0xFFB45309.toInt()),
            ChargedMove("Rock Slide", "rock", 45, 0xFF78716C.toInt())
        )),
        PvPokeEntry("drapion", "Drapion", FastMove("Poison Sting", "poison", 10, 2), listOf(
            ChargedMove("Aqua Tail", "water", 35, 0xFF0284C7.toInt()),
            ChargedMove("Crunch", "dark", 45, 0xFF334155.toInt())
        )),
        PvPokeEntry("serperior", "Serperior", FastMove("Vine Whip", "grass", 8, 2), listOf(
            ChargedMove("Frenzy Plant", "grass", 45, 0xFF16A34A.toInt()),
            ChargedMove("Aerial Ace", "flying", 40, 0xFF4F46E5.toInt())
        )),
        PvPokeEntry("jumpluff", "Jumpluff", FastMove("Fairy Wind", "fairy", 9, 2), listOf(
            ChargedMove("Aerial Ace", "flying", 40, 0xFF4F46E5.toInt()),
            ChargedMove("Energy Ball", "grass", 55, 0xFF16A34A.toInt())
        )),
        PvPokeEntry("lickilicky", "Lickilicky", FastMove("Rollout", "rock", 13, 3), listOf(
            ChargedMove("Body Slam", "normal", 35, 0xFF52525B.toInt()),
            ChargedMove("Shadow Ball", "ghost", 55, 0xFF6D28D9.toInt())
        )),
        PvPokeEntry("toxapex", "Toxapex", FastMove("Poison Jab", "poison", 7, 2), listOf(
            ChargedMove("Brine", "water", 40, 0xFF0284C7.toInt()),
            ChargedMove("Sludge Wave", "poison", 65, 0xFF9333EA.toInt())
        )),
        PvPokeEntry("dewgong", "Dewgong", FastMove("Ice Shard", "ice", 10, 3), listOf(
            ChargedMove("Icy Wind", "ice", 45, 0xFF0891B2.toInt()),
            ChargedMove("Drill Run", "ground", 45, 0xFFB45309.toInt())
        )),
        PvPokeEntry("giratina", "Giratina", FastMove("Shadow Claw", "ghost", 8, 2), listOf(
            ChargedMove("Dragon Claw", "dragon", 35, 0xFF4338CA.toInt()),
            ChargedMove("Shadow Sneak", "ghost", 45, 0xFF6D28D9.toInt())
        )),
        PvPokeEntry("cresselia", "Cresselia", FastMove("Psycho Cut", "psychic", 9, 2), listOf(
            ChargedMove("Grass Knot", "grass", 50, 0xFF16A34A.toInt()),
            ChargedMove("Moonblast", "fairy", 60, 0xFFBE185D.toInt())
        )),
        PvPokeEntry("zygarde", "Zygarde", FastMove("Dragon Tail", "dragon", 9, 3), listOf(
            ChargedMove("Crunch", "dark", 45, 0xFF334155.toInt()),
            ChargedMove("Earthquake", "ground", 65, 0xFFB45309.toInt())
        )),
        PvPokeEntry("palkia", "Palkia", FastMove("Dragon Breath", "dragon", 3, 1), listOf(
            ChargedMove("Aqua Tail", "water", 35, 0xFF0284C7.toInt()),
            ChargedMove("Spacial Rend", "dragon", 50, 0xFF4338CA.toInt())
        )),
        PvPokeEntry("dialga", "Dialga", FastMove("Dragon Breath", "dragon", 3, 1), listOf(
            ChargedMove("Iron Head", "steel", 50, 0xFF475569.toInt()),
            ChargedMove("Roar of Time", "dragon", 65, 0xFF4338CA.toInt())
        )),
        PvPokeEntry("landorus", "Landorus", FastMove("Mud Shot", "ground", 9, 2), listOf(
            ChargedMove("Sandsear Storm", "ground", 45, 0xFFB45309.toInt()),
            ChargedMove("Stone Edge", "rock", 55, 0xFF78716C.toInt())
        )),
        PvPokeEntry("ho-oh", "Ho-Oh", FastMove("Incinerate", "fire", 20, 5), listOf(
            ChargedMove("Sacred Fire", "fire", 65, 0xFFEA580C.toInt()),
            ChargedMove("Brave Bird", "flying", 55, 0xFF4F46E5.toInt())
        )),
        PvPokeEntry("necrozma", "Necrozma", FastMove("Shadow Claw", "ghost", 8, 2), listOf(
            ChargedMove("Dark Pulse", "dark", 50, 0xFF334155.toInt()),
            ChargedMove("Sunsteel Strike", "steel", 65, 0xFF475569.toInt())
        )),
        PvPokeEntry("rhyperior", "Rhyperior", FastMove("Mud Slap", "ground", 10, 3), listOf(
            ChargedMove("Breaking Swipe", "dragon", 35, 0xFF4338CA.toInt()),
            ChargedMove("Rock Wrecker", "rock", 50, 0xFF78716C.toInt())
        ))
    )

    fun matchPokemonName(ocrText: String): PvPokeEntry? {
        val normalized = ocrText.lowercase()
        return META_POKEMON.firstOrNull { normalized.contains(it.name.lowercase()) }
    }

    fun matchChargedMoveUsed(ocrText: String, entry: PvPokeEntry): ChargedMove? {
        val normalized = ocrText.lowercase()
        if (!normalized.contains("used") && !normalized.contains("incoming")) return null
        return entry.chargedMoves.firstOrNull { normalized.contains(it.name.lowercase()) }
    }
}
