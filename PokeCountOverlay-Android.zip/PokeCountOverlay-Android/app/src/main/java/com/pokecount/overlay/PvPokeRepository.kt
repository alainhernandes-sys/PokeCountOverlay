package com.pokecount.overlay

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

data class FastMove(val name: String, val type: String, val energyGain: Int, val turns: Int)
data class ChargedMove(val name: String, val type: String, val energyCost: Int)
data class PvPokeEntry(
    val id: String,
    val name: String,
    val primaryType: String,
    val fastMoves: List<FastMove>,
    val chargedMoves: List<ChargedMove>
) {
    fun getPvPokeMoveCounts(fastMove: FastMove, chargedMove: ChargedMove, cycles: Int = 4): List<Int> {
        val counts = mutableListOf<Int>()
        var residual = 0
        val eFast = max(1, fastMove.energyGain)
        for (i in 0 until cycles) {
            val needed = max(0, chargedMove.energyCost - residual)
            val moves = ceil(needed.toDouble() / eFast).toInt()
            counts.add(moves)
            residual = (residual + moves * eFast) - chargedMove.energyCost
        }
        return counts
    }
}

object PvPokeRepository {
    private fun fm(name: String, type: String, e: Int, t: Int) = FastMove(name, type, e, t)
    private fun cm(name: String, type: String, cost: Int) = ChargedMove(name, type, cost)

    val BUILT_IN_POKEMON: List<PvPokeEntry> = listOf(
        PvPokeEntry("melmetal", "Melmetal", "steel", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Double Iron Bash*", "steel", 35), cm("Dynamic Punch", "fighting", 45), cm("Superpower", "fighting", 40), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("clodsire", "Clodsire", "poison", listOf(fm("Poison Sting", "poison", 10, 2), fm("Mud Shot", "ground", 9, 2)), listOf(cm("Earthquake", "ground", 65), cm("Stone Edge", "rock", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("feraligatr", "Feraligatr", "water", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Water Gun", "water", 3, 1), fm("Ice Fang", "ice", 6, 2), fm("Waterfall", "water", 8, 3)), listOf(cm("Hydro Cannon*", "water", 40), cm("Ice Beam", "ice", 55), cm("Crunch", "dark", 45))),
        PvPokeEntry("mandibuzz", "Mandibuzz", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Air Slash", "flying", 9, 3)), listOf(cm("Dark Pulse", "dark", 50), cm("Aerial Ace", "flying", 40), cm("Foul Play", "dark", 45))),
        PvPokeEntry("azumarill", "Azumarill", "water", listOf(fm("Bubble", "water", 11, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Ice Beam", "ice", 55), cm("Play Rough", "fairy", 60), cm("Hydro Pump", "water", 75))),
        PvPokeEntry("gastrodon", "Gastrodon", "water", listOf(fm("Mud Slap", "ground", 10, 3), fm("Hidden Power", "normal", 8, 3)), listOf(cm("Body Slam", "normal", 35), cm("Earth Power", "ground", 55), cm("Water Pulse", "water", 55))),
        PvPokeEntry("jumpluff", "Jumpluff", "grass", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Aerial Ace", "flying", 40), cm("Energy Ball", "grass", 55), cm("Acrobatics", "flying", 60))),
        PvPokeEntry("dunsparce", "Dunsparce", "normal", listOf(fm("Rollout", "rock", 13, 3), fm("Bite", "dark", 4, 1), fm("Astonish", "ghost", 10, 3)), listOf(cm("Drill Run", "ground", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("annihilape", "Annihilape", "fighting", listOf(fm("Karate Chop", "fighting", 9, 2), fm("Counter", "fighting", 6, 2)), listOf(cm("Rage Fist*", "ghost", 35), cm("Ice Punch", "ice", 40), cm("Close Combat", "fighting", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("primeape", "Primeape", "fighting", listOf(fm("Karate Chop", "fighting", 9, 2), fm("Counter", "fighting", 6, 2)), listOf(cm("Rage Fist*", "ghost", 35), cm("Close Combat", "fighting", 45), cm("Night Slash", "dark", 35))),
        PvPokeEntry("corsola_galarian", "Corsola (Galarian)", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Night Shade", "ghost", 55), cm("Power Gem", "rock", 60))),
        PvPokeEntry("cursola", "Cursola", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Night Shade", "ghost", 55), cm("Rock Blast", "rock", 40))),
        PvPokeEntry("corviknight", "Corviknight", "steel", listOf(fm("Sand Attack", "ground", 4, 1), fm("Steel Wing", "steel", 6, 2), fm("Air Slash", "flying", 9, 3)), listOf(cm("Sky Attack", "flying", 55), cm("Iron Head", "steel", 50), cm("Payback", "dark", 60))),
        PvPokeEntry("morpeko", "Morpeko", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Aura Wheel", "electric", 45), cm("Psychic Fangs", "psychic", 35), cm("Seed Bomb", "grass", 45))),
        PvPokeEntry("serperior", "Serperior", "grass", listOf(fm("Vine Whip", "grass", 8, 2), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("lickilicky", "Lickilicky", "normal", listOf(fm("Rollout", "rock", 13, 3), fm("Lick", "ghost", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Shadow Ball", "ghost", 55), cm("Earthquake", "ground", 65))),
        PvPokeEntry("lickitung", "Lickitung", "normal", listOf(fm("Lick", "ghost", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Power Whip", "grass", 50))),
        PvPokeEntry("wigglytuff", "Wigglytuff", "normal", listOf(fm("Charm", "fairy", 6, 3), fm("Feint Attack", "dark", 6, 2), fm("Pound", "normal", 4, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Swift", "normal", 35), cm("Disarming Voice", "fairy", 45))),
        PvPokeEntry("clefable", "Clefable", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Charm", "fairy", 6, 3), fm("Pound", "normal", 4, 2)), listOf(cm("Meteor Mash*", "steel", 50), cm("Swift", "normal", 35), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("drapion", "Drapion", "poison", listOf(fm("Poison Sting", "poison", 10, 2), fm("Bite", "dark", 4, 1), fm("Ice Fang", "ice", 6, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("skuntank", "Skuntank", "poison", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Crunch", "dark", 45), cm("Trailblaze", "grass", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("overqwil", "Overqwil", "dark", listOf(fm("Poison Jab", "poison", 7, 2), fm("Poison Sting", "poison", 10, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("qwilfish", "Qwilfish", "water", listOf(fm("Poison Sting", "poison", 10, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Ice Beam", "ice", 55), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("qwilfish_hisuian", "Qwilfish (Hisuian)", "dark", listOf(fm("Poison Jab", "poison", 7, 2), fm("Poison Sting", "poison", 10, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("dewgong", "Dewgong", "water", listOf(fm("Ice Shard", "ice", 10, 3), fm("Frost Breath", "ice", 5, 2), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Drill Run", "ground", 45))),
        PvPokeEntry("toxapex", "Toxapex", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Bite", "dark", 4, 1)), listOf(cm("Brine", "water", 40), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("sandslash_alola", "Sandslash (Alolan)", "ice", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Powder Snow", "ice", 8, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Drill Run", "ground", 45))),
        PvPokeEntry("sandslash", "Sandslash", "ground", listOf(fm("Mud Shot", "ground", 9, 2), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Night Slash", "dark", 35), cm("Scorching Sands", "ground", 50), cm("Earthquake", "ground", 65))),
        PvPokeEntry("ninetales_alolan", "Ninetales (Alolan)", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Charm", "fairy", 6, 3)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Dazzling Gleam", "fairy", 70), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("ninetales", "Ninetales", "fire", listOf(fm("Fire Spin", "fire", 10, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Scorching Sands", "ground", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("carbink", "Carbink", "rock", listOf(fm("Rock Throw", "rock", 5, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("talonflame", "Talonflame", "fire", listOf(fm("Incinerate", "fire", 20, 5), fm("Peck", "flying", 5, 2), fm("Fire Spin", "fire", 10, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Fly", "flying", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("malamar", "Malamar", "dark", listOf(fm("Psywave", "psychic", 4, 1), fm("Psycho Cut", "psychic", 9, 2), fm("Peck", "flying", 5, 2)), listOf(cm("Superpower", "fighting", 40), cm("Foul Play", "dark", 45), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("diggersby", "Diggersby", "normal", listOf(fm("Quick Attack", "normal", 8, 2), fm("Mud Shot", "ground", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Scorching Sands", "ground", 50), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("marowak", "Marowak", "ground", listOf(fm("Mud Slap", "ground", 10, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Bone Club", "ground", 35), cm("Rock Slide", "rock", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("marowak_alolan", "Marowak (Alolan)", "fire", listOf(fm("Fire Spin", "fire", 10, 3), fm("Hex", "ghost", 11, 3), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Bone Club", "ground", 35), cm("Shadow Bone", "ghost", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("stunfisk", "Stunfisk", "ground", listOf(fm("Thunder Shock", "electric", 9, 2), fm("Mud Shot", "ground", 9, 2)), listOf(cm("Mud Bomb", "ground", 40), cm("Discharge", "electric", 45))),
        PvPokeEntry("stunfisk_galarian", "Stunfisk (Galarian)", "ground", listOf(fm("Mud Shot", "ground", 9, 2), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("chesnaught", "Chesnaught", "grass", listOf(fm("Vine Whip", "grass", 8, 2), fm("Smack Down", "rock", 8, 3), fm("Low Kick", "fighting", 5, 2)), listOf(cm("Superpower", "fighting", 40), cm("Frenzy Plant*", "grass", 45))),
        PvPokeEntry("abomasnow", "Abomasnow", "grass", listOf(fm("Powder Snow", "ice", 8, 2), fm("Razor Leaf", "grass", 4, 2), fm("Leafage", "grass", 7, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Energy Ball", "grass", 55), cm("Icy Wind", "ice", 45))),
        PvPokeEntry("bastiodon", "Bastiodon", "rock", listOf(fm("Smack Down", "rock", 8, 3), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Stone Edge", "rock", 55), cm("Flamethrower", "fire", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("probopass", "Probopass", "rock", listOf(fm("Spark", "electric", 7, 2), fm("Rock Throw", "rock", 5, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Magnet Bomb", "steel", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("cresselia", "Cresselia", "psychic", listOf(fm("Psycho Cut", "psychic", 9, 2), fm("Confusion", "psychic", 12, 4)), listOf(cm("Grass Knot", "grass", 50), cm("Moonblast", "fairy", 60), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("registeel", "Registeel", "steel", listOf(fm("Lock On", "normal", 5, 1)), listOf(cm("Focus Blast", "fighting", 75), cm("Zap Cannon", "electric", 80), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("regirock", "Regirock", "rock", listOf(fm("Lock On", "normal", 5, 1)), listOf(cm("Stone Edge", "rock", 55), cm("Focus Blast", "fighting", 75), cm("Earthquake", "ground", 65))),
        PvPokeEntry("regice", "Regice", "ice", listOf(fm("Lock On", "normal", 5, 1)), listOf(cm("Blizzard", "ice", 75), cm("Earthquake", "ground", 65), cm("Thunder", "electric", 60))),
        PvPokeEntry("skarmory", "Skarmory", "steel", listOf(fm("Steel Wing", "steel", 6, 2), fm("Air Slash", "flying", 9, 3)), listOf(cm("Sky Attack", "flying", 55), cm("Brave Bird", "flying", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("medicham", "Medicham", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Dynamic Punch", "fighting", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("sableye", "Sableye", "dark", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Foul Play", "dark", 45), cm("Power Gem", "rock", 60), cm("Return", "normal", 70))),
        PvPokeEntry("umbreon", "Umbreon", "dark", listOf(fm("Snarl", "dark", 13, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Foul Play", "dark", 45), cm("Last Resort*", "normal", 55), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("sylveon", "Sylveon", "fairy", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Psyshock", "psychic", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("vaporeon", "Vaporeon", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Last Resort*", "normal", 55), cm("Scald", "water", 55))),
        PvPokeEntry("jolteon", "Jolteon", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Discharge", "electric", 45), cm("Last Resort*", "normal", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("flareon", "Flareon", "fire", listOf(fm("Fire Spin", "fire", 10, 3)), listOf(cm("Flamethrower", "fire", 55), cm("Superpower", "fighting", 40), cm("Last Resort*", "normal", 55))),
        PvPokeEntry("espeon", "Espeon", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("leafeon", "Leafeon", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Last Resort*", "normal", 55))),
        PvPokeEntry("glaceon", "Glaceon", "ice", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("deoxys_defense", "Deoxys (Defense)", "psychic", listOf(fm("Counter", "fighting", 6, 2), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Psycho Boost", "psychic", 35), cm("Rock Slide", "rock", 45), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("lanturn", "Lanturn", "water", listOf(fm("Spark", "electric", 7, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("swampert", "Swampert", "water", listOf(fm("Mud Shot", "ground", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Hydro Cannon*", "water", 40), cm("Earthquake", "ground", 65), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("marshtomp", "Marshtomp", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Surf", "water", 40), cm("Mud Bomb", "ground", 40), cm("Sludge", "poison", 40))),
        PvPokeEntry("whiscash", "Whiscash", "water", listOf(fm("Mud Shot", "ground", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Mud Bomb", "ground", 40), cm("Scald", "water", 55), cm("Blizzard", "ice", 75))),
        PvPokeEntry("quagsire", "Quagsire", "water", listOf(fm("Mud Shot", "ground", 9, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Mud Bomb", "ground", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("pelipper", "Pelipper", "water", listOf(fm("Wing Attack", "flying", 8, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Hurricane", "flying", 65))),
        PvPokeEntry("mantine", "Mantine", "water", listOf(fm("Wing Attack", "flying", 8, 2), fm("Bubble", "water", 11, 3), fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Aerial Ace", "flying", 40), cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("altaria", "Altaria", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Peck", "flying", 5, 2)), listOf(cm("Sky Attack", "flying", 55), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("pidgeot", "Pidgeot", "normal", listOf(fm("Wing Attack", "flying", 8, 2), fm("Gust", "flying", 12, 4), fm("Steel Wing", "steel", 6, 2)), listOf(cm("Feather Dance", "flying", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("noctowl", "Noctowl", "normal", listOf(fm("Wing Attack", "flying", 8, 2), fm("Extrasensory", "psychic", 10, 3)), listOf(cm("Sky Attack", "flying", 55), cm("Shadow Ball", "ghost", 55), cm("Night Shade", "ghost", 55))),
        PvPokeEntry("staraptor", "Staraptor", "normal", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Fly", "flying", 45), cm("Close Combat", "fighting", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("swellow", "Swellow", "normal", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Aerial Ace", "flying", 40), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("fearow", "Fearow", "normal", listOf(fm("Peck", "flying", 5, 2)), listOf(cm("Drill Run", "ground", 45), cm("Sky Attack", "flying", 55), cm("Drill Peck", "flying", 40))),
        PvPokeEntry("dodrio", "Dodrio", "normal", listOf(fm("Peck", "flying", 5, 2)), listOf(cm("Drill Peck", "flying", 40), cm("Trailblaze", "grass", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("toucannon", "Toucannon", "normal", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Drill Peck", "flying", 40), cm("Rock Blast", "rock", 40))),
        PvPokeEntry("vigoroth", "Vigoroth", "normal", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Body Slam", "normal", 35), cm("Rock Slide", "rock", 45), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("slaking", "Slaking", "normal", listOf(fm("Yawn", "normal", 12, 4)), listOf(cm("Body Slam", "normal", 35), cm("Play Rough", "fairy", 60), cm("Earthquake", "ground", 65))),
        PvPokeEntry("obstagoon", "Obstagoon", "dark", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Night Slash", "dark", 35), cm("Cross Chop", "fighting", 35), cm("Obstruct", "dark", 40))),
        PvPokeEntry("linoone_galarian", "Linoone (Galarian)", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Body Slam", "normal", 35), cm("Dig", "ground", 50))),
        PvPokeEntry("linoone", "Linoone", "normal", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Grass Knot", "grass", 50), cm("Thunder", "electric", 60), cm("Dig", "ground", 50))),
        PvPokeEntry("dubwool", "Dubwool", "normal", listOf(fm("Double Kick", "fighting", 12, 3), fm("Take Down", "normal", 8, 3)), listOf(cm("Body Slam", "normal", 35), cm("Wild Charge", "electric", 45), cm("Payback", "dark", 60))),
        PvPokeEntry("greedent", "Greedent", "normal", listOf(fm("Mud Shot", "ground", 9, 2), fm("Bullet Seed", "grass", 13, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Crunch", "dark", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("oinkologne", "Oinkologne", "normal", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Trailblaze", "grass", 45), cm("Dig", "ground", 50))),
        PvPokeEntry("miltank", "Miltank", "normal", listOf(fm("Rollout", "rock", 13, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Ice Beam", "ice", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("tauros", "Tauros", "normal", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Horn Attack", "normal", 35), cm("Earthquake", "ground", 65), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("tauros_combat", "Tauros (Combat)", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("tauros_blaze", "Tauros (Blaze)", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("tauros_aqua", "Tauros (Aqua)", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Liquidation", "water", 45), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("bouffalant", "Bouffalant", "normal", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Stomp", "normal", 40), cm("Superpower", "fighting", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("kangaskhan", "Kangaskhan", "normal", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Power-Up Punch", "fighting", 35), cm("Outrage", "dragon", 60), cm("Crunch", "dark", 45))),
        PvPokeEntry("snorlax", "Snorlax", "normal", listOf(fm("Lick", "ghost", 3, 1), fm("Zen Headbutt", "psychic", 6, 3)), listOf(cm("Body Slam", "normal", 35), cm("Superpower", "fighting", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("munchlax", "Munchlax", "normal", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Bulldoze", "ground", 60), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("zangoose", "Zangoose", "normal", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Night Slash", "dark", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("oranguru", "Oranguru", "normal", listOf(fm("Confusion", "psychic", 12, 4), fm("Yawn", "normal", 12, 4)), listOf(cm("Brutal Swing", "dark", 40), cm("Trailblaze", "grass", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("girafarig", "Girafarig", "normal", listOf(fm("Double Kick", "fighting", 12, 3), fm("Confusion", "psychic", 12, 4), fm("Tackle", "normal", 3, 1)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Thunderbolt", "electric", 55), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("farigiraf", "Farigiraf", "normal", listOf(fm("Double Kick", "fighting", 12, 3), fm("Tackle", "normal", 3, 1)), listOf(cm("Foul Play", "dark", 45), cm("Trailblaze", "grass", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("bibarel", "Bibarel", "normal", listOf(fm("Rollout", "rock", 13, 3)), listOf(cm("Surf", "water", 40), cm("Hyper Fang", "normal", 50))),
        PvPokeEntry("raticate_alolan", "Raticate (Alolan)", "dark", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("Crunch", "dark", 45), cm("Return", "normal", 70), cm("Hyper Fang", "normal", 50))),
        PvPokeEntry("furret", "Furret", "normal", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Brick Break", "fighting", 40), cm("Trailblaze", "grass", 45), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("castform", "Castform", "normal", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Weather Ball (Rock)", "rock", 35), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("castform_sunny", "Castform (Sunny)", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("castform_rainy", "Castform (Rainy)", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Thunder", "electric", 60))),
        PvPokeEntry("castform_snowy", "Castform (Snowy)", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Blizzard", "ice", 75))),
        PvPokeEntry("cherrim_sunny", "Cherrim (Sunny)", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("scrafty", "Scrafty", "dark", listOf(fm("Counter", "fighting", 6, 2), fm("Snarl", "dark", 13, 3)), listOf(cm("Thunder Punch", "electric", 40), cm("Power-Up Punch", "fighting", 35), cm("Foul Play", "dark", 45))),
        PvPokeEntry("pangoro", "Pangoro", "fighting", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Night Slash", "dark", 35), cm("Close Combat", "fighting", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("guzzlord", "Guzzlord", "dark", listOf(fm("Dragon Tail", "dragon", 9, 3), fm("Snarl", "dark", 13, 3)), listOf(cm("Dragon Claw", "dragon", 35), cm("Brutal Swing", "dark", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("zweilous", "Zweilous", "dark", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("hydreigon", "Hydreigon", "dark", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Brutal Swing", "dark", 40), cm("Dragon Pulse", "dragon", 60))),
        PvPokeEntry("goodra", "Goodra", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Thunder Punch", "electric", 40), cm("Power Whip", "grass", 50))),
        PvPokeEntry("sliggoo", "Sliggoo", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Muddy Water", "water", 35))),
        PvPokeEntry("dragonair", "Dragonair", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Aqua Tail", "water", 35), cm("Body Slam", "normal", 35), cm("Dragon Pulse", "dragon", 60))),
        PvPokeEntry("dragonite", "Dragonite", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Dragon Tail", "dragon", 9, 3), fm("Steel Wing", "steel", 6, 2)), listOf(cm("Dragon Claw", "dragon", 35), cm("Superpower", "fighting", 40), cm("Hurricane", "flying", 65))),
        PvPokeEntry("hakamo_o", "Hakamo-o", "dragon", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Dragon Claw", "dragon", 35), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("kommo_o", "Kommo-o", "dragon", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Dragon Claw", "dragon", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("haxorus", "Haxorus", "dragon", listOf(fm("Counter", "fighting", 6, 2), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Night Slash", "dark", 35), cm("Earthquake", "ground", 65))),
        PvPokeEntry("fraxure", "Fraxure", "dragon", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Aqua Tail", "water", 35), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("flygon", "Flygon", "ground", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Dragon Claw", "dragon", 35), cm("Scorching Sands", "ground", 50), cm("Boomburst", "normal", 70))),
        PvPokeEntry("vibrava", "Vibrava", "ground", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Sand Tomb", "ground", 40), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("garchomp", "Garchomp", "dragon", listOf(fm("Mud Shot", "ground", 9, 2), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Sand Tomb", "ground", 40), cm("Outrage", "dragon", 60), cm("Earth Power", "ground", 55))),
        PvPokeEntry("gabite", "Gabite", "dragon", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Sand Tomb", "ground", 40), cm("Twister", "dragon", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("kingdra", "Kingdra", "water", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Octazooka", "water", 50), cm("Outrage", "dragon", 60))),
        PvPokeEntry("dragalge", "Dragalge", "poison", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Aqua Tail", "water", 35), cm("Outrage", "dragon", 60), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("turtonator", "Turtonator", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Dragon Pulse", "dragon", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("drampa", "Drampa", "normal", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Fly", "flying", 45), cm("Dragon Pulse", "dragon", 60))),
        PvPokeEntry("baxcalibur", "Baxcalibur", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("arctibax", "Arctibax", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("frigibax", "Frigibax", "dragon", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Avalanche", "ice", 45), cm("Dragon Claw", "dragon", 35))),
        PvPokeEntry("dragapult", "Dragapult", "dragon", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("venusaur", "Venusaur", "grass", listOf(fm("Vine Whip", "grass", 8, 2), fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("ivysaur", "Ivysaur", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Power Whip", "grass", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("charizard", "Charizard", "fire", listOf(fm("Wing Attack", "flying", 8, 2), fm("Fire Spin", "fire", 10, 3), fm("Dragon Breath", "dragon", 3, 1), fm("Ember", "fire", 7, 2)), listOf(cm("Dragon Claw", "dragon", 35), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("charmeleon", "Charmeleon", "fire", listOf(fm("Fire Fang", "fire", 8, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("blastoise", "Blastoise", "water", listOf(fm("Rollout", "rock", 13, 3), fm("Water Gun", "water", 3, 1), fm("Bite", "dark", 4, 1)), listOf(cm("Hydro Cannon*", "water", 40), cm("Ice Beam", "ice", 55), cm("Skull Bash", "normal", 75))),
        PvPokeEntry("wartortle", "Wartortle", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Aqua Jet", "water", 45), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("meganium", "Meganium", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("bayleef", "Bayleef", "grass", listOf(fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Grass Knot", "grass", 50), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("typhlosion", "Typhlosion", "fire", listOf(fm("Incinerate", "fire", 20, 5), fm("Shadow Claw", "ghost", 8, 2), fm("Ember", "fire", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("typhlosion_hisuian", "Typhlosion (Hisuian)", "fire", listOf(fm("Hex", "ghost", 11, 3), fm("Ember", "fire", 7, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("quilava", "Quilava", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Dig", "ground", 50))),
        PvPokeEntry("croconaw", "Croconaw", "water", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Crunch", "dark", 45), cm("Ice Punch", "ice", 40))),
        PvPokeEntry("sceptile", "Sceptile", "grass", listOf(fm("Bullet Seed", "grass", 13, 3), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Leaf Blade", "grass", 35), cm("Breaking Swipe", "dragon", 35), cm("Earthquake", "ground", 65))),
        PvPokeEntry("grovyle", "Grovyle", "grass", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("blaziken", "Blaziken", "fire", listOf(fm("Counter", "fighting", 6, 2), fm("Fire Spin", "fire", 10, 3)), listOf(cm("Blaze Kick", "fire", 40), cm("Blast Burn*", "fire", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("combusken", "Combusken", "fire", listOf(fm("Peck", "flying", 5, 2), fm("Ember", "fire", 7, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("torterra", "Torterra", "grass", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Sand Tomb", "ground", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("grotle", "Grotle", "grass", listOf(fm("Bite", "dark", 4, 1)), listOf(cm("Body Slam", "normal", 35), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("infernape", "Infernape", "fire", listOf(fm("Fire Spin", "fire", 10, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Blast Burn*", "fire", 50))),
        PvPokeEntry("monferno", "Monferno", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Flame Wheel", "fire", 55), cm("Low Sweep", "fighting", 40))),
        PvPokeEntry("empoleon", "Empoleon", "water", listOf(fm("Steel Wing", "steel", 6, 2), fm("Waterfall", "water", 8, 3), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Hydro Cannon*", "water", 40), cm("Drill Peck", "flying", 40))),
        PvPokeEntry("prinplup", "Prinplup", "water", listOf(fm("Metal Claw", "steel", 7, 2)), listOf(cm("Bubble Beam", "water", 40), cm("Icy Wind", "ice", 45))),
        PvPokeEntry("servine", "Servine", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Grass Knot", "grass", 50), cm("Wrap", "normal", 45))),
        PvPokeEntry("emboar", "Emboar", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Blast Burn*", "fire", 50), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("pignite", "Pignite", "fire", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Flame Charge", "fire", 50), cm("Rock Tomb", "rock", 60))),
        PvPokeEntry("samurott", "Samurott", "water", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Hydro Cannon*", "water", 40), cm("Megahorn", "bug", 55), cm("Razor Shell", "water", 35))),
        PvPokeEntry("samurott_hisuian", "Samurott (Hisuian)", "water", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Icy Wind", "ice", 45), cm("Dark Pulse", "dark", 50), cm("Razor Shell", "water", 35))),
        PvPokeEntry("dewott", "Dewott", "water", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Aqua Tail", "water", 35), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("quilladin", "Quilladin", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Body Slam", "normal", 35), cm("Gyro Ball", "steel", 60))),
        PvPokeEntry("delphox", "Delphox", "fire", listOf(fm("Fire Spin", "fire", 10, 3)), listOf(cm("Mystical Fire", "fire", 45), cm("Blast Burn*", "fire", 50), cm("Psychic", "psychic", 55))),
        PvPokeEntry("braixen", "Braixen", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("greninja", "Greninja", "water", listOf(fm("Water Shuriken", "water", 14, 3)), listOf(cm("Night Slash", "dark", 35), cm("Hydro Cannon*", "water", 40))),
        PvPokeEntry("frogadier", "Frogadier", "water", listOf(fm("Bubble", "water", 11, 3)), listOf(cm("Surf", "water", 40), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("decidueye", "Decidueye", "grass", listOf(fm("Astonish", "ghost", 10, 3), fm("Magical Leaf", "grass", 10, 3), fm("Leafage", "grass", 7, 2)), listOf(cm("Frenzy Plant*", "grass", 45), cm("Spirit Shackle", "ghost", 40), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("decidueye_hisuian", "Decidueye (Hisuian)", "grass", listOf(fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Aura Sphere", "fighting", 55), cm("Trailblaze", "grass", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("dartrix", "Dartrix", "grass", listOf(fm("Peck", "flying", 5, 2)), listOf(cm("Seed Bomb", "grass", 45), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("incineroar", "Incineroar", "fire", listOf(fm("Snarl", "dark", 13, 3), fm("Fire Fang", "fire", 8, 2), fm("Double Kick", "fighting", 12, 3)), listOf(cm("Blast Burn*", "fire", 50), cm("Darkest Lariat", "dark", 60), cm("Blaze Kick", "fire", 40))),
        PvPokeEntry("torracat", "Torracat", "fire", listOf(fm("Ember", "fire", 7, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Crunch", "dark", 45))),
        PvPokeEntry("primarina", "Primarina", "water", listOf(fm("Charm", "fairy", 6, 3), fm("Waterfall", "water", 8, 3)), listOf(cm("Hydro Cannon*", "water", 40), cm("Disarming Voice", "fairy", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("brionne", "Brionne", "water", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Aqua Jet", "water", 45), cm("Disarming Voice", "fairy", 45))),
        PvPokeEntry("rillaboom", "Rillaboom", "grass", listOf(fm("Scratch", "normal", 2, 1)), listOf(cm("Grass Knot", "grass", 50), cm("Earth Power", "ground", 55))),
        PvPokeEntry("cinderace", "Cinderace", "fire", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Flame Charge", "fire", 50), cm("Flamethrower", "fire", 55), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("inteleon", "Inteleon", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("meowscarada", "Meowscarada", "grass", listOf(fm("Leafage", "grass", 7, 2)), listOf(cm("Night Slash", "dark", 35), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("skeledirge", "Skeledirge", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Disarming Voice", "fairy", 45), cm("Shadow Ball", "ghost", 55), cm("Torch Song", "fire", 45))),
        PvPokeEntry("crocalor", "Crocalor", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Disarming Voice", "fairy", 45), cm("Crunch", "dark", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("quaquaval", "Quaquaval", "water", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Aqua Jet", "water", 45), cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("victreebel", "Victreebel", "grass", listOf(fm("Magical Leaf", "grass", 10, 3), fm("Razor Leaf", "grass", 4, 2), fm("Acid", "poison", 8, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Sludge Bomb", "poison", 50), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("weepinbell", "Weepinbell", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Power Whip", "grass", 50), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("vileplume", "Vileplume", "grass", listOf(fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Sludge Bomb", "poison", 50), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("bellossom", "Bellossom", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("tropius", "Tropius", "grass", listOf(fm("Air Slash", "flying", 9, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("cradily", "Cradily", "rock", listOf(fm("Bullet Seed", "grass", 13, 3), fm("Acid", "poison", 8, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("lileep", "Lileep", "rock", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Ancient Power", "rock", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("ferrothorn", "Ferrothorn", "grass", listOf(fm("Bullet Seed", "grass", 13, 3), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Power Whip", "grass", 50), cm("Thunder", "electric", 60), cm("Mirror Shot", "steel", 35))),
        PvPokeEntry("trevenant", "Trevenant", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Seed Bomb", "grass", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("phantump", "Phantump", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("gourgeist", "Gourgeist", "ghost", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("pumpkaboo", "Pumpkaboo", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("lurantis", "Lurantis", "grass", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Leaf Blade", "grass", 35), cm("Superpower", "fighting", 40))),
        PvPokeEntry("tsareena", "Tsareena", "grass", listOf(fm("Magical Leaf", "grass", 10, 3)), listOf(cm("Triple Axel", "ice", 45), cm("High Jump Kick", "fighting", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("roserade", "Roserade", "grass", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Leaf Storm", "grass", 55))),
        PvPokeEntry("shiftry", "Shiftry", "grass", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Foul Play", "dark", 45), cm("Hurricane", "flying", 65))),
        PvPokeEntry("cacturne", "Cacturne", "grass", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Grass Knot", "grass", 50), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("whimsicott", "Whimsicott", "grass", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Seed Bomb", "grass", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("cottonee", "Cottonee", "grass", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("amoonguss", "Amoonguss", "grass", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Grass Knot", "grass", 50), cm("Foul Play", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("tangrowth", "Tangrowth", "grass", listOf(fm("Vine Whip", "grass", 8, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Power Whip", "grass", 50))),
        PvPokeEntry("sunflora", "Sunflora", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Leaf Storm", "grass", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("cherrim", "Cherrim", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("wormadam_trash", "Wormadam (Trash)", "bug", listOf(fm("Bug Bite", "bug", 3, 1)), listOf(cm("Iron Head", "steel", 50), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("wormadam_plant", "Wormadam (Plant)", "bug", listOf(fm("Bug Bite", "bug", 3, 1)), listOf(cm("Energy Ball", "grass", 55), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("forretress", "Forretress", "bug", listOf(fm("Volt Switch", "electric", 16, 4), fm("Bug Bite", "bug", 3, 1)), listOf(cm("Mirror Shot", "steel", 35), cm("Earthquake", "ground", 65), cm("Rock Tomb", "rock", 60))),
        PvPokeEntry("scizor", "Scizor", "bug", listOf(fm("Bullet Punch", "steel", 7, 2), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Night Slash", "dark", 35), cm("Iron Head", "steel", 50), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("scyther", "Scyther", "bug", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Night Slash", "dark", 35), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("kleavor", "Kleavor", "bug", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("X-Scissor", "bug", 40), cm("Rock Slide", "rock", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("pinsir", "Pinsir", "bug", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("X-Scissor", "bug", 40), cm("Close Combat", "fighting", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("heracross", "Heracross", "bug", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Rock Blast", "rock", 40), cm("Megahorn", "bug", 55), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("escavalier", "Escavalier", "bug", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Drill Run", "ground", 45), cm("Megahorn", "bug", 55), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("shelmet", "Shelmet", "bug", listOf(fm("Infestation", "bug", 12, 3)), listOf(cm("Body Slam", "normal", 35), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("accelgor", "Accelgor", "bug", listOf(fm("Water Shuriken", "water", 14, 3)), listOf(cm("Body Slam", "normal", 35), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("galvantula", "Galvantula", "bug", listOf(fm("Volt Switch", "electric", 16, 4), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Lunge", "bug", 45), cm("Discharge", "electric", 45), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("ariados", "Ariados", "bug", listOf(fm("Poison Sting", "poison", 10, 2), fm("Infestation", "bug", 12, 3)), listOf(cm("Lunge", "bug", 45), cm("Trailblaze", "grass", 45), cm("Megahorn", "bug", 55))),
        PvPokeEntry("beedrill", "Beedrill", "bug", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Drill Run", "ground", 45), cm("X-Scissor", "bug", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("venomoth", "Venomoth", "bug", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Poison Fang", "poison", 40), cm("Bug Buzz", "bug", 60), cm("Silver Wind", "bug", 45))),
        PvPokeEntry("ledian", "Ledian", "bug", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("yanmega", "Yanmega", "bug", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Ancient Power", "rock", 45), cm("Bug Buzz", "bug", 60))),
        PvPokeEntry("leavanny", "Leavanny", "bug", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("scolipede", "Scolipede", "bug", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("X-Scissor", "bug", 40), cm("Sludge Bomb", "poison", 50), cm("Megahorn", "bug", 55))),
        PvPokeEntry("crustle", "Crustle", "bug", listOf(fm("Smack Down", "rock", 8, 3)), listOf(cm("Rock Slide", "rock", 45), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("durant", "Durant", "bug", listOf(fm("Metal Claw", "steel", 7, 2)), listOf(cm("X-Scissor", "bug", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("genesect", "Genesect", "bug", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Techno Blast", "normal", 55), cm("X-Scissor", "bug", 40), cm("Magnet Bomb", "steel", 45))),
        PvPokeEntry("araquanid", "Araquanid", "water", listOf(fm("Bug Bite", "bug", 3, 1), fm("Infestation", "bug", 12, 3)), listOf(cm("Bubble Beam", "water", 40), cm("Bug Buzz", "bug", 60), cm("Water Pulse", "water", 55))),
        PvPokeEntry("dewpider", "Dewpider", "water", listOf(fm("Bug Bite", "bug", 3, 1)), listOf(cm("Bubble Beam", "water", 40), cm("Mirror Coat", "psychic", 55))),
        PvPokeEntry("golisopod", "Golisopod", "bug", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Fury Cutter", "bug", 4, 1), fm("Waterfall", "water", 8, 3)), listOf(cm("Liquidation", "water", 45), cm("X-Scissor", "bug", 40), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("charjabug", "Charjabug", "bug", listOf(fm("Volt Switch", "electric", 16, 4), fm("Bug Bite", "bug", 3, 1)), listOf(cm("X-Scissor", "bug", 40), cm("Discharge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("vikavolt", "Vikavolt", "bug", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Fly", "flying", 45), cm("Discharge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("ribombee", "Ribombee", "bug", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Dazzling Gleam", "fairy", 70), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("lokix", "Lokix", "bug", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Trailblaze", "grass", 45), cm("X-Scissor", "bug", 40), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("buzzwole", "Buzzwole", "bug", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Lunge", "bug", 45), cm("Superpower", "fighting", 40), cm("Power-Up Punch", "fighting", 35))),
        PvPokeEntry("machamp", "Machamp", "fighting", listOf(fm("Counter", "fighting", 6, 2), fm("Karate Chop", "fighting", 9, 2), fm("Bullet Punch", "steel", 7, 2)), listOf(cm("Cross Chop", "fighting", 35), cm("Rock Slide", "rock", 45), cm("Payback", "dark", 60))),
        PvPokeEntry("machoke", "Machoke", "fighting", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Cross Chop", "fighting", 35), cm("Brick Break", "fighting", 40), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("hariyama", "Hariyama", "fighting", listOf(fm("Force Palm", "fighting", 13, 3)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Upper Hand", "fighting", 40), cm("Superpower", "fighting", 40))),
        PvPokeEntry("hitmonchan", "Hitmonchan", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Thunder Punch", "electric", 40), cm("Fire Punch", "fire", 40), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("hitmontop", "Hitmontop", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Triple Axel", "ice", 45), cm("Close Combat", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("hitmonlee", "Hitmonlee", "fighting", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("poliwrath", "Poliwrath", "water", listOf(fm("Counter", "fighting", 6, 2), fm("Mud Shot", "ground", 9, 2), fm("Bubble", "water", 11, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Scald", "water", 55), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("politoed", "Politoed", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Weather Ball (Water)", "water", 35), cm("Earthquake", "ground", 65), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("toxicroak", "Toxicroak", "poison", listOf(fm("Counter", "fighting", 6, 2), fm("Mud Shot", "ground", 9, 2), fm("Poison Jab", "poison", 7, 2)), listOf(cm("Mud Bomb", "ground", 40), cm("Shadow Ball", "ghost", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("sneasler", "Sneasler", "fighting", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Poison Jab", "poison", 7, 2), fm("Rock Smash", "fighting", 7, 3)), listOf(cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("sneasel_hisuian", "Sneasel (Hisuian)", "fighting", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Close Combat", "fighting", 45), cm("Aerial Ace", "flying", 40), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("sneasel", "Sneasel", "dark", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Avalanche", "ice", 45), cm("Triple Axel", "ice", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("weavile", "Weavile", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Triple Axel", "ice", 45), cm("Avalanche", "ice", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("sirfetchd", "Sirfetch'd", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Night Slash", "dark", 35), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("lucario", "Lucario", "fighting", listOf(fm("Force Palm", "fighting", 13, 3), fm("Counter", "fighting", 6, 2), fm("Bullet Punch", "steel", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Shadow Ball", "ghost", 55), cm("Power-Up Punch", "fighting", 35))),
        PvPokeEntry("gallade", "Gallade", "psychic", listOf(fm("Psycho Cut", "psychic", 9, 2), fm("Confusion", "psychic", 12, 4), fm("Charm", "fairy", 6, 3)), listOf(cm("Leaf Blade", "grass", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("gardevoir", "Gardevoir", "psychic", listOf(fm("Charm", "fairy", 6, 3), fm("Confusion", "psychic", 12, 4)), listOf(cm("Shadow Ball", "ghost", 55), cm("Triple Axel", "ice", 45), cm("Synchronoise", "psychic", 50))),
        PvPokeEntry("conkeldurr", "Conkeldurr", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Brutal Swing", "dark", 40), cm("Dynamic Punch", "fighting", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("gurdurr", "Gurdurr", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("throh", "Throh", "fighting", listOf(fm("Low Kick", "fighting", 5, 2)), listOf(cm("Body Slam", "normal", 35), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("sawk", "Sawk", "fighting", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Body Slam", "normal", 35), cm("Close Combat", "fighting", 45))),
        PvPokeEntry("mienfoo", "Mienfoo", "fighting", listOf(fm("Force Palm", "fighting", 13, 3)), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("mienshao", "Mienshao", "fighting", listOf(fm("Force Palm", "fighting", 13, 3)), listOf(cm("Brick Break", "fighting", 40), cm("Stone Edge", "rock", 55), cm("Blaze Kick", "fire", 40))),
        PvPokeEntry("hawlucha", "Hawlucha", "fighting", listOf(fm("Wing Attack", "flying", 8, 2), fm("Poison Jab", "poison", 7, 2), fm("Low Kick", "fighting", 5, 2)), listOf(cm("Flying Press", "fighting", 40), cm("Sky Attack", "flying", 55), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("bewear", "Bewear", "normal", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Superpower", "fighting", 40), cm("Stomp", "normal", 40), cm("Payback", "dark", 60))),
        PvPokeEntry("stufful", "Stufful", "normal", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Superpower", "fighting", 40))),
        PvPokeEntry("passimian", "Passimian", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Brutal Swing", "dark", 40), cm("Close Combat", "fighting", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("falinks", "Falinks", "fighting", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Superpower", "fighting", 40), cm("Brick Break", "fighting", 40), cm("Megahorn", "bug", 55))),
        PvPokeEntry("pawmot", "Pawmot", "electric", listOf(fm("Spark", "electric", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Close Combat", "fighting", 45), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("pawmo", "Pawmo", "electric", listOf(fm("Spark", "electric", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Discharge", "electric", 45))),
        PvPokeEntry("jellicent", "Jellicent", "water", listOf(fm("Hex", "ghost", 11, 3), fm("Bubble", "water", 11, 3)), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55), cm("Bubble Beam", "water", 40))),
        PvPokeEntry("frillish", "Frillish", "water", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Ominous Wind", "ghost", 45), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("gengar", "Gengar", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Hex", "ghost", 11, 3), fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Shadow Punch", "ghost", 35), cm("Sludge Bomb", "poison", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("haunter", "Haunter", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Astonish", "ghost", 10, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Sludge Bomb", "poison", 50), cm("Ice Punch", "ice", 40))),
        PvPokeEntry("drifblim", "Drifblim", "ghost", listOf(fm("Astonish", "ghost", 10, 3), fm("Hex", "ghost", 11, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Mystical Fire", "fire", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("froslass", "Froslass", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Hex", "ghost", 11, 3)), listOf(cm("Avalanche", "ice", 45), cm("Triple Axel", "ice", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("spiritomb", "Spiritomb", "ghost", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Rock Tomb", "rock", 60), cm("Shadow Ball", "ghost", 55), cm("Ominous Wind", "ghost", 45))),
        PvPokeEntry("dusknoir", "Dusknoir", "ghost", listOf(fm("Astonish", "ghost", 10, 3), fm("Hex", "ghost", 11, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Dynamic Punch", "fighting", 45), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("dusclops", "Dusclops", "ghost", listOf(fm("Hex", "ghost", 11, 3), fm("Feint Attack", "dark", 6, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Shadow Punch", "ghost", 35), cm("Poltergeist", "ghost", 75))),
        PvPokeEntry("banette", "Banette", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Shadow Ball", "ghost", 55), cm("Thunder", "electric", 60), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("mismagius", "Mismagius", "ghost", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Shadow Ball", "ghost", 55), cm("Mystical Fire", "fire", 45), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("misdreavus", "Misdreavus", "ghost", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Ominous Wind", "ghost", 45), cm("Shadow Sneak", "ghost", 45))),
        PvPokeEntry("cofagrigus", "Cofagrigus", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Shadow Ball", "ghost", 55), cm("Dark Pulse", "dark", 50), cm("Psychic", "psychic", 55))),
        PvPokeEntry("runerigus", "Runerigus", "ground", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Brutal Swing", "dark", 40), cm("Sand Tomb", "ground", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("chandelure", "Chandelure", "ghost", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55), cm("Overheat", "fire", 55))),
        PvPokeEntry("lampent", "Lampent", "ghost", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("golurk", "Golurk", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Earth Power", "ground", 55), cm("Dynamic Punch", "fighting", 45))),
        PvPokeEntry("golett", "Golett", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Shadow Punch", "ghost", 35), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("aegislash", "Aegislash", "steel", listOf(fm("Psycho Cut", "psychic", 9, 2)), listOf(cm("Shadow Ball", "ghost", 55), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("palossand", "Palossand", "ghost", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Scorching Sands", "ground", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("mimikyu", "Mimikyu", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Play Rough", "fairy", 60), cm("Shadow Sneak", "ghost", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("gholdengo", "Gholdengo", "steel", listOf(fm("Hex", "ghost", 11, 3)), listOf(cm("Shadow Ball", "ghost", 55), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("houndstone", "Houndstone", "ghost", listOf(fm("Lick", "ghost", 3, 1)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Shadow Ball", "ghost", 55), cm("Dig", "ground", 50))),
        PvPokeEntry("ceruledge", "Ceruledge", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("armarouge", "Armarouge", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("hypno", "Hypno", "psychic", listOf(fm("Confusion", "psychic", 12, 4), fm("Psywave", "psychic", 4, 1)), listOf(cm("Thunder Punch", "electric", 40), cm("Ice Punch", "ice", 40), cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("alakazam", "Alakazam", "psychic", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Shadow Ball", "ghost", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowbro", "Slowbro", "water", listOf(fm("Confusion", "psychic", 12, 4), fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Ice Beam", "ice", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowbro_galarian", "Slowbro (Galarian)", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Confusion", "psychic", 12, 4)), listOf(cm("Brutal Swing", "dark", 40), cm("Surf", "water", 40), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("slowking", "Slowking", "water", listOf(fm("Confusion", "psychic", 12, 4), fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Blizzard", "ice", 75), cm("Psychic", "psychic", 55))),
        PvPokeEntry("slowking_galarian", "Slowking (Galarian)", "poison", listOf(fm("Hex", "ghost", 11, 3), fm("Confusion", "psychic", 12, 4), fm("Acid", "poison", 8, 2)), listOf(cm("Surf", "water", 40), cm("Shadow Ball", "ghost", 55), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("starmie", "Starmie", "water", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("Surf", "water", 40), cm("Psybeam", "psychic", 60), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("mr._mime", "Mr. Mime", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psybeam", "psychic", 60), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("mr._rime", "Mr. Rime", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Triple Axel", "ice", 45), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("xatu", "Xatu", "psychic", listOf(fm("Feint Attack", "dark", 6, 2)), listOf(cm("Aerial Ace", "flying", 40), cm("Ominous Wind", "ghost", 45), cm("Future Sight", "psychic", 65))),
        PvPokeEntry("wobbuffet", "Wobbuffet", "psychic", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Mirror Coat", "psychic", 55), cm("Return", "normal", 70))),
        PvPokeEntry("grumpig", "Grumpig", "psychic", listOf(fm("Psywave", "psychic", 4, 1)), listOf(cm("Dynamic Punch", "fighting", 45), cm("Shadow Ball", "ghost", 55), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("spoink", "Spoink", "psychic", listOf(fm("Splash", "water", 12, 4)), listOf(cm("Mirror Coat", "psychic", 55), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("claydol", "Claydol", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Scorching Sands", "ground", 50), cm("Ice Beam", "ice", 55), cm("Rock Tomb", "rock", 60), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("bronzong", "Bronzong", "steel", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psyshock", "psychic", 45), cm("Payback", "dark", 60), cm("Bulldoze", "ground", 60))),
        PvPokeEntry("bronzor", "Bronzor", "steel", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Psyshock", "psychic", 45), cm("Payback", "dark", 60), cm("Heavy Slam", "steel", 50))),
        PvPokeEntry("chimecho", "Chimecho", "psychic", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Psyshock", "psychic", 45), cm("Shadow Ball", "ghost", 55), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("jirachi", "Jirachi", "steel", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Doom Desire", "steel", 40), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("victini", "Victini", "psychic", listOf(fm("Quick Attack", "normal", 8, 2)), listOf(cm("V-create", "fire", 40), cm("Psyshock", "psychic", 45), cm("Overheat", "fire", 55))),
        PvPokeEntry("mew", "Mew", "psychic", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Volt Switch", "electric", 16, 4), fm("Snarl", "dark", 13, 3), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Surf", "water", 40), cm("Wild Charge", "electric", 45), cm("Psyshock", "psychic", 45), cm("Flame Charge", "fire", 50))),
        PvPokeEntry("celebi", "Celebi", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Seed Bomb", "grass", 45), cm("Leaf Storm", "grass", 55), cm("Psychic", "psychic", 55))),
        PvPokeEntry("gothorita", "Gothorita", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psyshock", "psychic", 45), cm("Foul Play", "dark", 45))),
        PvPokeEntry("gothitelle", "Gothitelle", "psychic", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Rock Slide", "rock", 45), cm("Psychic", "psychic", 55))),
        PvPokeEntry("reuniclus", "Reuniclus", "psychic", listOf(fm("Hidden Power", "normal", 8, 3)), listOf(cm("Shadow Ball", "ghost", 55), cm("Thunder", "electric", 60))),
        PvPokeEntry("beheeyem", "Beheeyem", "psychic", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Psychic", "psychic", 55), cm("Rock Slide", "rock", 45), cm("Dark Pulse", "dark", 50))),
        PvPokeEntry("meowstic", "Meowstic", "psychic", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Psyshock", "psychic", 45), cm("Energy Ball", "grass", 55), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("hatterene", "Hatterene", "psychic", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Psyshock", "psychic", 45), cm("Power Whip", "grass", 50))),
        PvPokeEntry("rapidash_galarian", "Rapidash (Galarian)", "psychic", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Body Slam", "normal", 35), cm("Play Rough", "fairy", 60), cm("Megahorn", "bug", 55))),
        PvPokeEntry("rapidash", "Rapidash", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Drill Run", "ground", 45), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("granbull", "Granbull", "fairy", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Crunch", "dark", 45), cm("Close Combat", "fighting", 45), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("snubbull", "Snubbull", "fairy", listOf(fm("Bite", "dark", 4, 1)), listOf(cm("Crunch", "dark", 45), cm("Brick Break", "fighting", 40))),
        PvPokeEntry("togetic", "Togetic", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Aerial Ace", "flying", 40), cm("Ancient Power", "rock", 45), cm("Dazzling Gleam", "fairy", 70))),
        PvPokeEntry("togekiss", "Togekiss", "fairy", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Ancient Power", "rock", 45), cm("Aura Sphere", "fighting", 55), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("mawile", "Mawile", "steel", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Power-Up Punch", "fighting", 35), cm("Play Rough", "fairy", 60), cm("Iron Head", "steel", 50))),
        PvPokeEntry("slurpuff", "Slurpuff", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Flamethrower", "fire", 55), cm("Play Rough", "fairy", 60), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("aromatisse", "Aromatisse", "fairy", listOf(fm("Charm", "fairy", 6, 3)), listOf(cm("Psychic", "psychic", 55), cm("Thunderbolt", "electric", 55), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("florges", "Florges", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Disarming Voice", "fairy", 45), cm("Trailblaze", "grass", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("floette", "Floette", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Brick Break", "fighting", 40), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("dedenne", "Dedenne", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Discharge", "electric", 45), cm("Play Rough", "fairy", 60), cm("Parabolic Charge", "electric", 55))),
        PvPokeEntry("klefki", "Klefki", "steel", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Foul Play", "dark", 45), cm("Play Rough", "fairy", 60), cm("Flash Cannon", "steel", 70))),
        PvPokeEntry("shiinotic", "Shiinotic", "grass", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Seed Bomb", "grass", 45), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("tapu_fini", "Tapu Fini", "water", listOf(fm("Water Gun", "water", 3, 1)), listOf(cm("Surf", "water", 40), cm("Nature's Madness", "fairy", 50), cm("Moonblast", "fairy", 60))),
        PvPokeEntry("tinkaton", "Tinkaton", "fairy", listOf(fm("Fairy Wind", "fairy", 9, 2)), listOf(cm("Play Rough", "fairy", 60), cm("Heavy Slam", "steel", 50), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("grimmsnarl", "Grimmsnarl", "dark", listOf(fm("Sucker Punch", "dark", 7, 2)), listOf(cm("Foul Play", "dark", 45), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("ampharos", "Ampharos", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Brutal Swing", "dark", 40), cm("Trailblaze", "grass", 45), cm("Thunder Punch", "electric", 40), cm("Zap Cannon", "electric", 80))),
        PvPokeEntry("raichu", "Raichu", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Thunder Shock", "electric", 9, 2), fm("Spark", "electric", 7, 2)), listOf(cm("Brick Break", "fighting", 40), cm("Trailblaze", "grass", 45), cm("Wild Charge", "electric", 45), cm("Thunder Punch", "electric", 40))),
        PvPokeEntry("raichu_alolan", "Raichu (Alolan)", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Thunder Shock", "electric", 9, 2), fm("Spark", "electric", 7, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Trailblaze", "grass", 45), cm("Wild Charge", "electric", 45), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("pikachu", "Pikachu", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Fly", "flying", 45), cm("Wild Charge", "electric", 45), cm("Surf", "water", 40))),
        PvPokeEntry("magneton", "Magneton", "electric", listOf(fm("Thunder Shock", "electric", 9, 2), fm("Spark", "electric", 7, 2)), listOf(cm("Magnet Bomb", "steel", 45), cm("Discharge", "electric", 45), cm("Zap Cannon", "electric", 80))),
        PvPokeEntry("magnezone", "Magnezone", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Spark", "electric", 7, 2)), listOf(cm("Mirror Shot", "steel", 35), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("electrode", "Electrode", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Discharge", "electric", 45), cm("Foul Play", "dark", 45), cm("Hyper Beam", "normal", 80))),
        PvPokeEntry("electrode_hisuian", "Electrode (Hisuian)", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Energy Ball", "grass", 55), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("electabuzz", "Electabuzz", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Thunder Punch", "electric", 40), cm("Flamethrower", "fire", 55), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("electivire", "Electivire", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Wild Charge", "electric", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("luxray", "Luxray", "electric", listOf(fm("Spark", "electric", 7, 2)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("pachirisu", "Pachirisu", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Thunder Punch", "electric", 40), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("emolga", "Emolga", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Acrobatics", "flying", 60), cm("Discharge", "electric", 45), cm("Aerial Ace", "flying", 40))),
        PvPokeEntry("eelektross", "Eelektross", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Dragon Claw", "dragon", 35), cm("Liquidation", "water", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("heliolisk", "Heliolisk", "electric", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Grass Knot", "grass", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("togedemaru", "Togedemaru", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Fell Stinger", "bug", 35), cm("Wild Charge", "electric", 45), cm("Gyro Ball", "steel", 60))),
        PvPokeEntry("bellibolt", "Bellibolt", "electric", listOf(fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Discharge", "electric", 45), cm("Zap Cannon", "electric", 80), cm("Water Pulse", "water", 55))),
        PvPokeEntry("lapras", "Lapras", "water", listOf(fm("Ice Shard", "ice", 10, 3), fm("Water Gun", "water", 3, 1), fm("Psywave", "psychic", 4, 1)), listOf(cm("Surf", "water", 40), cm("Ice Beam", "ice", 55), cm("Skull Bash", "normal", 75))),
        PvPokeEntry("sealeo", "Sealeo", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Water Gun", "water", 3, 1)), listOf(cm("Body Slam", "normal", 35), cm("Aurora Beam", "ice", 60))),
        PvPokeEntry("walrein", "Walrein", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Waterfall", "water", 8, 3)), listOf(cm("Icicle Spear", "ice", 40), cm("Earthquake", "ground", 65))),
        PvPokeEntry("cloyster", "Cloyster", "water", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Icy Wind", "ice", 45), cm("Liquidation", "water", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("seaking", "Seaking", "water", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Drill Run", "ground", 45))),
        PvPokeEntry("gyarados", "Gyarados", "water", listOf(fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45))),
        PvPokeEntry("kingler", "Kingler", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("X-Scissor", "bug", 40), cm("Crabhammer", "water", 50), cm("Razor Shell", "water", 35))),
        PvPokeEntry("crawdaunt", "Crawdaunt", "water", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Night Slash", "dark", 35), cm("Crabhammer", "water", 50))),
        PvPokeEntry("sharpedo", "Sharpedo", "water", listOf(fm("Waterfall", "water", 8, 3)), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("tentacruel", "Tentacruel", "water", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Scald", "water", 55), cm("Acid Spray", "poison", 45), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("golduck", "Golduck", "water", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Cross Chop", "fighting", 35), cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("ludicolo", "Ludicolo", "water", listOf(fm("Bubble", "water", 11, 3)), listOf(cm("Ice Beam", "ice", 55), cm("Leaf Storm", "grass", 55), cm("Energy Ball", "grass", 55))),
        PvPokeEntry("lombre", "Lombre", "water", listOf(fm("Bubble", "water", 11, 3)), listOf(cm("Ice Beam", "ice", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("seismitoad", "Seismitoad", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Muddy Water", "water", 35), cm("Earth Power", "ground", 55), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("palpitoad", "Palpitoad", "water", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Mud Bomb", "ground", 40), cm("Earth Power", "ground", 55))),
        PvPokeEntry("carracosta", "Carracosta", "water", listOf(fm("Rock Throw", "rock", 5, 2)), listOf(cm("Body Slam", "normal", 35), cm("Surf", "water", 40), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("swanna", "Swanna", "water", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Bubble Beam", "water", 40), cm("Fly", "flying", 45), cm("Hurricane", "flying", 65))),
        PvPokeEntry("alomomola", "Alomomola", "water", listOf(fm("Waterfall", "water", 8, 3)), listOf(cm("Psychic", "psychic", 55), cm("Blizzard", "ice", 75))),
        PvPokeEntry("barbaracle", "Barbaracle", "rock", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Cross Chop", "fighting", 35), cm("Stone Edge", "rock", 55), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("bruxish", "Bruxish", "water", listOf(fm("Confusion", "psychic", 12, 4)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Aqua Tail", "water", 35), cm("Crunch", "dark", 45))),
        PvPokeEntry("dondozo", "Dondozo", "water", listOf(fm("Waterfall", "water", 8, 3)), listOf(cm("Body Slam", "normal", 35), cm("Liquidation", "water", 45), cm("Outrage", "dragon", 60))),
        PvPokeEntry("basculegion", "Basculegion", "water", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Aqua Jet", "water", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("gligar", "Gligar", "ground", listOf(fm("Wing Attack", "flying", 8, 2), fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Aerial Ace", "flying", 40), cm("Dig", "ground", 50), cm("Night Slash", "dark", 35))),
        PvPokeEntry("gliscor", "Gliscor", "ground", listOf(fm("Wing Attack", "flying", 8, 2), fm("Fury Cutter", "bug", 4, 1), fm("Sand Attack", "ground", 4, 1)), listOf(cm("Night Slash", "dark", 35), cm("Earthquake", "ground", 65), cm("Sand Tomb", "ground", 40))),
        PvPokeEntry("steelix", "Steelix", "steel", listOf(fm("Thunder Fang", "electric", 5, 2), fm("Dragon Tail", "dragon", 9, 3), fm("Iron Tail", "steel", 6, 3)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Breaking Swipe", "dragon", 35), cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("onix", "Onix", "rock", listOf(fm("Rock Throw", "rock", 5, 2)), listOf(cm("Sand Tomb", "ground", 40), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("donphan", "Donphan", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Body Slam", "normal", 35), cm("Trailblaze", "grass", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("hippowdon", "Hippowdon", "ground", listOf(fm("Sand Attack", "ground", 4, 1)), listOf(cm("Weather Ball (Rock)", "rock", 35), cm("Scorching Sands", "ground", 50), cm("Body Slam", "normal", 35))),
        PvPokeEntry("rhydon", "Rhydon", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Surf", "water", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("rhyperior", "Rhyperior", "ground", listOf(fm("Mud Slap", "ground", 10, 3), fm("Smack Down", "rock", 8, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Surf", "water", 40), cm("Rock Wrecker*", "rock", 50))),
        PvPokeEntry("excadrill", "Excadrill", "ground", listOf(fm("Mud Shot", "ground", 9, 2), fm("Mud Slap", "ground", 10, 3), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Drill Run", "ground", 45), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("krookodile", "Krookodile", "ground", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Brick Break", "fighting", 40), cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("mamoswine", "Mamoswine", "ice", listOf(fm("Powder Snow", "ice", 8, 2), fm("Mud Slap", "ground", 10, 3)), listOf(cm("Avalanche", "ice", 45), cm("High Horsepower", "ground", 60))),
        PvPokeEntry("piloswine", "Piloswine", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Avalanche", "ice", 45), cm("High Horsepower", "ground", 60), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("swinub", "Swinub", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Body Slam", "normal", 35))),
        PvPokeEntry("avalugg", "Avalugg", "ice", listOf(fm("Ice Fang", "ice", 6, 2)), listOf(cm("Body Slam", "normal", 35), cm("Icy Wind", "ice", 45), cm("Avalanche", "ice", 45))),
        PvPokeEntry("avalugg_hisuian", "Avalugg (Hisuian)", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Icy Wind", "ice", 45), cm("Rock Slide", "rock", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("aurorus", "Aurorus", "rock", listOf(fm("Powder Snow", "ice", 8, 2), fm("Rock Throw", "rock", 5, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Meteor Beam", "rock", 60), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("amaura", "Amaura", "rock", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Weather Ball (Ice)", "ice", 35), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("beartic", "Beartic", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Ice Punch", "ice", 40), cm("Surf", "water", 40))),
        PvPokeEntry("cryogonal", "Cryogonal", "ice", listOf(fm("Ice Shard", "ice", 10, 3)), listOf(cm("Triple Axel", "ice", 45), cm("Night Slash", "dark", 35), cm("Water Pulse", "water", 55))),
        PvPokeEntry("cetitan", "Cetitan", "ice", listOf(fm("Powder Snow", "ice", 8, 2)), listOf(cm("Body Slam", "normal", 35), cm("Avalanche", "ice", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("golem", "Golem", "rock", listOf(fm("Mud Slap", "ground", 10, 3)), listOf(cm("Rock Blast", "rock", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("golem_alolan", "Golem (Alolan)", "rock", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Rock Blast", "rock", 40), cm("Wild Charge", "electric", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("graveler_alolan", "Graveler (Alolan)", "rock", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Rock Blast", "rock", 40), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("sudowoodo", "Sudowoodo", "rock", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Trailblaze", "grass", 45), cm("Meteor Beam", "rock", 60))),
        PvPokeEntry("magcargo", "Magcargo", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Rock Tomb", "rock", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("lairon", "Lairon", "steel", listOf(fm("Metal Claw", "steel", 7, 2)), listOf(cm("Body Slam", "normal", 35), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("aggron", "Aggron", "steel", listOf(fm("Smack Down", "rock", 8, 3)), listOf(cm("Heavy Slam", "steel", 50), cm("Meteor Beam", "rock", 60), cm("Thunder", "electric", 60))),
        PvPokeEntry("rampardos", "Rampardos", "rock", listOf(fm("Smack Down", "rock", 8, 3)), listOf(cm("Rock Slide", "rock", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("archeops", "Archeops", "rock", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Dragon Claw", "dragon", 35), cm("Ancient Power", "rock", 45))),
        PvPokeEntry("gigalith", "Gigalith", "rock", listOf(fm("Smack Down", "rock", 8, 3)), listOf(cm("Superpower", "fighting", 40), cm("Meteor Beam", "rock", 60), cm("Rock Slide", "rock", 45))),
        PvPokeEntry("tyrantrum", "Tyrantrum", "rock", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Crunch", "dark", 45), cm("Meteor Beam", "rock", 60))),
        PvPokeEntry("lycanroc_midnight", "Lycanroc (Midnight)", "rock", listOf(fm("Counter", "fighting", 6, 2)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Crunch", "dark", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("garganacl", "Garganacl", "rock", listOf(fm("Smack Down", "rock", 8, 3)), listOf(cm("Rock Slide", "rock", 45), cm("Superpower", "fighting", 40))),
        PvPokeEntry("nidoqueen", "Nidoqueen", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Bite", "dark", 4, 1)), listOf(cm("Poison Fang", "poison", 40), cm("Earth Power", "ground", 55), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("nidoking", "Nidoking", "poison", listOf(fm("Double Kick", "fighting", 12, 3)), listOf(cm("Sand Tomb", "ground", 40), cm("Earth Power", "ground", 55), cm("Megahorn", "bug", 55))),
        PvPokeEntry("nidorina", "Nidorina", "poison", listOf(fm("Poison Sting", "poison", 10, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Dig", "ground", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("golbat", "Golbat", "poison", listOf(fm("Wing Attack", "flying", 8, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("crobat", "Crobat", "poison", listOf(fm("Air Slash", "flying", 9, 3)), listOf(cm("Poison Fang", "poison", 40), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("muk", "Muk", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Infestation", "bug", 12, 3)), listOf(cm("Thunder Punch", "electric", 40), cm("Dark Pulse", "dark", 50), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("muk_alolan", "Muk (Alolan)", "poison", listOf(fm("Poison Jab", "poison", 7, 2), fm("Snarl", "dark", 13, 3), fm("Bite", "dark", 4, 1)), listOf(cm("Acid Spray", "poison", 45), cm("Dark Pulse", "dark", 50), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("grimer_alolan", "Grimer (Alolan)", "poison", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Crunch", "dark", 45), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("weezing", "Weezing", "poison", listOf(fm("Tackle", "normal", 3, 1)), listOf(cm("Sludge Bomb", "poison", 50), cm("Thunderbolt", "electric", 55))),
        PvPokeEntry("weezing_galarian", "Weezing (Galarian)", "poison", listOf(fm("Fairy Wind", "fairy", 9, 2), fm("Tackle", "normal", 3, 1)), listOf(cm("Brutal Swing", "dark", 40), cm("Sludge", "poison", 40), cm("Overheat", "fire", 55), cm("Play Rough", "fairy", 60))),
        PvPokeEntry("swalot", "Swalot", "poison", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Ice Beam", "ice", 55), cm("Sludge Bomb", "poison", 50), cm("Acid Spray", "poison", 45))),
        PvPokeEntry("seviper", "Seviper", "poison", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Poison Fang", "poison", 40), cm("Crunch", "dark", 45))),
        PvPokeEntry("arbok", "Arbok", "poison", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Acid Spray", "poison", 45), cm("Dark Pulse", "dark", 50), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("garbodor", "Garbodor", "poison", listOf(fm("Infestation", "bug", 12, 3)), listOf(cm("Body Slam", "normal", 35), cm("Seed Bomb", "grass", 45), cm("Gunk Shot", "poison", 75))),
        PvPokeEntry("salazzle", "Salazzle", "poison", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Poison Fang", "poison", 40), cm("Dragon Pulse", "dragon", 60), cm("Sludge Wave", "poison", 65))),
        PvPokeEntry("grafaiai", "Grafaiai", "poison", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Acrobatics", "flying", 60), cm("Sludge Bomb", "poison", 50))),
        PvPokeEntry("revavroom", "Revavroom", "steel", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Acid Spray", "poison", 45), cm("Gyro Ball", "steel", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("bisharp", "Bisharp", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Dark Pulse", "dark", 50), cm("Iron Head", "steel", 50), cm("X-Scissor", "bug", 40))),
        PvPokeEntry("kingambit", "Kingambit", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Dark Pulse", "dark", 50), cm("Iron Head", "steel", 50), cm("Focus Blast", "fighting", 75))),
        PvPokeEntry("pawniard", "Pawniard", "dark", listOf(fm("Fury Cutter", "bug", 4, 1)), listOf(cm("Night Slash", "dark", 35), cm("Iron Head", "steel", 50))),
        PvPokeEntry("perrserker", "Perrserker", "steel", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Close Combat", "fighting", 45), cm("Foul Play", "dark", 45), cm("Trailblaze", "grass", 45))),
        PvPokeEntry("torkoal", "Torkoal", "fire", listOf(fm("Fire Spin", "fire", 10, 3)), listOf(cm("Weather Ball (Fire)", "fire", 35), cm("Earthquake", "ground", 65), cm("Overheat", "fire", 55))),
        PvPokeEntry("magmortar", "Magmortar", "fire", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Thunderbolt", "electric", 55), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("magmar", "Magmar", "fire", listOf(fm("Karate Chop", "fighting", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Scorching Sands", "ground", 50))),
        PvPokeEntry("arcanine", "Arcanine", "fire", listOf(fm("Thunder Fang", "electric", 5, 2)), listOf(cm("Psychic Fangs", "psychic", 35), cm("Scorching Sands", "ground", 50), cm("Wild Charge", "electric", 45))),
        PvPokeEntry("arcanine_hisuian", "Arcanine (Hisuian)", "fire", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Rock Slide", "rock", 45), cm("Wild Charge", "electric", 45), cm("Crunch", "dark", 45))),
        PvPokeEntry("houndoom", "Houndoom", "dark", listOf(fm("Snarl", "dark", 13, 3)), listOf(cm("Foul Play", "dark", 45), cm("Flamethrower", "fire", 55))),
        PvPokeEntry("pyroar", "Pyroar", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Dark Pulse", "dark", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("camerupt", "Camerupt", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Earth Power", "ground", 55), cm("Solar Beam", "grass", 80))),
        PvPokeEntry("centiskorch", "Centiskorch", "fire", listOf(fm("Bug Bite", "bug", 3, 1)), listOf(cm("Lunge", "bug", 45), cm("Crunch", "dark", 45), cm("Heat Wave", "fire", 75))),
        PvPokeEntry("volcarona", "Volcarona", "bug", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Flame Charge", "fire", 50), cm("Bug Buzz", "bug", 60), cm("Overheat", "fire", 55))),
        PvPokeEntry("entei", "Entei", "fire", listOf(fm("Fire Spin", "fire", 10, 3), fm("Fire Fang", "fire", 8, 2)), listOf(cm("Flame Charge", "fire", 50), cm("Scorching Sands", "ground", 50), cm("Iron Head", "steel", 50), cm("Overheat", "fire", 55))),
        PvPokeEntry("raikou", "Raikou", "electric", listOf(fm("Volt Switch", "electric", 16, 4), fm("Thunder Shock", "electric", 9, 2)), listOf(cm("Wild Charge", "electric", 45), cm("Shadow Ball", "ghost", 55))),
        PvPokeEntry("suicune", "Suicune", "water", listOf(fm("Snarl", "dark", 13, 3), fm("Ice Fang", "ice", 6, 2), fm("Extrasensory", "psychic", 10, 3)), listOf(cm("Bubble Beam", "water", 40), cm("Ice Beam", "ice", 55), cm("Scald", "water", 55))),
        PvPokeEntry("lugia", "Lugia", "psychic", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Sky Attack", "flying", 55), cm("Aeroblast", "flying", 75))),
        PvPokeEntry("ho_oh", "Ho-Oh", "fire", listOf(fm("Incinerate", "fire", 20, 5)), listOf(cm("Sacred Fire", "fire", 65), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("mewtwo", "Mewtwo", "psychic", listOf(fm("Psycho Cut", "psychic", 9, 2), fm("Confusion", "psychic", 12, 4)), listOf(cm("Psystrike*", "psychic", 45), cm("Shadow Ball", "ghost", 55), cm("Ice Beam", "ice", 55))),
        PvPokeEntry("kyogre", "Kyogre", "water", listOf(fm("Waterfall", "water", 8, 3)), listOf(cm("Surf", "water", 40), cm("Origin Pulse", "water", 60))),
        PvPokeEntry("groudon", "Groudon", "ground", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Fire Punch", "fire", 40), cm("Precipice Blades", "ground", 60))),
        PvPokeEntry("rayquaza", "Rayquaza", "dragon", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Breaking Swipe", "dragon", 35), cm("Dragon Ascent", "flying", 70))),
        PvPokeEntry("dialga_origin", "Dialga (Origin)", "steel", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Metal Claw", "steel", 7, 2)), listOf(cm("Iron Head", "steel", 50), cm("Roar of Time", "dragon", 65))),
        PvPokeEntry("palkia_origin", "Palkia (Origin)", "water", listOf(fm("Dragon Breath", "dragon", 3, 1), fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Aqua Tail", "water", 35), cm("Spacial Rend", "dragon", 50))),
        PvPokeEntry("giratina_altered", "Giratina (Altered)", "ghost", listOf(fm("Shadow Claw", "ghost", 8, 2), fm("Dragon Breath", "dragon", 3, 1)), listOf(cm("Dragon Claw", "dragon", 35), cm("Shadow Sneak", "ghost", 45))),
        PvPokeEntry("zygarde_complete", "Zygarde (Complete)", "dragon", listOf(fm("Dragon Tail", "dragon", 9, 3)), listOf(cm("Crunch", "dark", 45), cm("Earthquake", "ground", 65))),
        PvPokeEntry("landorus_therian", "Landorus (Therian)", "ground", listOf(fm("Mud Shot", "ground", 9, 2)), listOf(cm("Sandsear Storm", "ground", 45), cm("Stone Edge", "rock", 55))),
        PvPokeEntry("necrozma_dusk", "Necrozma (Dusk Mane)", "psychic", listOf(fm("Shadow Claw", "ghost", 8, 2)), listOf(cm("Dark Pulse", "dark", 50), cm("Sunsteel Strike", "steel", 65))),
        PvPokeEntry("tapu_koko", "Tapu Koko", "electric", listOf(fm("Volt Switch", "electric", 16, 4)), listOf(cm("Nature's Madness", "fairy", 50), cm("Brave Bird", "flying", 55))),
        PvPokeEntry("tapu_lele", "Tapu Lele", "psychic", listOf(fm("Astonish", "ghost", 10, 3)), listOf(cm("Nature's Madness", "fairy", 50), cm("Psyshock", "psychic", 45))),
        PvPokeEntry("tapu_bulu", "Tapu Bulu", "grass", listOf(fm("Bullet Seed", "grass", 13, 3)), listOf(cm("Nature's Madness", "fairy", 50), cm("Grass Knot", "grass", 50))),
        PvPokeEntry("kartana", "Kartana", "grass", listOf(fm("Razor Leaf", "grass", 4, 2)), listOf(cm("Leaf Blade", "grass", 35), cm("Night Slash", "dark", 35))),
        PvPokeEntry("celesteela", "Celesteela", "steel", listOf(fm("Air Slash", "flying", 9, 3)), listOf(cm("Body Slam", "normal", 35), cm("Heavy Slam", "steel", 50), cm("Bulldoze", "ground", 60))),
        PvPokeEntry("nihilego", "Nihilego", "rock", listOf(fm("Poison Jab", "poison", 7, 2)), listOf(cm("Rock Slide", "rock", 45), cm("Sludge Bomb", "poison", 50)))
    )

    @Volatile
    var allPokemonList: List<PvPokeEntry> = BUILT_IN_POKEMON
        private set

    fun syncFullPvPokeGreatLeagueData(context: Context, onSynced: ((Int) -> Unit)? = null) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cacheFile = File(context.filesDir, "pvpoke_gl_cache_v6.json")
                val gmUrl = "https://raw.githubusercontent.com/pvpoke/pvpoke/master/src/data/gamemaster.json"
                val rkUrl = "https://raw.githubusercontent.com/pvpoke/pvpoke/master/src/data/rankings/all/overall/rankings-1500.json"

                val gmText = fetchUrl(gmUrl) ?: if (cacheFile.exists()) cacheFile.readText() else null
                val rkText = fetchUrl(rkUrl)
                if (gmText != null) {
                    val parsed = parseGamemasterAndRankings(gmText, rkText)
                    if (parsed.isNotEmpty()) {
                        val mergedMap = linkedMapOf<String, PvPokeEntry>()
                        for (p in BUILT_IN_POKEMON) mergedMap[p.name.lowercase()] = p
                        for (p in parsed) {
                            val key = p.name.lowercase()
                            if (!mergedMap.containsKey(key)) {
                                mergedMap[key] = p
                            }
                        }
                        allPokemonList = mergedMap.values.toList()
                        cacheFile.writeText(gmText)
                        onSynced?.invoke(allPokemonList.size)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun fetchUrl(urlStr: String): String? {
        return try {
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    private fun parseGamemasterAndRankings(gmJsonStr: String, rkJsonStr: String?): List<PvPokeEntry> {
        val root = JSONObject(gmJsonStr)
        val movesArr = root.optJSONArray("moves") ?: return emptyList()
        val fastMap = mutableMapOf<String, FastMove>()
        val chargedMap = mutableMapOf<String, ChargedMove>()

        for (i in 0 until movesArr.length()) {
            val m = movesArr.getJSONObject(i)
            val moveId = m.optString("moveId")
            val name = m.optString("name", moveId)
            val type = m.optString("type", "normal")
            val energyGain = m.optInt("energyGain", 0)
            val energyCost = m.optInt("energy", 0)
            val turns = max(1, m.optInt("turns", 500) / 500)
            if (energyGain > 0) {
                fastMap[moveId] = FastMove(name, type, energyGain, turns)
            } else if (energyCost > 0) {
                chargedMap[moveId] = ChargedMove(name, type, energyCost)
            }
        }

        val recMovesMap = mutableMapOf<String, List<String>>()
        if (!rkJsonStr.isNullOrBlank()) {
            try {
                val rkArr = JSONArray(rkJsonStr)
                for (i in 0 until rkArr.length()) {
                    val obj = rkArr.getJSONObject(i)
                    val sid = obj.optString("speciesId")
                    val mArr = obj.optJSONArray("moveset")
                    if (mArr != null && mArr.length() >= 2) {
                        val list = mutableListOf<String>()
                        for (j in 0 until mArr.length()) list.add(mArr.getString(j))
                        recMovesMap[sid] = list
                    }
                }
            } catch (_: Exception) {}
        }

        val pokeArr = root.optJSONArray("pokemon") ?: return emptyList()
        val result = mutableListOf<PvPokeEntry>()
        for (i in 0 until pokeArr.length()) {
            val p = pokeArr.getJSONObject(i)
            val sid = p.optString("speciesId")
            val sName = p.optString("speciesName", sid).replace(" (Shadow)", "")
            val typesArr = p.optJSONArray("types")
            val pType = if (typesArr != null && typesArr.length() > 0) typesArr.getString(0) else "normal"
            val rec = recMovesMap[sid]
            val fMoves = p.optJSONArray("fastMoves")
            val cMoves = p.optJSONArray("chargedMoves")

            val candidateFastMoves = mutableListOf<FastMove>()
            if (rec != null && rec.isNotEmpty()) {
                fastMap[rec[0]]?.let { candidateFastMoves.add(it) }
            }
            if (fMoves != null) {
                for (k in 0 until fMoves.length()) {
                    val fmObj = fastMap[fMoves.getString(k)]
                    if (fmObj != null && !candidateFastMoves.any { it.name == fmObj.name }) {
                        candidateFastMoves.add(fmObj)
                    }
                }
            }
            if (candidateFastMoves.isEmpty()) continue

            val chosenCharged = mutableListOf<ChargedMove>()
            if (rec != null && rec.size > 1) {
                for (k in 1 until rec.size) {
                    chargedMap[rec[k]]?.let { chosenCharged.add(it) }
                }
            }
            if (cMoves != null && chosenCharged.size < 3) {
                for (k in 0 until cMoves.length()) {
                    val cmObj = chargedMap[cMoves.getString(k)]
                    if (cmObj != null && !chosenCharged.any { it.name == cmObj.name }) {
                        chosenCharged.add(cmObj)
                        if (chosenCharged.size >= 3) break
                    }
                }
            }
            if (chosenCharged.isNotEmpty()) {
                result.add(PvPokeEntry(sid, sName, pType, candidateFastMoves, chosenCharged))
            }
        }
        return result
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = i - 1
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev else 1 + min(prev, min(dp[j], dp[j - 1]))
                prev = temp
            }
        }
        return dp[b.length]
    }

    private val HUD_NOISE_WORDS = setOf(
        "cp", "attack", "incoming", "use", "protect", "shield", "not", "now",
        "super", "effective", "very", "weak", "fast", "move", "count", "ready"
    )

    private fun cleanBaseSpeciesName(name: String): String {
        val idx = name.indexOf('(')
        return (if (idx > 0) name.substring(0, idx) else name).trim().lowercase()
    }

    private fun extractAlphaWords(raw: String): List<String> {
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            if (ch in 'a'..'z' || ch in 'A'..'Z' || ch == '-' || ch == '\'') {
                sb.append(ch)
            } else {
                sb.append(' ')
            }
        }
        return sb.toString()
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 3 && !HUD_NOISE_WORDS.contains(it.lowercase()) }
    }

    fun matchPokemonFromHudText(hudOcrText: String): PvPokeEntry? {
        if (hudOcrText.isBlank()) return null

        val cleanedWords = extractAlphaWords(hudOcrText)
        if (cleanedWords.isEmpty()) return null

        val joinedLower = cleanedWords.joinToString(" ").lowercase()
        val list = allPokemonList

        val sortedByLength = list.sortedByDescending {
            cleanBaseSpeciesName(it.name).length
        }

        for (entry in sortedByLength) {
            val baseName = cleanBaseSpeciesName(entry.name)
            if (baseName.length >= 3 && joinedLower.contains(baseName)) {
                return entry
            }
        }

        var bestMatch: PvPokeEntry? = null
        var bestDist = 3
        for (word in cleanedWords) {
            val wLow = word.lowercase()
            if (wLow.length < 4) continue
            for (entry in sortedByLength) {
                val baseName = cleanBaseSpeciesName(entry.name)
                if (abs(wLow.length - baseName.length) <= 2) {
                    val d = levenshtein(wLow, baseName)
                    val maxAllowed = if (baseName.length >= 7) 2 else 1
                    if (d <= maxAllowed && d < bestDist) {
                        bestDist = d
                        bestMatch = entry
                    }
                }
            }
        }
        if (bestMatch != null) return bestMatch

        if (hudOcrText.contains("CP", ignoreCase = true)) {
            val detectedName = cleanedWords.last()
            if (detectedName.length >= 4) {
                return PvPokeEntry(
                    id = "dyn_${detectedName.lowercase()}",
                    name = detectedName,
                    primaryType = "normal",
                    fastMoves = listOf(fm("Fast Attack", "normal", 8, 2)),
                    chargedMoves = listOf(
                        cm("Charged 1 (40E)", "normal", 40),
                        cm("Charged 2 (55E)", "normal", 55)
                    )
                )
            }
        }
        return null
    }

    fun detectChargedAttackAndEffectiveness(screenOcrText: String, entry: PvPokeEntry): Triple<Boolean, ChargedMove?, String?> {
        if (screenOcrText.isBlank()) return Triple(false, null, null)
        val norm = screenOcrText.lowercase()

        val effHint = when {
            norm.contains("super effective") -> "super"
            norm.contains("not very effective") -> "not_very"
            else -> null
        }

        for (cm in entry.chargedMoves) {
            val cleanMove = cleanBaseSpeciesName(cm.name.replace("*", ""))
            if (cleanMove.length >= 4 && norm.contains(cleanMove)) {
                return Triple(true, cm, effHint)
            }
        }

        val isIncomingBanner = norm.contains("attack incoming") ||
            norm.contains("protect shield") ||
            (norm.contains("used ") && norm.contains(cleanBaseSpeciesName(entry.name)))

        return Triple(isIncomingBanner, null, effHint)
    }

    fun isMenuOrPreBattleText(screenOcrText: String): Boolean {
        if (screenOcrText.isBlank()) return false
        val norm = screenOcrText.lowercase()
        return norm.contains("choose your league") ||
            norm.contains("great league") ||
            norm.contains("ultra league") ||
            norm.contains("master league") ||
            norm.contains("good effort") ||
            norm.contains("you win") ||
            norm.contains("go, ")
    }
}
