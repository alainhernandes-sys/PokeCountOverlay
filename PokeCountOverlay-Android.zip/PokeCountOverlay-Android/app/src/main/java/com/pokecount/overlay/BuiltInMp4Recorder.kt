package com.pokecount.overlay

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.Surface
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Built-in H.264 MP4 Video Recorder that encodes frames directly from OverlayVisionService's
 * existing ImageReader stream (with the PokéCount HUD rendered onto each frame) and saves
 * the resulting .mp4 video into the phone's Gallery (Movies/PokeCount) without needing a second
 * MediaProjection session!
 */
class BuiltInMp4Recorder(private val context: Context) {

    @Volatile
    var isRecording = false
        private set

    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var trackIndex = -1
    private var muxerStarted = false
    private var tempMp4File: File? = null
    private var recWidth = 480
    private var recHeight = 1040
    private var startNanoTime = 0L

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC090D16.toInt()
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF34D399.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF6EE7B7.toInt()
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
    }

    @Synchronized
    fun startRecording(frameW: Int, frameH: Int): Boolean {
        if (isRecording) return true
        return try {
            // H.264 requires dimensions to be multiples of 16
            recWidth = ((frameW.coerceIn(320, 720)) / 16) * 16
            recHeight = ((frameH.coerceIn(640, 1600)) / 16) * 16

            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outFile = File(context.cacheDir, "PokeCount_$stamp.mp4")
            tempMp4File = outFile

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, recWidth, recHeight).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, 10)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            }

            val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = codec.createInputSurface()
            codec.start()
            encoder = codec

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            trackIndex = -1
            muxerStarted = false
            startNanoTime = System.nanoTime()
            isRecording = true
            true
        } catch (_: Exception) {
            stopAndSaveRecording()
            false
        }
    }

    @Synchronized
    fun recordFrame(
        frameBmp: Bitmap,
        fastCountStr: String,
        headerStr: String,
        statusStr: String,
        moveLines: List<String>
    ) {
        if (!isRecording) return
        val surf = inputSurface ?: return
        try {
            val canvas: Canvas = surf.lockCanvas(null) ?: return
            try {
                val destRect = RectF(0f, 0f, recWidth.toFloat(), recHeight.toFloat())
                canvas.drawBitmap(frameBmp, null, destRect, null)

                // Draw PokéCount HUD box at top-right of the recorded video frame
                val boxLeft = recWidth * 0.44f
                val boxTop = recHeight * 0.12f
                val boxRight = recWidth - 10f
                val boxBottom = boxTop + 68f + (moveLines.size * 22f)
                val cardRect = RectF(boxLeft, boxTop, boxRight, boxBottom)
                canvas.drawRoundRect(cardRect, 14f, 14f, bgPaint)
                canvas.drawRoundRect(cardRect, 14f, 14f, borderPaint)

                canvas.drawText("$fastCountStr FAST · $headerStr", boxLeft + 12f, boxTop + 24f, titlePaint)
                canvas.drawText(statusStr, boxLeft + 12f, boxTop + 44f, subPaint)
                var my = boxTop + 66f
                for (line in moveLines) {
                    canvas.drawText(line, boxLeft + 12f, my, subPaint)
                    my += 20f
                }
            } finally {
                surf.unlockCanvasAndPost(canvas)
            }
            drainEncoder(false)
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun stopAndSaveRecording(): String? {
        if (!isRecording && encoder == null) return null
        isRecording = false
        try {
            drainEncoder(true)
        } catch (_: Exception) {
        }
        try {
            encoder?.stop()
        } catch (_: Exception) {
        }
        try {
            encoder?.release()
        } catch (_: Exception) {
        }
        encoder = null
        try {
            inputSurface?.release()
        } catch (_: Exception) {
        }
        inputSurface = null
        try {
            if (muxerStarted) muxer?.stop()
        } catch (_: Exception) {
        }
        try {
            muxer?.release()
        } catch (_: Exception) {
        }
        muxer = null
        muxerStarted = false

        val srcFile = tempMp4File
        tempMp4File = null
        if (srcFile != null && srcFile.exists() && srcFile.length() > 1024L) {
            val savedName = saveMp4ToGallery(srcFile)
            srcFile.delete()
            return savedName
        }
        srcFile?.delete()
        return null
    }

    private fun drainEncoder(endOfStream: Boolean) {
        val codec = encoder ?: return
        val mux = muxer ?: return
        if (endOfStream) {
            try {
                codec.signalEndOfInputStream()
            } catch (_: Exception) {
                return
            }
        }
        val bufferInfo = MediaCodec.BufferInfo()
        var loops = 0
        while (loops < 25) {
            loops++
            val status = codec.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000L else 0L)
            if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (!muxerStarted) {
                    trackIndex = mux.addTrack(codec.outputFormat)
                    mux.start()
                    muxerStarted = true
                }
            } else if (status >= 0) {
                val encodedData = codec.getOutputBuffer(status)
                if (encodedData != null && bufferInfo.size > 0 && muxerStarted) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        bufferInfo.presentationTimeUs = (System.nanoTime() - startNanoTime) / 1000L
                        mux.writeSampleData(trackIndex, encodedData, bufferInfo)
                    }
                }
                codec.releaseOutputBuffer(status, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
            }
        }
    }

    private fun saveMp4ToGallery(mp4File: File): String? {
        return try {
            val resolver = context.contentResolver
            val fileName = mp4File.name
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/PokeCount")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            resolver.openOutputStream(uri)?.use { outStream ->
                FileInputStream(mp4File).use { inStream ->
                    inStream.copyTo(outStream)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val doneValues = ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }
                resolver.update(uri, doneValues, null, null)
            }
            fileName
        } catch (_: Exception) {
            null
        }
    }
}
