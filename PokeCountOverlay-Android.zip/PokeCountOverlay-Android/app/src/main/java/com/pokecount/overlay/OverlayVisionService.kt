package com.pokecount.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var overlayRoot: LinearLayout
    private lateinit var counterBadgeLayout: LinearLayout
    private lateinit var countNumberText: TextView
    private lateinit var countLabelText: TextView
    private lateinit var pokemonTitleText: TextView
    private lateinit var ocrStatusText: TextView
    private lateinit var swapFastMoveBtn: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var closeOverlayBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val slotEnergies = mutableMapOf<String, Int>()
    private val slotCycleIndex = mutableMapOf<String, Int>()
    private val slotFastMoveIdx = mutableMapOf<String, Int>()

    private var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
    private var playerPokemonType: String? = null
    private var latestEffectivenessHint: String? = null

    // Battle state tracking
    private var inActiveMatch = false
    private var isBattleHudCurrentlyVisible = false
    private var hudMissingDurationMs = 0L
    private var noFrameDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var manualCollapse = false

    private var isOcrBusy = false
    private var turnElapsedMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x40000000, 0x26000000, 0x73090D16)
    private val borderAlphas = intArrayOf(0x36FFFFFF, 0x20FFFFFF, 0x5094A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    private fun getActiveFastMove(): FastMove {
        val idx = (slotFastMoveIdx[currentPokemon.id] ?: 0).coerceIn(0, max(0, currentPokemon.fastMoves.size - 1))
        return currentPokemon.fastMoves[idx]
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext)
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startTurnClockAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun createFloatingOverlayHud() {
        val (screenW, screenH) = getScreenDimensions()
        val compactWidth = (screenW * 0.50f).toInt()

        overlayParams = WindowManager.LayoutParams(
            compactWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = (screenH * 0.125f).toInt()
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
        }

        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        counterBadgeLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 5, 14, 5)
            setOnClickListener {
                manualCollapse = !manualCollapse
                refreshHudDisplay()
            }
        }

        countNumberText = TextView(this).apply {
            text = "0"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }

        countLabelText = TextView(this).apply {
            text = "FAST"
            textSize = 8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xCC6EE7B7.toInt())
        }

        counterBadgeLayout.addView(countNumberText)
        counterBadgeLayout.addView(countLabelText)

        val rightHeaderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        pokemonTitleText = TextView(this).apply {
            text = "Waiting for battle..."
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xEEFFFFFF.toInt())
            setOnClickListener {
                resetCurrentMatchState("● Reset to 0")
            }
        }

        val microControlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        ocrStatusText = TextView(this).apply {
            text = "● Standby"
            textSize = 8.5f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xAA6EE7B7.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        swapFastMoveBtn = TextView(this).apply {
            text = " [⇄Fast] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setOnClickListener {
                if (currentPokemon.fastMoves.size > 1) {
                    val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                    val nextIdx = (curIdx + 1) % currentPokemon.fastMoves.size
                    slotFastMoveIdx[currentPokemon.id] = nextIdx
                    ocrStatusText.text = "Fast: ${getActiveFastMove().name}"
                    refreshHudDisplay()
                }
            }
        }

        val minusOneBtn = TextView(this).apply {
            text = "[−]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = max(0, curE - getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        val plusOneBtn = TextView(this).apply {
            text = " [+]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF6EE7B7.toInt())
            setOnClickListener {
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, curE + getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = " ◐"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        closeOverlayBtn = TextView(this).apply {
            text = " ✕"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                stopSelf()
            }
        }

        microControlsRow.addView(ocrStatusText)
        microControlsRow.addView(swapFastMoveBtn)
        microControlsRow.addView(minusOneBtn)
        microControlsRow.addView(plusOneBtn)
        microControlsRow.addView(opacityToggleBtn)
        microControlsRow.addView(closeOverlayBtn)

        rightHeaderCol.addView(pokemonTitleText)
        rightHeaderCol.addView(microControlsRow)

        topHeaderRow.addView(counterBadgeLayout)
        topHeaderRow.addView(rightHeaderCol)

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        overlayRoot.addView(topHeaderRow)
        overlayRoot.addView(chargedBadgesContainer)

        applyStealthTheme()

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = overlayParams.x
                        initialY = overlayParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        overlayParams.x = initialX - dx
                        overlayParams.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, overlayParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        }

        counterBadgeLayout.setOnTouchListener(dragListener)
        pokemonTitleText.setOnTouchListener(dragListener)

        windowManager.addView(overlayRoot, overlayParams)
        refreshHudDisplay()
    }

    private fun resetCurrentMatchState(statusMsg: String) {
        slotEnergies.clear()
        slotCycleIndex.clear()
        turnElapsedMs = 0L
        chargedAttackDetectedDuringPause = false
        specificMoveDetectedDuringPause = null
        ocrStatusText.text = statusMsg
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 22f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        overlayRoot.background = panelBg

        val counterBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f
            setColor(0x44000000)
            setStroke(2, 0x8834D399.toInt())
        }
        counterBadgeLayout.background = counterBg
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()

            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpManager.getMediaProjection(resultCode, data) ?: return
            mediaProjection = mp

            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    virtualDisplay?.release()
                    imageReader?.close()
                    stopSelf()
                }
            }, mainHandler)

            val (screenW, screenH) = getScreenDimensions()
            val density = resources.displayMetrics.densityDpi

            imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mp.createVirtualDisplay(
                "PokeCountCaptureV8",
                screenW,
                screenH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
            ocrStatusText.text = "● Waiting for battle..."
        } catch (e: Exception) {
            ocrStatusText.text = "Err: ${e.javaClass.simpleName}"
        }
    }

    /**
     * Checks in <0.2ms whether the Pokémon GO Battle HUD (both the Top-Left white nameplate pill
     * and the Top-Right white nameplate pill, separated by a non-white gap) is currently visible.
     * In Pokémon GO, these two white pills are ONLY visible during active Fast-Move combat —
     * they immediately disappear during Charged Move animations ("Attack incoming!"),
     * during "3..2..1" pre-battle countdowns, and in menus ("CHOOSE YOUR LEAGUE").
     */
    private fun checkBattleHudAndAppVisibility(image: Image): Pair<Boolean, Boolean> {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            // Check if the captured frame is completely black (e.g. shared app is minimized/loading)
            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            val isBlackFrame = totalSamples > 0 && nonBlackSamples <= 2

            fun countWhiteRatio(leftR: Float, rightR: Float, topR: Float, botR: Float): Float {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * topR).toInt().coerceIn(0, height - 2)
                val y1 = (height * botR).toInt().coerceIn(y0 + 1, height)
                var whiteCnt = 0
                var count = 0
                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var x = x0
                    while (x < x1) {
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            count++
                            if (r > 212 && g > 212 && b > 212) {
                                whiteCnt++
                            }
                        }
                        x += 12
                    }
                    y += 8
                }
                return if (count > 0) whiteCnt.toFloat() / count else 0f
            }

            // Top-Left pill ("Mimikyu CP 1489") and Top-Right pill ("CP 1487 Combusken")
            val leftWhite = countWhiteRatio(0.03f, 0.41f, 0.042f, 0.098f)
            val rightWhite = countWhiteRatio(0.59f, 0.97f, 0.042f, 0.098f)
            val centerGapWhite = countWhiteRatio(0.45f, 0.55f, 0.042f, 0.098f)

            val hudPillsVisible = leftWhite > 0.34f && rightWhite > 0.34f && centerGapWhite < 0.55f
            Pair(!isBlackFrame, hudPillsVisible)
        } catch (_: Exception) {
            Pair(true, false)
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    val offset = rowOffset + x * pixelStride
                    if (offset >= 0 && offset + 3 < bufLimit) {
                        val r = buf.get(offset).toInt() and 0xFF
                        val g = buf.get(offset + 1).toInt() and 0xFF
                        val b = buf.get(offset + 2).toInt() and 0xFF
                        pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }

    private fun startTurnClockAndOcrLoop() {
        val tickMs = 200L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameAndUpdateState(tickMs)
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun subtractChargedMoveAndUpdate(cm: ChargedMove) {
        val currentE = slotEnergies[currentPokemon.id] ?: 0
        slotEnergies[currentPokemon.id] = max(0, currentE - cm.energyCost)
        val prevCycle = slotCycleIndex[currentPokemon.id] ?: 0
        slotCycleIndex[currentPokemon.id] = (prevCycle + 1) % 4
        lastSubtractedMoveTimestamp = System.currentTimeMillis()
        ocrStatusText.text = "▼ Subtracted ${cm.name}"
        refreshHudDisplay()
    }

    private fun processFrameAndUpdateState(tickMs: Long) {
        val image = imageReader?.acquireLatestImage()

        if (image == null) {
            // No new frame rendered by the shared app (Pokémon GO)
            noFrameDurationMs += tickMs
            // If Pokémon GO hasn't rendered any frames for >1.4s, the user switched to another app -> auto-hide overlay!
            if (noFrameDurationMs >= 1400L && overlayRoot.visibility == View.VISIBLE) {
                overlayRoot.visibility = View.GONE
            }
            // Only advance the Fast Move clock if the Battle HUD was confirmed visible right before this tick
            if (inActiveMatch && isBattleHudCurrentlyVisible && noFrameDurationMs < 600L) {
                advanceFastMoveClock(tickMs)
            }
            return
        }

        // We received a live frame from Pokémon GO!
        noFrameDurationMs = 0L
        val (isAppFrameValid, hudPillsVisible) = checkBattleHudAndAppVisibility(image)

        if (!isAppFrameValid) {
            image.close()
            if (overlayRoot.visibility == View.VISIBLE) {
                overlayRoot.visibility = View.GONE
            }
            return
        }

        // Show overlay since Pokémon GO is actively rendering on screen
        if (overlayRoot.visibility != View.VISIBLE) {
            overlayRoot.visibility = View.VISIBLE
        }

        if (hudPillsVisible) {
            // BOTH WHITE BATTLE HUD PILLS ARE VISIBLE -> ACTIVE FAST-MOVE COMBAT!
            if (!inActiveMatch) {
                // Brand new battle just started (e.g. after 3..2..1 countdown finished)!
                inActiveMatch = true
                resetCurrentMatchState("● Battle Started!")
            } else if (!isBattleHudCurrentlyVisible && hudMissingDurationMs >= 1800L) {
                // Battle HUD just reappeared after a Charged Move cutscene (which hid the HUD for 2-11 seconds)!
                if (chargedAttackDetectedDuringPause || specificMoveDetectedDuringPause != null) {
                    val moveToSub = specificMoveDetectedDuringPause ?: run {
                        val curE = slotEnergies[currentPokemon.id] ?: 0
                        currentPokemon.chargedMoves
                            .filter { curE >= it.energyCost }
                            .maxByOrNull { it.energyCost }
                            ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                    }
                    if (moveToSub != null && System.currentTimeMillis() - lastSubtractedMoveTimestamp > 3500L) {
                        subtractChargedMoveAndUpdate(moveToSub)
                    }
                }
                chargedAttackDetectedDuringPause = false
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudMissingDurationMs = 0L

            // Advance the Fast Move counter ONLY while the Battle HUD pills are visible!
            advanceFastMoveClock(tickMs)

            // Run Visual Fast-Move Classifier on the arena impact zone
            val arenaVisualBmp = cropRegionFromImage(image, 0.15f, 0.35f, 0.72f, 0.78f, step = 4)
            if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                    arenaVisualBmp,
                    currentPokemon,
                    latestEffectivenessHint,
                    playerPokemonType
                )
                if (detectedFmIdx != null && detectedFmIdx != (slotFastMoveIdx[currentPokemon.id] ?: 0)) {
                    slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                    val newFm = getActiveFastMove()
                    ocrStatusText.text = "⚡ Visual: ${newFm.name} (${newFm.energyGain}E)"
                    refreshHudDisplay()
                }
            }

            if (!isOcrBusy) {
                val topRightBmp = cropRegionFromImage(image, 0.52f, 0.025f, 0.99f, 0.095f, step = 1)
                val topLeftBmp = cropRegionFromImage(image, 0.02f, 0.025f, 0.45f, 0.095f, step = 2)
                image.close()

                if (topRightBmp != null) {
                    isOcrBusy = true
                    recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                        .addOnSuccessListener { topText ->
                            val matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text)
                            if (matchedPoke != null) {
                                if (matchedPoke.id != currentPokemon.id) {
                                    currentPokemon = matchedPoke
                                    turnElapsedMs = 0L
                                    visualClassifier.resetForNewOpponent()
                                    ocrStatusText.text = "● ${matchedPoke.name}"
                                    refreshHudDisplay()
                                } else {
                                    ocrStatusText.text = "● Counting ${getActiveFastMove().name}"
                                }
                            }
                        }
                        .addOnCompleteListener {
                            if (topLeftBmp != null) {
                                recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                    .addOnSuccessListener { leftText ->
                                        val playerPoke = PvPokeRepository.matchPokemonFromHudText(leftText.text)
                                        if (playerPoke != null) playerPokemonType = playerPoke.primaryType
                                    }
                                    .addOnCompleteListener { isOcrBusy = false }
                            } else {
                                isOcrBusy = false
                            }
                        }
                    return
                }
            }
            image.close()
        } else {
            // WHITE BATTLE HUD PILLS ARE NOT VISIBLE!
            // IMMEDIATELY PAUSE FAST MOVE COUNTING (opponent is either in Charged Move cutscene or in Menu/Countdown)!
            isBattleHudCurrentlyVisible = false
            hudMissingDurationMs += tickMs

            // If HUD pills have been gone for >12 seconds, we are out of battle (Menu / Map) -> reset match!
            if (hudMissingDurationMs >= 12000L && inActiveMatch) {
                inActiveMatch = false
                resetCurrentMatchState("● Waiting for battle...")
            } else if (inActiveMatch && hudMissingDurationMs >= 400L) {
                ocrStatusText.text = "⏸ Paused (Charged / Zoom)"
                refreshHudDisplay()
            }

            if (!isOcrBusy) {
                val bannerBmp = cropRegionFromImage(image, 0.08f, 0.18f, 0.92f, 0.90f, step = 2)
                image.close()
                if (bannerBmp != null) {
                    isOcrBusy = true
                    recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                        .addOnSuccessListener { bannerText ->
                            val rawBanner = bannerText.text
                            if (PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                                // Detected "CHOOSE YOUR LEAGUE", "VS", "Go, ...", or "GOOD EFFORT!"
                                inActiveMatch = false
                                resetCurrentMatchState("● Pre-Battle / Menu")
                            } else if (inActiveMatch) {
                                val (isIncoming, specificMove, effHint) =
                                    PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                                if (effHint != null) latestEffectivenessHint = effHint
                                if (specificMove != null) {
                                    specificMoveDetectedDuringPause = specificMove
                                    chargedAttackDetectedDuringPause = true
                                    ocrStatusText.text = "⚠️ Used ${specificMove.name}!"
                                } else if (isIncoming) {
                                    // "Attack incoming!" or "Use a Protect Shield?" is on screen!
                                    chargedAttackDetectedDuringPause = true
                                    ocrStatusText.text = "⚠️ Attack Incoming! (Paused)"
                                }
                            }
                        }
                        .addOnCompleteListener { isOcrBusy = false }
                    return
                }
            }
            image.close()
        }
    }

    private fun advanceFastMoveClock(tickMs: Long) {
        val activeFm = getActiveFastMove()
        turnElapsedMs += tickMs
        val moveDurationMs = activeFm.turns * 500L
        if (turnElapsedMs >= moveDurationMs) {
            turnElapsedMs -= moveDurationMs
            val prevE = slotEnergies[currentPokemon.id] ?: 0
            slotEnergies[currentPokemon.id] = min(100, prevE + activeFm.energyGain)
            refreshHudDisplay()
        }
    }

    private fun refreshHudDisplay() {
        val energy = slotEnergies[currentPokemon.id] ?: 0
        val activeFm = getActiveFastMove()
        val eFast = max(1, activeFm.energyGain)
        val fastCount = floor(energy.toDouble() / eFast).toInt()
        val cycleIdx = slotCycleIndex[currentPokemon.id] ?: 0

        countNumberText.text = fastCount.toString()

        if (!inActiveMatch) {
            pokemonTitleText.text = "Waiting for battle..."
            swapFastMoveBtn.visibility = View.GONE
            chargedBadgesContainer.visibility = View.GONE
            return
        }

        pokemonTitleText.text = "${currentPokemon.name} · ${activeFm.name} (${eFast}E/${activeFm.turns}T)"
        swapFastMoveBtn.visibility = if (currentPokemon.fastMoves.size > 1) View.VISIBLE else View.GONE
        chargedBadgesContainer.visibility = if (manualCollapse) View.GONE else View.VISIBLE

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val paceList = currentPokemon.getPvPokeMoveCounts(activeFm, cm, 4)
            val activePaceTarget = paceList[cycleIdx % paceList.size]
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val afterEnergy = max(0, energy - cm.energyCost)
            val afterFastCount = floor(afterEnergy.toDouble() / eFast).toInt()
            val subtractMovesCount = if (isReady) max(1, fastCount - afterFastCount) else activePaceTarget

            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4094A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val cardLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = badgeBg
                setPadding(12, 5, 12, 5)
                setOnClickListener {
                    subtractChargedMoveAndUpdate(cm)
                }
            }

            val topLine = TextView(this).apply {
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xEEFFFFFF.toInt())
                text = if (isReady) {
                    "⚡ ${cm.name} READY (▼-$subtractMovesCount)"
                } else {
                    "${cm.name}: $fastCount/$activePaceTarget (-$neededMoves)"
                }
            }

            val formattedPace = paceList.mapIndexed { idx, v ->
                if (idx == (cycleIdx % paceList.size)) "[$v]" else "$v"
            }.joinToString(" - ")

            val bottomLine = TextView(this).apply {
                textSize = 8.5f
                setSingleLine(true)
                setTextColor(0xBB94A3B8.toInt())
                text = "Fast Move Count: $formattedPace"
            }

            cardLayout.addView(topLine)
            cardLayout.addView(bottomLine)

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 5
            }
            chargedBadgesContainer.addView(cardLayout, lp)
        }
    }

    private fun createNotification(): Notification {
        val channelId = "pokecount_overlay_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "PokéCount PvPoke GL Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("PokéCount PvPoke v8 Active")
            .setContentText("Auto-pauses outside fast combat & hides outside Pokémon GO")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (overlayInitialized && ::overlayRoot.isInitialized) {
            windowManager.removeView(overlayRoot)
        }
    }

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
