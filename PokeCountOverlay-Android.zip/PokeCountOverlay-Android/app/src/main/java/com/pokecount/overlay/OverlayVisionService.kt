package com.pokecount.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/**
 * Foreground overlay service (`OverlayVisionService`) wired to [BattleSessionManager]
 * and [ScreenCaptureAnalyzer].
 *
 * - Observes [BattleSessionManager.snapshotFlow] on the main thread to render the HUD.
 * - Contains ZERO direct counter increments or raw energy math; all UI controls and
 *   analyzer detections dispatch strictly to [BattleSessionManager].
 */
class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var overlayRoot: LinearLayout
    private lateinit var counterBadgeLayout: LinearLayout
    private lateinit var countNumberText: TextView
    private lateinit var countLabelText: TextView
    private lateinit var pokemonTitleText: TextView
    private lateinit var ocrStatusText: TextView
    private lateinit var swapFastMoveBtn: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var closeOverlayBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout
    private lateinit var benchEnergyText: TextView

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    @Volatile
    private var isMediaProjectionStopped = false

    @Volatile
    private var isA11yCaptureInFlight = false
    private var lastA11yCaptureRequestMs = 0L

    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceUiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var sessionManager: BattleSessionManager
    private lateinit var screenCaptureAnalyzer: ScreenCaptureAnalyzer

    private var manualCollapse = false
    private var overlayInitialized = false

    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x40000000, 0x26000000, 0x73090D16)
    private val borderAlphas = intArrayOf(0x36FFFFFF, 0x20FFFFFF, 0x5094A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext)
            sessionManager = BattleSessionManager()
            screenCaptureAnalyzer = ScreenCaptureAnalyzer(
                sessionManager = sessionManager,
                overlayVersion = OVERLAY_VERSION,
                onUiStateChanged = {
                    mainHandler.post { refreshHudDisplay() }
                }
            )
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            observeSessionSnapshots()
            startCaptureLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        } else if (PokeCountAccessibilityService.instance != null) {
            isMediaProjectionStopped = true
            screenCaptureAnalyzer.setStatusText("🎥 [$OVERLAY_VERSION] Dual-Rec Mode Active")
        }
        return START_STICKY
    }

    private fun observeSessionSnapshots() {
        serviceUiScope.launch {
            sessionManager.snapshotFlow.collect { snapshot ->
                refreshHudDisplay(snapshot)
            }
        }
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun createFloatingOverlayHud() {
        val (screenW, screenH) = getScreenDimensions()
        val compactWidth = (screenW * 0.54f).toInt()

        overlayParams = WindowManager.LayoutParams(
            compactWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = (screenH * 0.125f).toInt()
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
        }

        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        counterBadgeLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 5, 12, 5)
            setOnClickListener {
                manualCollapse = !manualCollapse
                refreshHudDisplay()
            }
        }

        countNumberText = TextView(this).apply {
            text = "0"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }

        countLabelText = TextView(this).apply {
            text = "FAST · $OVERLAY_VERSION"
            textSize = 7.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFF6EE7B7.toInt())
        }

        counterBadgeLayout.addView(countNumberText)
        counterBadgeLayout.addView(countLabelText)

        val rightHeaderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        pokemonTitleText = TextView(this).apply {
            text = "[$OVERLAY_VERSION] Waiting for battle..."
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xEEFFFFFF.toInt())
            setOnClickListener {
                screenCaptureAnalyzer.resetAnalyzerAndSession("● [$OVERLAY_VERSION] Reset to 0")
            }
        }

        val microControlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        ocrStatusText = TextView(this).apply {
            text = "● $OVERLAY_VERSION Engine Ready"
            textSize = 8.5f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xAA6EE7B7.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        swapFastMoveBtn = TextView(this).apply {
            text = " [⇄Fast] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setOnClickListener {
                screenCaptureAnalyzer.cycleFastMoveOrForm()
            }
        }

        val minusOneBtn = TextView(this).apply {
            text = "[−]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                screenCaptureAnalyzer.markMatchActiveForManualInput()
                sessionManager.adjustFastMovesManually(-1)
            }
        }

        val plusOneBtn = TextView(this).apply {
            text = " [+]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF6EE7B7.toInt())
            setOnClickListener {
                screenCaptureAnalyzer.markMatchActiveForManualInput()
                sessionManager.adjustFastMovesManually(1)
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = " ◐"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        closeOverlayBtn = TextView(this).apply {
            text = " ✕"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                stopSelf()
            }
        }

        microControlsRow.addView(ocrStatusText)
        microControlsRow.addView(swapFastMoveBtn)
        microControlsRow.addView(minusOneBtn)
        microControlsRow.addView(plusOneBtn)
        microControlsRow.addView(opacityToggleBtn)
        microControlsRow.addView(closeOverlayBtn)

        rightHeaderCol.addView(pokemonTitleText)
        rightHeaderCol.addView(microControlsRow)

        topHeaderRow.addView(counterBadgeLayout)
        topHeaderRow.addView(rightHeaderCol)

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        benchEnergyText = TextView(this).apply {
            textSize = 8.5f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xFFFDE047.toInt())
            setPadding(4, 5, 4, 0)
            visibility = View.GONE
        }

        overlayRoot.addView(topHeaderRow)
        overlayRoot.addView(chargedBadgesContainer)
        overlayRoot.addView(benchEnergyText)

        applyStealthTheme()

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = overlayParams.x
                        initialY = overlayParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        overlayParams.x = initialX - dx
                        overlayParams.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, overlayParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        }

        counterBadgeLayout.setOnTouchListener(dragListener)
        pokemonTitleText.setOnTouchListener(dragListener)

        windowManager.addView(overlayRoot, overlayParams)
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 22f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        overlayRoot.background = panelBg

        val counterBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f
            setColor(0x44000000)
            setStroke(2, 0x8834D399.toInt())
        }
        counterBadgeLayout.background = counterBg
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()

            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpManager.getMediaProjection(resultCode, data) ?: return
            mediaProjection = mp

            isMediaProjectionStopped = false
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    isMediaProjectionStopped = true
                    try {
                        virtualDisplay?.release()
                    } catch (_: Exception) {
                    }
                    virtualDisplay = null
                    try {
                        imageReader?.close()
                    } catch (_: Exception) {
                    }
                    imageReader = null
                    if (PokeCountAccessibilityService.instance != null) {
                        screenCaptureAnalyzer.setStatusText("🎥 [$OVERLAY_VERSION] Dual-Rec Mode Active")
                    } else {
                        screenCaptureAnalyzer.setStatusText("⏸ Rec Conflict: Enable A11y or Tap to Resume")
                    }
                }
            }, mainHandler)

            val (screenW, screenH) = getScreenDimensions()
            val capW = max(360, screenW / 2)
            val capH = max(720, screenH / 2)
            val density = max(160, resources.displayMetrics.densityDpi / 2)

            imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mp.createVirtualDisplay(
                "MatchCalcCaptureV53",
                capW,
                capH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
            screenCaptureAnalyzer.setStatusText("● $OVERLAY_VERSION Scanner Ready")
        } catch (e: Exception) {
            screenCaptureAnalyzer.setStatusText("Err: ${e.javaClass.simpleName}")
        }
    }

    private fun getOverlayRectInImage(imgW: Int, imgH: Int): OverlayImageRect? {
        if (!::overlayRoot.isInitialized || overlayRoot.visibility != View.VISIBLE) return null
        val (screenW, screenH) = getScreenDimensions()
        if (screenW <= 0 || screenH <= 0) return null
        val loc = IntArray(2)
        overlayRoot.getLocationOnScreen(loc)
        val w = overlayRoot.width
        val h = overlayRoot.height
        if (w <= 0 || h <= 0) return null
        val scaleX = imgW.toFloat() / screenW.toFloat()
        val scaleY = imgH.toFloat() / screenH.toFloat()
        return OverlayImageRect(
            left = (loc[0] * scaleX).toInt() - 2,
            top = (loc[1] * scaleY).toInt() - 2,
            right = ((loc[0] + w) * scaleX).toInt() + 2,
            bottom = ((loc[1] + h) * scaleY).toInt() + 2
        )
    }

    private fun startCaptureLoop() {
        val tickMs = 100L
        mainHandler.post(object : Runnable {
            override fun run() {
                val image = try {
                    imageReader?.acquireLatestImage()
                } catch (_: Exception) {
                    null
                }
                if (image != null) {
                    val overlayRect = getOverlayRectInImage(image.width, image.height)
                    screenCaptureAnalyzer.processFrame(image, overlayRect, tickMs)
                } else if (isMediaProjectionStopped || imageReader == null) {
                    val a11yService = PokeCountAccessibilityService.instance
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (a11yService != null && !isA11yCaptureInFlight && (now - lastA11yCaptureRequestMs) >= 240L) {
                        val dtMs = if (lastA11yCaptureRequestMs > 0L) {
                            (now - lastA11yCaptureRequestMs).coerceIn(100L, 600L)
                        } else {
                            250L
                        }
                        isA11yCaptureInFlight = true
                        lastA11yCaptureRequestMs = now
                        a11yService.captureAccessibilityFrame { bmp ->
                            isA11yCaptureInFlight = false
                            if (bmp != null) {
                                val overlayRect = getOverlayRectInImage(bmp.width, bmp.height)
                                screenCaptureAnalyzer.processBitmapFrame(bmp, overlayRect, dtMs)
                            }
                        }
                    }
                }
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun refreshHudDisplay(snapshot: BattleSnapshot = sessionManager.snapshotFlow.value) {
        if (!::overlayRoot.isInitialized) return
        if (overlayRoot.visibility != View.VISIBLE) {
            overlayRoot.visibility = View.VISIBLE
        }

        val currentPokemon = screenCaptureAnalyzer.currentPokemon
        val activeFm = screenCaptureAnalyzer.getActiveFastMove(currentPokemon)
        val eFast = max(1, activeFm.energyGain)
        val energy = snapshot.energy.coerceIn(0, 100)
        val fastCount = snapshot.displayedFastMoveCount
        val cycleIdx = snapshot.cycleIndex

        countNumberText.text = fastCount.toString()
        countLabelText.text = if (snapshot.isLockedOut && screenCaptureAnalyzer.inActiveMatch) {
            val lockTurns = max(1, snapshot.cooldownTurnsRemaining)
            "LOCK ${lockTurns}T · $OVERLAY_VERSION"
        } else {
            "FAST · $OVERLAY_VERSION"
        }
        ocrStatusText.text = screenCaptureAnalyzer.statusMessage

        if (!screenCaptureAnalyzer.inActiveMatch) {
            pokemonTitleText.text = "[$OVERLAY_VERSION] Waiting for battle..."
            swapFastMoveBtn.visibility = View.GONE
            chargedBadgesContainer.visibility = View.GONE
            benchEnergyText.visibility = View.GONE
            return
        }

        pokemonTitleText.text =
            "[$OVERLAY_VERSION] ${currentPokemon.name} · ${activeFm.name} (${eFast}E/${activeFm.turns}T) [${energy}E]"
        val hasMultipleFastOrForms =
            currentPokemon.fastMoves.size > 1 || PvPokeRepository.getSiblingForms(currentPokemon).size > 1
        swapFastMoveBtn.visibility = if (hasMultipleFastOrForms) View.VISIBLE else View.GONE
        chargedBadgesContainer.visibility = if (manualCollapse) View.GONE else View.VISIBLE

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val paceList = currentPokemon.getPvPokeMoveCounts(activeFm, cm, 4)
            val activePaceTarget = paceList[cycleIdx % paceList.size]
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val afterEnergy = max(0, energy - cm.energyCost)
            val afterFastCount = floor(afterEnergy.toDouble() / eFast).toInt()
            val subtractMovesCount = if (isReady) max(1, fastCount - afterFastCount) else activePaceTarget

            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4094A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val cardLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = badgeBg
                setPadding(12, 5, 12, 5)
                setOnClickListener {
                    screenCaptureAnalyzer.onManualChargedMoveBadgeTap(cm)
                }
            }

            val topLine = TextView(this).apply {
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xEEFFFFFF.toInt())
                text = if (isReady) {
                    "⚡ ${cm.name} READY (▼-$subtractMovesCount)"
                } else {
                    "${cm.name}: $fastCount/$activePaceTarget (-$neededMoves)"
                }
            }

            val formattedPace = paceList.mapIndexed { idx, v ->
                if (idx == (cycleIdx % paceList.size)) "[$v]" else "$v"
            }.joinToString(" - ")

            val bottomLine = TextView(this).apply {
                textSize = 8.5f
                setSingleLine(true)
                setTextColor(0xBB94A3B8.toInt())
                text = "Fast Move Count: $formattedPace"
            }

            cardLayout.addView(topLine)
            cardLayout.addView(bottomLine)

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 4
            }
            chargedBadgesContainer.addView(cardLayout, lp)
        }

        val benchedSummaries = screenCaptureAnalyzer.seenOpponentPokemon.values
            .filter { poke ->
                poke.id != currentPokemon.id && (snapshot.benchedSlots[poke.id]?.energy ?: 0) > 0
            }
            .map { benchPoke ->
                val bEnergy = (snapshot.benchedSlots[benchPoke.id]?.energy ?: 0).coerceIn(0, 100)
                val bFm = screenCaptureAnalyzer.getActiveFastMove(benchPoke)
                val bFastCnt = floor(bEnergy.toDouble() / max(1, bFm.energyGain)).toInt()
                "${benchPoke.name}: $bFastCnt Fast (${bEnergy}E)"
            }

        if (benchedSummaries.isNotEmpty() && !manualCollapse) {
            benchEnergyText.text = "📦 Bench: ${benchedSummaries.joinToString(" · ")}"
            benchEnergyText.visibility = View.VISIBLE
        } else {
            benchEnergyText.visibility = View.GONE
        }
    }

    private fun createNotification(): Notification {
        val channelId = "gl_match_calc_v48"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "GL Match Calculator HUD v66",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("GL Match Calc v66")
            .setContentText("Deterministic 500ms Turn Engine HUD Active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        try {
            if (::sessionManager.isInitialized) {
                sessionManager.shutdown()
            }
            serviceUiScope.cancel()
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
            if (::overlayRoot.isInitialized) {
                windowManager.removeView(overlayRoot)
            }
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    companion object {
        const val OVERLAY_VERSION = "v66"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
