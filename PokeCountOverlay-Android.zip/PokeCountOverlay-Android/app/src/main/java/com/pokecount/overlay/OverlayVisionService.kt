package com.pokecount.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayRoot: LinearLayout
    private lateinit var orangeBubbleView: TextView
    private lateinit var detailsPanel: LinearLayout
    private lateinit var pokemonTitleText: TextView
    private lateinit var chargedBadgesContainer: LinearLayout

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val slotEnergies = mutableMapOf<String, Int>()
    private var currentPokemon: PvPokeEntry = PvPokeRepository.META_POKEMON.first()
    private var turnElapsedMs = 0L
    private var chargedPauseMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Android 14 / 15 requires startForeground with FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        // to be called AFTER MediaProjection permission is granted in MainActivity
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startTurnClockAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode != -1 && resultData != null && mediaProjection == null) {
            setupMediaProjection(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun createFloatingOverlayHud() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 320
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 12, 12, 12)
        }

        // Discreet HUD Card next to the Orange Bubble
        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 28f
            setColor(0xDD0F172A.toInt())
            setStroke(3, 0xFF38BDF8.toInt())
        }

        detailsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            setPadding(24, 16, 24, 16)
        }

        pokemonTitleText = TextView(this).apply {
            text = "Feraligatr · Shadow Claw"
            textSize = 12f
            setTextColor(0xFF38BDF8.toInt())
            setOnClickListener {
                // Tap title to cycle Pokémon manually if needed
                val idx = PvPokeRepository.META_POKEMON.indexOf(currentPokemon)
                currentPokemon = PvPokeRepository.META_POKEMON[(idx + 1) % PvPokeRepository.META_POKEMON.size]
                turnElapsedMs = 0L
                refreshHudDisplay()
            }
        }

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 0)
        }

        detailsPanel.addView(pokemonTitleText)
        detailsPanel.addView(chargedBadgesContainer)

        // Poke Genie-Style Circular Orange Bubble with White Border
        val circleDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFFF97316.toInt())
            setStroke(6, 0xFFFFFFFF.toInt())
        }

        orangeBubbleView = TextView(this).apply {
            text = "0"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = circleDrawable
            width = 130
            height = 130
            setOnClickListener {
                detailsPanel.visibility = if (detailsPanel.visibility == View.VISIBLE) {
                    View.GONE
                } else {
                    View.VISIBLE
                }
            }
        }

        overlayRoot.addView(detailsPanel)
        overlayRoot.addView(orangeBubbleView)

        // Drag handler on the Orange Bubble
        orangeBubbleView.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                        params.x = initialX - dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(overlayRoot, params)
        refreshHudDisplay()
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)
        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "PokeCountCapture",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            mainHandler
        )
    }

    private fun startTurnClockAndOcrLoop() {
        val tickMs = 250L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameWithOcr()

                if (chargedPauseMs > 0) {
                    chargedPauseMs = max(0L, chargedPauseMs - tickMs)
                } else {
                    turnElapsedMs += tickMs
                    val moveDurationMs = currentPokemon.fastMove.turns * 500L
                    if (turnElapsedMs >= moveDurationMs) {
                        turnElapsedMs = 0L
                        val prevE = slotEnergies[currentPokemon.id] ?: 0
                        slotEnergies[currentPokemon.id] = min(100, prevE + currentPokemon.fastMove.energyGain)
                        refreshHudDisplay()
                    }
                }
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun processFrameWithOcr() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val plane = image.planes[0]
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width

            val bitmap = Bitmap.createBitmap(
                width + rowPadding / pixelStride,
                height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(plane.buffer)

            val cropHeight = (height * 0.35f).toInt()
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, cropHeight)

            recognizer.process(InputImage.fromBitmap(cropped, 0))
                .addOnSuccessListener { visionText ->
                    val raw = visionText.text
                    val matchedPoke = PvPokeRepository.matchPokemonName(raw)
                    if (matchedPoke != null && matchedPoke.id != currentPokemon.id) {
                        currentPokemon = matchedPoke
                        turnElapsedMs = 0L
                        refreshHudDisplay()
                    }

                    val now = System.currentTimeMillis()
                    if (now - lastSubtractedMoveTimestamp > 4500L) {
                        val usedMove = PvPokeRepository.matchChargedMoveUsed(raw, currentPokemon)
                        if (usedMove != null) {
                            lastSubtractedMoveTimestamp = now
                            chargedPauseMs = 9500L
                            val currentE = slotEnergies[currentPokemon.id] ?: 0
                            slotEnergies[currentPokemon.id] = max(0, currentE - usedMove.energyCost)
                            refreshHudDisplay()
                        }
                    }
                }
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun refreshHudDisplay() {
        val energy = slotEnergies[currentPokemon.id] ?: 0
        val eFast = currentPokemon.fastMove.energyGain
        val fastCount = floor(energy.toDouble() / eFast).toInt()
        val residual = energy % eFast

        orangeBubbleView.text = fastCount.toString()
        pokemonTitleText.text = "${currentPokemon.name} · ${currentPokemon.fastMove.name} (${energy}E)"

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18f
                setColor(if (isReady) cm.colorHex else 0xFF1E293B.toInt())
                setStroke(3, if (isReady) 0xFF34D399.toInt() else cm.colorHex)
            }

            val badge = TextView(this).apply {
                background = badgeBg
                setPadding(18, 10, 18, 10)
                textSize = 11f
                setTextColor(0xFFFFFFFF.toInt())
                text = if (isReady) "⚡${cm.name} (RDY)" else "${cm.name} (-$neededMoves)"
                // Tapping any Charged Move badge manually subtracts its energy immediately!
                setOnClickListener {
                    val curE = slotEnergies[currentPokemon.id] ?: 0
                    slotEnergies[currentPokemon.id] = max(0, curE - cm.energyCost)
                    refreshHudDisplay()
                }
            }

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = 12
            }
            chargedBadgesContainer.addView(badge, lp)
        }
    }

    private fun createNotification(): Notification {
        val channelId = "pokecount_overlay_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "PokéCount Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("PokéCount Auto-Vision Active")
            .setContentText("Monitoring Pokémon GO opponent moves & energy")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        mediaProjection?.stop()
        if (overlayInitialized && ::overlayRoot.isInitialized) {
            windowManager.removeView(overlayRoot)
        }
    }

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
