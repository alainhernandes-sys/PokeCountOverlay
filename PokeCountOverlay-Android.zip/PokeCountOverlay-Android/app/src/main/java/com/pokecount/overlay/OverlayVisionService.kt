package com.pokecount.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var overlayRoot: LinearLayout
    private lateinit var counterBadgeLayout: LinearLayout
    private lateinit var countNumberText: TextView
    private lateinit var countLabelText: TextView
    private lateinit var pokemonTitleText: TextView
    private lateinit var ocrStatusText: TextView
    private lateinit var swapFastMoveBtn: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var closeOverlayBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout
    private lateinit var benchEnergyText: TextView

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()
    private val mainHandler = Handler(Looper.getMainLooper())

    // Per-Pokemon persistent battle state (remembers energy & move cycle across switches!)
    private val slotEnergies = mutableMapOf<String, Int>()
    private val slotCycleIndex = mutableMapOf<String, Int>()
    private val slotFastMoveIdx = mutableMapOf<String, Int>()
    private val seenOpponentPokemon = linkedMapOf<String, PvPokeEntry>()
    private val manualFormOverrideByBase = mutableMapOf<String, String>()

    private var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
    private var hasLockedFirstRealOpponentInMatch = false
    private var totalFastMovesInCurrentMatch = 0

    private var currentPlayerPokemonId: String? = null
    private var currentPlayerPokemonName: String? = null
    private var playerDefenderTypes: List<String> = emptyList()
    private var latestEffectivenessHint: String? = null
    private var fastHitsLandedOnCurrentPlayer: Int = 0

    // Battle & Cutscene state tracking
    private var inActiveMatch = false
    private var isBattleHudCurrentlyVisible = false
    private var hudCompletelyMissingDurationMs = 0L
    private var zoomedWithoutHpDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var playerUsedChargedMoveDuringZoom = false
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var hasSubtractedChargedMoveForCurrentCutscene = false
    private var energyAtCutsceneStart: Int = -1
    private var postCutsceneFastEnergyEarned: Int = 0
    private var lastAutoSubtractedMove: ChargedMove? = null
    private var lastAutoSubtractedPokemonId: String? = null
    private var postCutsceneBannerTicks = 0
    private var manualCollapse = false

    // v27 Lunge-Safe & Opening-Safe HP Bar Tracker (Zero Y-Axis Resets + Immediate Drop Detection)
    private var hasInitializedLeadPlayerHp = false
    private var refPlayerHpFillPx: Int? = null
    private var refPlayerHpBarY: Int = -1
    private var prevOrangeDrainPx: Int = 0
    private var higherHpConfirmTicks: Int = 0
    private var lastVisualFastMoveTimestampMs: Long = 0L

    // OCR concurrency, throttling & watchdog
    private var isOcrBusy = false
    private var lastOcrStartTimestampMs = 0L
    private var lastOcrCompletedTimestampMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x40000000, 0x26000000, 0x73090D16)
    private val borderAlphas = intArrayOf(0x36FFFFFF, 0x20FFFFFF, 0x5094A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    private fun getActiveFastMove(entry: PvPokeEntry = currentPokemon): FastMove {
        val idx = (slotFastMoveIdx[entry.id] ?: 0).coerceIn(0, max(0, entry.fastMoves.size - 1))
        return entry.fastMoves[idx]
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext)
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startVisualAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun createFloatingOverlayHud() {
        val (screenW, screenH) = getScreenDimensions()
        val compactWidth = (screenW * 0.54f).toInt()

        overlayParams = WindowManager.LayoutParams(
            compactWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = (screenH * 0.125f).toInt()
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
        }

        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        counterBadgeLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 5, 12, 5)
            setOnClickListener {
                manualCollapse = !manualCollapse
                refreshHudDisplay()
            }
        }

        countNumberText = TextView(this).apply {
            text = "0"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }

        countLabelText = TextView(this).apply {
            text = "FAST · $OVERLAY_VERSION"
            textSize = 7.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFF6EE7B7.toInt())
        }

        counterBadgeLayout.addView(countNumberText)
        counterBadgeLayout.addView(countLabelText)

        val rightHeaderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        pokemonTitleText = TextView(this).apply {
            text = "[$OVERLAY_VERSION] Waiting for battle..."
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xEEFFFFFF.toInt())
            setOnClickListener {
                resetCurrentMatchState("● [$OVERLAY_VERSION] Reset to 0")
            }
        }

        val microControlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        ocrStatusText = TextView(this).apply {
            text = "● $OVERLAY_VERSION Engine Ready"
            textSize = 8.5f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xAA6EE7B7.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        swapFastMoveBtn = TextView(this).apply {
            text = " [⇄Fast] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setOnClickListener {
                val oldFm = getActiveFastMove()
                val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                val siblings = PvPokeRepository.getSiblingForms(currentPokemon)

                if (curIdx + 1 < currentPokemon.fastMoves.size) {
                    slotFastMoveIdx[currentPokemon.id] = curIdx + 1
                    val newFm = getActiveFastMove()
                    if (oldCount > 0) {
                        slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                    }
                    ocrStatusText.text = "Fast: ${newFm.name}"
                    refreshHudDisplay()
                } else if (siblings.size > 1) {
                    val curFormIdx = siblings.indexOfFirst { it.id == currentPokemon.id }.coerceAtLeast(0)
                    val nextForm = siblings[(curFormIdx + 1) % siblings.size]
                    seenOpponentPokemon.remove(currentPokemon.id)
                    seenOpponentPokemon[nextForm.id] = nextForm
                    slotFastMoveIdx[nextForm.id] = 0
                    val nextFm = nextForm.fastMoves.first()
                    slotEnergies[nextForm.id] = min(100, oldCount * nextFm.energyGain)
                    slotCycleIndex[nextForm.id] = slotCycleIndex[currentPokemon.id] ?: 0
                    val baseKey = nextForm.name.substringBefore("(").trim().lowercase()
                    manualFormOverrideByBase[baseKey] = nextForm.id
                    currentPokemon = nextForm
                    ocrStatusText.text = "Form: ${nextForm.name}"
                    refreshHudDisplay()
                } else if (currentPokemon.fastMoves.size > 1) {
                    slotFastMoveIdx[currentPokemon.id] = 0
                    val newFm = getActiveFastMove()
                    if (oldCount > 0) {
                        slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                    }
                    ocrStatusText.text = "Fast: ${newFm.name}"
                    refreshHudDisplay()
                }
            }
        }

        val minusOneBtn = TextView(this).apply {
            text = "[−]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = max(0, curE - getActiveFastMove().energyGain)
                totalFastMovesInCurrentMatch = max(0, totalFastMovesInCurrentMatch - 1)
                refreshHudDisplay()
            }
        }

        val plusOneBtn = TextView(this).apply {
            text = " [+]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF6EE7B7.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, curE + getActiveFastMove().energyGain)
                totalFastMovesInCurrentMatch++
                refreshHudDisplay()
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = " ◐"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        closeOverlayBtn = TextView(this).apply {
            text = " ✕"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                stopSelf()
            }
        }

        microControlsRow.addView(ocrStatusText)
        microControlsRow.addView(swapFastMoveBtn)
        microControlsRow.addView(minusOneBtn)
        microControlsRow.addView(plusOneBtn)
        microControlsRow.addView(opacityToggleBtn)
        microControlsRow.addView(closeOverlayBtn)

        rightHeaderCol.addView(pokemonTitleText)
        rightHeaderCol.addView(microControlsRow)

        topHeaderRow.addView(counterBadgeLayout)
        topHeaderRow.addView(rightHeaderCol)

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        benchEnergyText = TextView(this).apply {
            textSize = 8.5f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xFFFDE047.toInt())
            setPadding(4, 5, 4, 0)
            visibility = View.GONE
        }

        overlayRoot.addView(topHeaderRow)
        overlayRoot.addView(chargedBadgesContainer)
        overlayRoot.addView(benchEnergyText)

        applyStealthTheme()

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = overlayParams.x
                        initialY = overlayParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        overlayParams.x = initialX - dx
                        overlayParams.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, overlayParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        }

        counterBadgeLayout.setOnTouchListener(dragListener)
        pokemonTitleText.setOnTouchListener(dragListener)

        windowManager.addView(overlayRoot, overlayParams)
        refreshHudDisplay()
    }

    private fun resetCurrentMatchState(statusMsg: String) {
        slotEnergies.clear()
        slotCycleIndex.clear()
        seenOpponentPokemon.clear()
        manualFormOverrideByBase.clear()
        hasLockedFirstRealOpponentInMatch = false
        totalFastMovesInCurrentMatch = 0
        hasInitializedLeadPlayerHp = false
        refPlayerHpFillPx = null
        refPlayerHpBarY = -1
        prevOrangeDrainPx = 0
        higherHpConfirmTicks = 0
        lastVisualFastMoveTimestampMs = 0L
        fastHitsLandedOnCurrentPlayer = 0
        latestEffectivenessHint = null
        chargedAttackDetectedDuringPause = false
        playerUsedChargedMoveDuringZoom = false
        specificMoveDetectedDuringPause = null
        hasSubtractedChargedMoveForCurrentCutscene = false
        energyAtCutsceneStart = -1
        postCutsceneFastEnergyEarned = 0
        lastAutoSubtractedMove = null
        lastAutoSubtractedPokemonId = null
        postCutsceneBannerTicks = 0
        zoomedWithoutHpDurationMs = 0L
        ocrStatusText.text = statusMsg
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 22f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        overlayRoot.background = panelBg

        val counterBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f
            setColor(0x44000000)
            setStroke(2, 0x8834D399.toInt())
        }
        counterBadgeLayout.background = counterBg
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()

            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpManager.getMediaProjection(resultCode, data) ?: return
            mediaProjection = mp

            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    try {
                        virtualDisplay?.release()
                    } catch (_: Exception) {
                    }
                    virtualDisplay = null
                    try {
                        imageReader?.close()
                    } catch (_: Exception) {
                    }
                    imageReader = null
                    ocrStatusText.text = "⏸ [$OVERLAY_VERSION] Capture Paused"
                }
            }, mainHandler)

            val (screenW, screenH) = getScreenDimensions()
            val capW = max(360, screenW / 2)
            val capH = max(720, screenH / 2)
            val density = max(160, resources.displayMetrics.densityDpi / 2)

            imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mp.createVirtualDisplay(
                "MatchCalcCaptureV27",
                capW,
                capH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
            ocrStatusText.text = "● $OVERLAY_VERSION Scanner Ready"
        } catch (e: Exception) {
            ocrStatusText.text = "Err: ${e.javaClass.simpleName}"
        }
    }

    private data class OverlayImageRect(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int
    ) {
        fun contains(x: Int, y: Int): Boolean = x in left..right && y in top..bottom
    }

    private fun getOverlayRectInImage(imgW: Int, imgH: Int): OverlayImageRect? {
        if (!::overlayRoot.isInitialized || overlayRoot.visibility != View.VISIBLE) return null
        val (screenW, screenH) = getScreenDimensions()
        if (screenW <= 0 || screenH <= 0) return null
        val loc = IntArray(2)
        overlayRoot.getLocationOnScreen(loc)
        val w = overlayRoot.width
        val h = overlayRoot.height
        if (w <= 0 || h <= 0) return null
        val scaleX = imgW.toFloat() / screenW.toFloat()
        val scaleY = imgH.toFloat() / screenH.toFloat()
        return OverlayImageRect(
            left = (loc[0] * scaleX).toInt() - 2,
            top = (loc[1] * scaleY).toInt() - 2,
            right = ((loc[0] + w) * scaleX).toInt() + 2,
            bottom = ((loc[1] + h) * scaleY).toInt() + 2
        )
    }

    private data class FrameVisualTelemetry(
        val isFrameNonBlack: Boolean,
        val isBattleHudVisible: Boolean,
        val isShieldPromptVisible: Boolean,
        val barLenPx: Int,
        val playerHpFillPx: Int,
        val playerHpBarY: Int,
        val playerHpStage: Int,
        val orangeDrainPx: Int,
        val opponentBadgeTypes: Set<String>
    )

    private fun analyzeFrameVisualTelemetry(image: Image, overlayRect: OverlayImageRect?): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val barLen = max(20, (width * 0.272f).roundToInt())

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(false, false, false, barLen, -1, -1, 0, 0, emptySet())
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float, ignoreOverlay: Boolean): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.015f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.108f).toInt().coerceIn(y0 + 1, height)

                var maxRowWhiteRatio = 0f
                var pokeballIndicatorDots = 0
                var darkTextPixels = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        if (ignoreOverlay && overlayRect != null && overlayRect.contains(x, y)) {
                            x += max(2, width / 160)
                            continue
                        }
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 175 && g >= 185 && b >= 200) {
                                rowWhite++
                            }
                            if (r > 170 && g < 98 && b < 98) {
                                pokeballIndicatorDots++
                            }
                            if (r < 115 && g < 115 && b < 125) {
                                darkTextPixels++
                            }
                        }
                        x += max(2, width / 160)
                    }
                    if (rowTotal >= 6) {
                        val ratio = rowWhite.toFloat() / rowTotal
                        if (ratio > maxRowWhiteRatio) maxRowWhiteRatio = ratio
                    }
                    y += max(1, height / 700)
                }
                return (maxRowWhiteRatio > 0.40f && darkTextPixels >= 3 && pokeballIndicatorDots >= 1) ||
                    (maxRowWhiteRatio > 0.50f && darkTextPixels >= 5)
            }

            // Require BOTH top HUD pills (left AND right) so the instant "Attack incoming!" begins,
            // fast-move counting stops immediately!
            val leftPillVisible = checkBattlePillSide(0.02f, 0.42f, ignoreOverlay = false)
            val rightPillVisible = checkBattlePillSide(0.58f, 0.98f, ignoreOverlay = true)
            val hudPillsVisible = leftPillVisible && rightPillVisible

            var shieldMagentaCount = 0
            var shieldSampleTotal = 0
            val sx0 = (width * 0.38f).toInt().coerceIn(0, width - 2)
            val sx1 = (width * 0.62f).toInt().coerceIn(sx0 + 1, width)
            val sy0 = (height * 0.73f).toInt().coerceIn(0, height - 2)
            val sy1 = (height * 0.91f).toInt().coerceIn(sy0 + 1, height)
            var sy = sy0
            while (sy < sy1) {
                val rOff = sy * rowStride
                var sx = sx0
                while (sx < sx1) {
                    val off = rOff + sx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        shieldSampleTotal++
                        if (r >= 175 && b >= 195 && g in 110..235 && (b - g) >= 15) {
                            shieldMagentaCount++
                        }
                    }
                    sx += max(2, width / 120)
                }
                sy += max(2, height / 250)
            }
            val shieldMagentaRatio = if (shieldSampleTotal > 0) shieldMagentaCount.toFloat() / shieldSampleTotal else 0f
            val isShieldPromptVisible = !hudPillsVisible && shieldMagentaRatio >= 0.16f

            if (!hudPillsVisible) {
                return FrameVisualTelemetry(
                    isFrameNonBlack = true,
                    isBattleHudVisible = false,
                    isShieldPromptVisible = isShieldPromptVisible,
                    barLenPx = barLen,
                    playerHpFillPx = -1,
                    playerHpBarY = -1,
                    playerHpStage = 0,
                    orangeDrainPx = 0,
                    opponentBadgeTypes = emptySet()
                )
            }

            val detectedBadgeTypes = mutableSetOf<String>()
            val bx0 = (width * 0.87f).toInt().coerceIn(0, width - 2)
            val bx1 = (width * 0.985f).toInt().coerceIn(bx0 + 1, width)
            val by1 = max(4, (height * 0.025f).toInt()).coerceIn(1, height)
            val badgeCounts = mutableMapOf<String, Int>()
            for (by in 0 until by1) {
                val rOff = by * rowStride
                for (bx in bx0 until bx1) {
                    val off = rOff + bx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        val bType = when {
                            r > 215 && g in 130..195 && b > 195 && (r - g) > 40 && (b - g) > 30 -> "fairy"
                            r in 155..220 && g in 60..130 && b in 165..235 && (r - g) > 55 && (b - g) > 65 -> "poison"
                            r > 225 && g in 135..195 && b in 45..110 && (r - b) > 120 -> "fire"
                            r > 195 && g in 45..105 && b in 50..115 && (r - g) > 100 -> "fighting"
                            r in 75..150 && g in 150..210 && b > 205 && (b - r) > 70 -> "water"
                            r in 80..155 && g > 190 && b > 185 && abs(g - b) < 25 -> "ice"
                            r in 80..135 && g in 130..175 && b in 155..200 && (b - r) in 40..85 -> "steel"
                            r > 210 && g in 115..160 && b in 60..105 && (r - b) > 110 -> "ground"
                            r > 230 && g > 200 && b in 40..105 && (r - b) > 135 -> "electric"
                            r in 70..135 && g > 175 && b in 70..135 && (g - r) > 55 -> "grass"
                            r > 220 && g in 95..145 && b in 120..175 && (r - g) > 85 -> "psychic"
                            r in 75..135 && g in 85..140 && b in 155..215 && (b - r) > 50 -> "ghost"
                            r in 65..110 && g in 60..105 && b in 75..120 && abs(r - g) < 20 -> "dark"
                            else -> null
                        }
                        if (bType != null) {
                            badgeCounts[bType] = (badgeCounts[bType] ?: 0) + 1
                        }
                    }
                }
            }
            for ((tName, cnt) in badgeCounts) {
                if (cnt >= 3) detectedBadgeTypes.add(tName)
            }

            fun classifyHpPixel(r: Int, g: Int, b: Int): Int {
                return when {
                    g >= 185 && r <= 105 && b in 110..215 && (g - r) >= 95 && (g - b) >= 32 -> 1
                    r >= 205 && g >= 185 && b in 60..180 && (r - b) >= 60 && abs(r - g) <= 45 -> 2
                    r >= 175 && g in 15..115 && b in 15..115 && (r - g) >= 85 && abs(g - b) <= 35 -> 3
                    (r < 172 && g < 172 && b < 178 && (r + g + b) <= 465) ||
                        (r >= 138 && g in 95..195 && b < 68 && (r - b) >= 80) -> 4
                    else -> 0
                }
            }

            val maxBorderDy = max(5, (height * 0.013f).toInt())
            val borderStepX = max(2, barLen / 22)

            fun hasHorizontalBoxBorder(py: Int, absStartX: Int): Boolean {
                var topBest = 0
                var botBest = 0
                var totalCols = 0
                val endX = min(width - 1, absStartX + barLen)
                var x = absStartX
                while (x < endX) {
                    totalCols++
                    x += borderStepX
                }
                if (totalCols <= 4) return false
                val reqBright = (totalCols * 0.48f).toInt()

                for (dy in 1..maxBorderDy) {
                    val ty = py - dy
                    if (ty >= 0) {
                        val rOff = ty * rowStride
                        var cnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 240 && max(r, max(g, b)) >= 88) cnt++
                            }
                            cx += borderStepX
                        }
                        if (cnt > topBest) topBest = cnt
                    }
                    val by = py + dy
                    if (by < height) {
                        val rOff = by * rowStride
                        var cnt = 0
                        var cx = absStartX
                        while (cx < endX) {
                            val off = rOff + cx * pixelStride
                            if (off >= 0 && off + 3 < bufLimit) {
                                val r = buf.get(off).toInt() and 0xFF
                                val g = buf.get(off + 1).toInt() and 0xFF
                                val b = buf.get(off + 2).toInt() and 0xFF
                                if ((r + g + b) >= 240 && max(r, max(g, b)) >= 88) cnt++
                            }
                            cx += borderStepX
                        }
                        if (cnt > botBest) botBest = cnt
                    }
                }
                return topBest >= reqBright && botBest >= reqBright
            }

            // Scan Player Floating HP Bar with Wide-Arena left-start bounds (0.048f..0.098f)
            val hx0 = (width * 0.035f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.42f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.15f).toInt().coerceIn(4, height - 5)
            val hy1 = (height * 0.75f).toInt().coerceIn(hy0 + 1, height - 4)

            val scanW = hx1 - hx0
            val minValidInBar = (barLen * 0.76f).toInt()
            val minSmoothInBar = (barLen * 0.72f).toInt()
            val minStartScreenX = (width * 0.048f).toInt()
            val maxStartScreenX = (width * 0.098f).toInt()

            val minGreenFill = max(12, (barLen * 0.44f).toInt())
            val minYellowFill = max(6, (barLen * 0.15f).toInt())
            val maxYellowFill = (barLen * 0.58f).toInt()
            val maxRedFill = max(6, (barLen * 0.26f).toInt())

            var bestGreenFillPx = -1
            var bestGreenY = -1
            var bestGreenOrangePx = 0
            var bestYellowFillPx = -1
            var bestYellowY = -1
            var bestYellowOrangePx = 0
            var bestRedFillPx = -1
            var bestRedY = -1
            var bestRedOrangePx = 0

            val rowTypes = IntArray(scanW)
            val rowOrange = BooleanArray(scanW)
            val smoothPrefix = IntArray(scanW)

            val prev1FirstCol = IntArray(4) { -1 }
            val prev1FillCnt = IntArray(4) { -1 }
            val prev1RowY = IntArray(4) { -1 }

            val maxOrangeTipSpan = max(6, barLen / 11)

            if (scanW > barLen) {
                for (py in hy0 until hy1) {
                    val rOff = py * rowStride
                    var gFirst = -1
                    var yFirst = -1
                    var rFirst = -1

                    var prevR = 0
                    var prevG = 0
                    var prevB = 0
                    var sSum = 0

                    for (col in 0 until scanW) {
                        val absX = hx0 + col
                        if (overlayRect != null && overlayRect.contains(absX, py)) {
                            rowTypes[col] = 0
                            rowOrange[col] = false
                            smoothPrefix[col] = sSum
                            continue
                        }
                        val off = rOff + absX * pixelStride
                        var t = 0
                        var isOrg = false
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF

                            if (col > 0) {
                                val diff = abs(r - prevR) + abs(g - prevG) + abs(b - prevB)
                                if (diff <= 22) sSum++
                            }
                            smoothPrefix[col] = sSum
                            prevR = r
                            prevG = g
                            prevB = b

                            t = classifyHpPixel(r, g, b)
                            when (t) {
                                1 -> if (gFirst < 0) gFirst = col
                                2 -> if (yFirst < 0) yFirst = col
                                3 -> if (rFirst < 0) rFirst = col
                            }

                            if (r >= 175 && g in 110..195 && b <= 62 && (r - b) >= 115 && r >= g + 14) {
                                isOrg = true
                            }
                        } else {
                            smoothPrefix[col] = sSum
                        }
                        rowTypes[col] = t
                        rowOrange[col] = isOrg
                    }

                    fun evalStageRow(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int): Pair<Int, Int> {
                        if (firstCol < 0 || firstCol + barLen > scanW) return Pair(-1, 0)
                        val absStartX = hx0 + firstCol
                        if (absStartX !in minStartScreenX..maxStartScreenX) return Pair(-1, 0)

                        val smoothCnt = smoothPrefix[firstCol + barLen - 1] - smoothPrefix[firstCol]
                        if (smoothCnt < minSmoothInBar) return Pair(-1, 0)

                        var fillCnt = 0
                        var gap = 0
                        var fillStopped = false
                        var emptyCnt = 0
                        for (c in firstCol until (firstCol + barLen)) {
                            val rt = rowTypes[c]
                            if (!fillStopped) {
                                if (rt == stageCode) {
                                    fillCnt++
                                    gap = 0
                                } else {
                                    gap++
                                    if (gap >= 3) fillStopped = true
                                    if (rt == 4) emptyCnt++
                                }
                            } else if (rt == 4) {
                                emptyCnt++
                            }
                        }
                        if (fillCnt !in minFill..maxFill || (fillCnt + emptyCnt) < minValidInBar) {
                            return Pair(-1, 0)
                        }

                        if (!hasHorizontalBoxBorder(py, absStartX)) {
                            return Pair(-1, 0)
                        }

                        var orgCnt = 0
                        val tipStart = (firstCol + fillCnt).coerceAtMost(scanW - 1)
                        val tipEnd = min(firstCol + barLen, firstCol + fillCnt + maxOrangeTipSpan)
                        for (c in tipStart until tipEnd) {
                            if (rowOrange[c]) orgCnt++
                        }
                        return Pair(fillCnt, orgCnt)
                    }

                    fun updateStageHistoryAndBest(firstCol: Int, stageCode: Int, minFill: Int, maxFill: Int) {
                        val (fillCnt, orgCnt) = evalStageRow(firstCol, stageCode, minFill, maxFill)
                        if (fillCnt > 0) {
                            if (
                                prev1RowY[stageCode] == py - 1 &&
                                abs(prev1FirstCol[stageCode] - firstCol) <= 2 &&
                                abs(prev1FillCnt[stageCode] - fillCnt) <= 3
                            ) {
                                val avgFill = max(fillCnt, prev1FillCnt[stageCode])
                                when (stageCode) {
                                    1 -> if (avgFill > bestGreenFillPx || (avgFill == bestGreenFillPx && orgCnt > bestGreenOrangePx)) {
                                        bestGreenFillPx = avgFill
                                        bestGreenY = py
                                        bestGreenOrangePx = max(bestGreenOrangePx, orgCnt)
                                    }
                                    2 -> if (avgFill > bestYellowFillPx || (avgFill == bestYellowFillPx && orgCnt > bestYellowOrangePx)) {
                                        bestYellowFillPx = avgFill
                                        bestYellowY = py
                                        bestYellowOrangePx = max(bestYellowOrangePx, orgCnt)
                                    }
                                    3 -> if (avgFill > bestRedFillPx || (avgFill == bestRedFillPx && orgCnt > bestRedOrangePx)) {
                                        bestRedFillPx = avgFill
                                        bestRedY = py
                                        bestRedOrangePx = max(bestRedOrangePx, orgCnt)
                                    }
                                }
                            }
                            prev1RowY[stageCode] = py
                            prev1FirstCol[stageCode] = firstCol
                            prev1FillCnt[stageCode] = fillCnt
                        }
                    }

                    updateStageHistoryAndBest(gFirst, 1, minGreenFill, barLen)
                    updateStageHistoryAndBest(yFirst, 2, minYellowFill, maxYellowFill)
                    updateStageHistoryAndBest(rFirst, 3, 2, maxRedFill)
                }
            }

            val hpFillPx: Int
            val hpBarY: Int
            val hpStage: Int
            val orangeDrainPx: Int
            when {
                bestGreenFillPx > 0 -> {
                    hpFillPx = bestGreenFillPx
                    hpBarY = bestGreenY
                    hpStage = 1
                    orangeDrainPx = bestGreenOrangePx
                }
                bestYellowFillPx > 0 -> {
                    hpFillPx = bestYellowFillPx
                    hpBarY = bestYellowY
                    hpStage = 2
                    orangeDrainPx = bestYellowOrangePx
                }
                bestRedFillPx > 0 -> {
                    hpFillPx = bestRedFillPx
                    hpBarY = bestRedY
                    hpStage = 3
                    orangeDrainPx = bestRedOrangePx
                }
                else -> {
                    hpFillPx = -1
                    hpBarY = -1
                    hpStage = 0
                    orangeDrainPx = 0
                }
            }

            FrameVisualTelemetry(
                isFrameNonBlack = true,
                isBattleHudVisible = true,
                isShieldPromptVisible = false,
                barLenPx = barLen,
                playerHpFillPx = hpFillPx,
                playerHpBarY = hpBarY,
                playerHpStage = hpStage,
                orangeDrainPx = orangeDrainPx,
                opponentBadgeTypes = detectedBadgeTypes
            )
        } catch (_: Exception) {
            FrameVisualTelemetry(true, false, false, 66, -1, -1, 0, 0, emptySet())
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1,
        maskOverlayRect: OverlayImageRect? = null
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    if (maskOverlayRect != null && maskOverlayRect.contains(x, y)) {
                        pixels[py * outW + px] = 0xFF000000.toInt()
                    } else {
                        val offset = rowOffset + x * pixelStride
                        if (offset >= 0 && offset + 3 < bufLimit) {
                            val r = buf.get(offset).toInt() and 0xFF
                            val g = buf.get(offset + 1).toInt() and 0xFF
                            val b = buf.get(offset + 2).toInt() and 0xFF
                            pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                        }
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }

    private fun startVisualAndOcrLoop() {
        val tickMs = 100L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameAndUpdateState(tickMs)
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun upgradeToSiblingFormIfMoveMatches(usedMove: ChargedMove) {
        if (currentPokemon.chargedMoves.any { it.name == usedMove.name }) return
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)
        val matchingSibling = siblings.firstOrNull { sib ->
            sib.chargedMoves.any { it.name == usedMove.name }
        } ?: return

        val oldFm = getActiveFastMove()
        val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
        seenOpponentPokemon.remove(currentPokemon.id)
        seenOpponentPokemon[matchingSibling.id] = matchingSibling
        val newFm = getActiveFastMove(matchingSibling)
        slotEnergies[matchingSibling.id] = min(100, oldCount * newFm.energyGain)
        slotCycleIndex[matchingSibling.id] = slotCycleIndex[currentPokemon.id] ?: 0
        val baseKey = matchingSibling.name.substringBefore("(").trim().lowercase()
        manualFormOverrideByBase[baseKey] = matchingSibling.id
        currentPokemon = matchingSibling
    }

    private fun subtractChargedMoveAndUpdate(
        cm: ChargedMove,
        targetPokeId: String = currentPokemon.id,
        isManualTap: Boolean = false
    ) {
        upgradeToSiblingFormIfMoveMatches(cm)
        val effectiveId = currentPokemon.id
        val currentE = slotEnergies[effectiveId] ?: 0
        if (!isManualTap && energyAtCutsceneStart >= 0) {
            val baseResidual = max(0, energyAtCutsceneStart - cm.energyCost)
            slotEnergies[effectiveId] = min(100, baseResidual + postCutsceneFastEnergyEarned)
        } else {
            slotEnergies[effectiveId] = max(0, currentE - cm.energyCost)
        }
        val prevCycle = slotCycleIndex[effectiveId] ?: 0
        slotCycleIndex[effectiveId] = (prevCycle + 1) % 4
        lastSubtractedMoveTimestamp = System.currentTimeMillis()
        lastAutoSubtractedMove = cm
        lastAutoSubtractedPokemonId = effectiveId
        hasSubtractedChargedMoveForCurrentCutscene = true
        ocrStatusText.text = "▼ Subtracted ${cm.name}"
        refreshHudDisplay()
    }

    private fun undoFalsePlayerChargedMoveSubtractionIfNeeded() {
        val now = System.currentTimeMillis()
        val prevSub = lastAutoSubtractedMove ?: return
        val targetId = lastAutoSubtractedPokemonId ?: currentPokemon.id
        if ((now - lastSubtractedMoveTimestamp) <= 12000L) {
            val curE = slotEnergies[targetId] ?: 0
            slotEnergies[targetId] = (curE + prevSub.energyCost).coerceIn(0, 100)
            val prevCycle = slotCycleIndex[targetId] ?: 0
            slotCycleIndex[targetId] = (prevCycle + 3) % 4
            lastAutoSubtractedMove = null
            lastAutoSubtractedPokemonId = null
            lastSubtractedMoveTimestamp = 0L
            hasSubtractedChargedMoveForCurrentCutscene = false
        }
    }

    private fun reconcileChargedMoveFromBanner(actualMove: ChargedMove) {
        upgradeToSiblingFormIfMoveMatches(actualMove)
        val now = System.currentTimeMillis()
        val prevSub = lastAutoSubtractedMove
        val targetId = currentPokemon.id
        if (hasSubtractedChargedMoveForCurrentCutscene || (prevSub != null && (now - lastSubtractedMoveTimestamp) <= 12000L)) {
            if (prevSub != null && prevSub.name != actualMove.name) {
                val curE = slotEnergies[targetId] ?: 0
                val correctedE = (curE + prevSub.energyCost - actualMove.energyCost).coerceIn(0, 100)
                slotEnergies[targetId] = correctedE
                lastAutoSubtractedMove = actualMove
                lastAutoSubtractedPokemonId = targetId
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            } else {
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            }
        } else if ((now - lastSubtractedMoveTimestamp) > 3500L) {
            subtractChargedMoveAndUpdate(actualMove, currentPokemon.id, isManualTap = false)
        }
    }

    private fun creditOpponentFastMoves(movesToCredit: Int) {
        if (movesToCredit <= 0) return
        val activeFm = getActiveFastMove()
        val gainedE = movesToCredit * activeFm.energyGain
        fastHitsLandedOnCurrentPlayer += movesToCredit
        totalFastMovesInCurrentMatch += movesToCredit
        if (isBattleHudCurrentlyVisible && energyAtCutsceneStart >= 0) {
            postCutsceneFastEnergyEarned += gainedE
        }
        val prevE = slotEnergies[currentPokemon.id] ?: 0
        slotEnergies[currentPokemon.id] = min(100, prevE + gainedE)
        ocrStatusText.text = "⚡ [$OVERLAY_VERSION] +$movesToCredit ${activeFm.name}"
        refreshHudDisplay()
    }

    /**
     * Lunge-Safe & Opening-Safe Fast Move Evaluator (v27):
     * 1. NEVER resets `refPlayerHpFillPx` when your Pokémon's HP bar moves vertically (`hpBarY`),
     *    because in Pokémon GO your Pokémon's HP bar bobs vertically by 15–33px whenever your Pokémon
     *    lunges to attack (e.g. Thievul's HP bar moves between y=532 and y=565).
     * 2. On the very first frame of a new match (`!hasInitializedLeadPlayerHp`), your lead Pokémon starts
     *    at 100% Full HP (`barLen`). If 1–2 fast moves already landed during the "3, 2, 1, GO!" zoom-out
     *    before the top HUD pills finished sliding in (`barLen - hpPx >= 6px`), they are credited immediately!
     * 3. Counts `+1` fast move immediately on any `dropPx >= 2` (or `dropPx == 1` with an orange drain spike)
     *    without requiring a 3-tick delay, while silently absorbing `1px` post-drain anti-aliasing settles.
     */
    private fun evaluatePlayerHpDropForFastMoves(
        barLen: Int,
        hpPx: Int,
        hpBarY: Int,
        hpStage: Int,
        orangeDrainPx: Int,
        now: Long
    ): Boolean {
        if (hpPx <= 0 || hpBarY <= 0) return false

        val prevHpPx = refPlayerHpFillPx
        if (prevHpPx == null) {
            refPlayerHpFillPx = hpPx
            refPlayerHpBarY = hpBarY
            prevOrangeDrainPx = orangeDrainPx
            higherHpConfirmTicks = 0

            // Only on the very first HP lock of the lead Pokémon at the start of a match:
            // The lead Pokémon starts at 100% Full HP (barLen). If fast moves already chipped the bar
            // during the "3, 2, 1, GO!" zoom-out before the top HUD pills finished sliding in, credit them!
            if (!hasInitializedLeadPlayerHp) {
                hasInitializedLeadPlayerHp = true
                if (hpStage == 1 && hpPx >= (barLen * 0.68f).toInt()) {
                    val openingMissingPx = barLen - hpPx
                    val minSingleHitPx = max(5, barLen / 25)
                    if (openingMissingPx >= minSingleHitPx) {
                        val openingMoves = if (openingMissingPx >= minSingleHitPx * 2) 2 else 1
                        lastVisualFastMoveTimestampMs = now
                        creditOpponentFastMoves(openingMoves)
                        return true
                    }
                }
            }
            return false
        }

        // Update Y position without resetting refPlayerHpFillPx so lunging/attacking never drops a count!
        refPlayerHpBarY = hpBarY

        // Upward Re-Lock when switching in a healthier Pokémon
        if (hpPx > prevHpPx + max(4, barLen / 16)) {
            higherHpConfirmTicks++
            if (higherHpConfirmTicks >= 2) {
                refPlayerHpFillPx = hpPx
                prevOrangeDrainPx = orangeDrainPx
                higherHpConfirmTicks = 0
            }
            return false
        } else {
            higherHpConfirmTicks = 0
        }

        val dropPx = prevHpPx - hpPx

        // Ignore massive single-frame drops (>50% of bar) from Charged Move damage
        if (dropPx > (barLen * 0.50f).toInt()) {
            refPlayerHpFillPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            return false
        }

        val activeFm = getActiveFastMove()
        val moveMs = activeFm.turns * 500L
        val settleWindowMs = 420L
        val minDebounceMs = max(360L, min(680L, moveMs - 320L))
        val elapsedSinceLastCount = now - lastVisualFastMoveTimestampMs

        // Follow the orange drain slide to its settled plateau within 420ms of the last count
        if (lastVisualFastMoveTimestampMs > 0L && elapsedSinceLastCount < settleWindowMs) {
            if (dropPx in 1..18) {
                refPlayerHpFillPx = hpPx
            }
            prevOrangeDrainPx = orangeDrainPx
            return false
        }

        if (dropPx <= 0) {
            prevOrangeDrainPx = orangeDrainPx
            return false
        }

        // Absorb 1px post-drain anti-aliasing settles (when dropPx == 1 and orangeDrainPx did not spike from 0)
        if (dropPx == 1 && !(orangeDrainPx >= 2 && prevOrangeDrainPx == 0)) {
            refPlayerHpFillPx = hpPx
            prevOrangeDrainPx = orangeDrainPx
            return false
        }

        val hasValidDrop = (dropPx >= 2) || (dropPx == 1 && orangeDrainPx >= 2 && prevOrangeDrainPx == 0)
        prevOrangeDrainPx = orangeDrainPx

        if (elapsedSinceLastCount >= minDebounceMs && hasValidDrop) {
            refPlayerHpFillPx = hpPx
            lastVisualFastMoveTimestampMs = now
            creditOpponentFastMoves(1)
            return true
        }

        return false
    }

    private fun isPlayerBubbleMinigameText(rawText: String): Boolean {
        val lower = rawText.lowercase()
        return lower.contains("nice!") ||
            lower.contains("great!") ||
            lower.contains("excellent!") ||
            lower.contains("swipe")
    }

    private fun processFrameAndUpdateState(tickMs: Long) {
        val now = System.currentTimeMillis()
        if (isOcrBusy && now - lastOcrStartTimestampMs > 2500L) {
            isOcrBusy = false
        }

        val image = try {
            imageReader?.acquireLatestImage()
        } catch (_: Exception) {
            null
        } ?: return

        val overlayRect = getOverlayRectInImage(image.width, image.height)
        var telemetry = FrameVisualTelemetry(true, false, false, 66, -1, -1, 0, 0, emptySet())
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var aboveHpEffBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        val shouldRunOcrThisTick = !isOcrBusy && (now - lastOcrCompletedTimestampMs >= 300L)

        try {
            telemetry = analyzeFrameVisualTelemetry(image, overlayRect)
            val isWideArenaCombat = telemetry.isBattleHudVisible && telemetry.playerHpFillPx > 0

            if (telemetry.isFrameNonBlack) {
                if (isWideArenaCombat) {
                    if (currentPokemon.fastMoves.size > 1) {
                        arenaVisualBmp = cropRegionFromImage(image, 0.08f, 0.20f, 0.46f, 0.66f, step = 2)
                    }
                    if (shouldRunOcrThisTick) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.095f, step = 1)
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.46f, 0.110f, step = 1)
                        if (postCutsceneBannerTicks > 0) {
                            bannerBmp = cropRegionFromImage(
                                image, 0.06f, 0.16f, 0.92f, 0.40f, step = 1, maskOverlayRect = overlayRect
                            )
                        } else if (telemetry.playerHpBarY > 10 && currentPokemon.fastMoves.size > 1) {
                            val hpYRatio = telemetry.playerHpBarY.toFloat() / image.height
                            val effTop = max(0.11f, hpYRatio - 0.048f)
                            val effBot = max(effTop + 0.02f, hpYRatio - 0.003f)
                            aboveHpEffBmp = cropRegionFromImage(
                                image, 0.03f, effTop, 0.42f, effBot, step = 1, maskOverlayRect = overlayRect
                            )
                        }
                    }
                } else if (shouldRunOcrThisTick) {
                    bannerBmp = if (telemetry.isBattleHudVisible) {
                        cropRegionFromImage(
                            image, 0.06f, 0.16f, 0.92f, 0.44f, step = 1, maskOverlayRect = overlayRect
                        )
                    } else {
                        cropRegionFromImage(
                            image, 0.06f, 0.16f, 0.92f, 0.88f, step = 1, maskOverlayRect = overlayRect
                        )
                    }
                    if (telemetry.isBattleHudVisible) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.095f, step = 1)
                    }
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        if (!telemetry.isFrameNonBlack) {
            return
        }

        if (overlayRoot.visibility != View.VISIBLE) {
            overlayRoot.visibility = View.VISIBLE
        }

        val badgeTypesThisFrame = telemetry.opponentBadgeTypes

        if (telemetry.isBattleHudVisible) {
            if (postCutsceneBannerTicks > 0) {
                postCutsceneBannerTicks--
                if (postCutsceneBannerTicks == 0) {
                    energyAtCutsceneStart = -1
                    postCutsceneFastEnergyEarned = 0
                    hasSubtractedChargedMoveForCurrentCutscene = false
                }
            }

            if (!inActiveMatch) {
                inActiveMatch = true
                resetCurrentMatchState("● [$OVERLAY_VERSION] Battle Active")
            } else if (!isBattleHudCurrentlyVisible && hudCompletelyMissingDurationMs >= 1200L) {
                postCutsceneBannerTicks = 28

                if (playerUsedChargedMoveDuringZoom) {
                    energyAtCutsceneStart = -1
                    postCutsceneFastEnergyEarned = 0
                    hasSubtractedChargedMoveForCurrentCutscene = false
                } else if (
                    chargedAttackDetectedDuringPause ||
                    specificMoveDetectedDuringPause != null ||
                    hasSubtractedChargedMoveForCurrentCutscene
                ) {
                    if (!hasSubtractedChargedMoveForCurrentCutscene) {
                        val curEBeforeSub = if (energyAtCutsceneStart >= 0) {
                            energyAtCutsceneStart
                        } else {
                            slotEnergies[currentPokemon.id] ?: 0
                        }
                        val moveToSub = specificMoveDetectedDuringPause ?: run {
                            currentPokemon.chargedMoves.firstOrNull { curEBeforeSub >= it.energyCost }
                                ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                        }
                        if (moveToSub != null && now - lastSubtractedMoveTimestamp > 3000L) {
                            subtractChargedMoveAndUpdate(moveToSub, currentPokemon.id, isManualTap = false)
                        }
                    }
                }
                // Re-lock HP baseline cleanly on the first Wide-Arena frame after any cutscene
                refPlayerHpFillPx = null
                refPlayerHpBarY = -1
                prevOrangeDrainPx = 0
                higherHpConfirmTicks = 0

                chargedAttackDetectedDuringPause = false
                playerUsedChargedMoveDuringZoom = false
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudCompletelyMissingDurationMs = 0L

            if (telemetry.playerHpFillPx > 0) {
                if (zoomedWithoutHpDurationMs >= 1400L) {
                    refPlayerHpFillPx = null
                    refPlayerHpBarY = -1
                    prevOrangeDrainPx = 0
                    higherHpConfirmTicks = 0
                }
                zoomedWithoutHpDurationMs = 0L

                val justRegisteredHit = evaluatePlayerHpDropForFastMoves(
                    barLen = telemetry.barLenPx,
                    hpPx = telemetry.playerHpFillPx,
                    hpBarY = telemetry.playerHpBarY,
                    hpStage = telemetry.playerHpStage,
                    orangeDrainPx = telemetry.orangeDrainPx,
                    now = now
                )

                if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                    val curActiveIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                    val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                        arenaVisualBmp,
                        currentPokemon,
                        curActiveIdx,
                        latestEffectivenessHint,
                        playerDefenderTypes,
                        fastHitsLandedOnCurrentPlayer,
                        justRegisteredHit
                    )
                    if (detectedFmIdx != null && detectedFmIdx != curActiveIdx) {
                        val oldFm = getActiveFastMove()
                        val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                        slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                        val newFm = getActiveFastMove()
                        if (oldCount > 0) {
                            slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                        }
                        ocrStatusText.text = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                        refreshHudDisplay()
                    }
                }
            } else {
                zoomedWithoutHpDurationMs += tickMs
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        var matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text, badgeTypesThisFrame)
                        if (matchedPoke != null) {
                            val baseKey = matchedPoke.name.substringBefore("(").trim().lowercase()
                            val manualId = manualFormOverrideByBase[baseKey]
                            if (manualId != null) {
                                val manualEntry = PvPokeRepository.getSiblingForms(matchedPoke).firstOrNull { it.id == manualId }
                                if (manualEntry != null) matchedPoke = manualEntry
                            }

                            val isRealPoke = !matchedPoke.id.startsWith("dyn_")
                            // Ignore temporary "dyn_" OCR reads if we already locked onto a real PvPoke species!
                            if (!isRealPoke && hasLockedFirstRealOpponentInMatch) {
                                return@addOnSuccessListener
                            }

                            if (isRealPoke) {
                                seenOpponentPokemon[matchedPoke.id] = matchedPoke
                            }

                            if (!hasLockedFirstRealOpponentInMatch && isRealPoke) {
                                // First real opponent lock in this match!
                                // Transfer ALL opening fast moves counted so far in the match (even if they were
                                // temporarily credited to default Melmetal or a partial sliding-pill "dyn_" entry)!
                                hasLockedFirstRealOpponentInMatch = true
                                if (matchedPoke.id != currentPokemon.id) {
                                    seenOpponentPokemon.remove(currentPokemon.id)
                                    slotEnergies.remove(currentPokemon.id)
                                    if (totalFastMovesInCurrentMatch > 0) {
                                        val leadFm = matchedPoke.fastMoves.first()
                                        slotEnergies[matchedPoke.id] = min(100, totalFastMovesInCurrentMatch * leadFm.energyGain)
                                    }
                                }
                            }

                            if (matchedPoke.id != currentPokemon.id) {
                                val prevBaseKey = currentPokemon.name.substringBefore("(").trim().lowercase()
                                val isSameBaseFormSwap = (prevBaseKey == baseKey) || currentPokemon.id.startsWith("dyn_")
                                if (isSameBaseFormSwap && (slotEnergies[currentPokemon.id] ?: 0) > 0 && (slotEnergies[matchedPoke.id] ?: 0) == 0) {
                                    val oldFm = getActiveFastMove()
                                    val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                                    seenOpponentPokemon.remove(currentPokemon.id)
                                    val newFm = getActiveFastMove(matchedPoke)
                                    slotEnergies[matchedPoke.id] = min(100, oldCount * newFm.energyGain)
                                    slotCycleIndex[matchedPoke.id] = slotCycleIndex[currentPokemon.id] ?: 0
                                    slotEnergies.remove(currentPokemon.id)
                                }
                                currentPokemon = matchedPoke
                                fastHitsLandedOnCurrentPlayer = 0
                                latestEffectivenessHint = null
                                visualClassifier.resetForNewOpponent()
                                val savedE = slotEnergies[matchedPoke.id] ?: 0
                                val savedFm = getActiveFastMove(matchedPoke)
                                val savedFastCnt = floor(savedE.toDouble() / max(1, savedFm.energyGain)).toInt()
                                ocrStatusText.text = if (savedE > 0) {
                                    "🔄 Restored ${matchedPoke.name}: $savedFastCnt Fast (${savedE}E)"
                                } else {
                                    "● Locked: ${matchedPoke.name}"
                                }
                                refreshHudDisplay()
                            } else if (!ocrStatusText.text.startsWith("⚡") && !ocrStatusText.text.startsWith("▼") && !ocrStatusText.text.startsWith("🔄")) {
                                ocrStatusText.text = "● [$OVERLAY_VERSION] Watching ${matchedPoke.name}"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val rawLeft = leftText.text
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(rawLeft)
                                    if (playerPoke != null && !playerPoke.id.startsWith("dyn_") && playerPoke.id != currentPlayerPokemonId) {
                                        currentPlayerPokemonId = playerPoke.id
                                        currentPlayerPokemonName = playerPoke.name
                                        playerDefenderTypes = PvPokeRepository.getDefenderTypes(playerPoke)
                                        fastHitsLandedOnCurrentPlayer = 0
                                        latestEffectivenessHint = null
                                    }
                                }
                                .addOnCompleteListener {
                                    val nextBmp = bannerBmp ?: aboveHpEffBmp
                                    val isBannerCrop = (bannerBmp != null)
                                    if (nextBmp != null) {
                                        recognizer.process(InputImage.fromBitmap(nextBmp, 0))
                                            .addOnSuccessListener { subText ->
                                                val rawS = subText.text
                                                if (!isBannerCrop) {
                                                    val (_, _, effH) = PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    if (effH != null) latestEffectivenessHint = effH
                                                } else if (
                                                    isPlayerBubbleMinigameText(rawS) ||
                                                    PvPokeRepository.isPlayerOwnChargedMoveBanner(rawS, currentPlayerPokemonName, currentPokemon.name)
                                                ) {
                                                    playerUsedChargedMoveDuringZoom = true
                                                    undoFalsePlayerChargedMoveSubtractionIfNeeded()
                                                    ocrStatusText.text = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                                    refreshHudDisplay()
                                                } else {
                                                    val (_, specificMove, _) =
                                                        PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    if (specificMove != null) {
                                                        reconcileChargedMoveFromBanner(specificMove)
                                                        postCutsceneBannerTicks = 0
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                                lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                                isOcrBusy = false
                                            }
                                    } else {
                                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                        isOcrBusy = false
                                    }
                                }
                        } else if (bannerBmp != null) {
                            recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                                .addOnSuccessListener { bText ->
                                    val rawB = bText.text
                                    if (
                                        isPlayerBubbleMinigameText(rawB) ||
                                        PvPokeRepository.isPlayerOwnChargedMoveBanner(rawB, currentPlayerPokemonName, currentPokemon.name)
                                    ) {
                                        playerUsedChargedMoveDuringZoom = true
                                        undoFalsePlayerChargedMoveSubtractionIfNeeded()
                                        ocrStatusText.text = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                        refreshHudDisplay()
                                    } else {
                                        val (_, specificMove, _) =
                                            PvPokeRepository.detectChargedAttackAndEffectiveness(rawB, currentPokemon)
                                        if (specificMove != null) {
                                            reconcileChargedMoveFromBanner(specificMove)
                                            postCutsceneBannerTicks = 0
                                        }
                                    }
                                }
                                .addOnCompleteListener {
                                    lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                    isOcrBusy = false
                                }
                        } else {
                            lastOcrCompletedTimestampMs = System.currentTimeMillis()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            if (isBattleHudCurrentlyVisible) {
                energyAtCutsceneStart = slotEnergies[currentPokemon.id] ?: 0
                postCutsceneFastEnergyEarned = 0
                hasSubtractedChargedMoveForCurrentCutscene = false
            }
            isBattleHudCurrentlyVisible = false
            hudCompletelyMissingDurationMs += tickMs

            if (inActiveMatch && telemetry.isShieldPromptVisible) {
                chargedAttackDetectedDuringPause = true
                if (!ocrStatusText.text.startsWith("▼")) {
                    ocrStatusText.text = "⚠️ Attack Incoming!"
                    refreshHudDisplay()
                }
            }

            if (hudCompletelyMissingDurationMs >= 25000L && inActiveMatch) {
                inActiveMatch = false
                resetCurrentMatchState("● [$OVERLAY_VERSION] Waiting for battle...")
            } else if (inActiveMatch && hudCompletelyMissingDurationMs >= 450L) {
                if (!ocrStatusText.text.startsWith("⚠️") && !ocrStatusText.text.startsWith("🛡️") && !ocrStatusText.text.startsWith("▼")) {
                    ocrStatusText.text = "⏸ [$OVERLAY_VERSION] Paused (Cutscene)"
                    refreshHudDisplay()
                }
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        if (PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetCurrentMatchState("● [$OVERLAY_VERSION] Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            if (
                                isPlayerBubbleMinigameText(rawBanner) ||
                                PvPokeRepository.isPlayerOwnChargedMoveBanner(rawBanner, currentPlayerPokemonName, currentPokemon.name)
                            ) {
                                playerUsedChargedMoveDuringZoom = true
                                undoFalsePlayerChargedMoveSubtractionIfNeeded()
                                ocrStatusText.text = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                refreshHudDisplay()
                            } else {
                                val (isIncoming, specificMove, _) =
                                    PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                                if (specificMove != null) {
                                    upgradeToSiblingFormIfMoveMatches(specificMove)
                                    specificMoveDetectedDuringPause = specificMove
                                    chargedAttackDetectedDuringPause = true
                                    if (!hasSubtractedChargedMoveForCurrentCutscene && now - lastSubtractedMoveTimestamp > 3000L) {
                                        subtractChargedMoveAndUpdate(specificMove, currentPokemon.id, isManualTap = false)
                                    } else {
                                        reconcileChargedMoveFromBanner(specificMove)
                                    }
                                } else if (isIncoming) {
                                    chargedAttackDetectedDuringPause = true
                                    ocrStatusText.text = "⚠️ Attack Incoming!"
                                    refreshHudDisplay()
                                }
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun refreshHudDisplay() {
        val energy = (slotEnergies[currentPokemon.id] ?: 0).coerceIn(0, 100)
        val activeFm = getActiveFastMove()
        val eFast = max(1, activeFm.energyGain)
        val fastCount = floor(energy.toDouble() / eFast).toInt()
        val cycleIdx = slotCycleIndex[currentPokemon.id] ?: 0

        countNumberText.text = fastCount.toString()
        countLabelText.text = "FAST · $OVERLAY_VERSION"

        if (!inActiveMatch) {
            pokemonTitleText.text = "[$OVERLAY_VERSION] Waiting for battle..."
            swapFastMoveBtn.visibility = View.GONE
            chargedBadgesContainer.visibility = View.GONE
            benchEnergyText.visibility = View.GONE
            return
        }

        pokemonTitleText.text = "[$OVERLAY_VERSION] ${currentPokemon.name} · ${activeFm.name} (${eFast}E/${activeFm.turns}T) [${energy}E]"
        val hasMultipleFastOrForms = currentPokemon.fastMoves.size > 1 || PvPokeRepository.getSiblingForms(currentPokemon).size > 1
        swapFastMoveBtn.visibility = if (hasMultipleFastOrForms) View.VISIBLE else View.GONE
        chargedBadgesContainer.visibility = if (manualCollapse) View.GONE else View.VISIBLE

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val paceList = currentPokemon.getPvPokeMoveCounts(activeFm, cm, 4)
            val activePaceTarget = paceList[cycleIdx % paceList.size]
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val afterEnergy = max(0, energy - cm.energyCost)
            val afterFastCount = floor(afterEnergy.toDouble() / eFast).toInt()
            val subtractMovesCount = if (isReady) max(1, fastCount - afterFastCount) else activePaceTarget

            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4094A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val cardLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = badgeBg
                setPadding(12, 5, 12, 5)
                setOnClickListener {
                    subtractChargedMoveAndUpdate(cm, currentPokemon.id, isManualTap = true)
                }
            }

            val topLine = TextView(this).apply {
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xEEFFFFFF.toInt())
                text = if (isReady) {
                    "⚡ ${cm.name} READY (▼-$subtractMovesCount)"
                } else {
                    "${cm.name}: $fastCount/$activePaceTarget (-$neededMoves)"
                }
            }

            val formattedPace = paceList.mapIndexed { idx, v ->
                if (idx == (cycleIdx % paceList.size)) "[$v]" else "$v"
            }.joinToString(" - ")

            val bottomLine = TextView(this).apply {
                textSize = 8.5f
                setSingleLine(true)
                setTextColor(0xBB94A3B8.toInt())
                text = "Fast Move Count: $formattedPace"
            }

            cardLayout.addView(topLine)
            cardLayout.addView(bottomLine)

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 4
            }
            chargedBadgesContainer.addView(cardLayout, lp)
        }

        val benchedSummaries = seenOpponentPokemon.values
            .filter { it.id != currentPokemon.id && (slotEnergies[it.id] ?: 0) > 0 }
            .map { benchPoke ->
                val bEnergy = (slotEnergies[benchPoke.id] ?: 0).coerceIn(0, 100)
                val bFm = getActiveFastMove(benchPoke)
                val bFastCnt = floor(bEnergy.toDouble() / max(1, bFm.energyGain)).toInt()
                "${benchPoke.name}: $bFastCnt Fast (${bEnergy}E)"
            }

        if (benchedSummaries.isNotEmpty() && !manualCollapse) {
            benchEnergyText.text = "📦 Bench: ${benchedSummaries.joinToString(" · ")}"
            benchEnergyText.visibility = View.VISIBLE
        } else {
            benchEnergyText.visibility = View.GONE
        }
    }

    private fun createNotification(): Notification {
        val channelId = "gl_match_calc_v27"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "GL Match Calculator HUD v27",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("GL Match Calc v27")
            .setContentText("Opening-Safe & Lunge-Safe Fast Move HUD Active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
            if (::overlayRoot.isInitialized) {
                windowManager.removeView(overlayRoot)
            }
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    companion object {
        const val OVERLAY_VERSION = "v27"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
