package com.pokecount.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var overlayRoot: LinearLayout
    private lateinit var counterBadgeLayout: LinearLayout
    private lateinit var countNumberText: TextView
    private lateinit var countLabelText: TextView
    private lateinit var pokemonTitleText: TextView
    private lateinit var ocrStatusText: TextView
    private lateinit var swapFastMoveBtn: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var closeOverlayBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout
    private lateinit var benchEnergyText: TextView

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()
    private val mainHandler = Handler(Looper.getMainLooper())

    // Per-Pokemon persistent battle state (remembers energy & move cycle across switches!)
    private val slotEnergies = mutableMapOf<String, Int>()
    private val slotCycleIndex = mutableMapOf<String, Int>()
    private val slotFastMoveIdx = mutableMapOf<String, Int>()
    private val seenOpponentPokemon = linkedMapOf<String, PvPokeEntry>()

    private var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
    private var hasLockedFirstOpponentInMatch = false
    private var unassignedOpeningFastMoves = 0

    private var currentPlayerPokemonId: String? = null
    private var playerDefenderTypes: List<String> = emptyList()
    private var latestEffectivenessHint: String? = null
    private var fastHitsLandedOnCurrentPlayer: Int = 0

    // Battle & Visual HP-Bar state tracking
    private var inActiveMatch = false
    private var isBattleHudCurrentlyVisible = false
    private var hudMissingDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var lastAutoSubtractedMove: ChargedMove? = null
    private var lastAutoSubtractedPokemonId: String? = null
    private var postCutsceneBannerTicks = 0
    private var manualCollapse = false

    // High-Precision 1px Contiguous HP Fill + 1-Turn Multi-Catchup Tracker
    private var refPlayerHpFillPx: Int? = null
    private var higherHpConfirmTicks: Int = 0
    private var lastHpChipTimestampMs: Long = 0L
    private var lastVisualFastMoveTimestampMs: Long = 0L
    private var hudReappearedGraceTicks: Int = 0

    // 32x32 motion grids
    private var prevLowerPlatformGrid: IntArray? = null
    private var prevPlayerWingGrid: IntArray? = null
    private var prevTargetImpactGrid: IntArray? = null

    // OCR concurrency, throttling & watchdog
    private var isOcrBusy = false
    private var lastOcrStartTimestampMs = 0L
    private var lastOcrCompletedTimestampMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x40000000, 0x26000000, 0x73090D16)
    private val borderAlphas = intArrayOf(0x36FFFFFF, 0x20FFFFFF, 0x5094A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    private fun getActiveFastMove(entry: PvPokeEntry = currentPokemon): FastMove {
        val idx = (slotFastMoveIdx[entry.id] ?: 0).coerceIn(0, max(0, entry.fastMoves.size - 1))
        return entry.fastMoves[idx]
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext)
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startVisualAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun createFloatingOverlayHud() {
        val (screenW, screenH) = getScreenDimensions()
        val compactWidth = (screenW * 0.52f).toInt()

        overlayParams = WindowManager.LayoutParams(
            compactWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = (screenH * 0.125f).toInt()
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
        }

        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        counterBadgeLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 5, 14, 5)
            setOnClickListener {
                manualCollapse = !manualCollapse
                refreshHudDisplay()
            }
        }

        countNumberText = TextView(this).apply {
            text = "0"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }

        countLabelText = TextView(this).apply {
            text = "FAST"
            textSize = 8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xCC6EE7B7.toInt())
        }

        counterBadgeLayout.addView(countNumberText)
        counterBadgeLayout.addView(countLabelText)

        val rightHeaderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        pokemonTitleText = TextView(this).apply {
            text = "Waiting for battle..."
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xEEFFFFFF.toInt())
            setOnClickListener {
                resetCurrentMatchState("● Match Reset to 0")
            }
        }

        val microControlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        ocrStatusText = TextView(this).apply {
            text = "● Visual Cue Mode v15"
            textSize = 8.5f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xAA6EE7B7.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        swapFastMoveBtn = TextView(this).apply {
            text = " [⇄Fast] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setOnClickListener {
                if (currentPokemon.fastMoves.size > 1) {
                    val oldFm = getActiveFastMove()
                    val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                    val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                    val nextIdx = (curIdx + 1) % currentPokemon.fastMoves.size
                    slotFastMoveIdx[currentPokemon.id] = nextIdx
                    val newFm = getActiveFastMove()
                    if (oldCount > 0) {
                        slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                    }
                    ocrStatusText.text = "Fast: ${newFm.name}"
                    refreshHudDisplay()
                }
            }
        }

        val minusOneBtn = TextView(this).apply {
            text = "[−]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = max(0, curE - getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        val plusOneBtn = TextView(this).apply {
            text = " [+]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF6EE7B7.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, curE + getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        val recRelinkBtn = TextView(this).apply {
            text = " 🎥"
            textSize = 10f
            setTextColor(0xFFFDE047.toInt())
            setOnClickListener {
                // Re-opens MainActivity to re-link MediaProjection if Samsung Screen Recorder paused capture
                val reIntent = Intent(this@OverlayVisionService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(reIntent)
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = " ◐"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        closeOverlayBtn = TextView(this).apply {
            text = " ✕"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                stopSelf()
            }
        }

        microControlsRow.addView(ocrStatusText)
        microControlsRow.addView(swapFastMoveBtn)
        microControlsRow.addView(minusOneBtn)
        microControlsRow.addView(plusOneBtn)
        microControlsRow.addView(recRelinkBtn)
        microControlsRow.addView(opacityToggleBtn)
        microControlsRow.addView(closeOverlayBtn)

        rightHeaderCol.addView(pokemonTitleText)
        rightHeaderCol.addView(microControlsRow)

        topHeaderRow.addView(counterBadgeLayout)
        topHeaderRow.addView(rightHeaderCol)

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        benchEnergyText = TextView(this).apply {
            textSize = 8.5f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xFFFDE047.toInt())
            setPadding(4, 5, 4, 0)
            visibility = View.GONE
        }

        overlayRoot.addView(topHeaderRow)
        overlayRoot.addView(chargedBadgesContainer)
        overlayRoot.addView(benchEnergyText)

        applyStealthTheme()

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = overlayParams.x
                        initialY = overlayParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        overlayParams.x = initialX - dx
                        overlayParams.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, overlayParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        }

        counterBadgeLayout.setOnTouchListener(dragListener)
        pokemonTitleText.setOnTouchListener(dragListener)

        windowManager.addView(overlayRoot, overlayParams)
        refreshHudDisplay()
    }

    private fun resetCurrentMatchState(statusMsg: String) {
        slotEnergies.clear()
        slotCycleIndex.clear()
        seenOpponentPokemon.clear()
        hasLockedFirstOpponentInMatch = false
        unassignedOpeningFastMoves = 0
        refPlayerHpFillPx = null
        higherHpConfirmTicks = 0
        lastHpChipTimestampMs = 0L
        fastHitsLandedOnCurrentPlayer = 0
        latestEffectivenessHint = null
        prevLowerPlatformGrid = null
        prevPlayerWingGrid = null
        prevTargetImpactGrid = null
        chargedAttackDetectedDuringPause = false
        specificMoveDetectedDuringPause = null
        lastAutoSubtractedMove = null
        lastAutoSubtractedPokemonId = null
        postCutsceneBannerTicks = 0
        ocrStatusText.text = statusMsg
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 22f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        overlayRoot.background = panelBg

        val counterBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f
            setColor(0x44000000)
            setStroke(2, 0x8834D399.toInt())
        }
        counterBadgeLayout.background = counterBg
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()

            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpManager.getMediaProjection(resultCode, data) ?: return
            mediaProjection = mp

            // IMPORTANT FOR SCREEN RECORDING COMPATIBILITY:
            // Do NOT call stopSelf() in onStop()! That way starting Samsung's built-in Screen Recorder
            // never kills the overlay service, and you can tap [🎥] on the overlay to re-link capture if needed.
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    virtualDisplay?.release()
                    imageReader?.close()
                    ocrStatusText.text = "🎥 Tap 🎥 to link w/ Recorder"
                }
            }, mainHandler)

            val (screenW, screenH) = getScreenDimensions()
            // Use 50% capture resolution (e.g. 540x1170) with maxImages=2 so Samsung's hardware
            // DisplayComposer & MediaCodec have plenty of bandwidth for concurrent Screen Recording!
            val capW = max(360, screenW / 2)
            val capH = max(720, screenH / 2)
            val density = max(160, resources.displayMetrics.densityDpi / 2)

            imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mp.createVirtualDisplay(
                "PokeCountCaptureV15",
                capW,
                capH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
            ocrStatusText.text = "● Visual Scanner v15 Ready"
        } catch (e: Exception) {
            ocrStatusText.text = "Err: ${e.javaClass.simpleName}"
        }
    }

    private data class FrameVisualTelemetry(
        val isFrameNonBlack: Boolean,
        val isBattleHudVisible: Boolean,
        val playerHpFillPx: Int,
        val opponentAttackMotionRatio: Float,
        val targetImpactVfxRatio: Float
    )

    /**
     * Performs ultra-fast visual telemetry directly on the ImageReader buffer:
     * 1. Non-black frame check.
     * 2. Top-Left & Top-Right Battle HUD pill detector (Day & Night arenas).
     * 3. 1px-resolution Player HP-Bar Fill Width (playerHpFillPx) across Green, Amber-Yellow, and Red states.
     *    CRITICAL FIX IN V15: Continues measuring playerHpFillPx even when hudPillsVisible == false
     *    (during the "Attack incoming! Use a Protect Shield?" prompt!) so the final fast attack that
     *    triggers a Charged Move (e.g. Azumarill's 7th Bubble or Corviknight's 10th Sand Attack) is NEVER missed!
     */
    private fun analyzeFrameVisualTelemetry(image: Image, checkHpEvenIfHudHidden: Boolean): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(false, false, -1, 0f, 0f)
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.015f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.110f).toInt().coerceIn(y0 + 1, height)

                var maxRowWhiteRatio = 0f
                var redPokeballDots = 0
                var darkTextPixels = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 182 && g >= 192 && b >= 208) {
                                rowWhite++
                            }
                            if (r > 180 && g < 92 && b < 92) {
                                redPokeballDots++
                            }
                            if (r < 110 && g < 110 && b < 120) {
                                darkTextPixels++
                            }
                        }
                        x += max(2, width / 160)
                    }
                    if (rowTotal > 0) {
                        val ratio = rowWhite.toFloat() / rowTotal
                        if (ratio > maxRowWhiteRatio) maxRowWhiteRatio = ratio
                    }
                    y += max(1, height / 700)
                }
                return maxRowWhiteRatio > 0.46f && redPokeballDots >= 3 && darkTextPixels >= 4
            }

            val hudPillsVisible = checkBattlePillSide(0.02f, 0.42f) && checkBattlePillSide(0.58f, 0.98f)
            if (!hudPillsVisible && !checkHpEvenIfHudHidden) {
                return FrameVisualTelemetry(true, false, -1, 0f, 0f)
            }

            // 3. Measure 1px-resolution Player HP Bar Fill Width (x: 5.2%..34.8%, y: 16%..67%)
            val hx0 = (width * 0.052f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.348f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.16f).toInt().coerceIn(0, height - 2)
            val hy1 = (height * 0.67f).toInt().coerceIn(hy0 + 1, height)

            val barW = hx1 - hx0
            val barMinTotal = (barW * 0.78f).toInt()
            val maxStartOffset = (barW * 0.18f).toInt()

            var bestGreenFillPx = -1
            var bestAmberFillPx = -1
            var bestRedFillPx = -1

            var y = hy0
            while (y < hy1) {
                val rowOff = y * rowStride
                var gCnt = 0
                var gFirstX = -1
                var aCnt = 0
                var aFirstX = -1
                var rCnt = 0
                var rFirstX = -1
                var emptyTrackCnt = 0

                var colIdx = 0
                var x = hx0
                while (x < hx1) {
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF

                        if (g > 200 && r < 90 && b in 125..200 && (g - b) >= 42) {
                            gCnt++
                            if (gFirstX < 0) gFirstX = colIdx
                        } else if (r > 210 && g in 125..255 && b < 165 && (r - b) >= 75 && abs(r - g) <= 135) {
                            aCnt++
                            if (aFirstX < 0) aFirstX = colIdx
                        } else if (r > 180 && g in 0..115 && b in 0..115 && (r - g) >= 85 && (r - b) >= 85) {
                            rCnt++
                            if (rFirstX < 0) rFirstX = colIdx
                        } else if (r < 115 && g < 132 && b < 138) {
                            emptyTrackCnt++
                        }
                    }
                    x += 1
                    colIdx++
                }

                if (gCnt >= 8 && gFirstX in 0..maxStartOffset && (gCnt + emptyTrackCnt) >= barMinTotal && gCnt > bestGreenFillPx) {
                    bestGreenFillPx = gCnt
                }
                if (aCnt >= 5 && aFirstX in 0..maxStartOffset && (aCnt + emptyTrackCnt) >= barMinTotal && aCnt > bestAmberFillPx) {
                    bestAmberFillPx = aCnt
                }
                if (rCnt >= 1 && rFirstX in 0..maxStartOffset && (rCnt + emptyTrackCnt) >= barMinTotal && rCnt > bestRedFillPx) {
                    bestRedFillPx = rCnt
                }
                y += 1
            }

            val hpFillPx = when {
                bestGreenFillPx > 0 -> bestGreenFillPx
                bestAmberFillPx > 0 -> bestAmberFillPx
                bestRedFillPx > 0 -> bestRedFillPx
                else -> -1
            }

            if (!hudPillsVisible) {
                return FrameVisualTelemetry(true, false, hpFillPx, 0f, 0f)
            }

            // 4. Sample 32x32 motion grids
            fun sampleMotionRatio(
                leftR: Float,
                topR: Float,
                rightR: Float,
                bottomR: Float,
                prevGrid: IntArray?,
                deltaThreshold: Int
            ): Pair<Float, IntArray> {
                val gridW = 32
                val gridH = 32
                val curr = IntArray(gridW * gridH)
                val sx0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val sx1 = (width * rightR).toInt().coerceIn(sx0 + 1, width)
                val sy0 = (height * topR).toInt().coerceIn(0, height - 2)
                val sy1 = (height * bottomR).toInt().coerceIn(sy0 + 1, height)

                var activeDiffs = 0
                for (gy in 0 until gridH) {
                    val py = sy0 + ((sy1 - sy0) * gy) / gridH
                    val rOff = py * rowStride
                    for (gx in 0 until gridW) {
                        val px = sx0 + ((sx1 - sx0) * gx) / gridW
                        val off = rOff + px * pixelStride
                        var packed = 0
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            packed = (r shl 16) or (g shl 8) or b
                            if (prevGrid != null) {
                                val old = prevGrid[gy * gridW + gx]
                                val or0 = (old shr 16) and 0xFF
                                val og0 = (old shr 8) and 0xFF
                                val ob0 = old and 0xFF
                                val d = abs(r - or0) + abs(g - og0) + abs(b - ob0)
                                if (d > deltaThreshold) activeDiffs++
                            }
                        }
                        curr[gy * gridW + gx] = packed
                    }
                }
                val ratio = if (prevGrid != null) activeDiffs.toFloat() / (gridW * gridH) else 0f
                return Pair(ratio, curr)
            }

            // Opponent Sprite & Platform Zone (x: 52%..84%, y: 18%..58%)
            val (oppMotion, newLowerGrid) = sampleMotionRatio(
                0.52f, 0.18f, 0.84f, 0.58f, prevLowerPlatformGrid, 75
            )
            prevLowerPlatformGrid = newLowerGrid

            // Foreground Hit-Impact VFX Zone on Player Pokémon (x: 10%..44%, y: 24%..64%)
            val (impVfxRatio, newImpGrid) = sampleMotionRatio(
                0.10f, 0.24f, 0.44f, 0.64f, prevTargetImpactGrid, 80
            )
            prevTargetImpactGrid = newImpGrid

            FrameVisualTelemetry(true, true, hpFillPx, oppMotion, impVfxRatio)
        } catch (_: Exception) {
            FrameVisualTelemetry(true, false, -1, 0f, 0f)
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    val offset = rowOffset + x * pixelStride
                    if (offset >= 0 && offset + 3 < bufLimit) {
                        val r = buf.get(offset).toInt() and 0xFF
                        val g = buf.get(offset + 1).toInt() and 0xFF
                        val b = buf.get(offset + 2).toInt() and 0xFF
                        pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }

    private fun startVisualAndOcrLoop() {
        val tickMs = 100L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameAndUpdateState(tickMs)
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun subtractChargedMoveAndUpdate(cm: ChargedMove, targetPokeId: String = currentPokemon.id) {
        val currentE = slotEnergies[targetPokeId] ?: 0
        slotEnergies[targetPokeId] = max(0, currentE - cm.energyCost)
        val prevCycle = slotCycleIndex[targetPokeId] ?: 0
        slotCycleIndex[targetPokeId] = (prevCycle + 1) % 4
        lastSubtractedMoveTimestamp = System.currentTimeMillis()
        lastAutoSubtractedMove = cm
        lastAutoSubtractedPokemonId = targetPokeId
        ocrStatusText.text = "▼ Subtracted ${cm.name}"
        refreshHudDisplay()
    }

    private fun reconcileChargedMoveFromBanner(actualMove: ChargedMove) {
        val now = System.currentTimeMillis()
        val prevSub = lastAutoSubtractedMove
        val targetId = lastAutoSubtractedPokemonId ?: currentPokemon.id
        if (prevSub != null && (now - lastSubtractedMoveTimestamp) <= 6500L) {
            if (prevSub.name != actualMove.name) {
                val curE = slotEnergies[targetId] ?: 0
                val correctedE = (curE + prevSub.energyCost - actualMove.energyCost).coerceIn(0, 100)
                slotEnergies[targetId] = correctedE
                lastAutoSubtractedMove = actualMove
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            } else {
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            }
        } else if ((now - lastSubtractedMoveTimestamp) > 3500L) {
            subtractChargedMoveAndUpdate(actualMove, currentPokemon.id)
        }
    }

    /**
     * Evaluates HP bar drops and 1-turn / multi-turn visual cues to increment Fast Attack counts.
     * Runs both during normal Battle HUD visibility AND during the opening 2.2s of a Shield Prompt
     * ("Attack incoming! Use a Protect Shield?") so the final Fast Attack that triggered the Charged Move
     * (e.g., Azumarill's 7th Bubble or Corviknight's 10th Sand Attack) is NEVER missed!
     */
    private fun evaluatePlayerHpDropForFastMoves(
        hpPx: Int,
        oppMotion: Float,
        impVfx: Float,
        now: Long
    ): Boolean {
        if (hpPx <= 0) return false

        if (hudReappearedGraceTicks > 0) {
            hudReappearedGraceTicks--
            val prev = refPlayerHpFillPx
            refPlayerHpFillPx = if (prev != null) max(prev, hpPx) else hpPx
            higherHpConfirmTicks = 0
            return false
        }

        val prevHpPx = refPlayerHpFillPx
        if (prevHpPx == null) {
            refPlayerHpFillPx = hpPx
            return false
        }

        val dropPx = prevHpPx - hpPx
        val activeFm = getActiveFastMove()
        var justRegisteredHit = false

        if (dropPx >= 1) {
            lastHpChipTimestampMs = now
        }

        if (activeFm.turns == 1) {
            // ---------------------------------------------------------------
            // 1-TURN (0.5s / 500ms) FAST MOVE TRACKER (e.g. Corviknight Sand Attack 4E/1T)
            // ---------------------------------------------------------------
            val elapsedSinceLastCount = now - lastVisualFastMoveTimestampMs
            // Resisted 1-turn moves (like Sand Attack vs Altaria) deal 1 HP (~1px per 0.5s hit).
            val has1PxDrop = dropPx in 1..65
            val isAnimAndImpactActive =
                (oppMotion >= 0.115f && impVfx >= 0.042f) &&
                    ((now - lastHpChipTimestampMs) <= 950L)

            if (elapsedSinceLastCount >= 420L && (has1PxDrop || isAnimAndImpactActive)) {
                // If two 0.5s Sand Attacks accumulated into a >=2px drop over ~0.9s-1.5s, credit +2 moves!
                val movesToCredit = if (dropPx >= 2 && elapsedSinceLastCount in 880L..1600L) 2 else 1
                lastVisualFastMoveTimestampMs = now
                refPlayerHpFillPx = hpPx
                higherHpConfirmTicks = 0
                fastHitsLandedOnCurrentPlayer += movesToCredit
                if (!hasLockedFirstOpponentInMatch) unassignedOpeningFastMoves += movesToCredit
                justRegisteredHit = true

                val prevE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, prevE + movesToCredit * activeFm.energyGain)
                ocrStatusText.text = "⚡ +$movesToCredit ${activeFm.name}"
                refreshHudDisplay()
            }
        } else {
            // ---------------------------------------------------------------
            // 2-TO-5 TURN (1.0s - 2.5s) FAST MOVE TRACKER (e.g. Azumarill Bubble 11E/3T)
            // ---------------------------------------------------------------
            val minDebounceMs = max(420L, activeFm.turns * 500L - 220L)
            if (dropPx in 1..68 && (now - lastVisualFastMoveTimestampMs) >= minDebounceMs) {
                lastVisualFastMoveTimestampMs = now
                refPlayerHpFillPx = hpPx
                higherHpConfirmTicks = 0
                fastHitsLandedOnCurrentPlayer++
                if (!hasLockedFirstOpponentInMatch) unassignedOpeningFastMoves++
                justRegisteredHit = true

                val prevE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, prevE + activeFm.energyGain)
                ocrStatusText.text = "⚡ Hit! +1 ${activeFm.name}"
                refreshHudDisplay()
            }
        }

        // Upward Re-Lock when switching in a healthier Pokémon
        if (hpPx > prevHpPx + 8) {
            higherHpConfirmTicks++
            if (higherHpConfirmTicks >= 2) {
                refPlayerHpFillPx = hpPx
                higherHpConfirmTicks = 0
            }
        } else {
            higherHpConfirmTicks = 0
        }

        return justRegisteredHit
    }

    private fun processFrameAndUpdateState(tickMs: Long) {
        val now = System.currentTimeMillis()
        if (isOcrBusy && now - lastOcrStartTimestampMs > 2500L) {
            isOcrBusy = false
        }

        val image = try {
            imageReader?.acquireLatestImage()
        } catch (_: Exception) {
            null
        }

        if (image == null) {
            // Keep overlay visible so Samsung Screen Recorder never hides the HUD!
            return
        }

        val checkHpDuringShieldPrompt = inActiveMatch && (hudMissingDurationMs <= 2200L)
        var telemetry = FrameVisualTelemetry(true, false, -1, 0f, 0f)
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        val shouldRunOcrThisTick = !isOcrBusy && (now - lastOcrCompletedTimestampMs >= 360L)

        try {
            telemetry = analyzeFrameVisualTelemetry(image, checkHpDuringShieldPrompt)
            if (telemetry.isFrameNonBlack) {
                if (telemetry.isBattleHudVisible) {
                    if (currentPokemon.fastMoves.size > 1) {
                        arenaVisualBmp = cropRegionFromImage(image, 0.08f, 0.20f, 0.46f, 0.66f, step = 2)
                    }
                    if (shouldRunOcrThisTick) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.110f, step = 1)
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.46f, 0.250f, step = 1)
                        if (postCutsceneBannerTicks > 0) {
                            bannerBmp = cropRegionFromImage(image, 0.10f, 0.20f, 0.90f, 0.36f, step = 1)
                        }
                    }
                } else if (shouldRunOcrThisTick) {
                    bannerBmp = cropRegionFromImage(image, 0.08f, 0.18f, 0.92f, 0.90f, step = 2)
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        if (!telemetry.isFrameNonBlack) {
            return
        }

        if (overlayRoot.visibility != View.VISIBLE) {
            overlayRoot.visibility = View.VISIBLE
        }

        if (telemetry.isBattleHudVisible) {
            if (postCutsceneBannerTicks > 0) postCutsceneBannerTicks--

            if (!inActiveMatch) {
                inActiveMatch = true
                resetCurrentMatchState("● Battle Active")
                hudReappearedGraceTicks = 1
            } else if (!isBattleHudCurrentlyVisible && hudMissingDurationMs >= 1600L) {
                // Returned from a Charged Move cutscene -> subtract the Charged Move and re-lock HP bar!
                refPlayerHpFillPx = null
                higherHpConfirmTicks = 0
                hudReappearedGraceTicks = 1
                postCutsceneBannerTicks = 35
                val curEBeforeSub = slotEnergies[currentPokemon.id] ?: 0
                val minMoveCost = currentPokemon.chargedMoves.minOfOrNull { it.energyCost } ?: 35
                val isCutsceneDurationChargedMove = (hudMissingDurationMs in 3200L..11000L && curEBeforeSub >= minMoveCost)
                if (chargedAttackDetectedDuringPause || specificMoveDetectedDuringPause != null || isCutsceneDurationChargedMove) {
                    val moveToSub = specificMoveDetectedDuringPause ?: run {
                        currentPokemon.chargedMoves
                            .filter { curEBeforeSub >= it.energyCost }
                            .maxByOrNull { it.energyCost }
                            ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                    }
                    if (moveToSub != null && now - lastSubtractedMoveTimestamp > 3500L) {
                        subtractChargedMoveAndUpdate(moveToSub, currentPokemon.id)
                    }
                }
                chargedAttackDetectedDuringPause = false
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudMissingDurationMs = 0L

            val justRegisteredHit = evaluatePlayerHpDropForFastMoves(
                telemetry.playerHpFillPx,
                telemetry.opponentAttackMotionRatio,
                telemetry.targetImpactVfxRatio,
                now
            )

            if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                val curActiveIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                    arenaVisualBmp,
                    currentPokemon,
                    curActiveIdx,
                    latestEffectivenessHint,
                    playerDefenderTypes,
                    fastHitsLandedOnCurrentPlayer,
                    justRegisteredHit
                )
                if (detectedFmIdx != null && detectedFmIdx != curActiveIdx) {
                    val oldFm = getActiveFastMove()
                    val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                    slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                    val newFm = getActiveFastMove()
                    if (oldCount > 0) {
                        slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                    }
                    ocrStatusText.text = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                    refreshHudDisplay()
                }
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        val matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text)
                        if (matchedPoke != null) {
                            seenOpponentPokemon[matchedPoke.id] = matchedPoke
                            if (!hasLockedFirstOpponentInMatch) {
                                hasLockedFirstOpponentInMatch = true
                                if (matchedPoke.id != currentPokemon.id && unassignedOpeningFastMoves > 0) {
                                    // Transfer any opening fast attack that landed before the 1st OCR pass finished!
                                    val leadFm = matchedPoke.fastMoves.first()
                                    slotEnergies[matchedPoke.id] = min(100, unassignedOpeningFastMoves * leadFm.energyGain)
                                }
                                unassignedOpeningFastMoves = 0
                            }
                            if (matchedPoke.id != currentPokemon.id) {
                                // Opponent switched Pokémon! Switch active view to matchedPoke and restore its saved energy!
                                currentPokemon = matchedPoke
                                fastHitsLandedOnCurrentPlayer = 0
                                latestEffectivenessHint = null
                                visualClassifier.resetForNewOpponent()
                                val savedE = slotEnergies[matchedPoke.id] ?: 0
                                val savedFm = getActiveFastMove(matchedPoke)
                                val savedFastCnt = floor(savedE.toDouble() / max(1, savedFm.energyGain)).toInt()
                                ocrStatusText.text = if (savedE > 0) {
                                    "🔄 Restored ${matchedPoke.name}: $savedFastCnt Fast (${savedE}E)"
                                } else {
                                    "● Locked: ${matchedPoke.name}"
                                }
                                refreshHudDisplay()
                            } else if (!ocrStatusText.text.startsWith("⚡") && !ocrStatusText.text.startsWith("▼") && !ocrStatusText.text.startsWith("🔄")) {
                                ocrStatusText.text = "● Watching ${matchedPoke.name}"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val rawLeft = leftText.text
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(rawLeft)
                                    if (playerPoke != null && playerPoke.id != currentPlayerPokemonId) {
                                        currentPlayerPokemonId = playerPoke.id
                                        playerDefenderTypes = PvPokeRepository.getDefenderTypes(playerPoke)
                                        fastHitsLandedOnCurrentPlayer = 0
                                        latestEffectivenessHint = null
                                    }
                                    // ONLY read opponent fast-move effectiveness from the LEFT side (above player's Pokémon)!
                                    val (_, _, effHint) = PvPokeRepository.detectChargedAttackAndEffectiveness(rawLeft, currentPokemon)
                                    if (effHint != null) {
                                        latestEffectivenessHint = effHint
                                    }
                                }
                                .addOnCompleteListener {
                                    if (bannerBmp != null) {
                                        recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                                            .addOnSuccessListener { bText ->
                                                val (_, specificMove, _) =
                                                    PvPokeRepository.detectChargedAttackAndEffectiveness(bText.text, currentPokemon)
                                                if (specificMove != null) {
                                                    reconcileChargedMoveFromBanner(specificMove)
                                                    postCutsceneBannerTicks = 0
                                                }
                                            }
                                            .addOnCompleteListener {
                                                lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                                isOcrBusy = false
                                            }
                                    } else {
                                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                        isOcrBusy = false
                                    }
                                }
                        } else {
                            lastOcrCompletedTimestampMs = System.currentTimeMillis()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            // Battle HUD pills are hidden (Shield Prompt, Charged Move cutscene, or Post-Match Menu)
            isBattleHudCurrentlyVisible = false
            hudMissingDurationMs += tickMs

            // CRITICAL FIX: During the first 2.2s of the Shield Prompt ("Attack incoming! Use a Protect Shield?"),
            // the Player's HP bar is STILL visible on screen and finishing the drop from the final fast attack!
            if (inActiveMatch && hudMissingDurationMs <= 2200L && telemetry.playerHpFillPx > 0) {
                evaluatePlayerHpDropForFastMoves(
                    telemetry.playerHpFillPx,
                    0f,
                    0f,
                    now
                )
            }

            if (hudMissingDurationMs >= 25000L && inActiveMatch) {
                inActiveMatch = false
                resetCurrentMatchState("● Waiting for battle...")
            } else if (inActiveMatch && hudMissingDurationMs >= 450L) {
                ocrStatusText.text = "⏸ Paused (Cutscene)"
                refreshHudDisplay()
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        if (PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetCurrentMatchState("● Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            // Do NOT overwrite latestEffectivenessHint from full-screen bannerBmp (could be player's own attack!)
                            val (isIncoming, specificMove, _) =
                                PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                            if (specificMove != null) {
                                specificMoveDetectedDuringPause = specificMove
                                chargedAttackDetectedDuringPause = true
                                ocrStatusText.text = "⚠️ Used ${specificMove.name}!"
                            } else if (isIncoming) {
                                chargedAttackDetectedDuringPause = true
                                ocrStatusText.text = "⚠️ Attack Incoming!"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun refreshHudDisplay() {
        val energy = (slotEnergies[currentPokemon.id] ?: 0).coerceIn(0, 100)
        val activeFm = getActiveFastMove()
        val eFast = max(1, activeFm.energyGain)
        val fastCount = floor(energy.toDouble() / eFast).toInt()
        val cycleIdx = slotCycleIndex[currentPokemon.id] ?: 0

        countNumberText.text = fastCount.toString()

        if (!inActiveMatch) {
            pokemonTitleText.text = "Waiting for battle..."
            swapFastMoveBtn.visibility = View.GONE
            chargedBadgesContainer.visibility = View.GONE
            benchEnergyText.visibility = View.GONE
            return
        }

        pokemonTitleText.text = "${currentPokemon.name} · ${activeFm.name} (${eFast}E/${activeFm.turns}T) [${energy}E]"
        swapFastMoveBtn.visibility = if (currentPokemon.fastMoves.size > 1) View.VISIBLE else View.GONE
        chargedBadgesContainer.visibility = if (manualCollapse) View.GONE else View.VISIBLE

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val paceList = currentPokemon.getPvPokeMoveCounts(activeFm, cm, 4)
            val activePaceTarget = paceList[cycleIdx % paceList.size]
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val afterEnergy = max(0, energy - cm.energyCost)
            val afterFastCount = floor(afterEnergy.toDouble() / eFast).toInt()
            val subtractMovesCount = if (isReady) max(1, fastCount - afterFastCount) else activePaceTarget

            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4094A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val cardLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = badgeBg
                setPadding(12, 5, 12, 5)
                setOnClickListener {
                    subtractChargedMoveAndUpdate(cm, currentPokemon.id)
                }
            }

            val topLine = TextView(this).apply {
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xEEFFFFFF.toInt())
                text = if (isReady) {
                    "⚡ ${cm.name} READY (▼-$subtractMovesCount)"
                } else {
                    "${cm.name}: $fastCount/$activePaceTarget (-$neededMoves)"
                }
            }

            val formattedPace = paceList.mapIndexed { idx, v ->
                if (idx == (cycleIdx % paceList.size)) "[$v]" else "$v"
            }.joinToString(" - ")

            val bottomLine = TextView(this).apply {
                textSize = 8.5f
                setSingleLine(true)
                setTextColor(0xBB94A3B8.toInt())
                text = "Fast Move Count: $formattedPace"
            }

            cardLayout.addView(topLine)
            cardLayout.addView(bottomLine)

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 5
            }
            chargedBadgesContainer.addView(cardLayout, lp)
        }

        // Show stored Bench Energy for any switched-out opponent Pokémon!
        val benchedSummaries = seenOpponentPokemon.values
            .filter { it.id != currentPokemon.id && (slotEnergies[it.id] ?: 0) > 0 }
            .map { benchPoke ->
                val bE = (slotEnergies[benchPoke.id] ?: 0).coerceIn(0, 100)
                val bFm = getActiveFastMove(benchPoke)
                val bCnt = floor(bE.toDouble() / max(1, bFm.energyGain)).toInt()
                "${benchPoke.name}: $bCnt Fast (${bE}E)"
            }

        if (benchedSummaries.isNotEmpty() && !manualCollapse) {
            benchEnergyText.text = "💾 Bench: ${benchedSummaries.joinToString(" · ")}"
            benchEnergyText.visibility = View.VISIBLE
        } else {
            benchEnergyText.visibility = View.GONE
        }
    }

    private fun createNotification(): Notification {
        val channelId = "pokecount_overlay_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "PokéCount PvPoke GL Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("PokéCount PvPoke v15 Active")
            .setContentText("100E Cap · Bench Energy Memory · Screen Recorder Compatible")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (overlayInitialized && ::overlayRoot.isInitialized) {
            windowManager.removeView(overlayRoot)
        }
    }

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
