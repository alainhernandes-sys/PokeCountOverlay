package com.pokecount.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var overlayRoot: LinearLayout
    private lateinit var counterBadgeLayout: LinearLayout
    private lateinit var countNumberText: TextView
    private lateinit var countLabelText: TextView
    private lateinit var pokemonTitleText: TextView
    private lateinit var ocrStatusText: TextView
    private lateinit var swapFastMoveBtn: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var closeOverlayBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val slotEnergies = mutableMapOf<String, Int>()
    private val slotCycleIndex = mutableMapOf<String, Int>()
    private val slotFastMoveIdx = mutableMapOf<String, Int>()

    private var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
    private var currentPlayerPokemonId: String? = null
    private var playerDefenderTypes: List<String> = emptyList()
    private var latestEffectivenessHint: String? = null
    private var fastHitsLandedOnCurrentPlayer: Int = 0

    // Battle & Visual HP-Bar state tracking
    private var inActiveMatch = false
    private var isBattleHudCurrentlyVisible = false
    private var hudMissingDurationMs = 0L
    private var noFrameDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var lastAutoSubtractedMove: ChargedMove? = null
    private var postCutsceneBannerTicks = 0
    private var manualCollapse = false

    // High-Precision 1px Contiguous HP Fill + Obstruction-Proof Tracker
    private var refPlayerHpFillPx: Int? = null
    private var higherHpConfirmTicks: Int = 0
    private var lastHpChipTimestampMs: Long = 0L
    private var lastVisualFastMoveTimestampMs: Long = 0L
    private var hudReappearedGraceTicks: Int = 0

    // 32x32 motion grids for Player Target Impact VFX (foreground on your Pokémon) and Lower Opponent Platform
    private var prevLowerPlatformGrid: IntArray? = null
    private var prevPlayerWingGrid: IntArray? = null
    private var prevTargetImpactGrid: IntArray? = null

    // OCR concurrency, throttling & watchdog
    private var isOcrBusy = false
    private var lastOcrStartTimestampMs = 0L
    private var lastOcrCompletedTimestampMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x40000000, 0x26000000, 0x73090D16)
    private val borderAlphas = intArrayOf(0x36FFFFFF, 0x20FFFFFF, 0x5094A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    private fun getActiveFastMove(): FastMove {
        val idx = (slotFastMoveIdx[currentPokemon.id] ?: 0).coerceIn(0, max(0, currentPokemon.fastMoves.size - 1))
        return currentPokemon.fastMoves[idx]
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext)
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startVisualAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun createFloatingOverlayHud() {
        val (screenW, screenH) = getScreenDimensions()
        val compactWidth = (screenW * 0.50f).toInt()

        overlayParams = WindowManager.LayoutParams(
            compactWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = (screenH * 0.125f).toInt()
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
        }

        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        counterBadgeLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 5, 14, 5)
            setOnClickListener {
                manualCollapse = !manualCollapse
                refreshHudDisplay()
            }
        }

        countNumberText = TextView(this).apply {
            text = "0"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }

        countLabelText = TextView(this).apply {
            text = "FAST"
            textSize = 8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xCC6EE7B7.toInt())
        }

        counterBadgeLayout.addView(countNumberText)
        counterBadgeLayout.addView(countLabelText)

        val rightHeaderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        pokemonTitleText = TextView(this).apply {
            text = "Waiting for battle..."
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xEEFFFFFF.toInt())
            setOnClickListener {
                resetCurrentMatchState("● Reset to 0")
            }
        }

        val microControlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        ocrStatusText = TextView(this).apply {
            text = "● Visual Cue Mode v13"
            textSize = 8.5f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xAA6EE7B7.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        swapFastMoveBtn = TextView(this).apply {
            text = " [⇄Fast] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setOnClickListener {
                if (currentPokemon.fastMoves.size > 1) {
                    val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                    val nextIdx = (curIdx + 1) % currentPokemon.fastMoves.size
                    slotFastMoveIdx[currentPokemon.id] = nextIdx
                    ocrStatusText.text = "Fast: ${getActiveFastMove().name}"
                    refreshHudDisplay()
                }
            }
        }

        val minusOneBtn = TextView(this).apply {
            text = "[−]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = max(0, curE - getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        val plusOneBtn = TextView(this).apply {
            text = " [+]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF6EE7B7.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, curE + getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = " ◐"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        closeOverlayBtn = TextView(this).apply {
            text = " ✕"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                stopSelf()
            }
        }

        microControlsRow.addView(ocrStatusText)
        microControlsRow.addView(swapFastMoveBtn)
        microControlsRow.addView(minusOneBtn)
        microControlsRow.addView(plusOneBtn)
        microControlsRow.addView(opacityToggleBtn)
        microControlsRow.addView(closeOverlayBtn)

        rightHeaderCol.addView(pokemonTitleText)
        rightHeaderCol.addView(microControlsRow)

        topHeaderRow.addView(counterBadgeLayout)
        topHeaderRow.addView(rightHeaderCol)

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        overlayRoot.addView(topHeaderRow)
        overlayRoot.addView(chargedBadgesContainer)

        applyStealthTheme()

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = overlayParams.x
                        initialY = overlayParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        overlayParams.x = initialX - dx
                        overlayParams.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, overlayParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        }

        counterBadgeLayout.setOnTouchListener(dragListener)
        pokemonTitleText.setOnTouchListener(dragListener)

        windowManager.addView(overlayRoot, overlayParams)
        refreshHudDisplay()
    }

    private fun resetCurrentMatchState(statusMsg: String) {
        slotEnergies.clear()
        slotCycleIndex.clear()
        refPlayerHpFillPx = null
        higherHpConfirmTicks = 0
        lastHpChipTimestampMs = 0L
        fastHitsLandedOnCurrentPlayer = 0
        latestEffectivenessHint = null
        prevLowerPlatformGrid = null
        prevPlayerWingGrid = null
        prevTargetImpactGrid = null
        chargedAttackDetectedDuringPause = false
        specificMoveDetectedDuringPause = null
        lastAutoSubtractedMove = null
        postCutsceneBannerTicks = 0
        ocrStatusText.text = statusMsg
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 22f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        overlayRoot.background = panelBg

        val counterBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f
            setColor(0x44000000)
            setStroke(2, 0x8834D399.toInt())
        }
        counterBadgeLayout.background = counterBg
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()

            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpManager.getMediaProjection(resultCode, data) ?: return
            mediaProjection = mp

            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    virtualDisplay?.release()
                    imageReader?.close()
                    stopSelf()
                }
            }, mainHandler)

            val (screenW, screenH) = getScreenDimensions()
            val density = resources.displayMetrics.densityDpi

            imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3)
            virtualDisplay = mp.createVirtualDisplay(
                "PokeCountCaptureV13",
                screenW,
                screenH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
            ocrStatusText.text = "● Visual Scanner v13 Ready"
        } catch (e: Exception) {
            ocrStatusText.text = "Err: ${e.javaClass.simpleName}"
        }
    }

    private data class FrameVisualTelemetry(
        val isFrameNonBlack: Boolean,
        val isBattleHudVisible: Boolean,
        val playerHpFillPx: Int,
        val opponentAttackMotionRatio: Float,
        val targetImpactVfxRatio: Float
    )

    /**
     * Performs ultra-fast (< 1.8ms) visual telemetry directly on the ImageReader buffer:
     * 1. Non-black frame check (hides overlay if user leaves Pokémon GO).
     * 2. Top-Left & Top-Right Battle HUD pill detector (Day & Night arenas).
     * 3. 1px-resolution Player HP-Bar Fill Width (playerHpFillPx) across:
     *    - Stage 1 Green ([44, 242, 164])
     *    - Stage 2 Amber-Orange / Yellow ([255, 151, 4] and [254, 255, 129])
     *    - Stage 3 Red ([245, 80, 75])
     *    paired with the Alpha-Darkened Empty Track (R < 115, G < 132, B < 138) and Left-Edge Start lock
     *    (firstX <= 18% of bar width), making it 100% immune to Altaria's wings flapping up and down!
     * 4. Foreground Impact VFX on Player Pokémon (x: 10%..44%, y: 24%..64%) + Lower Opponent Platform motion.
     */
    private fun analyzeFrameVisualTelemetry(image: Image): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(false, false, -1, 0f, 0f)
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.015f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.110f).toInt().coerceIn(y0 + 1, height)

                var maxRowWhiteRatio = 0f
                var redPokeballDots = 0
                var darkTextPixels = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 182 && g >= 192 && b >= 208) {
                                rowWhite++
                            }
                            if (r > 180 && g < 92 && b < 92) {
                                redPokeballDots++
                            }
                            if (r < 110 && g < 110 && b < 120) {
                                darkTextPixels++
                            }
                        }
                        x += 6
                    }
                    if (rowTotal > 0) {
                        val ratio = rowWhite.toFloat() / rowTotal
                        if (ratio > maxRowWhiteRatio) maxRowWhiteRatio = ratio
                    }
                    y += 3
                }
                return maxRowWhiteRatio > 0.48f && redPokeballDots >= 4 && darkTextPixels >= 6
            }

            val hudPillsVisible = checkBattlePillSide(0.02f, 0.42f) && checkBattlePillSide(0.58f, 0.98f)
            if (!hudPillsVisible) {
                return FrameVisualTelemetry(true, false, -1, 0f, 0f)
            }

            // 3. Measure 1px-resolution Player HP Bar Fill Width (x: 5.2%..34.8%, y: 16%..67%)
            val hx0 = (width * 0.052f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.348f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.16f).toInt().coerceIn(0, height - 2)
            val hy1 = (height * 0.67f).toInt().coerceIn(hy0 + 1, height)

            val barW = hx1 - hx0
            val barMinTotal = (barW * 0.78f).toInt()
            val maxStartOffset = (barW * 0.18f).toInt()

            var bestGreenFillPx = -1
            var bestAmberFillPx = -1
            var bestRedFillPx = -1

            var y = hy0
            while (y < hy1) {
                val rowOff = y * rowStride
                var gCnt = 0
                var gFirstX = -1
                var aCnt = 0
                var aFirstX = -1
                var rCnt = 0
                var rFirstX = -1
                var emptyTrackCnt = 0

                var colIdx = 0
                var x = hx0
                while (x < hx1) {
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF

                        if (g > 200 && r < 90 && b in 125..200 && (g - b) >= 42) {
                            // Stage 1: Green HP fill ([26..58, 238..255, 174..192])
                            gCnt++
                            if (gFirstX < 0) gFirstX = colIdx
                        } else if (r > 210 && g in 125..255 && b < 165 && (r - b) >= 75 && abs(r - g) <= 135) {
                            // Stage 2: Amber-Orange ([253, 151, 4]) & Yellow ([254, 255, 129]) HP fill (20%-50% HP)
                            aCnt++
                            if (aFirstX < 0) aFirstX = colIdx
                        } else if (r > 190 && g in 25..110 && b in 25..110 && (r - g) >= 90) {
                            // Stage 3: Red HP fill (< 20% HP)
                            rCnt++
                            if (rFirstX < 0) rFirstX = colIdx
                        } else if (r < 115 && g < 132 && b < 138) {
                            // Alpha-darkened empty HP bar track (works over night ground, daytime grass, and sky/Altaria feathers)
                            emptyTrackCnt++
                        }
                    }
                    x += 1
                    colIdx++
                }

                if (gCnt >= 10 && gFirstX in 0..maxStartOffset && (gCnt + emptyTrackCnt) >= barMinTotal && gCnt > bestGreenFillPx) {
                    bestGreenFillPx = gCnt
                }
                if (aCnt >= 6 && aFirstX in 0..maxStartOffset && (aCnt + emptyTrackCnt) >= barMinTotal && aCnt > bestAmberFillPx) {
                    bestAmberFillPx = aCnt
                }
                if (rCnt >= 3 && rFirstX in 0..maxStartOffset && (rCnt + emptyTrackCnt) >= barMinTotal && rCnt > bestRedFillPx) {
                    bestRedFillPx = rCnt
                }
                y += 2
            }

            val hpFillPx = when {
                bestGreenFillPx > 0 -> bestGreenFillPx
                bestAmberFillPx > 0 -> bestAmberFillPx
                bestRedFillPx > 0 -> bestRedFillPx
                else -> -1
            }

            // 4. Sample 32x32 motion grids
            fun sampleMotionRatio(
                leftR: Float,
                topR: Float,
                rightR: Float,
                bottomR: Float,
                prevGrid: IntArray?,
                deltaThreshold: Int
            ): Pair<Float, IntArray> {
                val gridW = 32
                val gridH = 32
                val curr = IntArray(gridW * gridH)
                val sx0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val sx1 = (width * rightR).toInt().coerceIn(sx0 + 1, width)
                val sy0 = (height * topR).toInt().coerceIn(0, height - 2)
                val sy1 = (height * bottomR).toInt().coerceIn(sy0 + 1, height)

                var activeDiffs = 0
                for (gy in 0 until gridH) {
                    val py = sy0 + ((sy1 - sy0) * gy) / gridH
                    val rOff = py * rowStride
                    for (gx in 0 until gridW) {
                        val px = sx0 + ((sx1 - sx0) * gx) / gridW
                        val off = rOff + px * pixelStride
                        var packed = 0
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            packed = (r shl 16) or (g shl 8) or b
                            if (prevGrid != null) {
                                val old = prevGrid[gy * gridW + gx]
                                val or0 = (old shr 16) and 0xFF
                                val og0 = (old shr 8) and 0xFF
                                val ob0 = old and 0xFF
                                val d = abs(r - or0) + abs(g - og0) + abs(b - ob0)
                                if (d > deltaThreshold) activeDiffs++
                            }
                        }
                        curr[gy * gridW + gx] = packed
                    }
                }
                val ratio = if (prevGrid != null) activeDiffs.toFloat() / (gridW * gridH) else 0f
                return Pair(ratio, curr)
            }

            // Lower Opponent Platform Zone (x: 54%..78%, y: 47%..59%)
            val (lowerPlatMotion, newLowerGrid) = sampleMotionRatio(
                0.54f, 0.47f, 0.78f, 0.59f, prevLowerPlatformGrid, 75
            )
            prevLowerPlatformGrid = newLowerGrid

            // Player Wing Zone (x: 6%..34%, y: 24%..46%) - cancels self-wing flapping
            val (playerWingMotion, newWingGrid) = sampleMotionRatio(
                0.06f, 0.24f, 0.34f, 0.46f, prevPlayerWingGrid, 75
            )
            prevPlayerWingGrid = newWingGrid

            // Foreground Hit-Impact VFX Zone on Player Pokémon (x: 10%..44%, y: 24%..64%)
            val (impVfxRatio, newImpGrid) = sampleMotionRatio(
                0.10f, 0.24f, 0.44f, 0.64f, prevTargetImpactGrid, 85
            )
            prevTargetImpactGrid = newImpGrid

            val cleanOpponentMotion = if (playerWingMotion >= lowerPlatMotion * 0.85f) {
                0f
            } else {
                lowerPlatMotion
            }

            FrameVisualTelemetry(true, true, hpFillPx, cleanOpponentMotion, impVfxRatio)
        } catch (_: Exception) {
            FrameVisualTelemetry(true, false, -1, 0f, 0f)
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    val offset = rowOffset + x * pixelStride
                    if (offset >= 0 && offset + 3 < bufLimit) {
                        val r = buf.get(offset).toInt() and 0xFF
                        val g = buf.get(offset + 1).toInt() and 0xFF
                        val b = buf.get(offset + 2).toInt() and 0xFF
                        pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }

    private fun startVisualAndOcrLoop() {
        val tickMs = 100L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameAndUpdateState(tickMs)
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun subtractChargedMoveAndUpdate(cm: ChargedMove) {
        val currentE = slotEnergies[currentPokemon.id] ?: 0
        slotEnergies[currentPokemon.id] = max(0, currentE - cm.energyCost)
        val prevCycle = slotCycleIndex[currentPokemon.id] ?: 0
        slotCycleIndex[currentPokemon.id] = (prevCycle + 1) % 4
        lastSubtractedMoveTimestamp = System.currentTimeMillis()
        lastAutoSubtractedMove = cm
        ocrStatusText.text = "▼ Subtracted ${cm.name}"
        refreshHudDisplay()
    }

    private fun reconcileChargedMoveFromBanner(actualMove: ChargedMove) {
        val now = System.currentTimeMillis()
        val prevSub = lastAutoSubtractedMove
        if (prevSub != null && (now - lastSubtractedMoveTimestamp) <= 6000L) {
            if (prevSub.name != actualMove.name) {
                // Refund the guessed move cost and subtract the actual move read from "Combusken used Rock Slide!"
                val curE = slotEnergies[currentPokemon.id] ?: 0
                val correctedE = (curE + prevSub.energyCost - actualMove.energyCost).coerceIn(0, 100)
                slotEnergies[currentPokemon.id] = correctedE
                lastAutoSubtractedMove = actualMove
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            } else {
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            }
        } else if ((now - lastSubtractedMoveTimestamp) > 3500L) {
            subtractChargedMoveAndUpdate(actualMove)
        }
    }

    private fun processFrameAndUpdateState(tickMs: Long) {
        val now = System.currentTimeMillis()
        if (isOcrBusy && now - lastOcrStartTimestampMs > 2500L) {
            isOcrBusy = false
        }

        val image = try {
            imageReader?.acquireLatestImage()
        } catch (_: Exception) {
            null
        }

        if (image == null) {
            noFrameDurationMs += tickMs
            if (noFrameDurationMs >= 1500L && overlayRoot.visibility == View.VISIBLE) {
                overlayRoot.visibility = View.GONE
            }
            return
        }

        noFrameDurationMs = 0L

        var telemetry = FrameVisualTelemetry(true, false, -1, 0f, 0f)
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        val shouldRunOcrThisTick = !isOcrBusy && (now - lastOcrCompletedTimestampMs >= 380L)

        try {
            telemetry = analyzeFrameVisualTelemetry(image)
            if (telemetry.isFrameNonBlack) {
                if (telemetry.isBattleHudVisible) {
                    if (currentPokemon.fastMoves.size > 1) {
                        // Crop the Foreground Impact Zone on the Player's Pokémon (x: 8%..46%, y: 20%..66%)
                        // where fast-move hit particles (Peck vs Ember) render in front of Altaria's wings!
                        arenaVisualBmp = cropRegionFromImage(image, 0.08f, 0.20f, 0.46f, 0.66f, step = 3)
                    }
                    if (shouldRunOcrThisTick) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.110f, step = 1)
                        // Extend topLeftBmp down to y=25% so it reads BOTH the player's Pokémon name (Altaria)
                        // AND any "Super effective!" / "Not very effective..." banner right below the top-left pill!
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.48f, 0.250f, step = 2)
                        if (postCutsceneBannerTicks > 0) {
                            // Also read "Combusken used Rock Slide!" banner (y: 20%..36%) right after a cutscene!
                            bannerBmp = cropRegionFromImage(image, 0.10f, 0.20f, 0.90f, 0.36f, step = 2)
                        }
                    }
                } else if (shouldRunOcrThisTick) {
                    bannerBmp = cropRegionFromImage(image, 0.08f, 0.18f, 0.92f, 0.90f, step = 2)
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        if (!telemetry.isFrameNonBlack) {
            if (overlayRoot.visibility == View.VISIBLE) {
                overlayRoot.visibility = View.GONE
            }
            return
        }

        if (overlayRoot.visibility != View.VISIBLE) {
            overlayRoot.visibility = View.VISIBLE
        }

        if (telemetry.isBattleHudVisible) {
            if (postCutsceneBannerTicks > 0) postCutsceneBannerTicks--

            if (!inActiveMatch) {
                inActiveMatch = true
                resetCurrentMatchState("● Battle Active")
                hudReappearedGraceTicks = 3
            } else if (!isBattleHudCurrentlyVisible && hudMissingDurationMs >= 1600L) {
                // Returned from a Charged Move cutscene -> subtract the Charged Move, re-lock HP bar,
                // and keep scanning the center banner for 3.5s in case "Combusken used Rock Slide!" is still on screen!
                refPlayerHpFillPx = null
                higherHpConfirmTicks = 0
                hudReappearedGraceTicks = 4
                postCutsceneBannerTicks = 35
                if (chargedAttackDetectedDuringPause || specificMoveDetectedDuringPause != null) {
                    val moveToSub = specificMoveDetectedDuringPause ?: run {
                        val curE = slotEnergies[currentPokemon.id] ?: 0
                        currentPokemon.chargedMoves
                            .filter { curE >= it.energyCost }
                            .maxByOrNull { it.energyCost }
                            ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                    }
                    if (moveToSub != null && now - lastSubtractedMoveTimestamp > 3500L) {
                        subtractChargedMoveAndUpdate(moveToSub)
                    }
                }
                chargedAttackDetectedDuringPause = false
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudMissingDurationMs = 0L

            // =========================================================================
            // OBSTRUCTION-PROOF 3-STAGE HP BAR + 1-TURN VISUAL FAST ATTACK COUNTER (v13)
            // =========================================================================
            val hpPx = telemetry.playerHpFillPx
            val oppMotion = telemetry.opponentAttackMotionRatio
            val impVfx = telemetry.targetImpactVfxRatio
            var justRegisteredHit = false

            if (hpPx > 0) {
                if (hudReappearedGraceTicks > 0) {
                    hudReappearedGraceTicks--
                    refPlayerHpFillPx = hpPx
                    higherHpConfirmTicks = 0
                } else {
                    val prevHpPx = refPlayerHpFillPx
                    if (prevHpPx == null) {
                        refPlayerHpFillPx = hpPx
                    } else {
                        val dropPx = prevHpPx - hpPx
                        val activeFm = getActiveFastMove()

                        if (dropPx >= 1) {
                            lastHpChipTimestampMs = now
                        }

                        if (activeFm.turns == 1) {
                            val elapsedSinceLastCount = now - lastVisualFastMoveTimestampMs
                            val isContinuousHpDrain = dropPx in 2..65
                            val isAnimationAndImpactActive =
                                (oppMotion >= 0.125f && impVfx >= 0.045f) &&
                                    (dropPx >= 1 || (now - lastHpChipTimestampMs) <= 850L)

                            if (elapsedSinceLastCount >= 460L && (isContinuousHpDrain || isAnimationAndImpactActive)) {
                                lastVisualFastMoveTimestampMs = now
                                refPlayerHpFillPx = hpPx
                                higherHpConfirmTicks = 0
                                fastHitsLandedOnCurrentPlayer++
                                justRegisteredHit = true
                                val prevE = slotEnergies[currentPokemon.id] ?: 0
                                slotEnergies[currentPokemon.id] = min(100, prevE + activeFm.energyGain)
                                ocrStatusText.text = if (isContinuousHpDrain) {
                                    "⚡ 1T Drain: +1 ${activeFm.name}"
                                } else {
                                    "⚡ 1T Anim: +1 ${activeFm.name}"
                                }
                                refreshHudDisplay()
                            }
                        } else {
                            // 2-to-5 Turn Fast Move Tracker (e.g. Peck 2T / Ember 2T)
                            val minDebounceMs = max(420L, activeFm.turns * 500L - 180L)
                            if (dropPx in 2..68 && (now - lastVisualFastMoveTimestampMs) >= minDebounceMs) {
                                lastVisualFastMoveTimestampMs = now
                                refPlayerHpFillPx = hpPx
                                higherHpConfirmTicks = 0
                                fastHitsLandedOnCurrentPlayer++
                                justRegisteredHit = true
                                val prevE = slotEnergies[currentPokemon.id] ?: 0
                                slotEnergies[currentPokemon.id] = min(100, prevE + activeFm.energyGain)
                                ocrStatusText.text = "⚡ Hit! +1 ${activeFm.name}"
                                refreshHudDisplay()
                            }
                        }

                        if (hpPx > prevHpPx + 16) {
                            higherHpConfirmTicks++
                            if (higherHpConfirmTicks >= 4) {
                                refPlayerHpFillPx = hpPx
                                higherHpConfirmTicks = 0
                            }
                        } else {
                            higherHpConfirmTicks = 0
                        }
                    }
                }
            }

            if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                    arenaVisualBmp,
                    currentPokemon,
                    latestEffectivenessHint,
                    playerDefenderTypes,
                    fastHitsLandedOnCurrentPlayer,
                    justRegisteredHit
                )
                if (detectedFmIdx != null && detectedFmIdx != (slotFastMoveIdx[currentPokemon.id] ?: 0)) {
                    val oldFm = getActiveFastMove()
                    val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                    slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                    val newFm = getActiveFastMove()
                    // Preserve the exact Fast Move count when switching from Ember (9E) to Peck (8E)!
                    if (oldCount > 0) {
                        slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                    }
                    ocrStatusText.text = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                    refreshHudDisplay()
                }
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        val matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text)
                        if (matchedPoke != null) {
                            if (matchedPoke.id != currentPokemon.id) {
                                currentPokemon = matchedPoke
                                fastHitsLandedOnCurrentPlayer = 0
                                latestEffectivenessHint = null
                                visualClassifier.resetForNewOpponent()
                                ocrStatusText.text = "● Locked: ${matchedPoke.name}"
                                refreshHudDisplay()
                            } else if (!ocrStatusText.text.startsWith("⚡") && !ocrStatusText.text.startsWith("▼")) {
                                ocrStatusText.text = "● Watching ${matchedPoke.name}"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val rawLeft = leftText.text
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(rawLeft)
                                    if (playerPoke != null) {
                                        if (playerPoke.id != currentPlayerPokemonId) {
                                            currentPlayerPokemonId = playerPoke.id
                                            playerDefenderTypes = PvPokeRepository.getDefenderTypes(playerPoke)
                                            fastHitsLandedOnCurrentPlayer = 0
                                            latestEffectivenessHint = null
                                        }
                                    }
                                    val (_, _, effHint) = PvPokeRepository.detectChargedAttackAndEffectiveness(rawLeft, currentPokemon)
                                    if (effHint != null) {
                                        latestEffectivenessHint = effHint
                                    }
                                }
                                .addOnCompleteListener {
                                    if (bannerBmp != null) {
                                        recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                                            .addOnSuccessListener { bText ->
                                                val (_, specificMove, effH) =
                                                    PvPokeRepository.detectChargedAttackAndEffectiveness(bText.text, currentPokemon)
                                                if (effH != null) latestEffectivenessHint = effH
                                                if (specificMove != null) {
                                                    reconcileChargedMoveFromBanner(specificMove)
                                                    postCutsceneBannerTicks = 0
                                                }
                                            }
                                            .addOnCompleteListener {
                                                lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                                isOcrBusy = false
                                            }
                                    } else {
                                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                        isOcrBusy = false
                                    }
                                }
                        } else {
                            lastOcrCompletedTimestampMs = System.currentTimeMillis()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            isBattleHudCurrentlyVisible = false
            hudMissingDurationMs += tickMs

            if (hudMissingDurationMs >= 12000L && inActiveMatch) {
                inActiveMatch = false
                resetCurrentMatchState("● Waiting for battle...")
            } else if (inActiveMatch && hudMissingDurationMs >= 450L) {
                ocrStatusText.text = "⏸ Paused (Cutscene)"
                refreshHudDisplay()
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        if (PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetCurrentMatchState("● Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            val (isIncoming, specificMove, effHint) =
                                PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                            if (effHint != null) latestEffectivenessHint = effHint
                            if (specificMove != null) {
                                specificMoveDetectedDuringPause = specificMove
                                chargedAttackDetectedDuringPause = true
                                ocrStatusText.text = "⚠️ Used ${specificMove.name}!"
                            } else if (isIncoming) {
                                chargedAttackDetectedDuringPause = true
                                ocrStatusText.text = "⚠️ Attack Incoming!"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun refreshHudDisplay() {
        val energy = slotEnergies[currentPokemon.id] ?: 0
        val activeFm = getActiveFastMove()
        val eFast = max(1, activeFm.energyGain)
        val fastCount = floor(energy.toDouble() / eFast).toInt()
        val cycleIdx = slotCycleIndex[currentPokemon.id] ?: 0

        countNumberText.text = fastCount.toString()

        if (!inActiveMatch) {
            pokemonTitleText.text = "Waiting for battle..."
            swapFastMoveBtn.visibility = View.GONE
            chargedBadgesContainer.visibility = View.GONE
            return
        }

        pokemonTitleText.text = "${currentPokemon.name} · ${activeFm.name} (${eFast}E/${activeFm.turns}T)"
        swapFastMoveBtn.visibility = if (currentPokemon.fastMoves.size > 1) View.VISIBLE else View.GONE
        chargedBadgesContainer.visibility = if (manualCollapse) View.GONE else View.VISIBLE

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val paceList = currentPokemon.getPvPokeMoveCounts(activeFm, cm, 4)
            val activePaceTarget = paceList[cycleIdx % paceList.size]
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val afterEnergy = max(0, energy - cm.energyCost)
            val afterFastCount = floor(afterEnergy.toDouble() / eFast).toInt()
            val subtractMovesCount = if (isReady) max(1, fastCount - afterFastCount) else activePaceTarget

            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4094A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val cardLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = badgeBg
                setPadding(12, 5, 12, 5)
                setOnClickListener {
                    subtractChargedMoveAndUpdate(cm)
                }
            }

            val topLine = TextView(this).apply {
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xEEFFFFFF.toInt())
                text = if (isReady) {
                    "⚡ ${cm.name} READY (▼-$subtractMovesCount)"
                } else {
                    "${cm.name}: $fastCount/$activePaceTarget (-$neededMoves)"
                }
            }

            val formattedPace = paceList.mapIndexed { idx, v ->
                if (idx == (cycleIdx % paceList.size)) "[$v]" else "$v"
            }.joinToString(" - ")

            val bottomLine = TextView(this).apply {
                textSize = 8.5f
                setSingleLine(true)
                setTextColor(0xBB94A3B8.toInt())
                text = "Fast Move Count: $formattedPace"
            }

            cardLayout.addView(topLine)
            cardLayout.addView(bottomLine)

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 5
            }
            chargedBadgesContainer.addView(cardLayout, lp)
        }
    }

    private fun createNotification(): Notification {
        val channelId = "pokecount_overlay_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "PokéCount PvPoke GL Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("PokéCount PvPoke v13 Active")
            .setContentText("Peck/Ember Dual-Type + Amber HP + Obstruction-Proof Counter")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (overlayInitialized && ::overlayRoot.isInitialized) {
            windowManager.removeView(overlayRoot)
        }
    }

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
