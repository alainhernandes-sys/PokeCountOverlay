package com.pokecount.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var overlayRoot: LinearLayout
    private lateinit var counterBadgeLayout: LinearLayout
    private lateinit var countNumberText: TextView
    private lateinit var countLabelText: TextView
    private lateinit var pokemonTitleText: TextView
    private lateinit var ocrStatusText: TextView
    private lateinit var swapFastMoveBtn: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var closeOverlayBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val slotEnergies = mutableMapOf<String, Int>()
    private val slotCycleIndex = mutableMapOf<String, Int>()
    private val slotFastMoveIdx = mutableMapOf<String, Int>()

    private var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
    private var playerPokemonType: String? = null
    private var latestEffectivenessHint: String? = null

    // Battle & Visual HP-Bar + Obstruction-Aware 1-Turn Opponent Animation state tracking
    private var inActiveMatch = false
    private var isBattleHudCurrentlyVisible = false
    private var hudMissingDurationMs = 0L
    private var noFrameDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var manualCollapse = false

    // High-Precision 1px Contiguous HP Fill + Obstruction-Aware Tracker
    private var refPlayerHpFillPx: Int? = null
    private var higherHpConfirmTicks: Int = 0
    private var lastHpChipTimestampMs: Long = 0L
    private var lastVisualFastMoveTimestampMs: Long = 0L
    private var hudReappearedGraceTicks: Int = 0

    // 32x32 motion grids for Upper Opponent, Lower Opponent Platform (under Altaria wings), Player Self-Wing, and Target Impact
    private var prevUpperOpponentGrid: IntArray? = null
    private var prevLowerPlatformGrid: IntArray? = null
    private var prevPlayerWingGrid: IntArray? = null
    private var prevTargetImpactGrid: IntArray? = null

    // OCR concurrency, throttling & watchdog
    private var isOcrBusy = false
    private var lastOcrStartTimestampMs = 0L
    private var lastOcrCompletedTimestampMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x40000000, 0x26000000, 0x73090D16)
    private val borderAlphas = intArrayOf(0x36FFFFFF, 0x20FFFFFF, 0x5094A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    private fun getActiveFastMove(): FastMove {
        val idx = (slotFastMoveIdx[currentPokemon.id] ?: 0).coerceIn(0, max(0, currentPokemon.fastMoves.size - 1))
        return currentPokemon.fastMoves[idx]
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext)
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startVisualAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun createFloatingOverlayHud() {
        val (screenW, screenH) = getScreenDimensions()
        val compactWidth = (screenW * 0.50f).toInt()

        overlayParams = WindowManager.LayoutParams(
            compactWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = (screenH * 0.125f).toInt()
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
        }

        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        counterBadgeLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 5, 14, 5)
            setOnClickListener {
                manualCollapse = !manualCollapse
                refreshHudDisplay()
            }
        }

        countNumberText = TextView(this).apply {
            text = "0"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }

        countLabelText = TextView(this).apply {
            text = "FAST"
            textSize = 8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xCC6EE7B7.toInt())
        }

        counterBadgeLayout.addView(countNumberText)
        counterBadgeLayout.addView(countLabelText)

        val rightHeaderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        pokemonTitleText = TextView(this).apply {
            text = "Waiting for battle..."
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xEEFFFFFF.toInt())
            setOnClickListener {
                resetCurrentMatchState("● Reset to 0")
            }
        }

        val microControlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        ocrStatusText = TextView(this).apply {
            text = "● Visual Cue Mode v12"
            textSize = 8.5f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xAA6EE7B7.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        swapFastMoveBtn = TextView(this).apply {
            text = " [⇄Fast] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setOnClickListener {
                if (currentPokemon.fastMoves.size > 1) {
                    val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                    val nextIdx = (curIdx + 1) % currentPokemon.fastMoves.size
                    slotFastMoveIdx[currentPokemon.id] = nextIdx
                    ocrStatusText.text = "Fast: ${getActiveFastMove().name}"
                    refreshHudDisplay()
                }
            }
        }

        val minusOneBtn = TextView(this).apply {
            text = "[−]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = max(0, curE - getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        val plusOneBtn = TextView(this).apply {
            text = " [+]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF6EE7B7.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, curE + getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = " ◐"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        closeOverlayBtn = TextView(this).apply {
            text = " ✕"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                stopSelf()
            }
        }

        microControlsRow.addView(ocrStatusText)
        microControlsRow.addView(swapFastMoveBtn)
        microControlsRow.addView(minusOneBtn)
        microControlsRow.addView(plusOneBtn)
        microControlsRow.addView(opacityToggleBtn)
        microControlsRow.addView(closeOverlayBtn)

        rightHeaderCol.addView(pokemonTitleText)
        rightHeaderCol.addView(microControlsRow)

        topHeaderRow.addView(counterBadgeLayout)
        topHeaderRow.addView(rightHeaderCol)

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        overlayRoot.addView(topHeaderRow)
        overlayRoot.addView(chargedBadgesContainer)

        applyStealthTheme()

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = overlayParams.x
                        initialY = overlayParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        overlayParams.x = initialX - dx
                        overlayParams.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, overlayParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        }

        counterBadgeLayout.setOnTouchListener(dragListener)
        pokemonTitleText.setOnTouchListener(dragListener)

        windowManager.addView(overlayRoot, overlayParams)
        refreshHudDisplay()
    }

    private fun resetCurrentMatchState(statusMsg: String) {
        slotEnergies.clear()
        slotCycleIndex.clear()
        refPlayerHpFillPx = null
        higherHpConfirmTicks = 0
        lastHpChipTimestampMs = 0L
        prevUpperOpponentGrid = null
        prevLowerPlatformGrid = null
        prevPlayerWingGrid = null
        prevTargetImpactGrid = null
        chargedAttackDetectedDuringPause = false
        specificMoveDetectedDuringPause = null
        ocrStatusText.text = statusMsg
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 22f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        overlayRoot.background = panelBg

        val counterBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f
            setColor(0x44000000)
            setStroke(2, 0x8834D399.toInt())
        }
        counterBadgeLayout.background = counterBg
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()

            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpManager.getMediaProjection(resultCode, data) ?: return
            mediaProjection = mp

            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    virtualDisplay?.release()
                    imageReader?.close()
                    stopSelf()
                }
            }, mainHandler)

            val (screenW, screenH) = getScreenDimensions()
            val density = resources.displayMetrics.densityDpi

            imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3)
            virtualDisplay = mp.createVirtualDisplay(
                "PokeCountCaptureV12",
                screenW,
                screenH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
            ocrStatusText.text = "● Visual Scanner v12 Ready"
        } catch (e: Exception) {
            ocrStatusText.text = "Err: ${e.javaClass.simpleName}"
        }
    }

    private data class FrameVisualTelemetry(
        val isFrameNonBlack: Boolean,
        val isBattleHudVisible: Boolean,
        val playerHpFillPx: Int,
        val isUpperArenaObstructed: Boolean,
        val opponentAttackMotionRatio: Float,
        val targetImpactVfxRatio: Float
    )

    /**
     * Performs 5 ultra-fast (< 2.0ms) visual checks directly on the ImageReader buffer:
     * 1. Non-black frame check (hides overlay if user leaves Pokémon GO).
     * 2. Top-Left & Top-Right Battle HUD pill detector (works in both Day & Night arenas).
     * 3. 1px-resolution Player HP-Bar Fill Width (playerHpFillPx) across Green, Yellow, and Red states,
     *    supporting BOTH dark ground empty tracks ([20,27,20]) AND sky/feather-translucent empty tracks
     *    ([58,108,115] when flying Pokémon like Altaria place the HP bar high at y=21.2%).
     * 4. Foreground Obstruction Detector: detects when a large/flying player Pokémon (like Altaria's cloud wings)
     *    covers the upper opponent box (y: 26%..45% or playerHpBarYRatio < 0.38) and automatically shifts
     *    tracking down to the unobstructed Lower Opponent Platform Zone (x: 54%..78%, y: 46%..58%) while
     *    canceling out self-wing motion!
     */
    private fun analyzeFrameVisualTelemetry(image: Image): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(false, false, -1, false, 0f, 0f)
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.015f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.110f).toInt().coerceIn(y0 + 1, height)

                var maxRowWhiteRatio = 0f
                var redPokeballDots = 0
                var darkTextPixels = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 182 && g >= 192 && b >= 208) {
                                rowWhite++
                            }
                            if (r > 180 && g < 92 && b < 92) {
                                redPokeballDots++
                            }
                            if (r < 110 && g < 110 && b < 120) {
                                darkTextPixels++
                            }
                        }
                        x += 6
                    }
                    if (rowTotal > 0) {
                        val ratio = rowWhite.toFloat() / rowTotal
                        if (ratio > maxRowWhiteRatio) maxRowWhiteRatio = ratio
                    }
                    y += 3
                }
                return maxRowWhiteRatio > 0.48f && redPokeballDots >= 4 && darkTextPixels >= 6
            }

            val hudPillsVisible = checkBattlePillSide(0.02f, 0.42f) && checkBattlePillSide(0.58f, 0.98f)
            if (!hudPillsVisible) {
                return FrameVisualTelemetry(true, false, -1, false, 0f, 0f)
            }

            // 3. Measure 1px-resolution Player HP Bar Fill Width (x: 4%..36%, y: 16%..67%)
            //    Supports BOTH dark ground empty track ([20,27,20]) and sky/feather-translucent empty track ([58,108,115])!
            val hx0 = (width * 0.04f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.36f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.16f).toInt().coerceIn(0, height - 2)
            val hy1 = (height * 0.67f).toInt().coerceIn(hy0 + 1, height)

            val barMinTotal = ((hx1 - hx0) * 0.44f).toInt()

            var bestGreenFillPx = -1
            var bestGreenY = -1
            var bestYellowFillPx = -1
            var bestYellowY = -1
            var bestRedFillPx = -1
            var bestRedY = -1

            var y = hy0
            while (y < hy1) {
                val rowOff = y * rowStride
                var gCnt = 0
                var yCnt = 0
                var rCnt = 0
                var emptyTrackCnt = 0

                var x = hx0
                while (x < hx1) {
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF

                        // Empty HP bar track: jet-black over ground OR translucent slate over sky/feathers (Altaria)
                        val isDarkEmptyTrack = (r < 42 && g < 48 && b < 48)
                        val isSkySlateEmptyTrack = (r in 35..92 && g in 75..128 && b in 80..135 && abs(g - b) <= 22)

                        if (isDarkEmptyTrack || isSkySlateEmptyTrack) {
                            emptyTrackCnt++
                        } else if (g > 200 && r < 90 && b in 125..195 && (g - b) >= 42) {
                            gCnt++
                        } else if (r > 220 && g > 200 && b in 70..165 && (r - b) >= 75) {
                            yCnt++
                        } else if (r > 195 && g in 35..110 && b in 35..110 && (r - g) >= 95) {
                            rCnt++
                        }
                    }
                    x += 1
                }

                if (gCnt >= 12 && (gCnt + emptyTrackCnt) >= barMinTotal && gCnt > bestGreenFillPx) {
                    bestGreenFillPx = gCnt
                    bestGreenY = y
                }
                if (yCnt >= 8 && emptyTrackCnt >= 20 && (yCnt + emptyTrackCnt) >= barMinTotal && yCnt > bestYellowFillPx) {
                    bestYellowFillPx = yCnt
                    bestYellowY = y
                }
                if (rCnt >= 4 && emptyTrackCnt >= 35 && (rCnt + emptyTrackCnt) >= barMinTotal && rCnt > bestRedFillPx) {
                    bestRedFillPx = rCnt
                    bestRedY = y
                }
                y += 2
            }

            val (hpFillPx, detectedHpBarY) = when {
                bestGreenFillPx > 0 -> Pair(bestGreenFillPx, bestGreenY)
                bestYellowFillPx > 0 -> Pair(bestYellowFillPx, bestYellowY)
                bestRedFillPx > 0 -> Pair(bestRedFillPx, bestRedY)
                else -> Pair(-1, -1)
            }

            val playerHpBarYRatio = if (detectedHpBarY > 0) detectedHpBarY.toFloat() / height else 0.63f

            // 4. Sample 32x32 motion grids & check for foreground cloud/wing obstruction (e.g. Altaria)
            var upperCloudPixels = 0
            fun sampleMotionRatio(
                leftR: Float,
                topR: Float,
                rightR: Float,
                bottomR: Float,
                prevGrid: IntArray?,
                deltaThreshold: Int,
                countCloudObstruction: Boolean = false
            ): Pair<Float, IntArray> {
                val gridW = 32
                val gridH = 32
                val curr = IntArray(gridW * gridH)
                val sx0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val sx1 = (width * rightR).toInt().coerceIn(sx0 + 1, width)
                val sy0 = (height * topR).toInt().coerceIn(0, height - 2)
                val sy1 = (height * bottomR).toInt().coerceIn(sy0 + 1, height)

                var activeDiffs = 0
                for (gy in 0 until gridH) {
                    val py = sy0 + ((sy1 - sy0) * gy) / gridH
                    val rOff = py * rowStride
                    for (gx in 0 until gridW) {
                        val px = sx0 + ((sx1 - sx0) * gx) / gridW
                        val off = rOff + px * pixelStride
                        var packed = 0
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            packed = (r shl 16) or (g shl 8) or b
                            if (countCloudObstruction && r > 155 && g > 165 && b > 175 && abs(r - b) < 35) {
                                upperCloudPixels++
                            }
                            if (prevGrid != null) {
                                val old = prevGrid[gy * gridW + gx]
                                val or0 = (old shr 16) and 0xFF
                                val og0 = (old shr 8) and 0xFF
                                val ob0 = old and 0xFF
                                val d = abs(r - or0) + abs(g - og0) + abs(b - ob0)
                                if (d > deltaThreshold) activeDiffs++
                            }
                        }
                        curr[gy * gridW + gx] = packed
                    }
                }
                val ratio = if (prevGrid != null) activeDiffs.toFloat() / (gridW * gridH) else 0f
                return Pair(ratio, curr)
            }

            // Upper Opponent Zone (x: 46%..76%, y: 26%..45%) - obstructed when Altaria is on field
            val (upperOppMotion, newUpperGrid) = sampleMotionRatio(
                0.46f, 0.26f, 0.76f, 0.45f, prevUpperOpponentGrid, 75, countCloudObstruction = true
            )
            prevUpperOpponentGrid = newUpperGrid

            // Lower Opponent Platform Zone (x: 54%..78%, y: 46%..58%) - unobstructed below Altaria's wings!
            val (lowerPlatMotion, newLowerGrid) = sampleMotionRatio(
                0.54f, 0.46f, 0.78f, 0.58f, prevLowerPlatformGrid, 75
            )
            prevLowerPlatformGrid = newLowerGrid

            // Player Self-Wing Zone (x: 6%..34%, y: 24%..46%) - detects when player's own flying sprite flaps
            val (playerWingMotion, newWingGrid) = sampleMotionRatio(
                0.06f, 0.24f, 0.34f, 0.46f, prevPlayerWingGrid, 75
            )
            prevPlayerWingGrid = newWingGrid

            // Player Target Impact VFX Zone (x: 22%..50%, y: 46%..68%)
            val (impVfxRatio, newImpGrid) = sampleMotionRatio(
                0.22f, 0.46f, 0.50f, 0.68f, prevTargetImpactGrid, 85
            )
            prevTargetImpactGrid = newImpGrid

            val cloudObstructionRatio = upperCloudPixels.toFloat() / (32 * 32)
            // Upper arena is obstructed if the player's HP bar is high up (flying Pokémon like Altaria at y=0.212)
            // OR if cloud/wing pixels cover >= 35% of the upper opponent box!
            val isObstructed = (playerHpBarYRatio < 0.38f) || (cloudObstructionRatio >= 0.35f)

            // When obstructed by Altaria, read opponent motion strictly from the unobstructed lower platform (y: 46%..58%)
            // and cancel any synchronized self-wing flapping!
            val rawOpponentMotion = if (isObstructed) lowerPlatMotion else max(upperOppMotion, lowerPlatMotion)
            val cleanOpponentMotion = if (isObstructed && playerWingMotion >= rawOpponentMotion * 0.85f) {
                0f
            } else {
                rawOpponentMotion
            }

            FrameVisualTelemetry(true, true, hpFillPx, isObstructed, cleanOpponentMotion, impVfxRatio)
        } catch (_: Exception) {
            FrameVisualTelemetry(true, false, -1, false, 0f, 0f)
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    val offset = rowOffset + x * pixelStride
                    if (offset >= 0 && offset + 3 < bufLimit) {
                        val r = buf.get(offset).toInt() and 0xFF
                        val g = buf.get(offset + 1).toInt() and 0xFF
                        val b = buf.get(offset + 2).toInt() and 0xFF
                        pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }

    private fun startVisualAndOcrLoop() {
        val tickMs = 100L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameAndUpdateState(tickMs)
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun subtractChargedMoveAndUpdate(cm: ChargedMove) {
        val currentE = slotEnergies[currentPokemon.id] ?: 0
        slotEnergies[currentPokemon.id] = max(0, currentE - cm.energyCost)
        val prevCycle = slotCycleIndex[currentPokemon.id] ?: 0
        slotCycleIndex[currentPokemon.id] = (prevCycle + 1) % 4
        lastSubtractedMoveTimestamp = System.currentTimeMillis()
        ocrStatusText.text = "▼ Subtracted ${cm.name}"
        refreshHudDisplay()
    }

    private fun processFrameAndUpdateState(tickMs: Long) {
        val now = System.currentTimeMillis()
        if (isOcrBusy && now - lastOcrStartTimestampMs > 2500L) {
            isOcrBusy = false
        }

        val image = try {
            imageReader?.acquireLatestImage()
        } catch (_: Exception) {
            null
        }

        if (image == null) {
            noFrameDurationMs += tickMs
            if (noFrameDurationMs >= 1500L && overlayRoot.visibility == View.VISIBLE) {
                overlayRoot.visibility = View.GONE
            }
            return
        }

        noFrameDurationMs = 0L

        var telemetry = FrameVisualTelemetry(true, false, -1, false, 0f, 0f)
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        val shouldRunOcrThisTick = !isOcrBusy && (now - lastOcrCompletedTimestampMs >= 380L)

        try {
            telemetry = analyzeFrameVisualTelemetry(image)
            if (telemetry.isFrameNonBlack) {
                if (telemetry.isBattleHudVisible) {
                    if (currentPokemon.fastMoves.size > 1) {
                        // If obstructed by Altaria's wings, crop the unobstructed lower platform (y: 46%..72%)!
                        arenaVisualBmp = if (telemetry.isUpperArenaObstructed) {
                            cropRegionFromImage(image, 0.48f, 0.46f, 0.82f, 0.72f, step = 3)
                        } else {
                            cropRegionFromImage(image, 0.15f, 0.35f, 0.72f, 0.78f, step = 4)
                        }
                    }
                    if (shouldRunOcrThisTick) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.105f, step = 1)
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.45f, 0.105f, step = 2)
                    }
                } else if (shouldRunOcrThisTick) {
                    bannerBmp = cropRegionFromImage(image, 0.08f, 0.18f, 0.92f, 0.90f, step = 2)
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        if (!telemetry.isFrameNonBlack) {
            if (overlayRoot.visibility == View.VISIBLE) {
                overlayRoot.visibility = View.GONE
            }
            return
        }

        if (overlayRoot.visibility != View.VISIBLE) {
            overlayRoot.visibility = View.VISIBLE
        }

        if (telemetry.isBattleHudVisible) {
            if (!inActiveMatch) {
                inActiveMatch = true
                resetCurrentMatchState("● Battle Active")
                hudReappearedGraceTicks = 3
            } else if (!isBattleHudCurrentlyVisible && hudMissingDurationMs >= 1600L) {
                refPlayerHpFillPx = null
                higherHpConfirmTicks = 0
                hudReappearedGraceTicks = 4
                if (chargedAttackDetectedDuringPause || specificMoveDetectedDuringPause != null) {
                    val moveToSub = specificMoveDetectedDuringPause ?: run {
                        val curE = slotEnergies[currentPokemon.id] ?: 0
                        currentPokemon.chargedMoves
                            .filter { curE >= it.energyCost }
                            .maxByOrNull { it.energyCost }
                            ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                    }
                    if (moveToSub != null && now - lastSubtractedMoveTimestamp > 3500L) {
                        subtractChargedMoveAndUpdate(moveToSub)
                    }
                }
                chargedAttackDetectedDuringPause = false
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudMissingDurationMs = 0L

            // =========================================================================
            // OBSTRUCTION-PROOF VISUAL-CUE FAST ATTACK COUNTER (v12)
            // =========================================================================
            val hpPx = telemetry.playerHpFillPx
            val oppMotion = telemetry.opponentAttackMotionRatio
            val impVfx = telemetry.targetImpactVfxRatio

            if (hpPx > 0) {
                if (hudReappearedGraceTicks > 0) {
                    hudReappearedGraceTicks--
                    refPlayerHpFillPx = hpPx
                    higherHpConfirmTicks = 0
                } else {
                    val prevHpPx = refPlayerHpFillPx
                    if (prevHpPx == null) {
                        refPlayerHpFillPx = hpPx
                    } else {
                        val dropPx = prevHpPx - hpPx
                        val activeFm = getActiveFastMove()

                        if (dropPx >= 1) {
                            lastHpChipTimestampMs = now
                        }

                        if (activeFm.turns == 1) {
                            // ---------------------------------------------------------------
                            // 1-TURN (0.5s / 500ms) FAST MOVE VISUAL TRACKER
                            // ---------------------------------------------------------------
                            val elapsedSinceLastCount = now - lastVisualFastMoveTimestampMs
                            val isContinuousHpDrain = dropPx in 2..65
                            // Require recent real HP chip (<= 900ms) + unobstructed opponent platform motion & impact VFX
                            val isAnimationAndImpactActive =
                                (oppMotion >= 0.125f && impVfx >= 0.045f) &&
                                    (dropPx >= 1 || (now - lastHpChipTimestampMs) <= 900L)

                            if (elapsedSinceLastCount >= 460L && (isContinuousHpDrain || isAnimationAndImpactActive)) {
                                lastVisualFastMoveTimestampMs = now
                                refPlayerHpFillPx = hpPx
                                higherHpConfirmTicks = 0
                                val prevE = slotEnergies[currentPokemon.id] ?: 0
                                slotEnergies[currentPokemon.id] = min(100, prevE + activeFm.energyGain)
                                ocrStatusText.text = if (isContinuousHpDrain) {
                                    "⚡ 1T Drain: +1 ${activeFm.name}"
                                } else {
                                    "⚡ 1T Anim: +1 ${activeFm.name}"
                                }
                                refreshHudDisplay()
                            }
                        } else {
                            // ---------------------------------------------------------------
                            // 2-TO-5 TURN (1.0s - 2.5s) FAST MOVE VISUAL TRACKER (e.g. Ember 2T)
                            // ---------------------------------------------------------------
                            val minDebounceMs = max(420L, activeFm.turns * 500L - 180L)
                            if (dropPx in 2..68 && (now - lastVisualFastMoveTimestampMs) >= minDebounceMs) {
                                lastVisualFastMoveTimestampMs = now
                                refPlayerHpFillPx = hpPx
                                higherHpConfirmTicks = 0
                                val prevE = slotEnergies[currentPokemon.id] ?: 0
                                slotEnergies[currentPokemon.id] = min(100, prevE + activeFm.energyGain)
                                ocrStatusText.text = "⚡ Hit! +1 ${activeFm.name}"
                                refreshHudDisplay()
                            }
                        }

                        if (hpPx > prevHpPx + 16) {
                            higherHpConfirmTicks++
                            if (higherHpConfirmTicks >= 4) {
                                refPlayerHpFillPx = hpPx
                                higherHpConfirmTicks = 0
                            }
                        } else {
                            higherHpConfirmTicks = 0
                        }
                    }
                }
            }

            if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                    arenaVisualBmp,
                    currentPokemon,
                    latestEffectivenessHint,
                    playerPokemonType
                )
                if (detectedFmIdx != null && detectedFmIdx != (slotFastMoveIdx[currentPokemon.id] ?: 0)) {
                    slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                    val newFm = getActiveFastMove()
                    ocrStatusText.text = "⚡ Visual: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                    refreshHudDisplay()
                }
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        val matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text)
                        if (matchedPoke != null) {
                            if (matchedPoke.id != currentPokemon.id) {
                                currentPokemon = matchedPoke
                                visualClassifier.resetForNewOpponent()
                                ocrStatusText.text = "● Locked: ${matchedPoke.name}"
                                refreshHudDisplay()
                            } else if (!ocrStatusText.text.startsWith("⚡") && !ocrStatusText.text.startsWith("▼")) {
                                ocrStatusText.text = "● Watching ${matchedPoke.name}"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(leftText.text)
                                    if (playerPoke != null) playerPokemonType = playerPoke.primaryType
                                }
                                .addOnCompleteListener {
                                    lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                    isOcrBusy = false
                                }
                        } else {
                            lastOcrCompletedTimestampMs = System.currentTimeMillis()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            isBattleHudCurrentlyVisible = false
            hudMissingDurationMs += tickMs

            if (hudMissingDurationMs >= 12000L && inActiveMatch) {
                inActiveMatch = false
                resetCurrentMatchState("● Waiting for battle...")
            } else if (inActiveMatch && hudMissingDurationMs >= 450L) {
                ocrStatusText.text = "⏸ Paused (Cutscene)"
                refreshHudDisplay()
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        if (PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetCurrentMatchState("● Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            val (isIncoming, specificMove, effHint) =
                                PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                            if (effHint != null) latestEffectivenessHint = effHint
                            if (specificMove != null) {
                                specificMoveDetectedDuringPause = specificMove
                                chargedAttackDetectedDuringPause = true
                                ocrStatusText.text = "⚠️ Used ${specificMove.name}!"
                            } else if (isIncoming) {
                                chargedAttackDetectedDuringPause = true
                                ocrStatusText.text = "⚠️ Attack Incoming!"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun refreshHudDisplay() {
        val energy = slotEnergies[currentPokemon.id] ?: 0
        val activeFm = getActiveFastMove()
        val eFast = max(1, activeFm.energyGain)
        val fastCount = floor(energy.toDouble() / eFast).toInt()
        val cycleIdx = slotCycleIndex[currentPokemon.id] ?: 0

        countNumberText.text = fastCount.toString()

        if (!inActiveMatch) {
            pokemonTitleText.text = "Waiting for battle..."
            swapFastMoveBtn.visibility = View.GONE
            chargedBadgesContainer.visibility = View.GONE
            return
        }

        pokemonTitleText.text = "${currentPokemon.name} · ${activeFm.name} (${eFast}E/${activeFm.turns}T)"
        swapFastMoveBtn.visibility = if (currentPokemon.fastMoves.size > 1) View.VISIBLE else View.GONE
        chargedBadgesContainer.visibility = if (manualCollapse) View.GONE else View.VISIBLE

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val paceList = currentPokemon.getPvPokeMoveCounts(activeFm, cm, 4)
            val activePaceTarget = paceList[cycleIdx % paceList.size]
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val afterEnergy = max(0, energy - cm.energyCost)
            val afterFastCount = floor(afterEnergy.toDouble() / eFast).toInt()
            val subtractMovesCount = if (isReady) max(1, fastCount - afterFastCount) else activePaceTarget

            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4094A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val cardLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = badgeBg
                setPadding(12, 5, 12, 5)
                setOnClickListener {
                    subtractChargedMoveAndUpdate(cm)
                }
            }

            val topLine = TextView(this).apply {
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xEEFFFFFF.toInt())
                text = if (isReady) {
                    "⚡ ${cm.name} READY (▼-$subtractMovesCount)"
                } else {
                    "${cm.name}: $fastCount/$activePaceTarget (-$neededMoves)"
                }
            }

            val formattedPace = paceList.mapIndexed { idx, v ->
                if (idx == (cycleIdx % paceList.size)) "[$v]" else "$v"
            }.joinToString(" - ")

            val bottomLine = TextView(this).apply {
                textSize = 8.5f
                setSingleLine(true)
                setTextColor(0xBB94A3B8.toInt())
                text = "Fast Move Count: $formattedPace"
            }

            cardLayout.addView(topLine)
            cardLayout.addView(bottomLine)

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 5
            }
            chargedBadgesContainer.addView(cardLayout, lp)
        }
    }

    private fun createNotification(): Notification {
        val channelId = "pokecount_overlay_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "PokéCount PvPoke GL Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("PokéCount PvPoke v12 Active")
            .setContentText("Obstruction-Proof + Sky-HP + 1-Turn Visual Counter")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (overlayInitialized && ::overlayRoot.isInitialized) {
            windowManager.removeView(overlayRoot)
        }
    }

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
