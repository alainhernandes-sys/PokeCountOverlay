package com.pokecount.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayParams: WindowManager.LayoutParams
    private lateinit var overlayRoot: LinearLayout
    private lateinit var counterBadgeLayout: LinearLayout
    private lateinit var countNumberText: TextView
    private lateinit var countLabelText: TextView
    private lateinit var pokemonTitleText: TextView
    private lateinit var ocrStatusText: TextView
    private lateinit var swapFastMoveBtn: TextView
    private lateinit var resumeCaptureBtn: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var closeOverlayBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout
    private lateinit var benchEnergyText: TextView

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isMediaProjectionActive = false

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val visualClassifier = FastMoveVisualClassifier()
    private val mainHandler = Handler(Looper.getMainLooper())

    // Per-Pokemon persistent battle state (remembers energy & move cycle across switches!)
    private val slotEnergies = mutableMapOf<String, Int>()
    private val slotCycleIndex = mutableMapOf<String, Int>()
    private val slotFastMoveIdx = mutableMapOf<String, Int>()
    private val seenOpponentPokemon = linkedMapOf<String, PvPokeEntry>()
    private val manualFormOverrideByBase = mutableMapOf<String, String>()

    private var currentPokemon: PvPokeEntry = PvPokeRepository.BUILT_IN_POKEMON.first()
    private var hasLockedFirstOpponentInMatch = false
    private var unassignedOpeningFastMoves = 0

    private var currentPlayerPokemonId: String? = null
    private var currentPlayerPokemonName: String? = null
    private var playerDefenderTypes: List<String> = emptyList()
    private var latestEffectivenessHint: String? = null
    private var fastHitsLandedOnCurrentPlayer: Int = 0

    // Battle & Cutscene state tracking
    private var inActiveMatch = false
    private var isBattleHudCurrentlyVisible = false
    private var hudCompletelyMissingDurationMs = 0L
    private var zoomedWithoutHpDurationMs = 0L
    private var chargedAttackDetectedDuringPause = false
    private var playerUsedChargedMoveDuringZoom = false
    private var specificMoveDetectedDuringPause: ChargedMove? = null
    private var lastAutoSubtractedMove: ChargedMove? = null
    private var lastAutoSubtractedPokemonId: String? = null
    private var postCutsceneBannerTicks = 0
    private var manualCollapse = false

    // High-Precision 1px Contiguous HP Fill + White-Top-Border Tracker
    private var refPlayerHpFillPx: Int? = null
    private var refPlayerHpBarY: Int = -1
    private var higherHpConfirmTicks: Int = 0
    private var lastHpChipTimestampMs: Long = 0L
    private var lastVisualFastMoveTimestampMs: Long = 0L

    // 32x32 motion grids
    private var prevLowerPlatformGrid: IntArray? = null
    private var prevTargetImpactGrid: IntArray? = null

    // OCR concurrency, throttling & watchdog
    private var isOcrBusy = false
    private var lastOcrStartTimestampMs = 0L
    private var lastOcrCompletedTimestampMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x40000000, 0x26000000, 0x73090D16)
    private val borderAlphas = intArrayOf(0x36FFFFFF, 0x20FFFFFF, 0x5094A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    private fun getActiveFastMove(entry: PvPokeEntry = currentPokemon): FastMove {
        val idx = (slotFastMoveIdx[entry.id] ?: 0).coerceIn(0, max(0, entry.fastMoves.size - 1))
        return entry.fastMoves[idx]
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!overlayInitialized) {
            overlayInitialized = true
            PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext)
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startVisualAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    1,
                    createNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    1,
                    createNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(1, createNotification())
            }
            setupMediaProjection(resultCode, resultData)
        } else {
            promoteToSpecialUseForeground()
        }
        return START_STICKY
    }

    private fun promoteToSpecialUseForeground() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(1, createNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, createNotification())
            }
        } catch (_: Exception) {
        }
    }

    private fun promptMediaProjectionReconnect() {
        try {
            val reIntent = Intent(this@OverlayVisionService, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(MainActivity.EXTRA_AUTO_PROMPT_CAPTURE, true)
            }
            startActivity(reIntent)
        } catch (_: Exception) {
        }
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = resources.displayMetrics
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun createFloatingOverlayHud() {
        val (screenW, screenH) = getScreenDimensions()
        val compactWidth = (screenW * 0.54f).toInt()

        overlayParams = WindowManager.LayoutParams(
            compactWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = (screenH * 0.125f).toInt()
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
        }

        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        counterBadgeLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 5, 14, 5)
            setOnClickListener {
                manualCollapse = !manualCollapse
                refreshHudDisplay()
            }
        }

        countNumberText = TextView(this).apply {
            text = "0"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }

        countLabelText = TextView(this).apply {
            text = "FAST"
            textSize = 8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xCC6EE7B7.toInt())
        }

        counterBadgeLayout.addView(countNumberText)
        counterBadgeLayout.addView(countLabelText)

        val rightHeaderCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        pokemonTitleText = TextView(this).apply {
            text = "Waiting for battle..."
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xEEFFFFFF.toInt())
            setOnClickListener {
                resetCurrentMatchState("● Match Reset to 0")
            }
        }

        val microControlsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        ocrStatusText = TextView(this).apply {
            text = "● Visual Cue Mode v21"
            textSize = 8.5f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xAA6EE7B7.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                if (!isMediaProjectionActive) {
                    promptMediaProjectionReconnect()
                }
            }
        }

        resumeCaptureBtn = TextView(this).apply {
            text = " [🔄Resume] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFDE047.toInt())
            visibility = View.GONE
            setOnClickListener {
                promptMediaProjectionReconnect()
            }
        }

        swapFastMoveBtn = TextView(this).apply {
            text = " [⇄Fast] "
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setOnClickListener {
                val oldFm = getActiveFastMove()
                val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                val curIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                val siblings = PvPokeRepository.getSiblingForms(currentPokemon)

                if (curIdx + 1 < currentPokemon.fastMoves.size) {
                    slotFastMoveIdx[currentPokemon.id] = curIdx + 1
                    val newFm = getActiveFastMove()
                    if (oldCount > 0) {
                        slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                    }
                    ocrStatusText.text = "Fast: ${newFm.name}"
                    refreshHudDisplay()
                } else if (siblings.size > 1) {
                    val curFormIdx = siblings.indexOfFirst { it.id == currentPokemon.id }.coerceAtLeast(0)
                    val nextForm = siblings[(curFormIdx + 1) % siblings.size]
                    seenOpponentPokemon.remove(currentPokemon.id)
                    seenOpponentPokemon[nextForm.id] = nextForm
                    slotFastMoveIdx[nextForm.id] = 0
                    val nextFm = nextForm.fastMoves.first()
                    slotEnergies[nextForm.id] = min(100, oldCount * nextFm.energyGain)
                    slotCycleIndex[nextForm.id] = slotCycleIndex[currentPokemon.id] ?: 0
                    val baseKey = nextForm.name.substringBefore("(").trim().lowercase()
                    manualFormOverrideByBase[baseKey] = nextForm.id
                    currentPokemon = nextForm
                    ocrStatusText.text = "Form: ${nextForm.name}"
                    refreshHudDisplay()
                } else if (currentPokemon.fastMoves.size > 1) {
                    slotFastMoveIdx[currentPokemon.id] = 0
                    val newFm = getActiveFastMove()
                    if (oldCount > 0) {
                        slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                    }
                    ocrStatusText.text = "Fast: ${newFm.name}"
                    refreshHudDisplay()
                }
            }
        }

        val minusOneBtn = TextView(this).apply {
            text = "[−]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = max(0, curE - getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        val plusOneBtn = TextView(this).apply {
            text = " [+]"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF6EE7B7.toInt())
            setOnClickListener {
                inActiveMatch = true
                val curE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, curE + getActiveFastMove().energyGain)
                refreshHudDisplay()
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = " ◐"
            textSize = 11f
            setTextColor(0xCCFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        closeOverlayBtn = TextView(this).apply {
            text = " ✕"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener {
                stopSelf()
            }
        }

        microControlsRow.addView(ocrStatusText)
        microControlsRow.addView(resumeCaptureBtn)
        microControlsRow.addView(swapFastMoveBtn)
        microControlsRow.addView(minusOneBtn)
        microControlsRow.addView(plusOneBtn)
        microControlsRow.addView(opacityToggleBtn)
        microControlsRow.addView(closeOverlayBtn)

        rightHeaderCol.addView(pokemonTitleText)
        rightHeaderCol.addView(microControlsRow)

        topHeaderRow.addView(counterBadgeLayout)
        topHeaderRow.addView(rightHeaderCol)

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 0)
        }

        benchEnergyText = TextView(this).apply {
            textSize = 8.5f
            typeface = Typeface.DEFAULT_BOLD
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xFFFDE047.toInt())
            setPadding(4, 5, 4, 0)
            visibility = View.GONE
        }

        overlayRoot.addView(topHeaderRow)
        overlayRoot.addView(chargedBadgesContainer)
        overlayRoot.addView(benchEnergyText)

        applyStealthTheme()

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = overlayParams.x
                        initialY = overlayParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        overlayParams.x = initialX - dx
                        overlayParams.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, overlayParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        }

        counterBadgeLayout.setOnTouchListener(dragListener)
        pokemonTitleText.setOnTouchListener(dragListener)

        windowManager.addView(overlayRoot, overlayParams)
        refreshHudDisplay()
    }

    private fun resetCurrentMatchState(statusMsg: String) {
        slotEnergies.clear()
        slotCycleIndex.clear()
        seenOpponentPokemon.clear()
        manualFormOverrideByBase.clear()
        hasLockedFirstOpponentInMatch = false
        unassignedOpeningFastMoves = 0
        refPlayerHpFillPx = null
        refPlayerHpBarY = -1
        higherHpConfirmTicks = 0
        lastHpChipTimestampMs = 0L
        fastHitsLandedOnCurrentPlayer = 0
        latestEffectivenessHint = null
        prevLowerPlatformGrid = null
        prevTargetImpactGrid = null
        chargedAttackDetectedDuringPause = false
        playerUsedChargedMoveDuringZoom = false
        specificMoveDetectedDuringPause = null
        lastAutoSubtractedMove = null
        lastAutoSubtractedPokemonId = null
        postCutsceneBannerTicks = 0
        zoomedWithoutHpDurationMs = 0L
        ocrStatusText.text = statusMsg
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 22f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        overlayRoot.background = panelBg

        val counterBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16f
            setColor(0x44000000)
            setStroke(2, 0x8834D399.toInt())
        }
        counterBadgeLayout.background = counterBg
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()

            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpManager.getMediaProjection(resultCode, data) ?: return
            mediaProjection = mp
            isMediaProjectionActive = true
            resumeCaptureBtn.visibility = View.GONE

            // When the user starts their phone's built-in Screen Recorder, Android OS revokes this
            // MediaProjection token and invokes onStop(). We keep the service alive under
            // FOREGROUND_SERVICE_TYPE_SPECIAL_USE and show [🔄Resume] so 1 tap reconnects capture!
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    isMediaProjectionActive = false
                    try {
                        virtualDisplay?.release()
                    } catch (_: Exception) {
                    }
                    virtualDisplay = null
                    try {
                        imageReader?.close()
                    } catch (_: Exception) {
                    }
                    imageReader = null
                    promoteToSpecialUseForeground()
                    resumeCaptureBtn.visibility = View.VISIBLE
                    ocrStatusText.text = "🔄 Tap [Resume] to track"
                }
            }, mainHandler)

            val (screenW, screenH) = getScreenDimensions()
            val capW = max(360, screenW / 2)
            val capH = max(720, screenH / 2)
            val density = max(160, resources.displayMetrics.densityDpi / 2)

            imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mp.createVirtualDisplay(
                "PokeCountCaptureV21",
                capW,
                capH,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
            ocrStatusText.text = "● Visual Scanner v21 Ready"
        } catch (e: Exception) {
            ocrStatusText.text = "Err: ${e.javaClass.simpleName}"
        }
    }

    private data class FrameVisualTelemetry(
        val isFrameNonBlack: Boolean,
        val isBattleHudVisible: Boolean,
        val playerHpFillPx: Int,
        val playerHpBarY: Int,
        val opponentAttackMotionRatio: Float,
        val targetImpactVfxRatio: Float,
        val opponentBadgeTypes: Set<String>
    )

    private fun analyzeFrameVisualTelemetry(image: Image): FrameVisualTelemetry {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            var nonBlackSamples = 0
            var totalSamples = 0
            for (sy in 1..8) {
                val y = (height * (sy * 0.10f)).toInt().coerceIn(0, height - 1)
                val rowOff = y * rowStride
                for (sx in 1..5) {
                    val x = (width * (sx * 0.16f)).toInt().coerceIn(0, width - 1)
                    val off = rowOff + x * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        totalSamples++
                        if (r > 12 || g > 12 || b > 12) nonBlackSamples++
                    }
                }
            }
            if (totalSamples > 0 && nonBlackSamples <= 2) {
                return FrameVisualTelemetry(false, false, -1, -1, 0f, 0f, emptySet())
            }

            fun checkBattlePillSide(leftR: Float, rightR: Float): Boolean {
                val x0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val x1 = (width * rightR).toInt().coerceIn(x0 + 1, width)
                val y0 = (height * 0.015f).toInt().coerceIn(0, height - 2)
                val y1 = (height * 0.110f).toInt().coerceIn(y0 + 1, height)

                var maxRowWhiteRatio = 0f
                var redPokeballDots = 0
                var darkTextPixels = 0

                var y = y0
                while (y < y1) {
                    val rowOff = y * rowStride
                    var rowWhite = 0
                    var rowTotal = 0
                    var x = x0
                    while (x < x1) {
                        val off = rowOff + x * pixelStride
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            rowTotal++
                            if (r >= 182 && g >= 192 && b >= 208) {
                                rowWhite++
                            }
                            if (r > 180 && g < 92 && b < 92) {
                                redPokeballDots++
                            }
                            if (r < 110 && g < 110 && b < 120) {
                                darkTextPixels++
                            }
                        }
                        x += max(2, width / 160)
                    }
                    if (rowTotal > 0) {
                        val ratio = rowWhite.toFloat() / rowTotal
                        if (ratio > maxRowWhiteRatio) maxRowWhiteRatio = ratio
                    }
                    y += max(1, height / 700)
                }
                return maxRowWhiteRatio > 0.46f && redPokeballDots >= 3 && darkTextPixels >= 4
            }

            val hudPillsVisible = checkBattlePillSide(0.02f, 0.42f) && checkBattlePillSide(0.58f, 0.98f)
            if (!hudPillsVisible) {
                return FrameVisualTelemetry(true, false, -1, -1, 0f, 0f, emptySet())
            }

            // Scan Top-Right Circular Type Badges (x: 87%..98.5%, y: 0.0%..2.5%)
            val detectedBadgeTypes = mutableSetOf<String>()
            val bx0 = (width * 0.87f).toInt().coerceIn(0, width - 2)
            val bx1 = (width * 0.985f).toInt().coerceIn(bx0 + 1, width)
            val by1 = max(4, (height * 0.025f).toInt()).coerceIn(1, height)
            val badgeCounts = mutableMapOf<String, Int>()
            for (by in 0 until by1) {
                val rOff = by * rowStride
                for (bx in bx0 until bx1) {
                    val off = rOff + bx * pixelStride
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF
                        val bType = when {
                            r > 215 && g in 130..195 && b > 195 && (r - g) > 40 && (b - g) > 30 -> "fairy"
                            r in 155..220 && g in 60..130 && b in 165..235 && (r - g) > 55 && (b - g) > 65 -> "poison"
                            r > 225 && g in 135..195 && b in 45..110 && (r - b) > 120 -> "fire"
                            r > 195 && g in 45..105 && b in 50..115 && (r - g) > 100 -> "fighting"
                            r in 75..150 && g in 150..210 && b > 205 && (b - r) > 70 -> "water"
                            r in 80..155 && g > 190 && b > 185 && abs(g - b) < 25 -> "ice"
                            r in 80..135 && g in 130..175 && b in 155..200 && (b - r) in 40..85 -> "steel"
                            r > 210 && g in 115..160 && b in 60..105 && (r - b) > 110 -> "ground"
                            r > 230 && g > 200 && b in 40..105 && (r - b) > 135 -> "electric"
                            r in 70..135 && g > 175 && b in 70..135 && (g - r) > 55 -> "grass"
                            r > 220 && g in 95..145 && b in 120..175 && (r - g) > 85 -> "psychic"
                            r in 75..135 && g in 85..140 && b in 155..215 && (b - r) > 50 -> "ghost"
                            r in 65..110 && g in 60..105 && b in 75..120 && abs(r - g) < 20 -> "dark"
                            else -> null
                        }
                        if (bType != null) {
                            badgeCounts[bType] = (badgeCounts[bType] ?: 0) + 1
                        }
                    }
                }
            }
            for ((tName, cnt) in badgeCounts) {
                if (cnt >= 3) detectedBadgeTypes.add(tName)
            }

            // White-Top-Border + Contiguous-Fill 27.4% Player HP Bar Scanner (x: 4.5%..38.5%, y: 16%..67%)
            val hx0 = (width * 0.045f).toInt().coerceIn(0, width - 2)
            val hx1 = (width * 0.385f).toInt().coerceIn(hx0 + 1, width)
            val hy0 = (height * 0.16f).toInt().coerceIn(0, height - 2)
            val hy1 = (height * 0.67f).toInt().coerceIn(hy0 + 1, height)

            val scanW = hx1 - hx0
            val barLen = max(20, (width * 0.274f).toInt())
            val minValidInBar = (barLen * 0.82f).toInt()
            val minTopBorderCount = (barLen * 0.60f).toInt()
            val minStartScreenX = (width * 0.052f).toInt()
            val maxStartScreenX = (width * 0.102f).toInt()

            var bestGreenFillPx = -1
            var bestGreenY = -1
            var bestYellowFillPx = -1
            var bestYellowY = -1
            var bestRedFillPx = -1
            var bestRedY = -1

            val whitePrefixRing = Array(8) { IntArray(scanW + 1) }
            val rowTypes = IntArray(scanW)

            val startPreY = max(0, hy0 - 7)
            for (py in startPreY until hy1) {
                val rOff = py * rowStride
                val ringRow = whitePrefixRing[py and 7]
                var wSum = 0
                ringRow[0] = 0

                var gFirst = -1
                var yFirst = -1
                var rFirst = -1

                for (col in 0 until scanW) {
                    val off = rOff + (hx0 + col) * pixelStride
                    var t = 0
                    if (off >= 0 && off + 3 < bufLimit) {
                        val r = buf.get(off).toInt() and 0xFF
                        val g = buf.get(off + 1).toInt() and 0xFF
                        val b = buf.get(off + 2).toInt() and 0xFF

                        if (r >= 170 && g >= 170 && b >= 145 && abs(r - g) <= 45) {
                            wSum++
                        }

                        if (py >= hy0) {
                            if (g > 200 && r < 90 && b in 125..200 && (g - b) >= 42) {
                                t = 1
                                if (gFirst < 0) gFirst = col
                            } else if (r > 215 && g > 200 && b in 75..170 && (r - b) >= 70) {
                                t = 2
                                if (yFirst < 0) yFirst = col
                            } else if (r > 180 && g in 0..115 && b in 0..110 && (r - g) >= 85 && (r - b) >= 85) {
                                t = 3
                                if (rFirst < 0) rFirst = col
                            } else if ((r < 135 && g < 135 && b < 140 && (r + g + b) <= 355) || (r > 210 && g in 115..195 && b < 55)) {
                                t = 4
                            }
                        }
                    }
                    ringRow[col + 1] = wSum
                    if (py >= hy0) rowTypes[col] = t
                }

                if (py < hy0) continue

                fun hasWhiteBorderAbove(firstCol: Int): Boolean {
                    val endCol = firstCol + barLen
                    for (dy in 4..7) {
                        val by = py - dy
                        if (by >= startPreY) {
                            val pRow = whitePrefixRing[by and 7]
                            if (pRow[endCol] - pRow[firstCol] >= minTopBorderCount) return true
                        }
                    }
                    return false
                }

                fun evalStage(firstCol: Int, stageCode: Int, minFill: Int): Int {
                    if (firstCol < 0 || firstCol + barLen > scanW) return -1
                    val absStartX = hx0 + firstCol
                    if (absStartX !in minStartScreenX..maxStartScreenX) return -1
                    if (!hasWhiteBorderAbove(firstCol)) return -1

                    var fillCnt = 0
                    var gap = 0
                    var fillStopped = false
                    var emptyCnt = 0
                    for (c in firstCol until (firstCol + barLen)) {
                        val rt = rowTypes[c]
                        if (!fillStopped) {
                            if (rt == stageCode) {
                                fillCnt++
                                gap = 0
                            } else {
                                gap++
                                if (gap >= 3) fillStopped = true
                                if (rt == 4) emptyCnt++
                            }
                        } else if (rt == 4) {
                            emptyCnt++
                        }
                    }
                    return if (fillCnt >= minFill && (fillCnt + emptyCnt) >= minValidInBar) fillCnt else -1
                }

                val gFill = evalStage(gFirst, 1, 8)
                if (gFill > bestGreenFillPx) {
                    bestGreenFillPx = gFill
                    bestGreenY = py
                }
                val yFill = evalStage(yFirst, 2, 5)
                if (yFill > bestYellowFillPx) {
                    bestYellowFillPx = yFill
                    bestYellowY = py
                }
                val rFill = evalStage(rFirst, 3, 1)
                if (rFill > bestRedFillPx) {
                    bestRedFillPx = rFill
                    bestRedY = py
                }
            }

            val (hpFillPx, hpBarY) = when {
                bestGreenFillPx > 0 -> Pair(bestGreenFillPx, bestGreenY)
                bestYellowFillPx > 0 -> Pair(bestYellowFillPx, bestYellowY)
                bestRedFillPx > 0 -> Pair(bestRedFillPx, bestRedY)
                else -> Pair(-1, -1)
            }

            if (hpFillPx <= 0) {
                return FrameVisualTelemetry(true, true, -1, -1, 0f, 0f, detectedBadgeTypes)
            }

            fun sampleMotionRatio(
                leftR: Float,
                topR: Float,
                rightR: Float,
                bottomR: Float,
                prevGrid: IntArray?,
                deltaThreshold: Int
            ): Pair<Float, IntArray> {
                val gridW = 32
                val gridH = 32
                val curr = IntArray(gridW * gridH)
                val sx0 = (width * leftR).toInt().coerceIn(0, width - 2)
                val sx1 = (width * rightR).toInt().coerceIn(sx0 + 1, width)
                val sy0 = (height * topR).toInt().coerceIn(0, height - 2)
                val sy1 = (height * bottomR).toInt().coerceIn(sy0 + 1, height)

                var activeDiffs = 0
                for (gy in 0 until gridH) {
                    val py = sy0 + ((sy1 - sy0) * gy) / gridH
                    val rOff = py * rowStride
                    for (gx in 0 until gridW) {
                        val px = sx0 + ((sx1 - sx0) * gx) / gridW
                        val off = rOff + px * pixelStride
                        var packed = 0
                        if (off >= 0 && off + 3 < bufLimit) {
                            val r = buf.get(off).toInt() and 0xFF
                            val g = buf.get(off + 1).toInt() and 0xFF
                            val b = buf.get(off + 2).toInt() and 0xFF
                            packed = (r shl 16) or (g shl 8) or b
                            if (prevGrid != null) {
                                val old = prevGrid[gy * gridW + gx]
                                val or0 = (old shr 16) and 0xFF
                                val og0 = (old shr 8) and 0xFF
                                val ob0 = old and 0xFF
                                val d = abs(r - or0) + abs(g - og0) + abs(b - ob0)
                                if (d > deltaThreshold) activeDiffs++
                            }
                        }
                        curr[gy * gridW + gx] = packed
                    }
                }
                val ratio = if (prevGrid != null) activeDiffs.toFloat() / (gridW * gridH) else 0f
                return Pair(ratio, curr)
            }

            val (oppMotion, newLowerGrid) = sampleMotionRatio(
                0.52f, 0.18f, 0.84f, 0.58f, prevLowerPlatformGrid, 75
            )
            prevLowerPlatformGrid = newLowerGrid

            val (impVfxRatio, newImpGrid) = sampleMotionRatio(
                0.10f, 0.24f, 0.44f, 0.64f, prevTargetImpactGrid, 80
            )
            prevTargetImpactGrid = newImpGrid

            FrameVisualTelemetry(true, true, hpFillPx, hpBarY, oppMotion, impVfxRatio, detectedBadgeTypes)
        } catch (_: Exception) {
            FrameVisualTelemetry(true, false, -1, -1, 0f, 0f, emptySet())
        }
    }

    private fun cropRegionFromImage(
        image: Image,
        leftRatio: Float,
        topRatio: Float,
        rightRatio: Float,
        bottomRatio: Float,
        step: Int = 1
    ): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val bufLimit = buf.limit()
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val startX = (width * leftRatio).toInt().coerceIn(0, width - 2)
            val endX = (width * rightRatio).toInt().coerceIn(startX + 1, width)
            val startY = (height * topRatio).toInt().coerceIn(0, height - 2)
            val endY = (height * bottomRatio).toInt().coerceIn(startY + 1, height)

            val outW = max(1, (endX - startX) / step)
            val outH = max(1, (endY - startY) / step)
            val pixels = IntArray(outW * outH)

            var py = 0
            var y = startY
            while (py < outH && y < endY) {
                val rowOffset = y * rowStride
                var px = 0
                var x = startX
                while (px < outW && x < endX) {
                    val offset = rowOffset + x * pixelStride
                    if (offset >= 0 && offset + 3 < bufLimit) {
                        val r = buf.get(offset).toInt() and 0xFF
                        val g = buf.get(offset + 1).toInt() and 0xFF
                        val b = buf.get(offset + 2).toInt() and 0xFF
                        pixels[py * outW + px] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    x += step
                    px++
                }
                y += step
                py++
            }
            Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Exception) {
            null
        }
    }

    private fun startVisualAndOcrLoop() {
        val tickMs = 100L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameAndUpdateState(tickMs)
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun upgradeToSiblingFormIfMoveMatches(usedMove: ChargedMove) {
        if (currentPokemon.chargedMoves.any { it.name == usedMove.name }) return
        val siblings = PvPokeRepository.getSiblingForms(currentPokemon)
        val matchingSibling = siblings.firstOrNull { sib ->
            sib.chargedMoves.any { it.name == usedMove.name }
        } ?: return

        val oldFm = getActiveFastMove()
        val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
        seenOpponentPokemon.remove(currentPokemon.id)
        seenOpponentPokemon[matchingSibling.id] = matchingSibling
        val newFm = getActiveFastMove(matchingSibling)
        slotEnergies[matchingSibling.id] = min(100, oldCount * newFm.energyGain)
        slotCycleIndex[matchingSibling.id] = slotCycleIndex[currentPokemon.id] ?: 0
        val baseKey = matchingSibling.name.substringBefore("(").trim().lowercase()
        manualFormOverrideByBase[baseKey] = matchingSibling.id
        currentPokemon = matchingSibling
    }

    private fun subtractChargedMoveAndUpdate(cm: ChargedMove, targetPokeId: String = currentPokemon.id) {
        upgradeToSiblingFormIfMoveMatches(cm)
        val effectiveId = currentPokemon.id
        val currentE = slotEnergies[effectiveId] ?: 0
        slotEnergies[effectiveId] = max(0, currentE - cm.energyCost)
        val prevCycle = slotCycleIndex[effectiveId] ?: 0
        slotCycleIndex[effectiveId] = (prevCycle + 1) % 4
        lastSubtractedMoveTimestamp = System.currentTimeMillis()
        lastAutoSubtractedMove = cm
        lastAutoSubtractedPokemonId = effectiveId
        ocrStatusText.text = "▼ Subtracted ${cm.name}"
        refreshHudDisplay()
    }

    private fun undoFalsePlayerChargedMoveSubtractionIfNeeded() {
        val now = System.currentTimeMillis()
        val prevSub = lastAutoSubtractedMove ?: return
        val targetId = lastAutoSubtractedPokemonId ?: currentPokemon.id
        if ((now - lastSubtractedMoveTimestamp) <= 6500L) {
            val curE = slotEnergies[targetId] ?: 0
            slotEnergies[targetId] = (curE + prevSub.energyCost).coerceIn(0, 100)
            val prevCycle = slotCycleIndex[targetId] ?: 0
            slotCycleIndex[targetId] = (prevCycle + 3) % 4
            lastAutoSubtractedMove = null
            lastAutoSubtractedPokemonId = null
            lastSubtractedMoveTimestamp = 0L
        }
    }

    private fun reconcileChargedMoveFromBanner(actualMove: ChargedMove) {
        upgradeToSiblingFormIfMoveMatches(actualMove)
        val now = System.currentTimeMillis()
        val prevSub = lastAutoSubtractedMove
        val targetId = currentPokemon.id
        if (prevSub != null && (now - lastSubtractedMoveTimestamp) <= 6500L) {
            if (prevSub.name != actualMove.name) {
                val curE = slotEnergies[targetId] ?: 0
                val correctedE = (curE + prevSub.energyCost - actualMove.energyCost).coerceIn(0, 100)
                slotEnergies[targetId] = correctedE
                lastAutoSubtractedMove = actualMove
                lastAutoSubtractedPokemonId = targetId
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            } else {
                ocrStatusText.text = "▼ Used ${actualMove.name}!"
                refreshHudDisplay()
            }
        } else if ((now - lastSubtractedMoveTimestamp) > 3200L) {
            subtractChargedMoveAndUpdate(actualMove, currentPokemon.id)
        }
    }

    private fun evaluatePlayerHpDropForFastMoves(
        hpPx: Int,
        hpBarY: Int,
        oppMotion: Float,
        impVfx: Float,
        now: Long
    ): Boolean {
        if (hpPx <= 0 || hpBarY <= 0) return false

        val prevHpPx = refPlayerHpFillPx
        if (prevHpPx == null || refPlayerHpBarY < 0) {
            refPlayerHpFillPx = hpPx
            refPlayerHpBarY = hpBarY
            higherHpConfirmTicks = 0
            return false
        }

        if (abs(hpBarY - refPlayerHpBarY) > 8) {
            refPlayerHpFillPx = hpPx
            refPlayerHpBarY = hpBarY
            higherHpConfirmTicks = 0
            return false
        }

        val dropPx = prevHpPx - hpPx

        if (dropPx > 28) {
            refPlayerHpFillPx = hpPx
            refPlayerHpBarY = hpBarY
            higherHpConfirmTicks = 0
            return false
        }

        val elapsedSinceLastCount = now - lastVisualFastMoveTimestampMs
        if (dropPx in 1..14 && elapsedSinceLastCount < 240L) {
            refPlayerHpFillPx = hpPx
            refPlayerHpBarY = hpBarY
            return false
        }

        val activeFm = getActiveFastMove()
        var justRegisteredHit = false

        if (dropPx >= 1) {
            lastHpChipTimestampMs = now
        }

        if (activeFm.turns == 1) {
            val hasDrop = dropPx in 1..28
            val isAnimAndImpactActive =
                (oppMotion >= 0.115f && impVfx >= 0.042f) &&
                    ((now - lastHpChipTimestampMs) <= 900L)

            if (elapsedSinceLastCount >= 380L && (hasDrop || isAnimAndImpactActive)) {
                val movesToCredit = if (dropPx >= 2 && elapsedSinceLastCount in 850L..1650L) 2 else 1
                lastVisualFastMoveTimestampMs = now
                refPlayerHpFillPx = hpPx
                refPlayerHpBarY = hpBarY
                higherHpConfirmTicks = 0
                fastHitsLandedOnCurrentPlayer += movesToCredit
                if (!hasLockedFirstOpponentInMatch) unassignedOpeningFastMoves += movesToCredit
                justRegisteredHit = true

                val prevE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, prevE + movesToCredit * activeFm.energyGain)
                ocrStatusText.text = "⚡ +$movesToCredit ${activeFm.name}"
                refreshHudDisplay()
            }
        } else {
            val minDebounceMs = max(360L, min(700L, activeFm.turns * 500L - 380L))
            if (dropPx in 1..28 && elapsedSinceLastCount >= minDebounceMs) {
                lastVisualFastMoveTimestampMs = now
                refPlayerHpFillPx = hpPx
                refPlayerHpBarY = hpBarY
                higherHpConfirmTicks = 0
                fastHitsLandedOnCurrentPlayer++
                if (!hasLockedFirstOpponentInMatch) unassignedOpeningFastMoves++
                justRegisteredHit = true

                val prevE = slotEnergies[currentPokemon.id] ?: 0
                slotEnergies[currentPokemon.id] = min(100, prevE + activeFm.energyGain)
                ocrStatusText.text = "⚡ Hit! +1 ${activeFm.name}"
                refreshHudDisplay()
            }
        }

        if (hpPx > prevHpPx + 6) {
            higherHpConfirmTicks++
            if (higherHpConfirmTicks >= 2) {
                refPlayerHpFillPx = hpPx
                refPlayerHpBarY = hpBarY
                higherHpConfirmTicks = 0
            }
        } else {
            higherHpConfirmTicks = 0
        }

        return justRegisteredHit
    }

    private fun isPlayerBubbleMinigameText(rawText: String): Boolean {
        val lower = rawText.lowercase()
        return lower.contains("nice!") ||
            lower.contains("great!") ||
            lower.contains("excellent!") ||
            lower.contains("swipe")
    }

    private fun processFrameAndUpdateState(tickMs: Long) {
        val now = System.currentTimeMillis()
        if (isOcrBusy && now - lastOcrStartTimestampMs > 2500L) {
            isOcrBusy = false
        }

        val image = try {
            imageReader?.acquireLatestImage()
        } catch (_: Exception) {
            null
        } ?: return

        var telemetry = FrameVisualTelemetry(true, false, -1, -1, 0f, 0f, emptySet())
        var arenaVisualBmp: Bitmap? = null
        var topRightBmp: Bitmap? = null
        var topLeftBmp: Bitmap? = null
        var aboveHpEffBmp: Bitmap? = null
        var bannerBmp: Bitmap? = null
        val shouldRunOcrThisTick = !isOcrBusy && (now - lastOcrCompletedTimestampMs >= 320L)

        try {
            telemetry = analyzeFrameVisualTelemetry(image)
            val isWideArenaCombat = telemetry.isBattleHudVisible && telemetry.playerHpFillPx > 0

            if (telemetry.isFrameNonBlack) {
                if (isWideArenaCombat) {
                    if (currentPokemon.fastMoves.size > 1) {
                        arenaVisualBmp = cropRegionFromImage(image, 0.08f, 0.20f, 0.46f, 0.66f, step = 2)
                    }
                    if (shouldRunOcrThisTick) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.110f, step = 1)
                        topLeftBmp = cropRegionFromImage(image, 0.02f, 0.015f, 0.46f, 0.115f, step = 1)
                        if (postCutsceneBannerTicks > 0) {
                            bannerBmp = cropRegionFromImage(image, 0.08f, 0.17f, 0.92f, 0.40f, step = 1)
                        } else if (telemetry.playerHpBarY > 10 && currentPokemon.fastMoves.size > 1) {
                            val hpYRatio = telemetry.playerHpBarY.toFloat() / image.height
                            val effTop = max(0.11f, hpYRatio - 0.048f)
                            val effBot = max(effTop + 0.02f, hpYRatio - 0.003f)
                            aboveHpEffBmp = cropRegionFromImage(image, 0.03f, effTop, 0.42f, effBot, step = 1)
                        }
                    }
                } else if (shouldRunOcrThisTick) {
                    bannerBmp = if (telemetry.isBattleHudVisible) {
                        cropRegionFromImage(image, 0.08f, 0.16f, 0.92f, 0.45f, step = 1)
                    } else {
                        cropRegionFromImage(image, 0.08f, 0.16f, 0.92f, 0.88f, step = 1)
                    }
                    if (telemetry.isBattleHudVisible) {
                        topRightBmp = cropRegionFromImage(image, 0.52f, 0.015f, 0.99f, 0.110f, step = 1)
                    }
                }
            }
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }

        if (!telemetry.isFrameNonBlack) {
            return
        }

        if (overlayRoot.visibility != View.VISIBLE) {
            overlayRoot.visibility = View.VISIBLE
        }

        val badgeTypesThisFrame = telemetry.opponentBadgeTypes

        if (telemetry.isBattleHudVisible) {
            if (postCutsceneBannerTicks > 0) postCutsceneBannerTicks--

            if (!inActiveMatch) {
                inActiveMatch = true
                resetCurrentMatchState("● Battle Active")
            } else if (!isBattleHudCurrentlyVisible && hudCompletelyMissingDurationMs >= 1200L) {
                refPlayerHpFillPx = null
                refPlayerHpBarY = -1
                higherHpConfirmTicks = 0
                postCutsceneBannerTicks = 28

                if (!playerUsedChargedMoveDuringZoom) {
                    val curEBeforeSub = slotEnergies[currentPokemon.id] ?: 0
                    if (chargedAttackDetectedDuringPause || specificMoveDetectedDuringPause != null) {
                        val moveToSub = specificMoveDetectedDuringPause ?: run {
                            currentPokemon.chargedMoves.firstOrNull { curEBeforeSub >= it.energyCost }
                                ?: currentPokemon.chargedMoves.minByOrNull { it.energyCost }
                        }
                        if (moveToSub != null && now - lastSubtractedMoveTimestamp > 3000L) {
                            subtractChargedMoveAndUpdate(moveToSub, currentPokemon.id)
                        }
                    }
                }
                chargedAttackDetectedDuringPause = false
                playerUsedChargedMoveDuringZoom = false
                specificMoveDetectedDuringPause = null
            }

            isBattleHudCurrentlyVisible = true
            hudCompletelyMissingDurationMs = 0L

            if (telemetry.playerHpFillPx > 0) {
                if (zoomedWithoutHpDurationMs >= 1500L) {
                    refPlayerHpFillPx = null
                    refPlayerHpBarY = -1
                    higherHpConfirmTicks = 0
                }
                zoomedWithoutHpDurationMs = 0L

                val justRegisteredHit = evaluatePlayerHpDropForFastMoves(
                    telemetry.playerHpFillPx,
                    telemetry.playerHpBarY,
                    telemetry.opponentAttackMotionRatio,
                    telemetry.targetImpactVfxRatio,
                    now
                )

                if (arenaVisualBmp != null && currentPokemon.fastMoves.size > 1) {
                    val curActiveIdx = slotFastMoveIdx[currentPokemon.id] ?: 0
                    val detectedFmIdx = visualClassifier.analyzeArenaFrame(
                        arenaVisualBmp,
                        currentPokemon,
                        curActiveIdx,
                        latestEffectivenessHint,
                        playerDefenderTypes,
                        fastHitsLandedOnCurrentPlayer,
                        justRegisteredHit
                    )
                    if (detectedFmIdx != null && detectedFmIdx != curActiveIdx) {
                        val oldFm = getActiveFastMove()
                        val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                        slotFastMoveIdx[currentPokemon.id] = detectedFmIdx
                        val newFm = getActiveFastMove()
                        if (oldCount > 0) {
                            slotEnergies[currentPokemon.id] = min(100, oldCount * newFm.energyGain)
                        }
                        ocrStatusText.text = "⚡ Auto: ${newFm.name} (${newFm.energyGain}E/${newFm.turns}T)"
                        refreshHudDisplay()
                    }
                }
            } else {
                zoomedWithoutHpDurationMs += tickMs
            }

            if (shouldRunOcrThisTick && topRightBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(topRightBmp, 0))
                    .addOnSuccessListener { topText ->
                        var matchedPoke = PvPokeRepository.matchPokemonFromHudText(topText.text, badgeTypesThisFrame)
                        if (matchedPoke != null) {
                            val baseKey = matchedPoke.name.substringBefore("(").trim().lowercase()
                            val manualId = manualFormOverrideByBase[baseKey]
                            if (manualId != null) {
                                val manualEntry = PvPokeRepository.getSiblingForms(matchedPoke).firstOrNull { it.id == manualId }
                                if (manualEntry != null) matchedPoke = manualEntry
                            }

                            seenOpponentPokemon[matchedPoke.id] = matchedPoke
                            if (!hasLockedFirstOpponentInMatch) {
                                hasLockedFirstOpponentInMatch = true
                                if (matchedPoke.id != currentPokemon.id && unassignedOpeningFastMoves > 0) {
                                    val leadFm = matchedPoke.fastMoves.first()
                                    slotEnergies[matchedPoke.id] = min(100, unassignedOpeningFastMoves * leadFm.energyGain)
                                }
                                unassignedOpeningFastMoves = 0
                            }
                            if (matchedPoke.id != currentPokemon.id) {
                                val prevBaseKey = currentPokemon.name.substringBefore("(").trim().lowercase()
                                if (prevBaseKey == baseKey && (slotEnergies[currentPokemon.id] ?: 0) > 0 && (slotEnergies[matchedPoke.id] ?: 0) == 0) {
                                    val oldFm = getActiveFastMove()
                                    val oldCount = floor((slotEnergies[currentPokemon.id] ?: 0).toDouble() / max(1, oldFm.energyGain)).toInt()
                                    seenOpponentPokemon.remove(currentPokemon.id)
                                    val newFm = getActiveFastMove(matchedPoke)
                                    slotEnergies[matchedPoke.id] = min(100, oldCount * newFm.energyGain)
                                    slotCycleIndex[matchedPoke.id] = slotCycleIndex[currentPokemon.id] ?: 0
                                    slotEnergies.remove(currentPokemon.id)
                                }
                                currentPokemon = matchedPoke
                                fastHitsLandedOnCurrentPlayer = 0
                                latestEffectivenessHint = null
                                visualClassifier.resetForNewOpponent()
                                val savedE = slotEnergies[matchedPoke.id] ?: 0
                                val savedFm = getActiveFastMove(matchedPoke)
                                val savedFastCnt = floor(savedE.toDouble() / max(1, savedFm.energyGain)).toInt()
                                ocrStatusText.text = if (savedE > 0) {
                                    "🔄 Restored ${matchedPoke.name}: $savedFastCnt Fast (${savedE}E)"
                                } else {
                                    "● Locked: ${matchedPoke.name}"
                                }
                                refreshHudDisplay()
                            } else if (!ocrStatusText.text.startsWith("⚡") && !ocrStatusText.text.startsWith("▼") && !ocrStatusText.text.startsWith("🔄")) {
                                ocrStatusText.text = "● Watching ${matchedPoke.name}"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        if (topLeftBmp != null) {
                            recognizer.process(InputImage.fromBitmap(topLeftBmp, 0))
                                .addOnSuccessListener { leftText ->
                                    val rawLeft = leftText.text
                                    val playerPoke = PvPokeRepository.matchPokemonFromHudText(rawLeft)
                                    if (playerPoke != null && playerPoke.id != currentPlayerPokemonId) {
                                        currentPlayerPokemonId = playerPoke.id
                                        currentPlayerPokemonName = playerPoke.name
                                        playerDefenderTypes = PvPokeRepository.getDefenderTypes(playerPoke)
                                        fastHitsLandedOnCurrentPlayer = 0
                                        latestEffectivenessHint = null
                                    }
                                }
                                .addOnCompleteListener {
                                    val nextBmp = bannerBmp ?: aboveHpEffBmp
                                    val isBannerCrop = (bannerBmp != null)
                                    if (nextBmp != null) {
                                        recognizer.process(InputImage.fromBitmap(nextBmp, 0))
                                            .addOnSuccessListener { subText ->
                                                val rawS = subText.text
                                                if (!isBannerCrop) {
                                                    val (_, _, effH) = PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    if (effH != null) latestEffectivenessHint = effH
                                                } else if (
                                                    isPlayerBubbleMinigameText(rawS) ||
                                                    PvPokeRepository.isPlayerOwnChargedMoveBanner(rawS, currentPlayerPokemonName, currentPokemon.name)
                                                ) {
                                                    playerUsedChargedMoveDuringZoom = true
                                                    undoFalsePlayerChargedMoveSubtractionIfNeeded()
                                                    ocrStatusText.text = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                                    refreshHudDisplay()
                                                } else {
                                                    val (_, specificMove, _) =
                                                        PvPokeRepository.detectChargedAttackAndEffectiveness(rawS, currentPokemon)
                                                    if (specificMove != null) {
                                                        reconcileChargedMoveFromBanner(specificMove)
                                                        postCutsceneBannerTicks = 0
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                                lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                                isOcrBusy = false
                                            }
                                    } else {
                                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                        isOcrBusy = false
                                    }
                                }
                        } else if (bannerBmp != null) {
                            recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                                .addOnSuccessListener { bText ->
                                    val rawB = bText.text
                                    if (
                                        isPlayerBubbleMinigameText(rawB) ||
                                        PvPokeRepository.isPlayerOwnChargedMoveBanner(rawB, currentPlayerPokemonName, currentPokemon.name)
                                    ) {
                                        playerUsedChargedMoveDuringZoom = true
                                        undoFalsePlayerChargedMoveSubtractionIfNeeded()
                                        ocrStatusText.text = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                        refreshHudDisplay()
                                    } else {
                                        val (_, specificMove, _) =
                                            PvPokeRepository.detectChargedAttackAndEffectiveness(rawB, currentPokemon)
                                        if (specificMove != null) {
                                            reconcileChargedMoveFromBanner(specificMove)
                                            postCutsceneBannerTicks = 0
                                        }
                                    }
                                }
                                .addOnCompleteListener {
                                    lastOcrCompletedTimestampMs = System.currentTimeMillis()
                                    isOcrBusy = false
                                }
                        } else {
                            lastOcrCompletedTimestampMs = System.currentTimeMillis()
                            isOcrBusy = false
                        }
                    }
            }
        } else {
            isBattleHudCurrentlyVisible = false
            hudCompletelyMissingDurationMs += tickMs

            if (hudCompletelyMissingDurationMs >= 25000L && inActiveMatch) {
                inActiveMatch = false
                resetCurrentMatchState("● Waiting for battle...")
            } else if (inActiveMatch && hudCompletelyMissingDurationMs >= 450L) {
                if (!ocrStatusText.text.startsWith("⚠️") && !ocrStatusText.text.startsWith("🛡️") && !ocrStatusText.text.startsWith("▼")) {
                    ocrStatusText.text = "⏸ Paused (Cutscene)"
                    refreshHudDisplay()
                }
            }

            if (shouldRunOcrThisTick && bannerBmp != null) {
                isOcrBusy = true
                lastOcrStartTimestampMs = now
                recognizer.process(InputImage.fromBitmap(bannerBmp, 0))
                    .addOnSuccessListener { bannerText ->
                        val rawBanner = bannerText.text
                        if (PvPokeRepository.isMenuOrPreBattleText(rawBanner)) {
                            inActiveMatch = false
                            resetCurrentMatchState("● Pre-Battle / Menu")
                        } else if (inActiveMatch) {
                            if (
                                isPlayerBubbleMinigameText(rawBanner) ||
                                PvPokeRepository.isPlayerOwnChargedMoveBanner(rawBanner, currentPlayerPokemonName, currentPokemon.name)
                            ) {
                                playerUsedChargedMoveDuringZoom = true
                                undoFalsePlayerChargedMoveSubtractionIfNeeded()
                                ocrStatusText.text = "🛡️ Your ${currentPlayerPokemonName ?: "Pokémon"} used move"
                                refreshHudDisplay()
                            } else {
                                val (isIncoming, specificMove, _) =
                                    PvPokeRepository.detectChargedAttackAndEffectiveness(rawBanner, currentPokemon)
                                if (specificMove != null) {
                                    upgradeToSiblingFormIfMoveMatches(specificMove)
                                    specificMoveDetectedDuringPause = specificMove
                                    chargedAttackDetectedDuringPause = true
                                    if (now - lastSubtractedMoveTimestamp > 3000L) {
                                        subtractChargedMoveAndUpdate(specificMove, currentPokemon.id)
                                        chargedAttackDetectedDuringPause = false
                                        specificMoveDetectedDuringPause = null
                                    } else {
                                        reconcileChargedMoveFromBanner(specificMove)
                                    }
                                } else if (isIncoming) {
                                    chargedAttackDetectedDuringPause = true
                                    ocrStatusText.text = "⚠️ Attack Incoming!"
                                    refreshHudDisplay()
                                }
                            }
                        }
                    }
                    .addOnCompleteListener {
                        lastOcrCompletedTimestampMs = System.currentTimeMillis()
                        isOcrBusy = false
                    }
            }
        }
    }

    private fun refreshHudDisplay() {
        val energy = (slotEnergies[currentPokemon.id] ?: 0).coerceIn(0, 100)
        val activeFm = getActiveFastMove()
        val eFast = max(1, activeFm.energyGain)
        val fastCount = floor(energy.toDouble() / eFast).toInt()
        val cycleIdx = slotCycleIndex[currentPokemon.id] ?: 0

        countNumberText.text = fastCount.toString()

        if (!inActiveMatch) {
            pokemonTitleText.text = "Waiting for battle..."
            swapFastMoveBtn.visibility = View.GONE
            chargedBadgesContainer.visibility = View.GONE
            benchEnergyText.visibility = View.GONE
            return
        }

        pokemonTitleText.text = "${currentPokemon.name} · ${activeFm.name} (${eFast}E/${activeFm.turns}T) [${energy}E]"
        val hasMultipleFastOrForms = currentPokemon.fastMoves.size > 1 || PvPokeRepository.getSiblingForms(currentPokemon).size > 1
        swapFastMoveBtn.visibility = if (hasMultipleFastOrForms) View.VISIBLE else View.GONE
        chargedBadgesContainer.visibility = if (manualCollapse) View.GONE else View.VISIBLE

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val paceList = currentPokemon.getPvPokeMoveCounts(activeFm, cm, 4)
            val activePaceTarget = paceList[cycleIdx % paceList.size]
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            val afterEnergy = max(0, energy - cm.energyCost)
            val afterFastCount = floor(afterEnergy.toDouble() / eFast).toInt()
            val subtractMovesCount = if (isReady) max(1, fastCount - afterFastCount) else activePaceTarget

            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4094A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val cardLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = badgeBg
                setPadding(12, 5, 12, 5)
                setOnClickListener {
                    subtractChargedMoveAndUpdate(cm, currentPokemon.id)
                }
            }

            val topLine = TextView(this).apply {
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xEEFFFFFF.toInt())
                text = if (isReady) {
                    "⚡ ${cm.name} READY (▼-$subtractMovesCount)"
                } else {
                    "${cm.name}: $fastCount/$activePaceTarget (-$neededMoves)"
                }
            }

            val formattedPace = paceList.mapIndexed { idx, v ->
                if (idx == (cycleIdx % paceList.size)) "[$v]" else "$v"
            }.joinToString(" - ")

            val bottomLine = TextView(this).apply {
                textSize = 8.5f
                setSingleLine(true)
                setTextColor(0xBB94A3B8.toInt())
                text = "Fast Move Count: $formattedPace"
            }

            cardLayout.addView(topLine)
            cardLayout.addView(bottomLine)

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 4
            }
            chargedBadgesContainer.addView(cardLayout, lp)
        }

        val benchedSummaries = seenOpponentPokemon.values
            .filter { it.id != currentPokemon.id && (slotEnergies[it.id] ?: 0) > 0 }
            .map { benchPoke ->
                val bEnergy = (slotEnergies[benchPoke.id] ?: 0).coerceIn(0, 100)
                val bFm = getActiveFastMove(benchPoke)
                val bFastCnt = floor(bEnergy.toDouble() / max(1, bFm.energyGain)).toInt()
                "${benchPoke.name}: $bFastCnt Fast (${bEnergy}E)"
            }

        if (benchedSummaries.isNotEmpty() && !manualCollapse) {
            benchEnergyText.text = "📦 Bench: ${benchedSummaries.joinToString(" · ")}"
            benchEnergyText.visibility = View.VISIBLE
        } else {
            benchEnergyText.visibility = View.GONE
        }
    }

    private fun createNotification(): Notification {
        val channelId = "pokecount_overlay_v21"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "PokéCount Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("PokéCount PvPoke Great League v21")
            .setContentText("Tracking Fast & Charged Moves (Offline Play-Protect Clean)")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
            if (::overlayRoot.isInitialized) {
                windowManager.removeView(overlayRoot)
            }
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
