package com.pokecount.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var statusText: TextView
    private lateinit var screenRecordModeCard: TextView
    private lateinit var enableAccessibilityBtn: Button
    private lateinit var startOverlayBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(56, 96, 56, 56)
            setBackgroundColor(0xFF090D16.toInt())
        }

        val title = TextView(this).apply {
            text = "PokéCount PvPoke Great League v20"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        statusText = TextView(this).apply {
            text = "Built-in: ${PvPokeRepository.BUILT_IN_POKEMON.size} Great League Pokémon · Post-Charged-Move Fix Ready"
            textSize = 12.5f
            setTextColor(0xFF34D399.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 20)
        }

        val cardBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 24f
            setColor(0xFF111827.toInt())
            setStroke(2, 0xFF334155.toInt())
        }

        screenRecordModeCard = TextView(this).apply {
            background = cardBg
            textSize = 13f
            setTextColor(0xFFE2E8F0.toInt())
            setPadding(36, 28, 36, 28)
        }

        val accBtnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 28f
            setColor(0xFF38BDF8.toInt())
        }

        enableAccessibilityBtn = Button(this).apply {
            text = "ENABLE NATIVE SCREEN-RECORD MODE"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            background = accBtnBg
            setTextColor(0xFF082F49.toInt())
            setPadding(48, 28, 48, 28)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 28
                bottomMargin = 20
            }
            layoutParams = lp
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {
                }
            }
        }

        val subtitle = TextView(this).apply {
            text = "• Zero post-Charged-Move blind window: counts Fast Attacks immediately after every Charged Move\n• Exact Charged Move banner reconciliation & PvPoke primary meta fallback\n• Native Phone Screen-Record Compatibility: tracks live while you record with your phone's built-in Screen Recorder"
            textSize = 13f
            setTextColor(0xFF94A3B8.toInt())
            setPadding(0, 16, 0, 44)
        }

        val btnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 32f
            setColor(0xFF10B981.toInt())
        }

        startOverlayBtn = Button(this).apply {
            text = "START VISUAL OVERLAY"
            textSize = 16.5f
            typeface = Typeface.DEFAULT_BOLD
            background = btnBg
            setTextColor(0xFF052E16.toInt())
            setPadding(64, 34, 64, 34)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = lp
            setOnClickListener {
                ensureOverlayPermissionAndStart()
            }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(screenRecordModeCard)
        root.addView(enableAccessibilityBtn)
        root.addView(subtitle)
        root.addView(startOverlayBtn)
        setContentView(root)

        refreshAccessibilityModeUi()

        PvPokeRepository.syncFullPvPokeGreatLeagueData(applicationContext) { totalCount ->
            runOnUiThread {
                statusText.text = "✓ Synced $totalCount PvPoke Great League Pokémon & All Fast Moves!"
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshAccessibilityModeUi()
    }

    private fun refreshAccessibilityModeUi() {
        val accEnabled = isAccessibilityCaptureEnabled()
        if (accEnabled) {
            screenRecordModeCard.text =
                "✓ Native Screen-Record Mode is ENABLED!\nYou can use your phone's built-in Screen Recorder at any time and PokéCount will keep tracking every Fast & Charged Move without stopping."
            screenRecordModeCard.setTextColor(0xFFA7F3D0.toInt())
            enableAccessibilityBtn.text = "✓ NATIVE SCREEN-RECORD MODE ACTIVE"
            enableAccessibilityBtn.alpha = 0.75f
        } else {
            screenRecordModeCard.text =
                "📹 Want to record with your phone's built-in Screen Recorder?\nAndroid only allows one MediaProjection at a time. Tap below once and turn ON \"PokéCount PvPoke v20 (Screen-Record Mode)\" in Accessibility -> Installed Apps so PokéCount can track while your phone records!"
            screenRecordModeCard.setTextColor(0xFFFDE047.toInt())
            enableAccessibilityBtn.text = "1. ENABLE NATIVE SCREEN-RECORD MODE"
            enableAccessibilityBtn.alpha = 1.0f
        }
    }

    private fun isAccessibilityCaptureEnabled(): Boolean {
        if (PokeCountAccessibilityService.isServiceEnabled()) return true
        return try {
            val enabledServices = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            enabledServices.contains(packageName, ignoreCase = true) &&
                enabledServices.contains("PokeCountAccessibilityService", ignoreCase = true)
        } catch (_: Exception) {
            false
        }
    }

    private fun ensureOverlayPermissionAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY_PERMISSION)
            return
        }

        // If Native Screen-Record Mode (AccessibilityService) is active, start the overlay directly
        // WITHOUT requesting MediaProjection so the phone's native Screen Recorder is 100% free!
        if (PokeCountAccessibilityService.isServiceEnabled()) {
            val serviceIntent = Intent(this, OverlayVisionService::class.java)
            startForegroundService(serviceIntent)
            moveTaskToBack(true)
            return
        }

        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY_PERMISSION && Settings.canDrawOverlays(this)) {
            ensureOverlayPermissionAndStart()
        } else if (requestCode == REQ_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, OverlayVisionService::class.java).apply {
                putExtra(OverlayVisionService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OverlayVisionService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(serviceIntent)
            moveTaskToBack(true)
        }
    }

    companion object {
        private const val REQ_OVERLAY_PERMISSION = 1001
        private const val REQ_MEDIA_PROJECTION = 1002
    }
}
