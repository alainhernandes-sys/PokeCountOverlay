package com.pokecount.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var statusText: TextView
    private lateinit var actionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(64, 110, 64, 64)
            setBackgroundColor(0xFF090D16.toInt())
        }

        val title = TextView(this).apply {
            text = "GL Match Calc v24"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        statusText = TextView(this).apply {
            text = "Built-in: ${PvPokeRepository.BUILT_IN_POKEMON.size} Great League Pokémon · Hybrid Engine v24 Ready"
            textSize = 13f
            setTextColor(0xFF34D399.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }

        val subtitle = TextView(this).apply {
            text = "• Position-Independent Dual HP-Bar + Box-Border Scanner: tracks every Pokémon regardless of HP bar height, vertical lunges, or overlay placement\n• Opening Full-HP Lead Anchor + Cumulative Segment Reconciliation: catches opening moves during \"GO!\" and reconciles 100% of fast moves before every Charged Move\n• Play Protect & Samsung One UI Hardened Release Build"
            textSize = 14f
            setTextColor(0xFF94A3B8.toInt())
            setPadding(0, 12, 0, 64)
        }

        val btnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 32f
            setColor(0xFF10B981.toInt())
        }

        actionButton = Button(this).apply {
            text = if (Settings.canDrawOverlays(this@MainActivity)) {
                "START MATCH HUD OVERLAY"
            } else {
                "STEP 1: GRANT OVERLAY PERMISSION"
            }
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            background = btnBg
            setTextColor(0xFF052E16.toInt())
            setPadding(64, 36, 64, 36)
            setOnClickListener {
                onActionButtonClicked()
            }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(subtitle)
        root.addView(actionButton)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (::actionButton.isInitialized) {
            actionButton.text = if (Settings.canDrawOverlays(this)) {
                "START MATCH HUD OVERLAY"
            } else {
                "STEP 1: GRANT OVERLAY PERMISSION"
            }
        }
    }

    private fun onActionButtonClicked() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        @Suppress("DEPRECATION")
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, OverlayVisionService::class.java).apply {
                putExtra(OverlayVisionService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OverlayVisionService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(serviceIntent)
            statusText.text = "● Match HUD Active — Switch to Pokémon GO"
            actionButton.text = "HUD RUNNING (TAP TO RESTART)"
        }
    }

    companion object {
        private const val REQ_MEDIA_PROJECTION = 1002
    }
}
