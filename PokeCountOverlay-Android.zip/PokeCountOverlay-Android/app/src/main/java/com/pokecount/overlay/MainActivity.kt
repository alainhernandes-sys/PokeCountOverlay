package com.pokecount.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var statusText: TextView
    private lateinit var actionButton: Button
    private lateinit var a11yButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(64, 96, 64, 64)
            setBackgroundColor(0xFF090D16.toInt())
        }

        val title = TextView(this).apply {
            text = "GL Match Calc v64"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        statusText = TextView(this).apply {
            text = "Built-in: ${PvPokeRepository.BUILT_IN_POKEMON.size} Great League Pokémon · Engine v64 Ready"
            textSize = 13f
            setTextColor(0xFF34D399.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 20)
        }

        val subtitle = TextView(this).apply {
            text = "• Shows "v64" on the floating overlay badge & header
• True 3E/1T Dragon Breath & 1-turn cadence tracking + post-Charged-Move 400ms recovery buffer
• Samsung Native Screen Recorder Compatibility (Dual-Recorder Accessibility fallback so recording never pauses capture!)"
            textSize = 14f
            setTextColor(0xFF94A3B8.toInt())
            setPadding(0, 12, 0, 48)
        }

        val btnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 32f
            setColor(0xFF10B981.toInt())
        }

        actionButton = Button(this).apply {
            text = if (Settings.canDrawOverlays(this@MainActivity)) {
                "START MATCH HUD OVERLAY (v64)"
            } else {
                "STEP 1: GRANT OVERLAY PERMISSION"
            }
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            background = btnBg
            setTextColor(0xFF052E16.toInt())
            setPadding(64, 36, 64, 36)
            setOnClickListener {
                onActionButtonClicked()
            }
        }

        val a11yBtnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 28f
            setColor(0xFF1E293B.toInt())
            setStroke(2, 0xFF38BDF8.toInt())
        }

        a11yButton = Button(this).apply {
            text = getA11yButtonText()
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            background = a11yBtnBg
            setTextColor(0xFF7DD3FC.toInt())
            setPadding(48, 28, 48, 28)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 28
            }
            layoutParams = lp
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(subtitle)
        root.addView(actionButton)
        root.addView(a11yButton)
        setContentView(root)
    }

    private fun getA11yButtonText(): String {
        return if (PokeCountAccessibilityService.instance != null) {
            "✓ SCREEN-RECORDER COMPATIBILITY ENABLED"
        } else {
            "ENABLE SCREEN-RECORDER COMPATIBILITY (ACCESSIBILITY)"
        }
    }

    override fun onResume() {
        super.onResume()
        if (::actionButton.isInitialized) {
            actionButton.text = if (Settings.canDrawOverlays(this)) {
                "START MATCH HUD OVERLAY (v64)"
            } else {
                "STEP 1: GRANT OVERLAY PERMISSION"
            }
        }
        if (::a11yButton.isInitialized) {
            a11yButton.text = getA11yButtonText()
        }
    }

    private fun onActionButtonClicked() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        @Suppress("DEPRECATION")
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, OverlayVisionService::class.java).apply {
                putExtra(OverlayVisionService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OverlayVisionService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(serviceIntent)
            statusText.text = "● Match HUD v64 Active — Switch to Pokémon GO"
            actionButton.text = "HUD v64 RUNNING (TAP TO RESTART)"
        }
    }

    companion object {
        private const val REQ_MEDIA_PROJECTION = 1002
    }
}
