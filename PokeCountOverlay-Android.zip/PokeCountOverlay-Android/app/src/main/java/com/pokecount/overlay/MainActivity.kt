package com.pokecount.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(60, 100, 60, 60)
            setBackgroundColor(0xFF090D16.toInt())
        }

        val title = TextView(this).apply {
            text = "PokéCount PvPoke Great League v21"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        statusText = TextView(this).apply {
            text = "✓ 100% Offline PvPoke Database (${PvPokeRepository.BUILT_IN_POKEMON.size} Great League Pokémon) · Play Protect Clean"
            textSize = 13f
            setTextColor(0xFF34D399.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }

        val subtitle = TextView(this).apply {
            text = "• Zero post-Charged-Move blind window: counts Fast Attacks immediately after every Charged Move\n• Exact Charged Move banner reconciliation & PvPoke primary meta fallback\n• Native Phone Screen Recording tip: start your phone's Screen Recorder first, then tap START VISUAL OVERLAY (or tap [🔄Resume] on the overlay if interrupted)"
            textSize = 13.5f
            setTextColor(0xFF94A3B8.toInt())
            setPadding(0, 12, 0, 56)
        }

        val btnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 32f
            setColor(0xFF10B981.toInt())
        }

        val startOverlayBtn = Button(this).apply {
            text = "START VISUAL OVERLAY"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            background = btnBg
            setTextColor(0xFF052E16.toInt())
            setPadding(72, 36, 72, 36)
            setOnClickListener {
                ensureOverlayPermissionAndStart()
            }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(subtitle)
        root.addView(startOverlayBtn)
        setContentView(root)

        if (intent?.getBooleanExtra(EXTRA_AUTO_PROMPT_CAPTURE, false) == true) {
            intent?.removeExtra(EXTRA_AUTO_PROMPT_CAPTURE)
            ensureOverlayPermissionAndStart()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra(EXTRA_AUTO_PROMPT_CAPTURE, false) == true) {
            intent.removeExtra(EXTRA_AUTO_PROMPT_CAPTURE)
            ensureOverlayPermissionAndStart()
        }
    }

    private fun ensureOverlayPermissionAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY_PERMISSION)
            return
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY_PERMISSION && Settings.canDrawOverlays(this)) {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
        } else if (requestCode == REQ_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, OverlayVisionService::class.java).apply {
                putExtra(OverlayVisionService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OverlayVisionService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(serviceIntent)
            moveTaskToBack(true)
        }
    }

    companion object {
        private const val REQ_OVERLAY_PERMISSION = 1001
        private const val REQ_MEDIA_PROJECTION = 1002
        const val EXTRA_AUTO_PROMPT_CAPTURE = "extra_auto_prompt_capture"
    }
}
