package com.pokecount.overlay

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import kotlin.math.max

/**
 * Optional AccessibilityService fallback that uses [takeScreenshot] on Android 11+ (API 30+)
 * whenever Samsung's native Screen Recorder (or another recorder) revokes our MediaProjection,
 * allowing simultaneous native screen recording and live PvP move counting.
 */
class PokeCountAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No UI event inspection needed; used strictly for takeScreenshot fallback when MediaProjection is revoked.
    }

    override fun onInterrupt() {
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) {
            instance = null
        }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    fun captureAccessibilityFrame(onBitmapReady: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            onBitmapReady(null)
            return
        }
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val hwBuffer = screenshot.hardwareBuffer
                        val colorSpace = screenshot.colorSpace
                        var outBmp: Bitmap? = null
                        try {
                            val wrapped = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                            if (wrapped != null) {
                                val swBmp = wrapped.copy(Bitmap.Config.ARGB_8888, false)
                                wrapped.recycle()
                                if (swBmp != null) {
                                    val targetW = max(360, swBmp.width / 2)
                                    val targetH = max(720, swBmp.height / 2)
                                    outBmp = if (swBmp.width != targetW || swBmp.height != targetH) {
                                        val scaled = Bitmap.createScaledBitmap(swBmp, targetW, targetH, false)
                                        if (scaled !== swBmp) swBmp.recycle()
                                        scaled
                                    } else {
                                        swBmp
                                    }
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            try {
                                hwBuffer.close()
                            } catch (_: Exception) {
                            }
                        }
                        onBitmapReady(outBmp)
                    }

                    override fun onFailure(errorCode: Int) {
                        onBitmapReady(null)
                    }
                }
            )
        } catch (_: Exception) {
            onBitmapReady(null)
        }
    }

    companion object {
        @Volatile
        var instance: PokeCountAccessibilityService? = null
            private set
    }
}
