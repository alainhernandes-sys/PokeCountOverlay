package com.pokecount.overlay

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.ColorSpace
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors

/**
 * Allows PokéCount to capture screen frames via Android 11+ (API 30+)
 * AccessibilityService.takeScreenshot(Display.DEFAULT_DISPLAY, ...) WITHOUT using MediaProjection!
 *
 * Why this solves native phone screen recording:
 * Android OS only allows ONE active MediaProjection session across the entire phone.
 * When you start your phone's built-in Screen Recorder, Android OS revokes any app's
 * MediaProjection session. By capturing frames through AccessibilityService.takeScreenshot(),
 * PokéCount never touches MediaProjection while you record your screen natively!
 */
class PokeCountAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PokeCountAccessibilityService? = null
            private set

        @Volatile
        private var lastAcceptedShotMs: Long = 0L

        @Volatile
        private var captureInFlight: Boolean = false

        @Volatile
        private var inFlightStartMs: Long = 0L

        private val screenshotExecutor = Executors.newSingleThreadExecutor()

        fun isServiceEnabled(): Boolean = instance != null

        /**
         * Requests a screen capture via WindowManager's Accessibility screenshot API (API 30+).
         * Converts the returned HardwareBuffer into a 50%-scaled ARGB_8888 software Bitmap
         * for fast pixel scanning and ML Kit OCR.
         */
        fun requestScreenBitmap(onBitmapReady: (Bitmap) -> Unit) {
            val svc = instance ?: return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
            val now = System.currentTimeMillis()

            // Watchdog in case a callback is ever dropped by the OS
            if (captureInFlight && (now - inFlightStartMs) > 1500L) {
                captureInFlight = false
            }

            // Android 11-14 enforces a 333ms minimum interval between takeScreenshot() calls.
            // Spacing requests by >= 340ms guarantees every call succeeds on the first try.
            if (captureInFlight || (now - lastAcceptedShotMs) < 340L) return

            captureInFlight = true
            inFlightStartMs = now
            lastAcceptedShotMs = now

            try {
                svc.takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    screenshotExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshotResult: ScreenshotResult) {
                            try {
                                val hwBuffer = screenshotResult.hardwareBuffer
                                val colorSpace = screenshotResult.colorSpace ?: ColorSpace.get(ColorSpace.Named.SRGB)
                                val hwBitmap = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                                if (hwBitmap != null) {
                                    val targetW = (hwBitmap.width / 2).coerceAtLeast(1)
                                    val targetH = (hwBitmap.height / 2).coerceAtLeast(1)
                                    val softFull = hwBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                    hwBitmap.recycle()
                                    hwBuffer.close()
                                    if (softFull != null) {
                                        val scaled = Bitmap.createScaledBitmap(softFull, targetW, targetH, false)
                                        if (scaled !== softFull) {
                                            softFull.recycle()
                                        }
                                        captureInFlight = false
                                        onBitmapReady(scaled)
                                        return
                                    }
                                } else {
                                    hwBuffer.close()
                                }
                            } catch (_: Exception) {
                            }
                            captureInFlight = false
                        }

                        override fun onFailure(errorCode: Int) {
                            // Allow retry on the next 100ms tick if rate-limited
                            lastAcceptedShotMs = System.currentTimeMillis() - 260L
                            captureInFlight = false
                        }
                    }
                )
            } catch (_: Exception) {
                captureInFlight = false
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No accessibility event inspection needed; only used for non-MediaProjection screen capture.
    }

    override fun onInterrupt() {
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }
}
