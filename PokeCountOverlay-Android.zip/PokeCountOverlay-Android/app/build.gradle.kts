plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pokecount.overlay"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gltrainer.matchcalc.v38"
        minSdk = 26
        targetSdk = 34
        versionCode = 38
        versionName = "38.0.0"
    }

    signingConfigs {
        create("customRelease") {
            val ksFile = file("release.jks")
            if (ksFile.exists()) {
                storeFile = ksFile
                storePassword = "poke25release"
                keyAlias = "poke25key"
                keyPassword = "poke25release"
                enableV1Signing = true
                enableV2Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            val ksFile = file("release.jks")
            if (ksFile.exists()) {
                signingConfig = signingConfigs.getByName("customRelease")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            val ksFile = file("release.jks")
            if (ksFile.exists()) {
                signingConfig = signingConfigs.getByName("customRelease")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
