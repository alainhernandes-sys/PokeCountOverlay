# PokéCount Stealth Overlay v3 (Native Android APK Project)

## What's Fixed in v3 (Based on Your Entei Battle Screenshot)
1. **Accurate Top-Right Opponent OCR (`Entei` & 200+ Pokémon)**:
   - Crops **strictly the Top-Right Opponent HUD box (`x: 55%..99%, y: 1%..9.5%`)** where `CP 4163 Entei` appears, so it never accidentally reads your left-side Pokémon (`Haxorus`) or the overlay's own text.
   - Includes **Entei** and 200+ Great League, Ultra League, Master League, Raid, and Team Leader Pokémon, plus fuzzy OCR matching and dynamic name fallback so any Pokémon on screen is identified immediately.
   - Only counts Fast Moves while an active battle HUD (`CP` / Opponent Nameplate) is visible on screen, resetting cleanly between battles instead of counting up to 77E in menus.
2. **Ultra-Discreet "Ghost Stealth" Opacity & Subtle Colors**:
   - Replaced the solid dark blue box and bright neon borders with a **28% opacity see-through smoke-glass pill (`#47090D14`)** and soft, muted text colors so you can see right through the overlay during battle.
   - All Charged Move pills are strictly **single-line (`singleLine = true`)** so text never wraps awkwardly like `Cr / unch`.
   - Added a **`◐` Opacity Button** directly on the overlay to cycle live between **25% Ghost Stealth**, **45% Soft Smoke**, and **65% Dark Glass**, plus tap the Fast Move number circle to collapse/expand the move pills anytime.
