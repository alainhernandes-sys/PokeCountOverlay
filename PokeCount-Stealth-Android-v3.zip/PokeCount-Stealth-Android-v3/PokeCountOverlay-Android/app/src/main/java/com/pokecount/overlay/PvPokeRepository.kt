package com.pokecount.overlay

import kotlin.math.min

data class FastMove(val name: String, val type: String, val energyGain: Int, val turns: Int)
data class ChargedMove(val name: String, val type: String, val energyCost: Int, val icon: String)
data class PvPokeEntry(
    val id: String,
    val name: String,
    val fastMove: FastMove,
    val chargedMoves: List<ChargedMove>
)

object PvPokeRepository {
    private fun fm(name: String, type: String, e: Int, t: Int) = FastMove(name, type, e, t)
    private fun cm(name: String, type: String, cost: Int, icon: String) = ChargedMove(name, type, cost, icon)

    val META_POKEMON: List<PvPokeEntry> = listOf(
        // Team Leader / Master League / Legendaries & Mythicals
        PvPokeEntry("entei", "Entei", fm("Fire Spin", "fire", 10, 3), listOf(
            cm("Flame Charge", "fire", 50, "🔥"),
            cm("Scorching Sands", "ground", 50, "⛰️"),
            cm("Iron Head", "steel", 50, "⚙️"),
            cm("Overheat", "fire", 55, "💥")
        )),
        PvPokeEntry("raikou", "Raikou", fm("Volt Switch", "electric", 16, 4), listOf(
            cm("Wild Charge", "electric", 45, "⚡"),
            cm("Shadow Ball", "ghost", 55, "👻")
        )),
        PvPokeEntry("suicune", "Suicune", fm("Snarl", "dark", 13, 3), listOf(
            cm("Bubble Beam", "water", 40, "💧"),
            cm("Ice Beam", "ice", 55, "❄️"),
            cm("Scald", "water", 55, "💧")
        )),
        PvPokeEntry("moltres", "Moltres", fm("Wing Attack", "flying", 8, 2), listOf(
            cm("Sky Attack", "flying", 55, "🦅"),
            cm("Ancient Power", "rock", 45, "🪨"),
            cm("Overheat", "fire", 55, "🔥")
        )),
        PvPokeEntry("zapdos", "Zapdos", fm("Thunder Shock", "electric", 9, 2), listOf(
            cm("Drill Peck", "flying", 40, "🦅"),
            cm("Thunderbolt", "electric", 55, "⚡")
        )),
        PvPokeEntry("articuno", "Articuno", fm("Ice Shard", "ice", 10, 3), listOf(
            cm("Icy Wind", "ice", 45, "❄️"),
            cm("Ancient Power", "rock", 45, "🪨")
        )),
        PvPokeEntry("salamence", "Salamence", fm("Dragon Tail", "dragon", 9, 3), listOf(
            cm("Fly", "flying", 45, "🦅"),
            cm("Outrage", "dragon", 60, "🐉"),
            cm("Fire Blast", "fire", 80, "🔥")
        )),
        PvPokeEntry("electivire", "Electivire", fm("Thunder Shock", "electric", 9, 2), listOf(
            cm("Ice Punch", "ice", 40, "❄️"),
            cm("Wild Charge", "electric", 45, "⚡"),
            cm("Flamethrower", "fire", 55, "🔥")
        )),
        PvPokeEntry("milotic", "Milotic", fm("Dragon Tail", "dragon", 9, 3), listOf(
            cm("Surf", "water", 40, "💧"),
            cm("Blizzard", "ice", 75, "❄️")
        )),
        PvPokeEntry("tyranitar", "Tyranitar", fm("Smack Down", "rock", 8, 3), listOf(
            cm("Brutal Swing", "dark", 40, "🌑"),
            cm("Stone Edge", "rock", 55, "🪨")
        )),
        PvPokeEntry("metagross", "Metagross", fm("Bullet Punch", "steel", 7, 2), listOf(
            cm("Meteor Mash", "steel", 50, "⚙️"),
            cm("Earthquake", "ground", 65, "⛰️")
        )),
        PvPokeEntry("garchomp", "Garchomp", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Sand Tomb", "ground", 40, "⛰️"),
            cm("Outrage", "dragon", 60, "🐉"),
            cm("Earth Power", "ground", 55, "⛰️")
        )),
        PvPokeEntry("haxorus", "Haxorus", fm("Counter", "fighting", 6, 2), listOf(
            cm("Breaking Swipe", "dragon", 35, "🐉"),
            cm("Night Slash", "dark", 35, "🌑"),
            cm("Earthquake", "ground", 65, "⛰️")
        )),
        PvPokeEntry("mewtwo", "Mewtwo", fm("Psycho Cut", "psychic", 9, 2), listOf(
            cm("Psystrike", "psychic", 45, "🔮"),
            cm("Shadow Ball", "ghost", 55, "👻"),
            cm("Ice Beam", "ice", 55, "❄️")
        )),
        PvPokeEntry("kyogre", "Kyogre", fm("Waterfall", "water", 8, 3), listOf(
            cm("Surf", "water", 40, "💧"),
            cm("Origin Pulse", "water", 60, "💧"),
            cm("Thunder", "electric", 60, "⚡")
        )),
        PvPokeEntry("groudon", "Groudon", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Fire Punch", "fire", 40, "🔥"),
            cm("Precipice Blades", "ground", 60, "⛰️")
        )),
        PvPokeEntry("rayquaza", "Rayquaza", fm("Dragon Tail", "dragon", 9, 3), listOf(
            cm("Breaking Swipe", "dragon", 35, "🐉"),
            cm("Dragon Ascent", "flying", 70, "🦅")
        )),
        PvPokeEntry("lugia", "Lugia", fm("Dragon Tail", "dragon", 9, 3), listOf(
            cm("Sky Attack", "flying", 55, "🦅"),
            cm("Aeroblast", "flying", 75, "🦅")
        )),
        PvPokeEntry("ho-oh", "Ho-Oh", fm("Incinerate", "fire", 20, 5), listOf(
            cm("Sacred Fire", "fire", 65, "🔥"),
            cm("Brave Bird", "flying", 55, "🦅")
        )),
        PvPokeEntry("dialga", "Dialga", fm("Dragon Breath", "dragon", 3, 1), listOf(
            cm("Iron Head", "steel", 50, "⚙️"),
            cm("Roar of Time", "dragon", 65, "🐉"),
            cm("Draco Meteor", "dragon", 65, "🐉")
        )),
        PvPokeEntry("palkia", "Palkia", fm("Dragon Breath", "dragon", 3, 1), listOf(
            cm("Aqua Tail", "water", 35, "💧"),
            cm("Spacial Rend", "dragon", 50, "🐉")
        )),
        PvPokeEntry("giratina", "Giratina", fm("Shadow Claw", "ghost", 8, 2), listOf(
            cm("Dragon Claw", "dragon", 35, "🐉"),
            cm("Shadow Sneak", "ghost", 45, "👻"),
            cm("Shadow Ball", "ghost", 55, "👻")
        )),
        PvPokeEntry("landorus", "Landorus", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Sandsear Storm", "ground", 45, "⛰️"),
            cm("Stone Edge", "rock", 55, "🪨"),
            cm("Superpower", "fighting", 40, "🥊")
        )),
        PvPokeEntry("zacian", "Zacian", fm("Snarl", "dark", 13, 3), listOf(
            cm("Close Combat", "fighting", 45, "🥊"),
            cm("Wild Charge", "electric", 45, "⚡"),
            cm("Play Rough", "fairy", 60, "✨")
        )),
        PvPokeEntry("xerneas", "Xerneas", fm("Geomancy", "fairy", 13, 3), listOf(
            cm("Close Combat", "fighting", 45, "🥊"),
            cm("Moonblast", "fairy", 60, "✨")
        )),
        PvPokeEntry("yveltal", "Yveltal", fm("Sucker Punch", "dark", 7, 2), listOf(
            cm("Dark Pulse", "dark", 50, "🌑"),
            cm("Oblivion Wing", "flying", 50, "🦅"),
            cm("Focus Blast", "fighting", 75, "🥊")
        )),
        PvPokeEntry("zygarde", "Zygarde", fm("Dragon Tail", "dragon", 9, 3), listOf(
            cm("Crunch", "dark", 45, "🌑"),
            cm("Earthquake", "ground", 65, "⛰️")
        )),
        PvPokeEntry("solgaleo", "Solgaleo", fm("Fire Spin", "fire", 10, 3), listOf(
            cm("Psychic Fangs", "psychic", 35, "🔮"),
            cm("Iron Head", "steel", 50, "⚙️")
        )),
        PvPokeEntry("necrozma", "Necrozma", fm("Shadow Claw", "ghost", 8, 2), listOf(
            cm("Dark Pulse", "dark", 50, "🌑"),
            cm("Sunsteel Strike", "steel", 65, "⚙️"),
            cm("Moongeist Beam", "ghost", 65, "👻")
        )),
        PvPokeEntry("rhyperior", "Rhyperior", fm("Mud Slap", "ground", 10, 3), listOf(
            cm("Breaking Swipe", "dragon", 35, "🐉"),
            cm("Rock Wrecker", "rock", 50, "🪨"),
            cm("Surf", "water", 40, "💧")
        )),
        PvPokeEntry("dragonite", "Dragonite", fm("Dragon Breath", "dragon", 3, 1), listOf(
            cm("Dragon Claw", "dragon", 35, "🐉"),
            cm("Superpower", "fighting", 40, "🥊")
        )),
        PvPokeEntry("excadrill", "Excadrill", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Drill Run", "ground", 45, "⛰️"),
            cm("Rock Slide", "rock", 45, "🪨")
        )),
        PvPokeEntry("mamoswine", "Mamoswine", fm("Powder Snow", "ice", 8, 2), listOf(
            cm("Avalanche", "ice", 45, "❄️"),
            cm("High Horsepower", "ground", 60, "⛰️")
        )),
        PvPokeEntry("togekiss", "Togekiss", fm("Charm", "fairy", 6, 3), listOf(
            cm("Ancient Power", "rock", 45, "🪨"),
            cm("Aura Sphere", "fighting", 55, "🥊")
        )),
        PvPokeEntry("florges", "Florges", fm("Fairy Wind", "fairy", 9, 2), listOf(
            cm("Disarming Voice", "fairy", 45, "✨"),
            cm("Moonblast", "fairy", 60, "✨")
        )),
        PvPokeEntry("primarina", "Primarina", fm("Charm", "fairy", 6, 3), listOf(
            cm("Hydro Cannon", "water", 40, "💧"),
            cm("Disarming Voice", "fairy", 45, "✨")
        )),
        PvPokeEntry("gyarados", "Gyarados", fm("Dragon Breath", "dragon", 3, 1), listOf(
            cm("Aqua Tail", "water", 35, "💧"),
            cm("Crunch", "dark", 45, "🌑")
        )),
        PvPokeEntry("snorlax", "Snorlax", fm("Lick", "ghost", 3, 1), listOf(
            cm("Body Slam", "normal", 35, "⭐"),
            cm("Superpower", "fighting", 40, "🥊")
        )),
        PvPokeEntry("ursaluna", "Ursaluna", fm("Tackle", "normal", 3, 1), listOf(
            cm("Ice Punch", "ice", 40, "❄️"),
            cm("High Horsepower", "ground", 60, "⛰️")
        )),
        PvPokeEntry("melmetal", "Melmetal", fm("Thunder Shock", "electric", 9, 2), listOf(
            cm("Rock Slide", "rock", 45, "🪨"),
            cm("Superpower", "fighting", 40, "🥊"),
            cm("Double Iron Bash", "steel", 35, "⚙️")
        )),
        PvPokeEntry("machamp", "Machamp", fm("Counter", "fighting", 6, 2), listOf(
            cm("Cross Chop", "fighting", 35, "🥊"),
            cm("Rock Slide", "rock", 45, "🪨")
        )),
        PvPokeEntry("lucario", "Lucario", fm("Force Palm", "fighting", 13, 3), listOf(
            cm("Power-Up Punch", "fighting", 35, "🥊"),
            cm("Shadow Ball", "ghost", 55, "👻"),
            cm("Aura Sphere", "fighting", 55, "🥊")
        )),
        // Great League & Ultra League Core Meta
        PvPokeEntry("feraligatr", "Feraligatr", fm("Shadow Claw", "ghost", 8, 2), listOf(
            cm("Hydro Cannon", "water", 40, "💧"),
            cm("Ice Beam", "ice", 55, "❄️"),
            cm("Crunch", "dark", 45, "🌑")
        )),
        PvPokeEntry("clodsire", "Clodsire", fm("Poison Sting", "poison", 10, 2), listOf(
            cm("Earthquake", "ground", 65, "⛰️"),
            cm("Stone Edge", "rock", 55, "🪨"),
            cm("Sludge Bomb", "poison", 50, "☠️")
        )),
        PvPokeEntry("azumarill", "Azumarill", fm("Bubble", "water", 11, 3), listOf(
            cm("Ice Beam", "ice", 55, "❄️"),
            cm("Play Rough", "fairy", 60, "✨"),
            cm("Hydro Pump", "water", 75, "💧")
        )),
        PvPokeEntry("mandibuzz", "Mandibuzz", fm("Snarl", "dark", 13, 3), listOf(
            cm("Dark Pulse", "dark", 50, "🌑"),
            cm("Aerial Ace", "flying", 40, "🦅")
        )),
        PvPokeEntry("annihilape", "Annihilape", fm("Karate Chop", "fighting", 9, 2), listOf(
            cm("Rage Fist", "ghost", 35, "👻"),
            cm("Shadow Ball", "ghost", 55, "👻"),
            cm("Close Combat", "fighting", 45, "🥊")
        )),
        PvPokeEntry("gastrodon", "Gastrodon", fm("Mud Slap", "ground", 10, 3), listOf(
            cm("Body Slam", "normal", 35, "⭐"),
            cm("Earth Power", "ground", 55, "⛰️")
        )),
        PvPokeEntry("talonflame", "Talonflame", fm("Incinerate", "fire", 20, 5), listOf(
            cm("Flame Charge", "fire", 50, "🔥"),
            cm("Fly", "flying", 45, "🦅"),
            cm("Brave Bird", "flying", 55, "🦅")
        )),
        PvPokeEntry("swampert", "Swampert", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Hydro Cannon", "water", 40, "💧"),
            cm("Earthquake", "ground", 65, "⛰️")
        )),
        PvPokeEntry("whiscash", "Whiscash", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Mud Bomb", "ground", 40, "⛰️"),
            cm("Scald", "water", 55, "💧"),
            cm("Blizzard", "ice", 75, "❄️")
        )),
        PvPokeEntry("skarmory", "Skarmory", fm("Steel Wing", "steel", 6, 2), listOf(
            cm("Sky Attack", "flying", 55, "🦅"),
            cm("Brave Bird", "flying", 55, "🦅")
        )),
        PvPokeEntry("bastiodon", "Bastiodon", fm("Smack Down", "rock", 8, 3), listOf(
            cm("Stone Edge", "rock", 55, "🪨"),
            cm("Flamethrower", "fire", 55, "🔥")
        )),
        PvPokeEntry("wigglytuff", "Wigglytuff", fm("Charm", "fairy", 6, 3), listOf(
            cm("Icy Wind", "ice", 45, "❄️"),
            cm("Swift", "normal", 35, "⭐")
        )),
        PvPokeEntry("dunsparce", "Dunsparce", fm("Rollout", "rock", 13, 3), listOf(
            cm("Drill Run", "ground", 45, "⛰️"),
            cm("Rock Slide", "rock", 45, "🪨")
        )),
        PvPokeEntry("drapion", "Drapion", fm("Poison Sting", "poison", 10, 2), listOf(
            cm("Aqua Tail", "water", 35, "💧"),
            cm("Crunch", "dark", 45, "🌑")
        )),
        PvPokeEntry("serperior", "Serperior", fm("Vine Whip", "grass", 8, 2), listOf(
            cm("Frenzy Plant", "grass", 45, "🌿"),
            cm("Aerial Ace", "flying", 40, "🦅")
        )),
        PvPokeEntry("jumpluff", "Jumpluff", fm("Fairy Wind", "fairy", 9, 2), listOf(
            cm("Aerial Ace", "flying", 40, "🦅"),
            cm("Energy Ball", "grass", 55, "🌿")
        )),
        PvPokeEntry("lickilicky", "Lickilicky", fm("Rollout", "rock", 13, 3), listOf(
            cm("Body Slam", "normal", 35, "⭐"),
            cm("Shadow Ball", "ghost", 55, "👻")
        )),
        PvPokeEntry("toxapex", "Toxapex", fm("Poison Jab", "poison", 7, 2), listOf(
            cm("Brine", "water", 40, "💧"),
            cm("Sludge Wave", "poison", 65, "☠️")
        )),
        PvPokeEntry("dewgong", "Dewgong", fm("Ice Shard", "ice", 10, 3), listOf(
            cm("Icy Wind", "ice", 45, "❄️"),
            cm("Drill Run", "ground", 45, "⛰️")
        )),
        PvPokeEntry("sandslash", "Sandslash", fm("Shadow Claw", "ghost", 8, 2), listOf(
            cm("Ice Punch", "ice", 40, "❄️"),
            cm("Drill Run", "ground", 45, "⛰️")
        )),
        PvPokeEntry("carbink", "Carbink", fm("Rock Throw", "rock", 5, 2), listOf(
            cm("Rock Slide", "rock", 45, "🪨"),
            cm("Moonblast", "fairy", 60, "✨")
        )),
        PvPokeEntry("cresselia", "Cresselia", fm("Psycho Cut", "psychic", 9, 2), listOf(
            cm("Grass Knot", "grass", 50, "🌿"),
            cm("Moonblast", "fairy", 60, "✨")
        )),
        PvPokeEntry("venusaur", "Venusaur", fm("Vine Whip", "grass", 8, 2), listOf(
            cm("Frenzy Plant", "grass", 45, "🌿"),
            cm("Sludge Bomb", "poison", 50, "☠️")
        )),
        PvPokeEntry("charizard", "Charizard", fm("Wing Attack", "flying", 8, 2), listOf(
            cm("Dragon Claw", "dragon", 35, "🐉"),
            cm("Blast Burn", "fire", 50, "🔥")
        )),
        PvPokeEntry("blastoise", "Blastoise", fm("Rollout", "rock", 13, 3), listOf(
            cm("Hydro Cannon", "water", 40, "💧"),
            cm("Ice Beam", "ice", 55, "❄️")
        )),
        PvPokeEntry("greninja", "Greninja", fm("Water Shuriken", "water", 14, 3), listOf(
            cm("Night Slash", "dark", 35, "🌑"),
            cm("Hydro Cannon", "water", 40, "💧")
        )),
        PvPokeEntry("skeledirge", "Skeledirge", fm("Incinerate", "fire", 20, 5), listOf(
            cm("Disarming Voice", "fairy", 45, "✨"),
            cm("Shadow Ball", "ghost", 55, "👻")
        )),
        PvPokeEntry("umbreon", "Umbreon", fm("Snarl", "dark", 13, 3), listOf(
            cm("Foul Play", "dark", 45, "🌑"),
            cm("Last Resort", "normal", 55, "⭐")
        )),
        PvPokeEntry("medicham", "Medicham", fm("Counter", "fighting", 6, 2), listOf(
            cm("Ice Punch", "ice", 40, "❄️"),
            cm("Psychic", "psychic", 55, "🔮")
        )),
        PvPokeEntry("sableye", "Sableye", fm("Shadow Claw", "ghost", 8, 2), listOf(
            cm("Foul Play", "dark", 45, "🌑"),
            cm("Power Gem", "rock", 60, "🪨")
        )),
        PvPokeEntry("trevenant", "Trevenant", fm("Shadow Claw", "ghost", 8, 2), listOf(
            cm("Seed Bomb", "grass", 45, "🌿"),
            cm("Shadow Ball", "ghost", 55, "👻")
        )),
        PvPokeEntry("jellicent", "Jellicent", fm("Hex", "ghost", 11, 3), listOf(
            cm("Surf", "water", 40, "💧"),
            cm("Shadow Ball", "ghost", 55, "👻")
        )),
        PvPokeEntry("lanturn", "Lanturn", fm("Spark", "electric", 7, 2), listOf(
            cm("Surf", "water", 40, "💧"),
            cm("Thunderbolt", "electric", 55, "⚡")
        )),
        PvPokeEntry("quagsire", "Quagsire", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Aqua Tail", "water", 35, "💧"),
            cm("Stone Edge", "rock", 55, "🪨")
        )),
        PvPokeEntry("poliwrath", "Poliwrath", fm("Counter", "fighting", 6, 2), listOf(
            cm("Icy Wind", "ice", 45, "❄️"),
            cm("Scald", "water", 55, "💧")
        )),
        PvPokeEntry("walrein", "Walrein", fm("Powder Snow", "ice", 8, 2), listOf(
            cm("Icicle Spear", "ice", 40, "❄️"),
            cm("Earthquake", "ground", 65, "⛰️")
        )),
        PvPokeEntry("abomasnow", "Abomasnow", fm("Powder Snow", "ice", 8, 2), listOf(
            cm("Weather Ball", "ice", 35, "❄️"),
            cm("Energy Ball", "grass", 55, "🌿")
        )),
        PvPokeEntry("altaria", "Altaria", fm("Dragon Breath", "dragon", 3, 1), listOf(
            cm("Sky Attack", "flying", 55, "🦅"),
            cm("Moonblast", "fairy", 60, "✨")
        )),
        PvPokeEntry("pidgeot", "Pidgeot", fm("Wing Attack", "flying", 8, 2), listOf(
            cm("Feather Dance", "flying", 50, "🦅"),
            cm("Brave Bird", "flying", 55, "🦅")
        )),
        PvPokeEntry("vigoroth", "Vigoroth", fm("Counter", "fighting", 6, 2), listOf(
            cm("Body Slam", "normal", 35, "⭐"),
            cm("Rock Slide", "rock", 45, "🪨")
        )),
        PvPokeEntry("obstagoon", "Obstagoon", fm("Counter", "fighting", 6, 2), listOf(
            cm("Night Slash", "dark", 35, "🌑"),
            cm("Cross Chop", "fighting", 35, "🥊")
        )),
        PvPokeEntry("scrafty", "Scrafty", fm("Counter", "fighting", 6, 2), listOf(
            cm("Power-Up Punch", "fighting", 35, "🥊"),
            cm("Foul Play", "dark", 45, "🌑")
        )),
        PvPokeEntry("registeel", "Registeel", fm("Lock On", "normal", 5, 1), listOf(
            cm("Focus Blast", "fighting", 75, "🥊"),
            cm("Zap Cannon", "electric", 80, "⚡")
        )),
        PvPokeEntry("stunfisk", "Stunfisk", fm("Mud Shot", "ground", 9, 2), listOf(
            cm("Rock Slide", "rock", 45, "🪨"),
            cm("Earthquake", "ground", 65, "⛰️")
        )),
        PvPokeEntry("gligar", "Gligar", fm("Wing Attack", "flying", 8, 2), listOf(
            cm("Aerial Ace", "flying", 40, "🦅"),
            cm("Dig", "ground", 50, "⛰️")
        )),
        PvPokeEntry("pelipper", "Pelipper", fm("Wing Attack", "flying", 8, 2), listOf(
            cm("Weather Ball", "water", 35, "💧"),
            cm("Hurricane", "flying", 65, "🦅")
        )),
        PvPokeEntry("empoleon", "Empoleon", fm("Steel Wing", "steel", 6, 2), listOf(
            cm("Hydro Cannon", "water", 40, "💧"),
            cm("Drill Peck", "flying", 40, "🦅")
        )),
        PvPokeEntry("nidoqueen", "Nidoqueen", fm("Poison Jab", "poison", 7, 2), listOf(
            cm("Poison Fang", "poison", 40, "☠️"),
            cm("Earth Power", "ground", 55, "⛰️")
        )),
        PvPokeEntry("gengar", "Gengar", fm("Shadow Claw", "ghost", 8, 2), listOf(
            cm("Shadow Punch", "ghost", 35, "👻"),
            cm("Shadow Ball", "ghost", 55, "👻")
        ))
    )

    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = i - 1
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev else 1 + min(prev, min(dp[j], dp[j - 1]))
                prev = temp
            }
        }
        return dp[b.length]
    }

    /**
     * Parses the Top-Right Opponent HUD text (e.g. "CP 4163 Entei") and returns the matched
     * PvPokeEntry, or creates a dynamic entry if the Pokémon is an unlisted species.
     */
    fun matchTopRightOpponent(topRightOcrText: String): PvPokeEntry? {
        if (topRightOcrText.isBlank()) return null

        // Clean out "CP", numbers, and symbols to isolate the Pokémon name in the top-right box
        val words = topRightOcrText
            .replace(Regex("(?i)\bcp\b"), " ")
            .replace(Regex("[^a-zA-Z\-']"), " ")
            .split(Regex("\s+"))
            .map { it.trim() }
            .filter { it.length >= 3 }

        if (words.isEmpty()) return null

        // 1. Exact substring match against our PvPoke database
        val joinedLower = words.joinToString(" ").lowercase()
        for (entry in META_POKEMON) {
            if (joinedLower.contains(entry.name.lowercase())) {
                return entry
            }
        }

        // 2. Fuzzy Levenshtein match (handles OCR reading 'Entel' for 'Entei' or 'Azumari1l' for 'Azumarill')
        for (word in words) {
            val wLow = word.lowercase()
            var bestEntry: PvPokeEntry? = null
            var bestDist = 2
            for (entry in META_POKEMON) {
                val dist = levenshtein(wLow, entry.name.lowercase())
                if (dist <= 1 && dist < bestDist) {
                    bestDist = dist
                    bestEntry = entry
                }
            }
            if (bestEntry != null) return bestEntry
        }

        // 3. Dynamic Fallback if "CP" was explicitly seen in the top-right HUD box for an unlisted Pokémon
        if (topRightOcrText.contains("CP", ignoreCase = true)) {
            val detectedName = words.last()
            if (detectedName.length >= 4) {
                return PvPokeEntry(
                    id = "dyn_${detectedName.lowercase()}",
                    name = detectedName,
                    fastMove = fm("Fast Move", "normal", 8, 2),
                    chargedMoves = listOf(
                        cm("Charged 1 (40E)", "normal", 40, "⚡"),
                        cm("Charged 2 (55E)", "normal", 55, "💥")
                    )
                )
            }
        }
        return null
    }

    fun matchChargedMoveUsed(bannerOcrText: String, entry: PvPokeEntry): ChargedMove? {
        val normalized = bannerOcrText.lowercase()
        if (!normalized.contains("used") && !normalized.contains("incoming")) return null
        return entry.chargedMoves.firstOrNull { normalized.contains(it.name.lowercase()) }
            ?: if (normalized.contains("used")) entry.chargedMoves.firstOrNull() else null
    }
}
