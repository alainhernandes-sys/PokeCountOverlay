package com.pokecount.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(64, 120, 64, 64)
            setBackgroundColor(0xFF090D16.toInt())
        }

        val title = TextView(this).apply {
            text = "PokéCount Stealth v3"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "• Ultra-discreet see-through smoke glass overlay\n• Scans strictly the Top-Right Opponent box (e.g. Entei)\n• Tap ◐ on the overlay to adjust opacity live\n• Tap the Fast Move number circle to collapse/expand"
            textSize = 15f
            setTextColor(0xFF94A3B8.toInt())
            setPadding(0, 36, 0, 72)
        }

        val btnBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 32f
            setColor(0xFF10B981.toInt())
        }

        val startOverlayBtn = Button(this).apply {
            text = "START STEALTH OVERLAY"
            textSize = 17f
            background = btnBg
            setTextColor(0xFF052E16.toInt())
            setPadding(72, 36, 72, 36)
            setOnClickListener {
                ensureOverlayPermissionAndStart()
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(startOverlayBtn)
        setContentView(root)
    }

    private fun ensureOverlayPermissionAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY_PERMISSION)
            return
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY_PERMISSION && Settings.canDrawOverlays(this)) {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION)
        } else if (requestCode == REQ_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, OverlayVisionService::class.java).apply {
                putExtra(OverlayVisionService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OverlayVisionService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(serviceIntent)
            moveTaskToBack(true)
        }
    }

    companion object {
        private const val REQ_OVERLAY_PERMISSION = 1001
        private const val REQ_MEDIA_PROJECTION = 1002
    }
}
