package com.pokecount.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class OverlayVisionService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayRoot: LinearLayout
    private lateinit var countCircleView: TextView
    private lateinit var detailsPanel: LinearLayout
    private lateinit var pokemonTitleText: TextView
    private lateinit var opacityToggleBtn: TextView
    private lateinit var chargedBadgesContainer: LinearLayout

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val slotEnergies = mutableMapOf<String, Int>()
    private var currentPokemon: PvPokeEntry = PvPokeRepository.META_POKEMON.first()
    private var battleActiveOnScreen = false
    private var turnElapsedMs = 0L
    private var chargedPauseMs = 0L
    private var lastSubtractedMoveTimestamp = 0L
    private var overlayInitialized = false

    // 3 Stealth Opacity Presets: 0 = Ghost Stealth (26% alpha), 1 = Ultra-Ghost (16% alpha), 2 = Soft Smoke (48% alpha)
    private var stealthPresetIndex = 0
    private val bgAlphas = intArrayOf(0x42000000, 0x28000000, 0x7A090D16)
    private val borderAlphas = intArrayOf(0x38FFFFFF, 0x22FFFFFF, 0x5594A3B8)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, createNotification())
        }

        if (!overlayInitialized) {
            overlayInitialized = true
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            createFloatingOverlayHud()
            startTurnClockAndOcrLoop()
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode != -1 && resultData != null && mediaProjection == null) {
            setupMediaProjection(resultCode, resultData)
        }
        return START_STICKY
    }

    private fun createFloatingOverlayHud() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 240
        }

        overlayRoot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 8)
        }

        // Discreet See-Through Smoke-Glass Card
        detailsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 12)
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        pokemonTitleText = TextView(this).apply {
            text = "Waiting for battle..."
            textSize = 11f
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(0xCCFFFFFF.toInt())
            // Tap title to reset current Pokémon energy to 0
            setOnClickListener {
                slotEnergies[currentPokemon.id] = 0
                turnElapsedMs = 0L
                refreshHudDisplay()
            }
        }

        opacityToggleBtn = TextView(this).apply {
            text = "  ◐  "
            textSize = 12f
            setTextColor(0xAAFFFFFF.toInt())
            setOnClickListener {
                stealthPresetIndex = (stealthPresetIndex + 1) % bgAlphas.size
                applyStealthTheme()
                refreshHudDisplay()
            }
        }

        headerRow.addView(pokemonTitleText)
        headerRow.addView(opacityToggleBtn)

        val scrollRow = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }

        chargedBadgesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 6, 0, 0)
        }
        scrollRow.addView(chargedBadgesContainer)

        detailsPanel.addView(headerRow)
        detailsPanel.addView(scrollRow)

        // Compact, Discreet Smoked-Glass Fast Move Counter Circle (replaces distracting bright orange ball)
        countCircleView = TextView(this).apply {
            text = "0"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xEEFFFFFF.toInt())
            width = 96
            height = 96
            setOnClickListener {
                detailsPanel.visibility = if (detailsPanel.visibility == View.VISIBLE) {
                    View.GONE
                } else {
                    View.VISIBLE
                }
            }
        }

        val circleLp = LinearLayout.LayoutParams(96, 96).apply {
            marginStart = 10
        }

        overlayRoot.addView(detailsPanel)
        overlayRoot.addView(countCircleView, circleLp)

        applyStealthTheme()

        // Drag handler on the Fast Move Counter Circle
        countCircleView.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        params.x = initialX - dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(overlayRoot, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(overlayRoot, params)
        refreshHudDisplay()
    }

    private fun applyStealthTheme() {
        val bgColor = bgAlphas[stealthPresetIndex]
        val strokeColor = borderAlphas[stealthPresetIndex]

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 24f
            setColor(bgColor)
            setStroke(2, strokeColor)
        }
        detailsPanel.background = panelBg

        val circleDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(bgColor)
            setStroke(3, 0x8834D399.toInt())
        }
        countCircleView.background = circleDrawable
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)
        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "PokeCountCapture",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            mainHandler
        )
    }

    private fun startTurnClockAndOcrLoop() {
        val tickMs = 250L
        mainHandler.post(object : Runnable {
            override fun run() {
                processFrameWithOcr()

                if (chargedPauseMs > 0) {
                    chargedPauseMs = max(0L, chargedPauseMs - tickMs)
                } else if (battleActiveOnScreen) {
                    turnElapsedMs += tickMs
                    val moveDurationMs = currentPokemon.fastMove.turns * 500L
                    if (turnElapsedMs >= moveDurationMs) {
                        turnElapsedMs = 0L
                        val prevE = slotEnergies[currentPokemon.id] ?: 0
                        slotEnergies[currentPokemon.id] = min(100, prevE + currentPokemon.fastMove.energyGain)
                        refreshHudDisplay()
                    }
                }
                mainHandler.postDelayed(this, tickMs)
            }
        })
    }

    private fun processFrameWithOcr() {
        val image = imageReader?.acquireLatestImage() ?: return
        try {
            val plane = image.planes[0]
            val width = image.width
            val height = image.height
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width

            val bitmap = Bitmap.createBitmap(
                width + rowPadding / pixelStride,
                height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(plane.buffer)

            // 1. CROP STRICTLY THE TOP-RIGHT OPPONENT NAMEPLATE BOX (x: 54%..99%, y: 1%..10%)
            // In Pokémon GO battles (like "CP 4163 Entei"), the opponent's name is ALWAYS in this top-right box.
            // This avoids reading your left-side Pokémon ("Haxorus") and avoids reading the overlay itself!
            val rightX = (width * 0.54f).toInt()
            val rightW = max(1, width - rightX - 4)
            val topY = (height * 0.01f).toInt()
            val topH = max(1, (height * 0.095f).toInt())

            val topRightOpponentCrop = Bitmap.createBitmap(bitmap, rightX, topY, rightW, topH)

            recognizer.process(InputImage.fromBitmap(topRightOpponentCrop, 0))
                .addOnSuccessListener { visionText ->
                    val rawTopRight = visionText.text
                    val matchedPoke = PvPokeRepository.matchTopRightOpponent(rawTopRight)
                    if (matchedPoke != null) {
                        battleActiveOnScreen = true
                        if (matchedPoke.id != currentPokemon.id) {
                            currentPokemon = matchedPoke
                            turnElapsedMs = 0L
                            refreshHudDisplay()
                        }
                    } else if (rawTopRight.isBlank()) {
                        // Not currently in a battle screen
                        battleActiveOnScreen = false
                    }
                }

            // 2. CROP BATTLE ANNOUNCEMENT REGION FOR CHARGED MOVE SUBTRACTION (y: 18%..55%)
            val midY = (height * 0.18f).toInt()
            val midH = max(1, (height * 0.36f).toInt())
            val midCrop = Bitmap.createBitmap(bitmap, 0, midY, width, midH)

            recognizer.process(InputImage.fromBitmap(midCrop, 0))
                .addOnSuccessListener { visionText ->
                    val rawBanner = visionText.text
                    val now = System.currentTimeMillis()
                    if (now - lastSubtractedMoveTimestamp > 4500L) {
                        val usedMove = PvPokeRepository.matchChargedMoveUsed(rawBanner, currentPokemon)
                        if (usedMove != null) {
                            lastSubtractedMoveTimestamp = now
                            chargedPauseMs = 9500L
                            val currentE = slotEnergies[currentPokemon.id] ?: 0
                            slotEnergies[currentPokemon.id] = max(0, currentE - usedMove.energyCost)
                            refreshHudDisplay()
                        }
                    }
                }
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun refreshHudDisplay() {
        val energy = slotEnergies[currentPokemon.id] ?: 0
        val eFast = currentPokemon.fastMove.energyGain
        val fastCount = floor(energy.toDouble() / eFast).toInt()

        countCircleView.text = fastCount.toString()
        pokemonTitleText.text = "${currentPokemon.name} · ${currentPokemon.fastMove.name} (${fastCount} mv / ${energy}E)"

        chargedBadgesContainer.removeAllViews()
        currentPokemon.chargedMoves.forEach { cm ->
            val isReady = energy >= cm.energyCost
            val neededMoves = ceil(max(0, cm.energyCost - energy).toDouble() / eFast).toInt()

            // Ultra-subtle translucent pill background
            val pillFill = if (isReady) 0x5510B981 else 0x331E293B
            val pillStroke = if (isReady) 0xAA34D399.toInt() else 0x4494A3B8

            val badgeBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16f
                setColor(pillFill)
                setStroke(2, pillStroke)
            }

            val badge = TextView(this).apply {
                background = badgeBg
                setPadding(14, 6, 14, 6)
                textSize = 10.5f
                setSingleLine(true)
                setTextColor(if (isReady) 0xFFA7F3D0.toInt() else 0xCCFFFFFF.toInt())
                text = if (isReady) "${cm.icon} ${cm.name} ✓" else "${cm.icon} ${cm.name} -$neededMoves"
                setOnClickListener {
                    val curE = slotEnergies[currentPokemon.id] ?: 0
                    slotEnergies[currentPokemon.id] = max(0, curE - cm.energyCost)
                    refreshHudDisplay()
                }
            }

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = 8
            }
            chargedBadgesContainer.addView(badge, lp)
        }
    }

    private fun createNotification(): Notification {
        val channelId = "pokecount_overlay_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "PokéCount Stealth Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("PokéCount Stealth Overlay Active")
            .setContentText("Scanning top-right opponent HUD")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        mediaProjection?.stop()
        if (overlayInitialized && ::overlayRoot.isInitialized) {
            windowManager.removeView(overlayRoot)
        }
    }

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }
}
